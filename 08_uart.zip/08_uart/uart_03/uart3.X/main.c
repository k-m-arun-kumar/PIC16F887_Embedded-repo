/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    :  a preset PIN and account number is set by default in code. Account and PIN datas are fed by virtual terminal using keyboard. 
UART is used for communication between virtual terminal and PIC. UART flow control and parity error check are not implemented.
Overrun error and Frame error check has been implemented. 
Timeout for long pressed key and no key press is not required. 
Entered password in keypad is displayed in  LCD. Use RESET_SW to reset Process, if any problem arises and start afresh. 
USe enter key in keyboard to end input and entered data is at end.

  At first Welcome message to be displayed, when ACCOUNT_SW is pressed, account number is entered.
If entered account number is correct, then ask for PIN  and if entered PIN is correct,
then display Next stage. If account number is incorrect and ask to reenter account number.
After 3 failed iteration on entered account number, stop reenter of account number and display visit bank. 
If no key is pressed for longer duration or key has been pressed for long duration, display timeout and display visit bank.
After 3 failed iteration on entered PIN number, stop reenter of PIN number and display visit bank.
After displayed auth status, then wait for predetermined time(AUTH STATUS DISPLAY TIME DURATION), and then 
 display welcome message and wait for ACCOUNT_SW to be pressed to enter account number.
After that RESET_SW is pressed to restart the process, if any problem arises. 
Timer1 (executes time to wait from displayed auth status to display welcome message ) with status check. 
                     									 
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : When fast operation on backspace or input data is done on cur input data, then program got stuck, in UART , 
                        due to no implementation of XON & XOFF software flow control and fix issue of getting OERR error when fast pressed backspace key.     

NOTE                  :  Code with base from PIC16F887-repo->04_lcd->lcd_14->lcd14.c.           								
                        
                       
CHANGE LOGS           : 

*****************************************************************************/
 // PIC16F887 Configuration Bit Settings
// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.
// 'C' source line config statements

// CONFIG1
//#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
#pragma config FOSC = HS        // Oscillator Selection bits (HS oscillator: High-speed crystal/resonator on RA6/OSC2/CLKOUT and RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = ON       // Power-up Timer Enable bit (PWRT enabled)
#pragma config MCLRE = ON       // RE3/MCLR pin function select bit (RE3/MCLR pin function is MCLR)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = ON        // Internal External Switchover bit (Internal/External Switchover mode is enabled)
#pragma config FCMEN = ON       // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is enabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off) 

#include "main.h"
#include "port.h"
#include "io_conf.h"
#include "appl_conf.h"
#include "uart.h"
#include "lcd.h"
#include "timer.h"
#include "string.h"

#define ENTER_KEY_PLAIN_DISP_FORMAT    (1)
#define ENTER_KEY_HIDDEN_DISP_FORMAT   (2) 

#define ANY_DATA_DISP                 (1)
#define BLANK_LINE_DISP               (2)
#define NO_KEY_PRESS_TIMEOUT_DISP     (3)   
#define LONG_PRESS_TIMEOUT_DISP       (4)     
#define AUTH_PROCESS_TIMEOUT_DISP     (5) 
#define SET_PIN_TIMEOUT_DISP          (6)
#define AUTH_STATUS_DISP              (7)  
#define ERROR_DISP                    (8)
#define WARNING_DISP                  (9)
#define FATAL_DISP                    (10) 

#define ACCOUNT_SW_CODE               ('A')
#define RESET_SW_CODE                 ('R') 
#define HIDDEN_KEY_DISP_CHAR          ('X')

enum auth_fsm {INITIAL_AUTH_FSM =0 , ACCOUNT_FSM, PIN_FSM, AUTH_SUCCESS_FSM};
enum status_fsm {INITIAL_DISP_FSM = 0,INVALID_ACCOUNT_DISP_FSM,INVALID_PIN_DISP_FSM, AUTH_SUCCESS_DISP_FSM};

value_types to_disp;

char keypad_char[]   = {'1','2', '3', '4', '5', '6','7','8','9','*', '0', '#'};
const char default_account[] = {"56789"};       
const char enter_account_msg_disp[] =  {"Enter Account"},enter_pin_msg_disp[] = {"Enter PIN"}, default_pin[] = "1234";
const char auth_success_msg_disp[] = "Successful Auth", incorrect_auth_msg_disp[] = "Visit Bank";
const char reenter_acc_msg_disp[]= "Reenter Account",reenter_pin_msg_disp[] = "Reenter PIN";   
const char max_acc_try_msg_disp[]=  "Max Acc Exceed", max_pin_try_msg_disp[] = {"Max PIN Exceed"};
/*line_blank_disp[] num of blank spaces = max nums of chars in a line in a lcd and start loc is begin loc of that line */
const char welcome_msg_disp[] = "Welcome";   
 
char can_lcd_disp_flag = STATE_YES_IN_CHAR, key_or_sw_input_enable_flag = STATE_YES_IN_CHAR, max_input_num_chars_flag = STATE_NO_IN_CHAR, cur_data_echo_inputkey_inlcd = STATE_YES_IN_CHAR, uart_rcv_enable_flag = STATE_NO_IN_CHAR, \
 disp_status_flag = STATE_NO_IN_CHAR, need_input_flag = STATE_NO_IN_CHAR, lcd_avail_loc_within_limit = STATE_YES_IN_CHAR, reset_sw_enable_flag = STATE_NO_IN_CHAR, account_sw_enable_flag = STATE_YES_IN_CHAR, enter_or_backspace_enable_flag = STATE_NO_IN_CHAR ;

unsigned int num_chars_entered_cur_data = 0; 
char entered_cur_input_data[MAX_NUM_CHARS_INPUT_DATA + 1], cur_pressed_key_or_sw = '\0' ;
unsigned int count_cur_input_data_try = 0, count_long_press_key_timeout = 0, max_num_cur_data_input_try = 0; 
enum auth_fsm auth_fsm_state = INITIAL_AUTH_FSM; 
enum status_fsm status_disp_fsm =INITIAL_DISP_FSM;  
 
 /* currently displayed data in each line starts from 1 ie use array index as line num for us. index 0 can be used as all lines */
unsigned int cur_line_disp_data[] = {ANY_DATA_DISP, ANY_DATA_DISP, ANY_DATA_DISP, BLANK_LINE_DISP, BLANK_LINE_DISP};
 
unsigned int time_left_welcome_disp = REQ_TIMEOUT_WELCOME_MSG_DISP_IN_SEC;
 
unsigned int cur_data_enterchar_disp_format =  ENTER_KEY_PLAIN_DISP_FORMAT ;

void Reset_Process();
void Timer1_Tick();
void Welcome_Disp_Timeout_Occurs();
void Disp_Status_Fsm();
void Auth_Fsm_Proc();
void After_Key_Stoke_Proc(const char pressed_key);
void After_Switch_Stoke_Proc(const char pressed_key);
void Entered_Key_No_Long_Press_Proc(const char pressed_key);
void Entered_Backspace_Sw_No_Long_Press_Proc();
void Enter_Cur_Data_Proc();
void Auth_Proc();
void Is_Numchars_Within_Limit();
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void main()
{
		
     ACCOUNT_SW_TRIS = 1;
     RESET_SW_TRIS = 1;  

   /* to leave T1G pin in portb as input to PIC ie RB5 = 1 in TRISB  to run timer 1, if timer1 conf ie T1CON = (0xC5) was set run timer1. 
        if T1G pin in portb is 0 ie RB5 = 0	in TRISB, even if timer1 is conf ie T1CON = (0xC5) was set to run timer1, timer1 will not run.
        T1G pin is input to PIC to control run Timer1, if gate control for Timer 1 to run is enabled. 
		If T1CON = (0x85),  gate control for Timer 1 is disabled, so T1G pin can have used for other purpose */
	  
      ANSEL = 0x00;
      ANSELH = 0x00;
	  
	  UART_Init();
      LCD_Init();
	  Reset_Process();
      while(1)
      {  
          if(key_or_sw_input_enable_flag == STATE_YES_IN_CHAR)
          { 
                      				  
	           if(uart_rcv_enable_flag == STATE_YES_IN_CHAR  )
               {
	             	Enter_Cur_Data_Proc();	 
    			    
		            // received char is carriage return or enter key and Process for Enter key stroke
					if(num_chars_entered_cur_data)
					{
		               entered_cur_input_data[num_chars_entered_cur_data ] = '\0';		               		               
			           reset_sw_enable_flag = STATE_YES_IN_CHAR;
                       Auth_Fsm_Proc(); 
                       memset(entered_cur_input_data, '\0', sizeof(entered_cur_input_data)/sizeof(char));
                       num_chars_entered_cur_data = 0;
					}
                    else
					{
						// warning enter key pressed before any data is entered ie num_chars_entered_cur_data = 0
                       Enter_Cur_Data_Proc();
					}					   
               }    
               if(account_sw_enable_flag == STATE_YES_IN_CHAR && ACCOUNT_SW ==KEY_PRESSED )		 
               {
				   __delay_ms(50);
				   if(ACCOUNT_SW ==KEY_PRESSED)
				   {
					   while(ACCOUNT_SW ==KEY_PRESSED);
                       cur_pressed_key_or_sw = ACCOUNT_SW_CODE;//latest pressed key/switch  
                       After_Switch_Stoke_Proc(cur_pressed_key_or_sw);                             				  
                   } 
               }						
			   if(status_disp_fsm != INITIAL_DISP_FSM && cur_line_disp_data[ALL_LINES] == ANY_DATA_DISP )
               { 
	  	           Disp_Status_Fsm(); 
		           cur_line_disp_data[ALL_LINES] = AUTH_STATUS_DISP; 
                   time_left_welcome_disp = REQ_TIMEOUT_WELCOME_MSG_DISP_IN_SEC;
                   Timer1_Run(TMR1_WELCOME_DISP_STATE, REQ_TIMEOUT_WELCOME_MSG_DISP_IN_SEC * TIME_UNIT_1_SEC_IN_MILLI_SEC);                        				 
			    }
               while(status_disp_fsm != INITIAL_DISP_FSM)
			   {
				    Timer1_Tick();				 
			   }
               if(reset_sw_enable_flag == STATE_YES_IN_CHAR && RESET_SW == KEY_PRESSED )
               {
			        __delay_ms(50);
			       if(RESET_SW ==KEY_PRESSED)
			       {
				       while( RESET_SW ==KEY_PRESSED);
	                   cur_pressed_key_or_sw = RESET_SW_CODE;//latest pressed key/switch
			           After_Switch_Stoke_Proc(cur_pressed_key_or_sw);
                   }
	           }			   
          } 
	 } 		 
}
  
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 3   
-*------------------------------------------------------------*/
void Reset_Process()
{
  
  max_input_num_chars_flag = STATE_NO_IN_CHAR;   
   
  auth_fsm_state = INITIAL_AUTH_FSM;
  status_disp_fsm =INITIAL_DISP_FSM;
  
  memset(entered_cur_input_data, '\0', sizeof(entered_cur_input_data)/sizeof(char));
  num_chars_entered_cur_data = 0; 
 
  disp_status_flag = STATE_NO_IN_CHAR;  
  need_input_flag = STATE_NO_IN_CHAR; 
   
  count_cur_input_data_try = 0;
  can_lcd_disp_flag = STATE_YES_IN_CHAR;
  key_or_sw_input_enable_flag =STATE_YES_IN_CHAR;
    
  lcd_avail_loc_within_limit = STATE_YES_IN_CHAR;
  Timer1_Stop();  
  reset_sw_enable_flag = STATE_NO_IN_CHAR;
  account_sw_enable_flag = STATE_YES_IN_CHAR;
  uart_rcv_enable_flag = STATE_NO_IN_CHAR;
  enter_or_backspace_enable_flag = STATE_NO_IN_CHAR;
  
  Set_Cur_Loc_LCD(STATE_YES_IN_CHAR, ACCOUNT_ENTRY_START_LOC,STATE_YES_IN_CHAR, ACCOUNT_MSG_START_LOC ); 
  LCD_Clear_Screen(); //clear display
  Write_LCD_Command(0x0C); // display on , cursor and blinking OFF
  
  Goto_XY_LCD_Disp(WELCOME_MSG_LINE_NUM, WELCOME_MSG_START_COL_NUM);
  LCD_Disp_Str(welcome_msg_disp);  
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 4  
-*------------------------------------------------------------*/
void After_Key_Stoke_Proc(const char key_data)
{
   Entered_Key_No_Long_Press_Proc(key_data);
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 5   
-*------------------------------------------------------------*/  
void After_Switch_Stoke_Proc(const char pressed_sw)
{
	 switch(pressed_sw)
	 {
		case ACCOUNT_SW_CODE:
		   LCD_Clear_Screen(); //clear display
		   auth_fsm_state = ACCOUNT_FSM;
		   Goto_XY_LCD_Disp(ACCOUNT_MSG_LINE_NUM, ACCOUNT_MSG_START_COL_NUM);
           LCD_Disp_Str(enter_account_msg_disp);
           #if( NUM_CHARS_INPUTDATA == GIVEN_CHARS_MAX_CONFIG_LINES_AND_COLS)
              Cur_Input_Data_ByNumChars_Calc_Para(ACCOUNT_ENTRY_START_LINE_NUM, ACCOUNT_ENTRY_START_COL_NUM, MAX_ACCOUNT_NUM_CHARS);
           #elif(NUM_CHARS_INPUTDATA == GIVEN_XY_MAX_CONFIG_LINES_AND_COLS)
              /* ACCOUNT INPUT DATA max num of input account chars = num of chars from start pos (entry start line, entry start col) till end of that line */  
              Cur_Input_Data_ByXY_Calc_Para(ACCOUNT_ENTRY_START_LINE_NUM, ACCOUNT_ENTRY_START_COL_NUM, ACCOUNT_ENTRY_START_LINE_NUM + 1, NUM_COL1 );
           #else 
               /*NUM_CHARS_INPUTDATA = GIVEN_CHARS_MAX_XY */
               /* ACCOUNT INPUT DATA's max num of input account chars = min(num of chars from start pos (entry start line, entry start col) till end of that line, MAX_ACCOUNT_NUM_CHARS ) */ 
              Cur_Input_Data_ByCharsXY_Calc_Para(ACCOUNT_ENTRY_START_LINE_NUM, ACCOUNT_ENTRY_START_COL_NUM, MAX_ACCOUNT_NUM_CHARS, ACCOUNT_ENTRY_START_LINE_NUM + 1 , NUM_COL1); 
            #endif
			Goto_XY_LCD_Input(ACCOUNT_ENTRY_START_LINE_NUM, ACCOUNT_ENTRY_START_COL_NUM); 
            Write_LCD_Command(0x0E);
			count_cur_input_data_try = 0;
            max_num_cur_data_input_try= MAX_NUM_ACC_DATA_INPUT_TRY;
            cur_data_echo_inputkey_inlcd = STATE_YES_IN_CHAR;
            cur_data_enterchar_disp_format =  ENTER_KEY_PLAIN_DISP_FORMAT ;
            account_sw_enable_flag = STATE_NO_IN_CHAR;
			uart_rcv_enable_flag = STATE_YES_IN_CHAR;
			need_input_flag = STATE_YES_IN_CHAR;
        break;
        case RESET_SW_CODE:
		 /* process for reset sw operations when within long press timeout error occurs, reset sw is released */
            Reset_Process();
		    reset_sw_enable_flag = STATE_NO_IN_CHAR;
            break;	   
	 }
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 8   
-*------------------------------------------------------------*/
void Auth_Fsm_Proc()
{
    switch(auth_fsm_state)
    {
       case ACCOUNT_FSM: 
	      if(++count_cur_input_data_try <= max_num_cur_data_input_try)
          {
		       LCD_Clear_Screen(); //clear display
		 
              if(strcmp(entered_cur_input_data,default_account)== 0)
              {
			       /* start up for PIN_FSM to get pin data */
			       Goto_XY_LCD_Disp(PIN_MSG_LINE_NUM, NUM_COL1 );
			       LCD_Disp_Str(enter_pin_msg_disp);
                   auth_fsm_state = PIN_FSM;
			       #if (NUM_CHARS_INPUTDATA == GIVEN_CHARS_MAX_CONFIG_LINES_AND_COLS)
			          Cur_Input_Data_ByNumChars_Calc_Para(PIN_ENTRY_START_LINE_NUM, PIN_ENTRY_START_COL_NUM, MAX_PIN_NUM_CHARS);
			       #elif (NUM_CHARS_INPUTDATA == GIVEN_XY_MAX_CONFIG_LINES_AND_COLS)
			       /* PIN INPUT DATA max num of input pin chars = num of chars from start pos (entry start line, entry start col) till end of that line */ 	
			          Cur_Input_Data_ByXY_Calc_Para(PIN_ENTRY_START_LINE_NUM, PIN_ENTRY_START_COL_NUM, PIN_ENTRY_START_LINE_NUM + 1, NUM_COL1);
		           #else
                      /*	(NUM_CHARS_INPUTDATA = GIVEN_CHARS_MAX_XY)*/
		             /* PIN INPUT DATA max num of input pin chars =  min(num of chars from start pos (entry start line, entry start col) till end of that line, MAX_PIN_NUM_CHARS) */ 
			         Cur_Input_Data_ByCharsXY_Calc_Para(PIN_ENTRY_START_LINE_NUM, PIN_ENTRY_START_COL_NUM, MAX_PIN_NUM_CHARS,PIN_ENTRY_START_LINE_NUM + 1, NUM_COL1 );	
			       #endif
			       Goto_XY_LCD_Input(PIN_ENTRY_START_LINE_NUM, PIN_ENTRY_START_COL_NUM);	
		           cur_data_echo_inputkey_inlcd = STATE_YES_IN_CHAR;
			       cur_data_enterchar_disp_format = ENTER_KEY_HIDDEN_DISP_FORMAT ;
			       count_cur_input_data_try = 0;
                   Write_LCD_Command(0x0E); // insert cursor on at cur_input_lcd_loc
		           max_num_cur_data_input_try = MAX_NUM_PIN_DATA_INPUT_TRY;                                                                    
               } 
               else
               {
		    	 if(count_cur_input_data_try <= max_num_cur_data_input_try - 1)
			     {	 
			        Goto_XY_LCD_Disp(ACCOUNT_MSG_LINE_NUM, ACCOUNT_MSG_START_COL_NUM );
                    LCD_Disp_Str(reenter_acc_msg_disp);				
                    Goto_XY_LCD_Input(ACCOUNT_ENTRY_START_LINE_NUM, ACCOUNT_ENTRY_START_COL_NUM);
                    Write_LCD_Command(0x0E); // insert cursor on at cur_input_lcd_loc		       
			     }
                 else
                 {
				     status_disp_fsm = INVALID_ACCOUNT_DISP_FSM;
		             disp_status_flag = STATE_YES_IN_CHAR;               		
			     }     				
              }
	      }
          else	
          {
		      status_disp_fsm = INVALID_ACCOUNT_DISP_FSM;
		      disp_status_flag = STATE_YES_IN_CHAR;                      
	      }		   
       break;
       case  PIN_FSM:
	     if(++count_cur_input_data_try <= max_num_cur_data_input_try)
         {
            LCD_Clear_Screen(); //clear display
            if(strcmp(entered_cur_input_data,default_pin)== 0)
            {
				 /* start up for AUTH_SUCCESS_FSM  */
               count_cur_input_data_try = 0;
               auth_fsm_state = AUTH_SUCCESS_FSM;
			   cur_data_echo_inputkey_inlcd = STATE_YES_IN_CHAR;
			   cur_data_enterchar_disp_format = ENTER_KEY_PLAIN_DISP_FORMAT ;
               status_disp_fsm = AUTH_SUCCESS_DISP_FSM;
			   /* Update  use Cur_Input_Data_Set_Parameters()	to next data input's max and min loc parameters to be entered, if any in AUTH_SUCCESS_FSM */
			    disp_status_flag = STATE_YES_IN_CHAR;              			   
            } 
            else
            {
				if(count_cur_input_data_try <= max_num_cur_data_input_try - 1)
			    {
			      Goto_XY_LCD_Disp(PIN_MSG_LINE_NUM, NUM_COL1 );
                  LCD_Disp_Str(reenter_pin_msg_disp);				  
                  Goto_XY_LCD_Input(PIN_ENTRY_START_LINE_NUM,NUM_COL1);
                  Write_LCD_Command(0x0E); // insert cursor on at cur_input_lcd_loc		         
			    }
                else
                {
				    status_disp_fsm = INVALID_PIN_DISP_FSM; 
			        disp_status_flag = STATE_YES_IN_CHAR;   	
                }				
            }
		  }
		  else
		  {
			  status_disp_fsm = INVALID_PIN_DISP_FSM; 
			  disp_status_flag = STATE_YES_IN_CHAR;             
          }			  
       break; 
       case  AUTH_SUCCESS_FSM:	     
       break; 
    }    
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 9  
-*------------------------------------------------------------*/
void Disp_Status_Fsm()
{
	if(can_lcd_disp_flag == STATE_YES_IN_CHAR)
    {	

	   LCD_Clear_Screen(); //clear display  
	   Write_LCD_Command(0x0C);
	   
	   switch(status_disp_fsm)
       {
          case INVALID_ACCOUNT_DISP_FSM:
		     Goto_XY_LCD_Disp(FAILED_AUTH_REASON_LINE_NUM,NUM_COL1 );
			 LCD_Disp_Str(max_acc_try_msg_disp);
			 
			 Goto_XY_LCD_Disp(FAILED_AUTH_LINE_NUM, NUM_COL1); 
			 LCD_Disp_Str(incorrect_auth_msg_disp);
             break;
         case INVALID_PIN_DISP_FSM:
		     Goto_XY_LCD_Disp(FAILED_AUTH_REASON_LINE_NUM,NUM_COL1 ); 
             LCD_Disp_Str(max_pin_try_msg_disp);		 
             Goto_XY_LCD_Disp(FAILED_AUTH_LINE_NUM, NUM_COL1);
			 LCD_Disp_Str(incorrect_auth_msg_disp);	
             break;	    
         case AUTH_SUCCESS_DISP_FSM:
		    Goto_XY_LCD_Disp(SUCCESS_AUTH_LINE_NUM,NUM_COL1 );
			LCD_Disp_Str(auth_success_msg_disp);
			break; 
         default:
		    /* error: invalid  status_disp_fsm state */
			;
       }  
   }
   /* wait for welcome msg to be displayed */
    uart_rcv_enable_flag = STATE_NO_IN_CHAR; 
	key_or_sw_input_enable_flag = STATE_NO_IN_CHAR; 
    need_input_flag = STATE_NO_IN_CHAR; 
	can_lcd_disp_flag = STATE_NO_IN_CHAR; 	 
} 
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 10  
-*------------------------------------------------------------*/
void Is_Numchars_Within_Limit()
{
 	/* num char < valid char as when num chars <= max valid, and num char == max valid, then you can entry key and 
	and num char  =  max valid + 1, now you cannot input key */	
		
	if(num_chars_entered_cur_data < cur_data_input_max_num_chars_allocated)
        max_input_num_chars_flag = STATE_NO_IN_CHAR;
     else
	 {
        max_input_num_chars_flag = STATE_YES_IN_CHAR; 
		/* warning:  num of input data chars has reached max num of chars allocated for cur input data  */
     }  
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 10  
-*------------------------------------------------------------*/
void Enter_Cur_Data_Proc()
{
	char received_char;
	
    while((received_char = UART_Receive_Char()) != '\r' && received_char != 0)
	{
	    switch(received_char)	
        {
	        case '\b': 
	        /* rcvd char is backspace */
		       Entered_Backspace_Sw_No_Long_Press_Proc();
			break;
			default:  /* valid data keys */
			   Is_Numchars_Within_Limit();
			   if(max_input_num_chars_flag == STATE_NO_IN_CHAR )
			 	   After_Key_Stoke_Proc(received_char);  
		}
		
		/* //SHOULD_REMOVE 
        Goto_XY_LCD_Disp(3, NUM_COL1 + num_chars_entered_cur_data - 1);	
        Write_LCD_Data(received_char);  */	
	}
}	 
/*------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 11  
-*------------------------------------------------------------*/
void Entered_Key_No_Long_Press_Proc(const char key_data)
{
	/* make sure that entered key is within max available lcd loc and line, currently cur_data_input_max_num_chars_allocated 
	 sures that entered key is within max available lcd loc and within max line */
	 unsigned int cur_input_loc_line_num, cur_input_loc_col_num, next_input_loc_line_num, next_input_loc_col_num;
	
   if(cur_data_echo_inputkey_inlcd == STATE_YES_IN_CHAR)
   {
	   Write_LCD_Command(cur_input_lcd_loc);
	  
	    Write_LCD_Command(0x0E);// insert cursor on at cur_input_lcd_loc
	   // Write_LCD_Command(0x0C);
       switch(cur_data_enterchar_disp_format)
       {
         case ENTER_KEY_PLAIN_DISP_FORMAT:
           Write_LCD_Data(key_data);
        break;
        case ENTER_KEY_HIDDEN_DISP_FORMAT:
          Write_LCD_Data(key_data);
		  __delay_ms(REQ_TIME_PLAIN_DISP_IN_HIDDEN_IN_MILLI_SEC);
		  UART_Transmit_Char('\b');
		  UART_Transmit_Char(HIDDEN_KEY_DISP_CHAR);
          Write_LCD_Command(cur_input_lcd_loc); 
          Write_LCD_Data(HIDDEN_KEY_DISP_CHAR);
        break;
		default:
          ;
		  /* error: invalid lcd enter char disp format */		             
      }
	  
	 From_Loc_to_XY_LCD(cur_input_lcd_loc, &cur_input_loc_line_num, &cur_input_loc_col_num);
	 if(cur_input_loc_line_num == CONFIGURE_MAX_NUM_LINES && cur_input_loc_col_num == CONFIGURE_MAX_NUM_COLS)
	 {	 
		/* reached  end of max configured line and valid key is pressed, retain same loc position */ 
		;
	 }
	 else
	 {
		 /* put cur input lcd loc to next location */
		 if(cur_input_loc_col_num == CONFIGURE_MAX_NUM_COLS)
		 {	 
			next_input_loc_line_num = cur_input_loc_line_num + 1;
			next_input_loc_col_num = NUM_COL1;
		 }
         else
         {
			 next_input_loc_line_num = cur_input_loc_line_num;
			 next_input_loc_col_num = cur_input_loc_col_num + 1;
		 }	
		 From_XY_To_Loc_LCD(next_input_loc_line_num, next_input_loc_col_num, &cur_input_lcd_loc);
		 
		 entered_cur_input_data[num_chars_entered_cur_data] =key_data;   
         ++num_chars_entered_cur_data; 
	 }   		 
	  /* keep track of cur_input_lcd_loc as baskspace we need to -- it and also disp timeouts with.
 	  LCD automatically increments due to loc_command(0x06)in our case as after eg Write_LCD_Command(0x80)
	  ie set DDRAM */      
      	     
  }
}     
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 12   
-*------------------------------------------------------------*/
void Entered_Backspace_Sw_No_Long_Press_Proc()
{
	unsigned int cur_input_loc_line_num, cur_input_loc_col_num, previous_input_loc_line_num, previous_input_loc_col_num;
	
	lcd_avail_loc_within_limit = STATE_YES_IN_CHAR;	
       	
    if(num_chars_entered_cur_data > 0 && num_chars_entered_cur_data <= cur_data_input_max_num_chars_allocated )
    {
	    From_Loc_to_XY_LCD(cur_input_lcd_loc, &cur_input_loc_line_num, &cur_input_loc_col_num);
	   if(cur_input_loc_line_num == NUM_LINE1 && cur_input_loc_col_num == NUM_COL1)
	   {	 
		 /* reached begin of line 1 and valid backspace is pressed, retain same loc position */ 
	   }
	   else
	   {
		 /* put cur input lcd loc to one location back from current loc */
		 if(cur_input_loc_col_num == NUM_COL1)
		 {	 
			 previous_input_loc_line_num = cur_input_loc_line_num - 1;
			 previous_input_loc_col_num = CONFIGURE_MAX_NUM_COLS;
		 }
         else
         {
			 previous_input_loc_line_num = cur_input_loc_line_num;
			 previous_input_loc_col_num = cur_input_loc_col_num - 1;
		 }	
		 From_XY_To_Loc_LCD(previous_input_loc_line_num, previous_input_loc_col_num, &cur_input_lcd_loc);
		 
         /* do clear last char operation */
		 entered_cur_input_data[num_chars_entered_cur_data] = '\0'; 
		  /* to get key at previous location */
         Write_LCD_Command(cur_input_lcd_loc);
         --num_chars_entered_cur_data;
         Write_LCD_Data(' '); 
         Write_LCD_Command(0x10); //shift cursor to left  
	  }  
	  Write_LCD_Command(cur_input_lcd_loc);
      Write_LCD_Command(0x0E);	
   }
}    

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 15  
-*------------------------------------------------------------*/
void Timer1_Tick()
{
    //if(timer1_cur_run_state == TMR1_WELCOME_DISP_STATE)
	{
		while(TMR1IF == 0);	
		TMR1IF = 0;
		if(timer1_cur_service_type & 0x02)
	    {
			 //timer1 is in timer mode
		 	  TMR1 = timer1_init_val;             
		      //timer1 overflow for every TIMER1_TICK_IN_MILLI_SEC ie timer1_elapsed_num_overflow_1_update var is incremented for every TIMER1_TICK_IN_MILLI_SEC elapsed
              if(++timer1_elapsed_num_overflow_1_update >= timer1_1_update) 
              {
				  --time_left_welcome_disp;
				  if(++timer1_elapsed_num_update >= timer1_req_time_max_update)
			      {
					 timer1_timeout_occured_flag = STATE_YES_IN_CHAR;
				     Welcome_Disp_Timeout_Occurs(); 
					 timer1_elapsed_num_update = 0;                    
			      }
                 timer1_elapsed_num_overflow_1_update = 0;  			  
             }
		 }
	}	
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 15  
-*------------------------------------------------------------*/
void Welcome_Disp_Timeout_Occurs()
{
	    Timer1_Stop();
		status_disp_fsm = INITIAL_DISP_FSM;	
        cur_line_disp_data[ALL_LINES] = ANY_DATA_DISP;	
	   /* wait for account sw to be pressed after timer1 expiry */ 
       	key_or_sw_input_enable_flag = STATE_YES_IN_CHAR;    
        account_sw_enable_flag = STATE_YES_IN_CHAR; 
		can_lcd_disp_flag = STATE_YES_IN_CHAR;
		cur_data_enterchar_disp_format = ENTER_KEY_PLAIN_DISP_FORMAT; 
		LCD_Clear_Screen(); //clear display
		//Write_LCD_Command(0x0C);
		Goto_XY_LCD_Disp(WELCOME_MSG_LINE_NUM, WELCOME_MSG_START_COL_NUM);
        LCD_Disp_Str(welcome_msg_disp); 
}


/*------------------------------------------------------------*-
FUNCTION NAME  : Write_Bit

DESCRIPTION     : write bit valve to data's bit, without affecting other bits of data .
                . 0 is the least bit pos and 7 is the most bit pos 

INPUT          : 

OUTPUT         : none

NOTE           : 
-*------------------------------------------------------------*/
void Write_Bit_in_Data(unsigned int *data, const unsigned int bit_pos, const unsigned int set_bit_val )
{
     if (set_bit_val == 1)
       {
          Set_Bit_in_Data(data, bit_pos);
          return;
       }
       Clear_Bit_in_Data(data, bit_pos ); 
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
