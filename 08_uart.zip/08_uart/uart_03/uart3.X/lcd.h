/**************************************************************************
   FILE          :    lcd.h
 
   PURPOSE       :    LCD Header
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :  for  LCD disp 
 
  CHANGE LOGS    :
	   
 **************************************************************************/
 /* to avoid this header file to be included more than once, conditional directive is used  */
#ifndef _LCD_H
#define _LCD_H
                            

#define LCD_WRITE_ENABLE_PULSE_IN_USEC       (1)
#define LCD_ADDR_SETUP_IN_USEC               (1)
#define LCD_ENABLE_PULSE_BEFORE_WRITE_IN_USEC (1)
#define LCD_DATA_SETUP_IN_USEC               (1)
#define LCD_WRITE_ENABLE_PULSE_DELAY_IN_USEC (1)
#define LCD_CLEAR_EXEC_IN_USEC             (1650)
#define LCD_CURSOR_RETURN_EXEC_IN_USEC     (1650)
#define LCD_OTHER_INST_EXEC_IN_USEC          (40)

#define INVALID_DATA               (0)
#define ALL_LINES                  (0)
#define NUM_LINE1                  (1)
#define NUM_LINE2                  (2)
#define NUM_LINE3                  (3)
#define NUM_LINE4                  (4)

#define NUM_COL1                   (1)

#define CHECK_BUSY_FLAG             (1)
#define NO_CHECK_BUSY_FLAG          (0)

#define DATA_INTERFACE_8_BITS       (1) 
#define DATA_INTERFACE_4_BITS       (0)

#define CHAR_FONT_5_10_DOTS        (1)
#define CHAR_FONT_5_8_DOTS         (0)

#define MAX_DISP_NUM_LINES_2      (1)
#define MAX_DISP_NUM_LINES_1      (0)     

#define GIVEN_CHARS_MAX_CONFIG_LINES_AND_COLS (1)
#define GIVEN_XY_MAX_CONFIG_LINES_AND_COLS    (2)
#define GIVEN_CHARS_MAX_XY                    (3)

/* if  NUM_CHARS_INPUTDATA == GIVEN_CHARS_MAX_CONFIG_LINES_AND_COLS, then calc cur input data parameters by 
  using given max num of chars from start cur data input line and start cur data input col. 
  If conf max num of chars for cur input's data > max avail num of chars, then  alloc cur data input max num of chars  = max avail num of chars,
  whereas  max avail num of chars = num of chars from cur input's data start line and cur input's data start col till end of config lines and cols, else   
  then  alloc num of chars for input data =  given conf max num of chars for cur input's data.
  
   if  NUM_CHARS_INPUTDATA ==  GIVEN_XY_MAX_CONFIG_LINES_AND_COLS, then calc cur input data parameters by using given cur data input start line, cur data input start col ,
   next data start line, and next data start col. 
   XY(Cur input data's end line, ur input data's end col) = previous pos of XY( next data start line, and next data start col).
   max configured cur input's data max input chars =  num of chars from   XY(Cur input data's start line, Cur input data's start col) to XY(Cur input data's end line, cur input data's end col).
   max avail chars = num of chars  from cur data input start line and  cur data input start col,till end of config max lines and conf  max cols. 
   If  max configured cur input's data max input chars > max avail chars, then    alloc max num of chars for cur input data =  max avail chars, 
   else, alloc max num of chars for input data =  max configured cur input's data max input chars.
   
   if  NUM_CHARS_INPUTDATA ==  GIVEN_CHARS_MAX_XY, then calc cur input data parameters by using given cur data input start line,  cur data input start col , 
   next data start line, next data start col, and conf num of chars for cur input data.  
    XY(Cur input data's end line, ur input data's end col) = previous pos of XY( next data start line, and next data start col).
	max avail num of chars = num of chars  chars from cur data input start line and  cur data input start col, till XY(Cur input data's end line, ur input data's end col).
    If conf max num of chars for cur input data > max avail num of chars ,  then  alloc num of chars for cur input data =  max avail num of chars, 
    else max allocated data = given  conf num of chars for cur input data */

#define  NUM_CHARS_INPUTDATA            GIVEN_CHARS_MAX_CONFIG_LINES_AND_COLS
	
typedef struct {
		struct 	{
	    	unsigned int rs_pin: 1;
		    unsigned int rs_tris: 1;
		    unsigned int rw_pin: 1;
	    	unsigned int rw_tris: 1;
		    unsigned int en_pin: 1;
		    unsigned int en_tris: 1;
		    unsigned int interface: 1;
		    unsigned int num_lines: 2;
		    unsigned int font: 1;
		    unsigned int check_bf: 1;
	    } conf;
	    union {
	    	unsigned int tris;
	    	struct {
			   unsigned int tris_0: 1;
			   unsigned int tris_1: 1;
			   unsigned int tris_2: 1;
			   unsigned int tris_3: 1;
			   unsigned int tris_4: 1;
			   unsigned int tris_5: 1;
			   unsigned int tris_6: 1;
			   unsigned int tris_7: 1;
		   } data_tris;
	   } data_triss;	
	    union {
	    	unsigned int pins;
	    	struct {
			   unsigned int pin_0: 1;
			   unsigned int pin_1: 1;
			   unsigned int pin_2: 1;
			   unsigned int pin_3: 1;
			   unsigned int pin_4: 1;
			   unsigned int pin_5: 1;
			   unsigned int pin_6: 1;
			   unsigned int pin_7: 1;
		   } data_pin;
	   } data_pins;		
   } lcd;

extern char lcd_avail_loc_within_limit;
extern unsigned int cur_disp_lcd_loc , cur_input_lcd_loc, cur_data_input_max_num_chars_allocated ;
extern unsigned int lcd_read_command;
extern lcd lcd_unit; 

/* -------------------- public prototype declaration --------------------------------------- */
void Delay_Time_By_Count(unsigned long int delay_time_in_count);
void Write_LCD_Command_NO_BF(const unsigned int lcd_cmd);
void Write_LCD_Command(const unsigned int lcd_cmd);
void Write_LCD_Data(const char lcd_disp_ch);
void LCD_Disp_Str(const char *lcd_disp_str);
void LCD_Disp_Num(const disp_num_types lcd_datanum_disp_format, const value_types lcd_disp_data_int);
void Goto_XY_LCD_Disp(const unsigned int start_line_num, const unsigned int start_col_num);
void Goto_XY_LCD_Input(unsigned int start_line_num, unsigned int start_col_num);
void From_Loc_to_XY_LCD(const unsigned int loc_lcd, unsigned int * const loc_lcd_line_num, unsigned int * const loc_lcd_col_num );
void From_XY_To_Loc_LCD(const unsigned int start_line_num, const unsigned int start_col_num, unsigned int * const lcd_loc);
void Set_Cur_Loc_LCD(const char set_input_loc_flag,const unsigned int set_input_loc, const char set_disp_loc_flag, const unsigned int set_disp_loc);
void LCD_Init();
void Check_LCD_Busy();
unsigned int Read_LCD_Command();
void LCD_Clear_Screen();
void Write_Bit_in_Data( unsigned int *data, const unsigned int bit_pos, unsigned int set_bit_val );
void Cur_Input_Data_ByXY_Calc_Para(const unsigned int cur_data_entry_start_line_num, const unsigned int cur_data_entry_start_col_num, \
  const unsigned int next_data_start_line_num, const unsigned int next_data_start_col_num); 
void Cur_Input_Data_ByNumChars_Calc_Para(const unsigned int cur_data_entry_start_line_num, const unsigned int cur_data_entry_start_col_num, \
  const unsigned int configured_cur_data_input_max_num_chars);
void Cur_Input_Data_ByCharsXY_Calc_Para(const unsigned int cur_data_entry_start_line_num, const unsigned int cur_data_entry_start_col_num, \
  const unsigned int configured_cur_data_input_max_num_chars,const unsigned int next_data_start_line_num, const unsigned int next_data_start_col_num);   
void Reset_Cur_Input_Data_Para();  
#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
