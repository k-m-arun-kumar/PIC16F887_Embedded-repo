/**************************************************************************
   FILE          :    appl_conf.h
 
   PURPOSE       :   main application configuration Header
 
   AUTHOR        :   K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _APPL_CONF_H
 #define _APPL_CONF_H 
 
/*------------------------------- LCD disp conf ------------------------------------------*/
#define WELCOME_MSG_LINE_NUM          NUM_LINE1
#define WELCOME_MSG_START_COL_NUM     NUM_COL1
#define ACCOUNT_MSG_LINE_NUM          NUM_LINE1 
#define ACCOUNT_MSG_START_COL_NUM     NUM_COL1
#define PIN_MSG_LINE_NUM              NUM_LINE1 
#define FAILED_AUTH_REASON_LINE_NUM   NUM_LINE1
#define SUCCESS_AUTH_LINE_NUM         NUM_LINE1 
#define PIN_MSG_LINE_NUM              NUM_LINE1
#define FAILED_SET_PIN_LINE_NUM          NUM_LINE1	
#define ERROR_LINE_NUM                   NUM_LINE4  
#define ACCOUNT_ENTRY_START_LINE_NUM     NUM_LINE2
#define ACCOUNT_ENTRY_START_COL_NUM      NUM_COL1
// ACCOUNT_ENTRY_START_LOC = loc of ACCOUNT_ENTRY_START_LINE_NUM and ACCOUNT_ENTRY_START_COL_NUM
#define ACCOUNT_ENTRY_START_LOC          BEGIN_LOC_LINE2 
   
// ACCOUNT_MSG_START_LOC = loc of ACCOUNT_MSG_LINE_NUM and ACCOUNT_MSG_START_COL_NUM
#define ACCOUNT_MSG_START_LOC            BEGIN_LOC_LINE1 
#define PIN_ENTRY_START_LINE_NUM         NUM_LINE2
#define PIN_ENTRY_START_COL_NUM          NUM_COL1 
#define FAILED_AUTH_LINE_NUM             NUM_LINE2

/* -------------------------------Timer state conf ---------------------------------------*/

#define TMR1_WELCOME_DISP_STATE         (0)

/* ------------------------------- application conf --------------------------------------*/

#define PC_LINK_TRAN_BUFFER_LENGTH        (20U)

#define MAX_NUM_ACC_DATA_INPUT_TRY        (3U)
#define MAX_NUM_PIN_DATA_INPUT_TRY        (3U)
#define MAX_PIN_NUM_CHARS                 (5)
#define MAX_ACCOUNT_NUM_CHARS             (24)

#define REQ_TIMEOUT_WELCOME_MSG_DISP_IN_SEC     (5)
#define REQ_TIME_PLAIN_DISP_IN_HIDDEN_IN_MILLI_SEC (1000)      
#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
