/* ********************************************************************
FILE                   : uart2.c

PROGRAM DESCRIPTION    : enter a string by using keyboard and even using backspace in a virtual terminal and receive the entered string by UART 
and when a enter key is pressed in keyboard, display entered string in LCD. Normally backspace is considered as part of data.
 When backspace is pressed in keyboard, chars that are backspaced should not in displayed in LCD. Use RESET_SW to reset the process.
  
AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
                       
CHANGE LOGS           : 

*****************************************************************************/  
//#define HI_TECH_COMPILER
#ifdef HI_TECH_COMPILER
  #include <pic.h>
  __CONFIG(0x2CE4);
#else // XC8 compiler
  #include <xc.h>
#endif
#include <string.h>

#define STATE_YES                             'y'
#define STATE_NO                              'n'
#define KEY_PRESSED                            (1)
#define KEY_NOT_PRESSED                        (0)

#define RS_PIN                                 RC0
#define RW_PIN                                 RC1
#define EN_PIN                                 RC2
#define LCD_PORT                              PORTD
#define RESET_SW                               RC3

#define DISP_FLAG_NUM_DIGIT1                   (1)
#define DISP_FLAG_NUM_DIGIT2                   (2)
#define DISP_FLAG_NUM_DIGIT3                   (3)
#define DISP_FLAG_NUM_DIGIT4                   (4)
#define DISP_FLAG_NUM_DIGIT5                   (5)
#define DISP_FLAG_HEX_DIGIT1                   (6)
#define DISP_FLAG_HEX_DIGIT2                   (7)
#define DISP_FLAG_HEX_DIGIT3                   (8)
#define DISP_FLAG_HEX_DIGIT4                   (9) 

/* for 20 * 4 LCD disp */                             
#define BEGIN_LOC_LINE1                      (0X80)
#define BEGIN_LOC_LINE2                      (0xC0)
#define BEGIN_LOC_LINE3                      (0x94) 
#define BEGIN_LOC_LINE4                      (0xD4)
#define END_LOC_LINE1                        (0x93)
#define END_LOC_LINE2                        (0xD3)
#define END_LOC_LINE3                        (0xA7) 
#define END_LOC_LINE4                        (0xE7)

/* num cols = num of chars in a line */
#define MAX_COUNT_DELAY_TIME_LCDPULSE     (1000UL)
#define MAX_AVAIL_NUM_COLS                    (20)
#define CONFIGURE_MAX_NUM_LINES               (4)
#define MAX_AVAIL_NUM_LINES                   (4) 
#define MAX_AVAIL_NUM_CHARS_IN_LCD        (MAX_AVAIL_NUM_COLS * MAX_AVAIL_NUM_LINES) 
#define CONFIGURE_MAX_NUM_COLS             (MAX_AVAIL_NUM_COLS)
#define CONFIGURE_MAX_NUM_CHARS_IN_LCD    (CONFIGURE_MAX_NUM_LINES * CONFIGURE_MAX_NUM_COLS ) 
#define MAX_NUM_CHARS_INPUT_DATA          (MAX_AVAIL_NUM_COLS)  
#define ASCII_CODE_ZERO_CHAR              (0x30u)

#define INVALID_DATA               (0)
#define ALL_LINES                  (0)
#define NUM_LINE1                  (1)
#define NUM_LINE2                  (2)
#define NUM_LINE3                  (3)
#define NUM_LINE4                  (4)
#define NUM_COL1                   (1)

#define RCVD_UART_MSG_LINE_NUM    (NUM_LINE1)
#define RCVD_UART_DATA_LINE_NUM   (NUM_LINE2)
#define RCVD_UART_CHAR_LINE_NUM   (NUM_LINE3)

void Delay_Time_ByCount(unsigned int Delay_Time_Count_count);
void LCD_Init();
void LCD_Pulse ();
void Write_LCD_Command (const unsigned int Write_LCD_Command);
void Write_LCD_Data(const char lcd_disp_ch);
void Data_Str_Disp_LCD(const char *lcd_disp_str);
void Data_Num_Disp_LCD(const unsigned int lcd_datanum_disp_format, const unsigned long lcd_disp_data_int);
void LCD_Const_Disp();
void Datas_LCD_Disp();
void Goto_XY_LCD_Disp(const unsigned int start_line_num, const unsigned int start_col_num);

void Init_UART();
void Transmit_UART(const char transmit_char);
char Receive_UART();

unsigned int cur_disp_lcd_loc = BEGIN_LOC_LINE1;
char lcd_avail_loc_within_limit = STATE_YES;
char received_str[MAX_NUM_CHARS_INPUT_DATA + 1] ;
unsigned int receive_num_chars = 0;

const char received_msg_disp[] = "Rcvd Data :";
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void main()
{
	char reset_enable_flag = STATE_NO, uart_rcv_enable_flag = STATE_YES, lcd_const_disp_flag = STATE_NO ;
	   
	TRISC0 = 0;
	TRISC1 = 0;
	TRISC2 = 0;
	TRISC3 = 1;
	PORTC = 0x00;
	TRISD = 0x00;
	LCD_PORT = 0x00;
	ANSEL = 0x00;
	ANSELH = 0x00;
	LCD_Init();
	Init_UART();
	Goto_XY_LCD_Disp(RCVD_UART_MSG_LINE_NUM,NUM_COL1);
	Data_Str_Disp_LCD(received_msg_disp);
	
	//TEST code block for value of TRISA, PORTA
	/* Goto_XY_LCD_Disp(3,NUM_COL1);
	Data_Num_Disp_LCD(TRISA, DISP_FLAG_HEX_DIGIT4);
	Goto_XY_LCD_Disp(3,6);
	Data_Num_Disp_LCD(PORTA, DISP_FLAG_HEX_DIGIT4); */
	for(;;)
	{
		cur_disp_lcd_loc = BEGIN_LOC_LINE3;
		while(uart_rcv_enable_flag == STATE_YES && (received_str[receive_num_chars] = Receive_UART()) != '\r')
		{
		    if(received_str[receive_num_chars] == '\b')	
            {
				/* rcvd char is backspace */
				if(receive_num_chars > 0)
				{
					--cur_disp_lcd_loc;
				    Write_LCD_Command(cur_disp_lcd_loc);
				    Write_LCD_Data(' '); 
                    Write_LCD_Command(0x10); //shift cursor to left 
					--receive_num_chars;
				    received_str[receive_num_chars] = '\0';	
				}
                else
				{
					received_str[0] = '\0';
					receive_num_chars = 0;
					cur_disp_lcd_loc = BEGIN_LOC_LINE3;
			    }
			}
			else
			{
				//SHOULD_REMOVE
		        Write_LCD_Command(cur_disp_lcd_loc); 
	            Write_LCD_Data(received_str[receive_num_chars]);
				
				++cur_disp_lcd_loc;
                ++receive_num_chars;
			}
		}
		// received char is carriage return or enter key
		if(lcd_const_disp_flag == STATE_NO)
		{
	    	uart_rcv_enable_flag = STATE_NO; 
		    received_str[receive_num_chars] = '\0';
		    Goto_XY_LCD_Disp(RCVD_UART_DATA_LINE_NUM, NUM_COL1);
	        Data_Str_Disp_LCD(received_str);
		    reset_enable_flag = STATE_YES;
			lcd_const_disp_flag = STATE_YES;
	    }		
        if(reset_enable_flag == STATE_YES && RESET_SW == KEY_PRESSED)
		{
			while(RESET_SW == KEY_PRESSED);		 
    	    receive_num_chars = 0; 
			Write_LCD_Command(0x01);
		    Goto_XY_LCD_Disp(RCVD_UART_MSG_LINE_NUM,NUM_COL1);
	        Data_Str_Disp_LCD(received_msg_disp);
		    received_str[receive_num_chars] = '\0';
			uart_rcv_enable_flag = STATE_YES;
			lcd_const_disp_flag = STATE_NO;
		}	
	}
	
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/

void Init_UART()
{
	SPBRG = 23;  /* (_XTAL_FREQ /(16 * baud_rate) ) - 1,  Osc freq = 3686400 Hz, Baud Rate = 9600  */
	BRG16 = 0 ; 
	BRGH  = 1;   /* Fast baud rate */
	SYNC  = 0;   /* Asynchrous mode */
    SPEN  = 1;   /* enable serial port pins */
	CREN  = 1;   /* enable continuous receive */
	SREN  = 0;   /* single receive disabled */
	TXIE  = 0;   /* disable transmit interrupt */
	RCIE  = 1;   /* enable receiver interrupt */
	TX9   = 0;   /* 8 bit transmission */
	RX9   = 0;   /* 8 bit reception */
	TXEN  = 0;   /* reset transmitter */
	TXEN  = 1;   /* enable transmitter */
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void Transmit_UART(const char transmit_char)
{
	TXREG = transmit_char;	
	while(TRMT == 0); /* wait as TSR is full */	
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
char Receive_UART()
{
	char receive_char=0;
	
	while(RCIF == 0);
	receive_char = RCREG;
	
	/* echo received char in virtual terminal */
	Transmit_UART(receive_char);
	return receive_char;
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void LCD_Init()
{
    Write_LCD_Command(0x30);
    Write_LCD_Command(0x30);
    Write_LCD_Command(0x30);
    Write_LCD_Command(0x38);
    Write_LCD_Command(0x01);
    Write_LCD_Command(0x0E); //insert cursor on at cur_input_lcd_loc
	//Write_LCD_Command(0x0C);
    Write_LCD_Command(0x06);                                       
}     

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 23   
-*------------------------------------------------------------*/
  void Write_LCD_Command (unsigned int cmd)
  {
	  unsigned long int  time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	  
       RW_PIN = 0;
       RS_PIN = 0; 
       LCD_PORT = cmd;
      // LCD_Pulse();
	  EN_PIN = 1;
	  while(time_delay--);
    // Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);
      EN_PIN = 0;
	  time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	  while(time_delay--);
   //  Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);
 }
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 24   
-*------------------------------------------------------------*/
 void Write_LCD_Data(const char ch)
{
	unsigned long int  time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	// performance degraded if many data is written to LCD, to check if write loc is within avail disp loc
	// if(lcd_avail_loc_within_limit == STATE_YES) 
	{	
      RW_PIN = 0;
      RS_PIN = 1;
      LCD_PORT =ch;
     // LCD_Pulse();
      EN_PIN = 1;
	  while(time_delay--);
    // Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);
     EN_PIN = 0;
	 time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	  while(time_delay--);
   //  Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);	 
	}
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 25   
-*------------------------------------------------------------*/

void Data_Str_Disp_LCD(const char *char_ptr)
{ 
       while(*char_ptr)
       {
            Write_LCD_Data(*(char_ptr++));
       }
     
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 27  
-*------------------------------------------------------------*/
void Delay_Time_ByCount( unsigned int time_delay)
{
       while(time_delay--);
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 26  
-*------------------------------------------------------------*/
void Data_Num_Disp_LCD(const unsigned int lcd_datanum_disp_format, const unsigned long lcd_disp_data_int)
{
    unsigned int tens_thousand_digit,thousands_digit, hundreds_digit,tens_digit, unit_digit;
    unsigned long num = lcd_disp_data_int;
    char num_data[] ={'0','1','2','3','4','5','6','7','8','9'};  
	char hex_data[] ={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'}; 
    switch(lcd_datanum_disp_format)
	{
	  case DISP_FLAG_NUM_DIGIT5: 
		  num =  lcd_disp_data_int % 100000;
		  tens_thousand_digit = (unsigned int)(num / (unsigned long)(10000));
          Write_LCD_Data(num_data[tens_thousand_digit]);
	  case DISP_FLAG_NUM_DIGIT4:
	      num = lcd_disp_data_int % 10000;
	      thousands_digit = (unsigned int)(num / (unsigned long)(1000));
	      Write_LCD_Data(num_data[thousands_digit]); 
	  case DISP_FLAG_NUM_DIGIT3: 
		  num = lcd_disp_data_int % 1000;
	      hundreds_digit = (unsigned int) (num / (unsigned long) (100));
	      Write_LCD_Data(num_data[hundreds_digit]);
	  case DISP_FLAG_NUM_DIGIT2:
          num = lcd_disp_data_int % 100;
          tens_digit = (unsigned int) (num / 10);
          Write_LCD_Data(num_data[tens_digit]); 		  
	  case DISP_FLAG_NUM_DIGIT1:
	     unit_digit = (unsigned int) (lcd_disp_data_int % 10);
         Write_LCD_Data(num_data[unit_digit]); 
	  break;
	  case DISP_FLAG_HEX_DIGIT4:
	      /*  ( 16 * 16 * 16 *16 )  = 0 as divide by zero warning */
	      //num = lcd_disp_data_int % ( 16 * 16 * 16 *16 );
          thousands_digit = (num / (16 * 16 * 16));
	      Write_LCD_Data(hex_data[thousands_digit]);
	  case DISP_FLAG_HEX_DIGIT3:
	      num = lcd_disp_data_int %(unsigned long)(16 * 16 * 16);
	      hundreds_digit = (unsigned int) (num / (unsigned long) (16 * 16));
	      Write_LCD_Data(hex_data[hundreds_digit]);
	  case DISP_FLAG_HEX_DIGIT2:
	      num = lcd_disp_data_int %(unsigned long)(16 * 16);
          tens_digit = (unsigned int) (num / 16);
          Write_LCD_Data(hex_data[tens_digit]);
	  case DISP_FLAG_HEX_DIGIT1: 
	      unit_digit = (unsigned int) (lcd_disp_data_int % 16);
          Write_LCD_Data(hex_data[unit_digit]);    
	  break;
	  default:
	       /* Warning invalid lcd_disp flag */
	    ;
	}   	
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 29   
-*------------------------------------------------------------*/
void Goto_XY_LCD_Disp(const unsigned int start_line_num, const unsigned int start_col_num)
{
	/* max 4 lines and 20 columns */
	/* for us, lcd line starts from 1, but for uC, line starts from 0 */
	/* for us, lcd col starts from 1, but for uC, col starts from 0 */
    unsigned int start_line_lcd = start_line_num - 1, start_col_lcd = start_col_num - 1, error_disp_start_loc; 
	lcd_avail_loc_within_limit = STATE_YES;
	
   if(start_line_num <= CONFIGURE_MAX_NUM_LINES && start_col_num <= CONFIGURE_MAX_NUM_COLS )
   {
      switch(start_line_num)
	 {
		 case NUM_LINE1:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE1;
		   break;
		 case NUM_LINE2:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE2;
		   break;
		 case NUM_LINE3:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE3;
		   break;
		  case NUM_LINE4:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE4;
		   break;		 
	 }	
      cur_disp_lcd_loc = cur_disp_lcd_loc + start_col_lcd;
      Write_LCD_Command(cur_disp_lcd_loc);       
   }
   else
   {
	   /* error due to invalid lcd DISP loc  */
	     lcd_avail_loc_within_limit = STATE_NO;		
		       		
   }	   
} 
