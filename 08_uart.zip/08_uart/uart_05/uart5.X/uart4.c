/*------------------------------------------------------------*
FUNCTION NAME  : main

DESCRIPTION    :
								
INPUT          : none

Author         : K.M. Arun Kumar alias Arunkumar Murugeswaran

OUTPUT         : 

NOTE           : 

Func ID        : 1   
-*------------------------------------------------------------*/

void main()
{                               
      TRISA = 0x00;
      PORTA = 0x00;
	  /* to leave T1G pin in portb as input to PIC ie RB5 = 1 in TRISB  to run timer 1, if timer1 conf ie T1CON = (0xC5) was set run timer1. 
        if T1G pin in portb is 0 ie RB5 = 0	in TRISB, even if timer1 is conf ie T1CON = (0xC5) was set to run timer1, timer1 will not run.
        T1G pin is input to PIC to control run Timer1, if gate control for Timer 1 to run is enabled. 
		If T1CON = (0x85),  gate control for Timer 1 is disabled, so T1G pin can have used for other purpose */
	  TRISB = 0x00;
	  PORTB = 0x00;
      TRISC0 = 0;
	  TRISC1 = 0;
	  TRISC2 = 0;
	  TRISC3 = 1;
	  TRISC4 = 1;
      PORTC = 0x00;
      TRISD  = 0x00;
      PORTD = 0x00;
      TRISE = 0x00;
      PORTE = 0x00;
      ANSEL = 0x00;
      ANSELH = 0x00;
      LCD_Init();
	  Init_UART();
      Reset_Process();
      for(;;)
      {  
          while(key_or_sw_input_enable_flag == STATE_YES)
          { 
                      				  
	           if(keyboard_enable_flag == STATE_YES  )
               {
	             	Enter_Cur_Data_Proc();	 
    			    
		            // received char is carriage return or enter key and Process for Enter key stroke
					if(num_chars_entered_cur_data)
					{
		               entered_cur_input_data[num_chars_entered_cur_data ] = '\0';		               		               
			           reset_sw_enable_flag = STATE_YES;
                       Auth_Fsm_Proc(); 
                       memset(entered_cur_input_data, '\0', sizeof(entered_cur_input_data)/sizeof(char));
                       num_chars_entered_cur_data = 0;
					}
                    else
					{
						// warning enter key pressed before any data is entered ie num_chars_entered_cur_data = 0
                       Enter_Cur_Data_Proc();
					}					   
               }    
               if(ACCOUNT_SW ==KEY_PRESSED )		 
               {
                   cur_pressed_key_or_sw = ACCOUNT_SW_CODE;//latest pressed key/switch
	    		   if(account_sw_enable_flag == STATE_YES)
				    {					
                        After_Switch_Stoke_Proc(cur_pressed_key_or_sw);                             				  
                    }
               }						
			   if(status_disp_fsm != INITIAL_DISP_FSM && cur_line_disp_data[ALL_LINES] == ANY_DATA_DISP )
               { 
	  	           Disp_Status_Fsm(); 
		           cur_line_disp_data[ALL_LINES] = AUTH_STATUS_DISP;     
               }
               while(status_disp_fsm != INITIAL_DISP_FSM)
			   {
				   Wait_Welcome_Msg_Disp_Proc();
			   }				   
          }                    
          if(RESET_SW ==KEY_PRESSED )
          {
	           cur_pressed_key_or_sw = RESET_SW_CODE;//latest pressed key/switch
			   if(reset_sw_enable_flag == STATE_YES)
			   {       
                    After_Switch_Stoke_Proc(cur_pressed_key_or_sw);
               }
	     }
	 } 		 
}
