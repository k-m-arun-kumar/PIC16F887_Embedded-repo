/**************************************************************************
   FILE          :    Elap_232.h
 
   PURPOSE       :   type declarations for Elap_232.c .  
 
   AUTHOR        :     K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   see Elap_232.C for details
	
  CHANGE LOGS     :
	   
 **************************************************************************/
 
#ifndef _ELAP_232_H
#define _ELAP_232_H

// ------ Public function prototypes -------------------------------
void Elapsed_Time_RS232_Init(void);
void Elapsed_Time_RS232_Update(void);  

/* system ticks interval in m sec. for Every TICK_INTERVAL, application Task followed by e0S(system Task)
   is executed. NOTE: make sure that SYSTEM_TICK_INTERVAL is large enough that uC executing maximum time 
	 required to start and completes executing Application task and system task(sEOS_Go_To_Sleep) 	*/
	 
#define SYSTEM_TICK_INTERVAL  (5U)
#endif

/*------------------------------------------------------------------*-
  ---- END OF FILE -------------------------------------------------
-*------------------------------------------------------------------*/
