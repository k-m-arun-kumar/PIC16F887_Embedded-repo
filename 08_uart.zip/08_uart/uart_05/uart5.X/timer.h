/**************************************************************************
   FILE          :    timer.h
 
   PURPOSE       :    Timer Header
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :  
  
  CHANGE LOGS    :
	   
 **************************************************************************/
#ifndef _TIMER_H
#define _TIMER_H
#include <main.h>
 
 // TIMER1 expires every 50ms and   calls (),if timer1 runs 
#define TIMER1_TICK_MSEC               (50UL) 
#define TIME_UNIT_SEC_TO_MSEC        (1000UL)
#define INC1                        (unsigned long)((unsigned long)(_XTAL_FREQ * TIMER1_TICK_MSEC ) / (unsigned long)(OSC_PER_INST * TIME_UNIT_SEC_TO_MSEC)) 
#define UPDATE_TIME1_WELCOME_DISP    (1000UL/TIMER1_TICK_MSEC)
 
#define TMR1_OFF_STATE               (0)
#define TMR1_MODE_WELCOME_DISP       (1)

// ----------------- Public function prototypes -------------------------------
void Prescale_Timer1();     
void Timer1_Tick();
void Wait_Welcome_Msg_Disp_Proc();
void Check_Welcome_Disp_Time_Occurs();
void Run_Timer1(const unsigned int set_timer1_mode );
void Stop_Timer1();
#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
