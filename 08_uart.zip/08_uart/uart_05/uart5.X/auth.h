/**************************************************************************
   FILE          :    auth.h
 
   PURPOSE       :    Auth Header
 
   AUTHOR        :     K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _AUTH_H
 #define _AUTH_H
 
/* all below defines datas specifies full specified line */
#define WELCOME_MSG_LINE_NUM          NUM_LINE1
#define WELCOME_MSG_START_COL_NUM     NUM_COL1
#define ACCOUNT_MSG_LINE_NUM          NUM_LINE1 
#define ACCOUNT_MSG_START_COL_NUM     NUM_COL1
#define PIN_MSG_LINE_NUM              NUM_LINE1 
#define FAILED_AUTH_REASON_LINE_NUM   NUM_LINE1
#define SUCCESS_AUTH_LINE_NUM         NUM_LINE1 
#define PIN_MSG_LINE_NUM              NUM_LINE1
#define FAILED_SET_PIN_LINE_NUM          NUM_LINE1	
#define ERROR_LINE_NUM                   NUM_LINE4  
#define ACCOUNT_ENTRY_START_LINE_NUM     NUM_LINE2
#define ACCOUNT_ENTRY_START_COL_NUM      NUM_COL1
// ACCOUNT_ENTRY_START_LOC = loc of ACCOUNT_ENTRY_START_LINE_NUM and ACCOUNT_ENTRY_START_COL_NUM
#define ACCOUNT_ENTRY_START_LOC          BEGIN_LOC_LINE2 
   
// ACCOUNT_MSG_START_LOC = loc of ACCOUNT_MSG_LINE_NUM and ACCOUNT_MSG_START_COL_NUM
#define ACCOUNT_MSG_START_LOC            BEGIN_LOC_LINE1 
#define PIN_ENTRY_START_LINE_NUM         NUM_LINE2
#define PIN_ENTRY_START_COL_NUM          NUM_COL1 
#define FAILED_AUTH_LINE_NUM             NUM_LINE2
#define DISP_BLANK_LINE3_NUM             NUM_LINE3
#define DISP_BLANK_LINE4_NUM             NUM_LINE4

#define ENTER_KEY_PLAIN_DISP_FORMAT    (1)
#define ENTER_KEY_HIDDEN_DISP_FORMAT   (2) 

#define ANY_DATA_DISP                 (1)
#define BLANK_LINE_DISP               (2)
#define NO_KEY_PRESS_TIMEOUT_DISP     (3)   
#define LONG_PRESS_TIMEOUT_DISP       (4)     
#define AUTH_PROCESS_TIMEOUT_DISP     (5) 
#define SET_PIN_TIMEOUT_DISP          (6)
#define AUTH_STATUS_DISP              (7)  
#define ERROR_DISP                    (8)
#define WARNING_DISP                  (9)
#define FATAL_DISP                    (10) 

#define ACCOUNT_SW_CODE               ('A')
#define RESET_SW_CODE                 ('R') 
#define HIDDEN_KEY_DISP_CHAR          ('X')
#define NUM_CHARS_TRACE_CODE           (5)

#define GIVEN_CHARS_MAX_CONFIG_LINES_AND_COLS (1)
#define GIVEN_XY_MAX_CONFIG_LINES_AND_COLS    (2)
#define GIVEN_CHARS_MAX_XY                    (3)

/* if  NUM_INPUTDATA_CHARS == GIVEN_CHARS_MAX_CONFIG_LINES_AND_COLS, then calc cur input data parameters by 
  using given max num of chars from start cur data input line and start cur data input col. 
  If conf max num of chars for cur input's data > max avail num of chars, then  alloc cur data input max num of chars  = max avail num of chars,
  whereas  max avail num of chars = num of chars from cur input's data start line and cur input's data start col till end of config lines and cols, else   
  then  alloc num of chars for input data =  given conf max num of chars for cur input's data.
  
   if  NUM_INPUTDATA_CHARS ==  GIVEN_XY_MAX_CONFIG_LINES_AND_COLS, then calc cur input data parameters by using given cur data input start line, cur data input start col ,
   next data start line, and next data start col. 
   XY(Cur input data's end line, ur input data's end col) = previous pos of XY( next data start line, and next data start col).
   max configured cur input's data max input chars =  num of chars from   XY(Cur input data's start line, Cur input data's start col) to XY(Cur input data's end line, cur input data's end col).
   max avail chars = num of chars  from cur data input start line and  cur data input start col,till end of config max lines and conf  max cols. 
   If  max configured cur input's data max input chars > max avail chars, then    alloc max num of chars for cur input data =  max avail chars, 
   else, alloc max num of chars for input data =  max configured cur input's data max input chars.
   
   if  NUM_INPUTDATA_CHARS ==  GIVEN_CHARS_MAX_XY, then calc cur input data parameters by using given cur data input start line,  cur data input start col , 
   next data start line, next data start col, and conf num of chars for cur input data.  
    XY(Cur input data's end line, ur input data's end col) = previous pos of XY( next data start line, and next data start col).
	max avail num of chars = num of chars  chars from cur data input start line and  cur data input start col, till XY(Cur input data's end line, ur input data's end col).
    If conf max num of chars for cur input data > max avail num of chars ,  then  alloc num of chars for cur input data =  max avail num of chars, 
    else max allocated data = given  conf num of chars for cur input data */
     
#define  NUM_INPUTDATA_CHARS        GIVEN_CHARS_MAX_CONFIG_LINES_AND_COLS

#define PC_LINK_TRAN_BUFFER_LENGTH        (20U)

#define MAX_NUM_ACC_DATA_INPUT_TRY        (3U)
#define MAX_NUM_PIN_DATA_INPUT_TRY        (3U) 
#define MAX_COUNT_LONG_PRESSKEY_TIMEOUT   (3U)  
#define MAX_PIN_NUM_CHARS                 (5)
#define MAX_ACCOUNT_NUM_CHARS             (24)

#define REQ_TIMEOUT_WELCOME_MSG_DISP     (5)

 /* -------------------- public prototype declaration --------------------------------------- */
void Reset_Process();
void Stoke_Rcvd_Tmr1_Long_Press_Proc();
void Disp_Status_Fsm();
void Auth_Fsm_Proc();
void After_Key_Stoke_Proc(const char pressed_key);
void After_Switch_Stoke_Proc(const char pressed_key);
void Entered_Key_No_Long_Press_Proc(const char pressed_key);
void Entered_Backspace_Sw_No_Long_Press_Proc();
void Enter_Cur_Data_Proc();
void Auth_Proc();
void Is_Numchars_Within_Limit();
void Cur_Input_Data_ByXY_Calc_Para(const unsigned int cur_data_entry_start_line_num, const unsigned int cur_data_entry_start_col_num, \
  const unsigned int next_data_start_line_num, const unsigned int next_data_start_col_num); 
void Cur_Input_Data_ByNumChars_Calc_Para(const unsigned int cur_data_entry_start_line_num, const unsigned int cur_data_entry_start_col_num, \
  const unsigned int configured_cur_data_input_max_num_chars);
void Cur_Input_Data_ByCharsXY_Calc_Para(const unsigned int cur_data_entry_start_line_num, const unsigned int cur_data_entry_start_col_num, \
  const unsigned int configured_cur_data_input_max_num_chars,const unsigned int next_data_start_line_num, const unsigned int next_data_start_col_num);   
void Set_Cur_Loc_LCD(const char set_input_loc_flag, const unsigned int set_input_loc, const char set_disp_loc_flag, const unsigned int set_disp_loc);
void Reset_Cur_Input_Data_Para();

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
