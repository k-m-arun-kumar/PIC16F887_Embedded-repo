/* ********************************************************************
FILE                   : lcd_22.c

PROGRAM DESCRIPTION    :In LCD, fixed text is displayed at left most or right most side of LCD and running text is displayed either to left or to right with specified number of gaps between consecutive same running text display, without overwriting fixed text. 
	 
AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  it uses base from PIC16F887-repo-> 00_projects->LCD display scroll and modified for quick response, with no LCD busy flag check and fixed text is displayed at left most or right most side of LCD. NOT YET FINISHED  
                       										
                                    
CHANGE LOGS           : 

*****************************************************************************/
  

#ifdef HI_TECH_COMPILER
  #include <pic.h>
  __CONFIG(0X2CE4);
#else // XC8 compiler
  #include <xc.h>
#endif
#include <string.h>

#define STATE_YES             'y'
#define STATE_NO              'n'

#define RS_PIN                RD0
#define RW_PIN                RD1
#define EN_PIN                RD2
#define LCD_PORT              PORTC
#define LCD_PORT_GPIO         TRISC
  
#define LCD_ENABLE_PULSE_WIDTH            (1000ul)

#define NO_FIXED_TEXT_SHIFT_DISP_LEFT       (0U)
#define NO_FIXED_TEXT_SHIFT_DISP_RIGHT      (1U)
#define FIXED_TEXT_LEFT_SHIFT_DISP_LEFT     (2U)
#define FIXED_TEXT_LEFT_SHIFT_DISP_RIGHT    (3U)  
#define FIXED_TEXT_RIGHT_SHIFT_DISP_LEFT    (4U)
#define FIXED_TEXT_RIGHT_SHIFT_DISP_RIGHT   (5U)
#define FIXED_TEXT_LEFT_RIGHT_SHIFT_DISP_LEFT (6U)
#define FIXED_TEXT_LEFT_RIGHT_SHIFT_DISP_RIGHT (7U)

#define NUM_LINE1             (1U) 
#define NUM_LINE2             (2U)
#define NUM_LINE3             (3U) 
#define NUM_LINE4             (4U)
 
/* for 16 * 4 LCD disp */                             
#define BEGIN_LOC_LINE1       (0X80)
#define BEGIN_LOC_LINE2       (0xC0)
#define BEGIN_LOC_LINE3       (0x90) 
#define BEGIN_LOC_LINE4       (0xD0)

#define MAX_AVAIL_NUM_COLS    (16U)
#define MAX_NUM_CHARS_IN_TEXT (30U)

/* for SHIFT_DISP_LEFT, number of trailing gaps between consecutive running text  */
#define TRAIL_NUM_GAPS_BETWEEN_RUNNING_TEXT (2U)
/* for SHIFT_DISP_RIGHT, number of leading gaps between consecutive running text */
#define LEAD_NUM_GAPS_BETWEEN_RUNNING_TEXT  (2U)

// Ring Buffer for Line 1 
char lcd_buffer_line1[MAX_AVAIL_NUM_COLS]; 
// Ring Buffer for Line 2 
char lcd_buffer_line2[MAX_AVAIL_NUM_COLS]; 
char line1_text_disp_finish_flag = STATE_YES, line2_text_disp_finish_flag = STATE_YES;

void LCD_Init();
void LCD_Write_Pulse(unsigned long int time_delay);
void Delay_Time_By_Count(unsigned long int time_delay );
void LCD_Write_Command();
void LCD_Write_Data();
void LCD_Line_Select(const unsigned int line);
void LCD_Running_Text_Display_Line1(const char *fixed_text_str, const unsigned int fixed_text_str_len, const char *running_text_str, \
  const unsigned int running_text_str_len, const unsigned int num_gaps_between_running_text_str, const unsigned int running_text_shift_direction);
void LCD_Running_Text_Display_Line2(const char *fixed_text_str, const unsigned int fixed_text_str_len, const char *running_text_str, \
  const unsigned int running_text_str_len, const unsigned int num_gaps_between_running_text_str, const unsigned int running_text_shift_direction); 
void LCD_Clear();
void Data_Str_LCD_Disp(const char *str, const unsigned int str_len, const unsigned int line);

void main(void) 
{
	const char fixed_text_str_left[] = {"LEFT."};
	const char fixed_text_str_right[] = {"RIGHT."};
    //const char running_text_str_left[] = {"HELLO I AM ARUN AND SAVE UNIVERSE."};
	const char running_text_str_left[] = {"HELLO."};
    const char running_text_str_right[] = {"WORLD."};
    unsigned int running_text_str_left_len, running_text_str_right_len, fixed_text_str_left_len, fixed_text_str_right_len;
	
    LCD_PORT_GPIO = 0x00;
	PORTC = 0x00;
    TRISD = 0x00;  
    PORTD = 0x00;
    
    LCD_Init();
	// Flush buffers before starting something new on it
    memset(lcd_buffer_line1, 0, MAX_AVAIL_NUM_COLS ); 
	memset(lcd_buffer_line2, 0, MAX_AVAIL_NUM_COLS ); 
    running_text_str_left_len = strlen(running_text_str_left);
	running_text_str_right_len = strlen(running_text_str_right);
	fixed_text_str_left_len = strlen(fixed_text_str_left);
	fixed_text_str_right_len = strlen(fixed_text_str_right);
    for(;;)
    {
	   LCD_Running_Text_Display_Line1(NULL, 0, running_text_str_left, running_text_str_left_len, TRAIL_NUM_GAPS_BETWEEN_RUNNING_TEXT, NO_FIXED_TEXT_SHIFT_DISP_LEFT); 
		
		/* //SHOULD_REMOVE
		LCD_Write_Command();    
        LCD_PORT = 0x80;
        LCD_Write_Pulse(LCD_ENABLE_PULSE_WIDTH);
        LCD_Write_Data();
		LCD_PORT = 'E';
		LCD_Write_Pulse(LCD_ENABLE_PULSE_WIDTH); */
		
        LCD_Running_Text_Display_Line2(NULL, 0, running_text_str_right, running_text_str_right_len, LEAD_NUM_GAPS_BETWEEN_RUNNING_TEXT, NO_FIXED_TEXT_SHIFT_DISP_RIGHT);  		
    }   
}
void LCD_Running_Text_Display_Line1(const char *fixed_text_str, const unsigned int fixed_text_str_len, const char *running_text_str, \
  const unsigned int running_text_str_len, const unsigned int num_gaps_between_running_text_str, const unsigned int running_text_shift_direction)
{
    // keeping temp_text_str buffer custom for different string lengths is safe. 
	static char temp_text_str[MAX_NUM_CHARS_IN_TEXT]; 
	static int cur_char_in_str_index = 0;
	int cur_lcd_col, cur_temp_index;
	
	if(line1_text_disp_finish_flag == STATE_YES)
	{
	   //copy string into temp_text_str buffer up to the string length
        memcpy(temp_text_str, running_text_str, running_text_str_len); 
		cur_char_in_str_index = 0;	
	    line1_text_disp_finish_flag = STATE_NO;
	}  
	switch(running_text_shift_direction)
	{
		//Shift entire line number 1 display to left
	   case NO_FIXED_TEXT_SHIFT_DISP_LEFT:    
          //whole shifting length = running_text_str_len + num_gaps_between_running_text_str
         if( cur_char_in_str_index < (int)(running_text_str_len + num_gaps_between_running_text_str)) 
         {
		    // display lcd_buffer_line1, we use MAX_AVAIL_NUM_COLS as length because we are shifting entire line num 1 in LCD to left 
            Data_Str_LCD_Disp(lcd_buffer_line1, MAX_AVAIL_NUM_COLS, NUM_LINE1 ); 
            for(cur_lcd_col = 0; cur_lcd_col < (int) MAX_AVAIL_NUM_COLS; ++cur_lcd_col)
            {
			   // Left shifting
			   if(cur_lcd_col != (int)(MAX_AVAIL_NUM_COLS - 1))
                  lcd_buffer_line1[(unsigned int)cur_lcd_col] = lcd_buffer_line1[(unsigned int)(cur_lcd_col + 1)]; 
			   // entering first temp_text_str[0] value at the end to do left shift into lcd_buffer_line1
               else
				  //cur_lcd_col = (MAX_AVAIL_NUM_COLS - 1) 
				  lcd_buffer_line1[(unsigned int)cur_lcd_col] = temp_text_str[0]; 
            } 
			// shifting of temp_text_str also needed to get all values step by step left to temp_text_str[0] location to do left shifting
            for(cur_temp_index = 0; cur_temp_index < (int)(running_text_str_len - cur_char_in_str_index); ++cur_temp_index)
            {
			   if(cur_temp_index <  (int)(running_text_str_len - 1 - cur_char_in_str_index))
                   temp_text_str[(unsigned int) cur_temp_index] = temp_text_str[(unsigned int)(cur_temp_index + 1)];
			  // cur_temp_index = (running_text_str_len - cur_char_in_str_index - 1) and temp_text_str[cur_temp_index] = 0 to insert space 
               else
				  temp_text_str[(unsigned int) cur_temp_index] = 0; 
            }
			 ++cur_char_in_str_index;
         }
		 else
		 {
			line1_text_disp_finish_flag = STATE_YES;             		
		 }			 
       break;	
       	//Shift entire line number 1 display to right. logic is same as NO_FIXED_TEXT_SHIFT_DISP_LEFT and inverted so you can refer the above. 	   
       case NO_FIXED_TEXT_SHIFT_DISP_RIGHT:   
          if(cur_char_in_str_index < (int)(running_text_str_len + num_gaps_between_running_text_str))
          {
               Data_Str_LCD_Disp(lcd_buffer_line1, MAX_AVAIL_NUM_COLS, NUM_LINE1);
               for(cur_lcd_col = (int)(MAX_AVAIL_NUM_COLS - 1); cur_lcd_col >= 0; --cur_lcd_col)
               {
                   if(cur_lcd_col != 0)
				     lcd_buffer_line1[(unsigned int)cur_lcd_col] = lcd_buffer_line1[(unsigned int)(cur_lcd_col - 1)]; 						
				   else
					 lcd_buffer_line1[(unsigned int)cur_lcd_col] = temp_text_str[(unsigned int)(running_text_str_len - 1)]; 
               }
               for(cur_temp_index = (int) (running_text_str_len - 1 ); cur_temp_index >= cur_char_in_str_index; --cur_temp_index)
               {
                   if(cur_temp_index > cur_char_in_str_index )
				     temp_text_str[(unsigned int) cur_temp_index] = temp_text_str[(unsigned int)(cur_temp_index - 1)];
				   else
					 // cur_temp_index = (cur_char_in_str_index ) and temp_text_str[cur_temp_index] =  0 to insert space    
					 temp_text_str[(unsigned int) cur_temp_index] = 0; 
               }
			   ++cur_char_in_str_index;
          }
		  else
		  {
			  line1_text_disp_finish_flag = STATE_YES;               	  
		  }
	   break;
	   case FIXED_TEXT_LEFT_SHIFT_DISP_LEFT:
	   
	   break;
	   case FIXED_TEXT_LEFT_SHIFT_DISP_RIGHT:
	   break;
	   case FIXED_TEXT_RIGHT_SHIFT_DISP_LEFT:
	   break;
	   case FIXED_TEXT_RIGHT_SHIFT_DISP_RIGHT:
	   break;
	   default:
	    /* error: invalid */
	     ;
    }
}	 
 
void LCD_Running_Text_Display_Line2(const char *fixed_text_str, const unsigned int fixed_text_str_len, const char *running_text_str, \
  const unsigned int running_text_str_len, const unsigned int num_gaps_between_running_text_str, const unsigned int running_text_shift_direction)
{
   // keeping temp_text_str buffer custom for different string lengths is safe. 
	static char temp_text_str[MAX_NUM_CHARS_IN_TEXT]; 
	static int cur_char_in_str_index = 0;
	int cur_lcd_col, cur_temp_index;
	
	if(line2_text_disp_finish_flag == STATE_YES)
	{
	   //copy string into temp_text_str buffer up to the string length
        memcpy(temp_text_str, running_text_str, running_text_str_len); 
		cur_char_in_str_index = 0;	
	    line2_text_disp_finish_flag = STATE_NO;
	}  
	switch(running_text_shift_direction)
	{
		// running_text_shift_direction = LEFT  
	   case NO_FIXED_TEXT_SHIFT_DISP_LEFT:    
          //whole shifting length = running_text_str_len + num_gaps_between_running_text_str
         if( cur_char_in_str_index < (int)(running_text_str_len + num_gaps_between_running_text_str)) 
         {
		    // display lcd_buffer_line1, we use MAX_AVAIL_NUM_COLS as length because we are shifting entire line num 2 in LCD to left 
            Data_Str_LCD_Disp(lcd_buffer_line2, MAX_AVAIL_NUM_COLS, NUM_LINE2 ); 
            for(cur_lcd_col = 0; cur_lcd_col < (int) MAX_AVAIL_NUM_COLS; ++cur_lcd_col)
            {
			   // Left shifting
			   if(cur_lcd_col != (int)(MAX_AVAIL_NUM_COLS - 1))
                  lcd_buffer_line2[(unsigned int)cur_lcd_col] = lcd_buffer_line2[(unsigned int)(cur_lcd_col + 1)]; 
			   // entering first temp_text_str[0] value at the end to do left shift into lcd_buffer_line2
               else
				  //cur_lcd_col = (MAX_AVAIL_NUM_COLS - 1) 
				  lcd_buffer_line2[(unsigned int)cur_lcd_col] = temp_text_str[0]; 
            } 
			// shifting of temp_text_str also needed to get all values step by step left to temp_text_str[0] location to do left shifting
            for(cur_temp_index = 0; cur_temp_index < (int)(running_text_str_len - cur_char_in_str_index); ++cur_temp_index)
            {
			   if(cur_temp_index <  (int)(running_text_str_len - 1 - cur_char_in_str_index))
                   temp_text_str[(unsigned int) cur_temp_index] = temp_text_str[(unsigned int)(cur_temp_index + 1)];
			  // cur_temp_index = (running_text_str_len - cur_char_in_str_index - 1) and temp_text_str[cur_temp_index] = 0 to insert space 
               else
				  temp_text_str[(unsigned int) cur_temp_index] = 0; 
            }
			 ++cur_char_in_str_index;
         }
		 else
		 {
			line2_text_disp_finish_flag = STATE_YES;            		
		 }			 
       break;		
       //RIGHT running_text_shift_direction select (logic is same and inverted for running_text_shift_direction so you can refer the above. 	   
       case NO_FIXED_TEXT_SHIFT_DISP_RIGHT:   
          if(cur_char_in_str_index < (int)(running_text_str_len + num_gaps_between_running_text_str))
          {
               Data_Str_LCD_Disp(lcd_buffer_line2, MAX_AVAIL_NUM_COLS, NUM_LINE2);
               for(cur_lcd_col = (int)(MAX_AVAIL_NUM_COLS - 1); cur_lcd_col >= 0; --cur_lcd_col)
               {
                   if(cur_lcd_col != 0)
				     lcd_buffer_line2[(unsigned int)cur_lcd_col] = lcd_buffer_line2[(unsigned int)(cur_lcd_col - 1)]; 						
				   else
					 lcd_buffer_line2[(unsigned int)cur_lcd_col] = temp_text_str[(unsigned int)(running_text_str_len - 1)]; 
               }
               for(cur_temp_index = (int) (running_text_str_len - 1 ); cur_temp_index >= cur_char_in_str_index; --cur_temp_index)
               {
                   if(cur_temp_index > cur_char_in_str_index )
				     temp_text_str[(unsigned int) cur_temp_index] = temp_text_str[(unsigned int)(cur_temp_index - 1)];
				   else
					 // cur_temp_index = (cur_char_in_str_index ) and temp_text_str[cur_temp_index] =  0 to insert space    
					 temp_text_str[(unsigned int) cur_temp_index] = 0; 
               }
			   ++cur_char_in_str_index;
          }
		  else
		  {
			  line2_text_disp_finish_flag = STATE_YES;               	  
		  }
	   break;
    }   
} 

void LCD_Write_Pulse(unsigned long int time_delay)
{
   EN_PIN = 1;
   Delay_Time_By_Count(time_delay);
   EN_PIN = 0;
   Delay_Time_By_Count(time_delay);
}
void Delay_Time_By_Count(unsigned long int time_delay )
{
    while(time_delay--);
}
void LCD_Write_Command()
{
    RS_PIN = 0;
    RW_PIN = 0;       
}

void LCD_Write_Data()
{
    RS_PIN = 1;
    RW_PIN = 0;       
}
void LCD_Clear()
{
    LCD_Write_Command();
    LCD_PORT = 0x01;
    LCD_Write_Pulse(LCD_ENABLE_PULSE_WIDTH);    
}
 //Lcd line sel
void LCD_Line_Select(const unsigned int line)   
{
     LCD_Write_Command();
	 //Set cursor on line 1  
     switch(line)
     {
        case NUM_LINE1:
    	   LCD_PORT = BEGIN_LOC_LINE1; 
           LCD_Write_Pulse(LCD_ENABLE_PULSE_WIDTH);
		break;  
		//Set cursor on line 2
        case NUM_LINE2:  
	       LCD_PORT = BEGIN_LOC_LINE2;    
           LCD_Write_Pulse(LCD_ENABLE_PULSE_WIDTH);
		break;   
     }  
 }
 
 //write string of length on line
 void Data_Str_LCD_Disp(const char *running_text_str, const unsigned int running_text_str_len, const unsigned int line)
 {
     unsigned int cur_char_in_text_str_index;
	 
	 //Lcd line sel
     LCD_Line_Select(line);    
     LCD_Write_Data();
     for( cur_char_in_text_str_index = 0; cur_char_in_text_str_index < running_text_str_len; ++cur_char_in_text_str_index)
     {
         LCD_PORT = running_text_str[cur_char_in_text_str_index];
         LCD_Write_Pulse(LCD_ENABLE_PULSE_WIDTH);
     }     
 }
 
void LCD_Init()
{
    Delay_Time_By_Count(1500);
    LCD_Write_Command();    
    LCD_PORT = 0x30;      //function set, 2 lines, 8 bit and 5 * 7 dot matrix
    LCD_Write_Pulse(LCD_ENABLE_PULSE_WIDTH);
    LCD_PORT = 0x30;      //function set, 2 lines, 8 bit and 5 * 7 dot matrix
    LCD_Write_Pulse(LCD_ENABLE_PULSE_WIDTH);
    LCD_PORT = 0x30;      //function set, 2 lines, 8 bit and 5 * 7 dot matrix
    LCD_Write_Pulse(LCD_ENABLE_PULSE_WIDTH);
    LCD_PORT = 0x38;      //function set, 2 lines, 8 bit and 5 * 7 dot matrix
    LCD_Write_Pulse(LCD_ENABLE_PULSE_WIDTH);    
    LCD_PORT = 0x0C;     //display on,cursor off,blink off
    LCD_Write_Pulse(LCD_ENABLE_PULSE_WIDTH);      
    LCD_PORT = 0x01;    //clear display
    LCD_Write_Pulse(LCD_ENABLE_PULSE_WIDTH);    
    LCD_PORT = 0x06;    //entry mode, set increment 
    LCD_Write_Pulse(LCD_ENABLE_PULSE_WIDTH);        
}
