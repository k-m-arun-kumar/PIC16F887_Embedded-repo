/**************************************************************************
   FILE          :    text_oper.h
 
   PURPOSE       :    text_oper.c Header
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :  
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 #ifndef _TEXT_OPER_H
 #define _TEXT_OPER_H
 
 #define MAX_NUM_CHARS_IN_TEXT (30U)
 
#define ENTER_SW_CODE         'E'
#define RESET_SW_CODE         'S'
#define BACKSPACE_SW_CODE     'B'
#define DELETE_SW_CODE        'D'
#define INSERT_SW_CODE        'I'
#define LEFT_SW_CODE          'L'
#define RIGHT_SW_CODE         'R'

void After_Key_Stoke_Proc(const char pressed_key);
void After_Switch_Stoke_Proc(const char pressed_key);
void Entered_Key_No_Long_Press_Proc(const char pressed_key);
void Entered_Backspace_Sw_No_Long_Press_Proc();
void LCD_Line_Select(const unsigned int line);
void LCD_Text_Display(char *text_str, unsigned int *ptr_text_str_len, const unsigned int running_text_shift_direction);
void Data_Str_LCD_Disp(const char *text_str, const unsigned int text_str_len, const unsigned int line);
void Reset_Process();
void Is_Numchars_Within_Limit();
 #endif
 
 /*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
