/**************************************************************************
   FILE          :    text_oper.c
 
   PURPOSE       :    text_oper  
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :  
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 #include "main.h"
 #include "port.h"
 #include "text_oper.h"
 #include "lcd.h"
 #include "string.h"

#define SHIFT_DISP_LEFT   (0U)
#define SHIFT_DISP_RIGHT  (1U)

 // Ring Buffer for Line 1 
char lcd_buffer_line1[MAX_AVAIL_NUM_COLS]; 
// Ring Buffer for Line 2 
char lcd_buffer_line2[MAX_AVAIL_NUM_COLS]; 

char entered_cur_input_data[MAX_NUM_CHARS_IN_TEXT + 1], cur_pressed_key_or_sw = 0;
unsigned int num_chars_entered_cur_data, cursor_pos_line_num = 1, cursor_pos_col_num = 1, line1_num_chars, line2_num_chars;

extern unsigned int cur_input_lcd_loc;
extern char lcd_avail_loc_within_limit, key_or_sw_input_enable_flag, keypad_keys_enable_flag, max_input_num_chars_flag, cur_data_can_also_input_nonnum_key, \
  enter_sw_enable_flag, backspace_sw_enable_flag,delete_sw_enable_flag, insert_sw_enable_flag, left_sw_enable_flag, right_sw_enable_flag, reset_sw_enable_flag;

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 11  
-*------------------------------------------------------------*/ 
void LCD_Text_Display(char *text_str, unsigned int *ptr_text_str_len, const unsigned int running_text_shift_direction) 
{
    // keeping temp_text_str buffer custom for different string lengths is safe. 
	char temp_text_str[MAX_NUM_CHARS_IN_TEXT]; 
	int cur_char_in_str_index = 0;
	int cur_lcd_col, cur_temp_index;
	//copy string into temp_text_str buffer up to the string length
    memcpy(temp_text_str, text_str, *ptr_text_str_len); 
		
	switch(running_text_shift_direction)
	{
		// running_text_shift_direction = LEFT  
	   case SHIFT_DISP_LEFT:    
          //whole shifting length = *ptr_text_str_len + num_gaps_between_text_str
         for( cur_char_in_str_index = 0; cur_char_in_str_index < (int)(*ptr_text_str_len ); ++cur_char_in_str_index ) 
         {
		    // display lcd_buffer_line1, we use MAX_AVAIL_NUM_COLS as length because we are shifting entire line num 1 in LCD to left 
            Data_Str_LCD_Disp(lcd_buffer_line1, MAX_AVAIL_NUM_COLS, NUM_LINE1 ); 
            for(cur_lcd_col = 0; cur_lcd_col < (int) MAX_AVAIL_NUM_COLS; ++cur_lcd_col)
            {
			   // Left shifting
			   if(cur_lcd_col != (int)(MAX_AVAIL_NUM_COLS - 1))
                  lcd_buffer_line1[(unsigned int)cur_lcd_col] = lcd_buffer_line1[(unsigned int)(cur_lcd_col + 1)]; 
			   // entering first temp_text_str[0] value at the end to do left shift into lcd_buffer_line1
               else
				  //cur_lcd_col = (MAX_AVAIL_NUM_COLS - 1) 
				  lcd_buffer_line1[(unsigned int)cur_lcd_col] = temp_text_str[0]; 
            } 
			// shifting of temp_text_str also needed to get all values step by step left to temp_text_str[0] location to do left shifting
            for(cur_temp_index = 0; cur_temp_index < (int)(*ptr_text_str_len - cur_char_in_str_index); ++cur_temp_index)
            {
			   if(cur_temp_index <  (int)(*ptr_text_str_len - 1 - cur_char_in_str_index))
                   temp_text_str[(unsigned int) cur_temp_index] = temp_text_str[(unsigned int)(cur_temp_index + 1)];
			  // cur_temp_index = (*ptr_text_str_len - cur_char_in_str_index - 1) and temp_text_str[cur_temp_index] = 0 to insert space 
               else
				  temp_text_str[(unsigned int) cur_temp_index] = 0; 
            }
         }		 
       break;		
       //RIGHT running_text_shift_direction select (logic is same and inverted for running_text_shift_direction so you can refer the above. 	   
       case SHIFT_DISP_RIGHT:   
          for(cur_char_in_str_index = 0; cur_char_in_str_index < (int)(*ptr_text_str_len);  ++cur_char_in_str_index)
          {
               Data_Str_LCD_Disp(lcd_buffer_line1, MAX_AVAIL_NUM_COLS, NUM_LINE1);
               for(cur_lcd_col = (int)(MAX_AVAIL_NUM_COLS - 1); cur_lcd_col >= 0; --cur_lcd_col)
               {
                   if(cur_lcd_col != 0)
				     lcd_buffer_line1[(unsigned int)cur_lcd_col] = lcd_buffer_line1[(unsigned int)(cur_lcd_col - 1)]; 						
				   else
					 lcd_buffer_line1[(unsigned int)cur_lcd_col] = temp_text_str[(unsigned int)(*ptr_text_str_len - 1)]; 
               }
               for(cur_temp_index = (int) (*ptr_text_str_len - 1 ); cur_temp_index >= cur_char_in_str_index; --cur_temp_index)
               {
                   if(cur_temp_index > cur_char_in_str_index )
				     temp_text_str[(unsigned int) cur_temp_index] = temp_text_str[(unsigned int)(cur_temp_index - 1)];
				   else
					 // cur_temp_index = (cur_char_in_str_index ) and temp_text_str[cur_temp_index] =  0 to insert space    
					 temp_text_str[(unsigned int) cur_temp_index] = 0; 
               }
          }
	   break;
    }
}	 

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 11  
-*------------------------------------------------------------*/
void Entered_Key_No_Long_Press_Proc(const char key_data)
{
	/* make sure that entered key is within max available lcd loc and line, currently cur_data_input_max_num_chars_allocated 
	 sures that entered key is within max available lcd loc and within max line */
	 unsigned int cur_input_loc_line_num, cur_input_loc_col_num, next_input_loc_line_num, next_input_loc_col_num;
	
       Write_LCD_Command(cur_input_lcd_loc);
	  
	   Write_LCD_Command(0x0E);// insert cursor on at cur_input_lcd_loc
	   // Write_LCD_Command(0x0C);
        Write_LCD_Data(key_data);
       
	    From_Loc_to_XY_LCD(cur_input_lcd_loc, &cur_input_loc_line_num, &cur_input_loc_col_num);
	    if(cur_input_loc_line_num == CONFIGURE_MAX_NUM_LINES && cur_input_loc_col_num == CONFIGURE_MAX_NUM_COLS)
	    {	 
	    	/* warning: reached  end of max configured line and valid key is pressed, retain same loc position */ 
		
	    }
	    else
	    {
		   /* put cur input lcd loc to next location */
		   if(cur_input_loc_col_num == CONFIGURE_MAX_NUM_COLS)
		   {	 
		    	next_input_loc_line_num = cur_input_loc_line_num + 1;
			   next_input_loc_col_num = NUM_COL1;
		   }
           else
           {
		      next_input_loc_line_num = cur_input_loc_line_num;
			  next_input_loc_col_num = cur_input_loc_col_num + 1;
		   }	
		   From_XY_To_Loc_LCD(next_input_loc_line_num, next_input_loc_col_num, &cur_input_lcd_loc);
		 
           entered_cur_input_data[num_chars_entered_cur_data] = key_data;   
           ++num_chars_entered_cur_data; 
	   }   		 
	  /* keep track of cur_input_lcd_loc as baskspace we need to -- it and also disp timeouts with.
 	  LCD automatically increments due to loc_command(0x06)in our case as after eg Write_LCD_Command(0x80)
	  ie set DDRAM */      
      enter_sw_enable_flag = STATE_YES;
      backspace_sw_enable_flag = STATE_YES;	 
}
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 12   
-*------------------------------------------------------------*/
void Entered_Backspace_Sw_No_Long_Press_Proc()
{
	unsigned int cur_input_loc_line_num, cur_input_loc_col_num, previous_input_loc_line_num, previous_input_loc_col_num;
       	
    if(num_chars_entered_cur_data > 0 && num_chars_entered_cur_data <= MAX_NUM_CHARS_IN_TEXT )
    {
	    From_Loc_to_XY_LCD(cur_input_lcd_loc, &cur_input_loc_line_num, &cur_input_loc_col_num);
	   if(cur_input_loc_line_num == NUM_LINE1 && cur_input_loc_col_num == NUM_COL1)
	   {	 
		 /* reached begin of line 1 and valid backspace is pressed, retain same loc position */ 
	   }
	   else
	   {
		 /* put cur input lcd loc to one location back from current loc */
		 if(cur_input_loc_col_num == NUM_COL1)
		 {	 
			 previous_input_loc_line_num = cur_input_loc_line_num - 1;
			 previous_input_loc_col_num = CONFIGURE_MAX_NUM_COLS;
		 }
         else
         {
			 previous_input_loc_line_num = cur_input_loc_line_num;
			 previous_input_loc_col_num = cur_input_loc_col_num - 1;
		 }	
		 From_XY_To_Loc_LCD(previous_input_loc_line_num, previous_input_loc_col_num, &cur_input_lcd_loc);
		 
         /* do clear last char operation */
		 entered_cur_input_data[num_chars_entered_cur_data] = '\0'; 
		  /* to get key at previous location */
         Write_LCD_Command(cur_input_lcd_loc);
         --num_chars_entered_cur_data;
         Write_LCD_Data(' '); 
         Write_LCD_Command(0x10); //shift cursor to left  	 
           		
	  }  
	  Write_LCD_Command(cur_input_lcd_loc);
      Write_LCD_Command(0x0E);	
   }
}        
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 5   
-*------------------------------------------------------------*/  
void After_Switch_Stoke_Proc(const char pressed_sw)
{
	switch(pressed_sw)
	{
		case ENTER_SW_CODE:
		 /*  Process for valid Enter sw stroke */
		   if(num_chars_entered_cur_data > 0)
		   {
			  entered_cur_input_data[num_chars_entered_cur_data] = '\0';
			  enter_sw_enable_flag = STATE_NO;
	          backspace_sw_enable_flag = STATE_NO;
			  reset_sw_enable_flag = STATE_YES;
			  /* display data */
              memset(entered_cur_input_data, sizeof(entered_cur_input_data)/sizeof(char), '\0');
              num_chars_entered_cur_data = 0;
		   }  
        break;
        case BACKSPACE_SW_CODE:				  
		  /* Process for valid Backspace */
		  if(num_chars_entered_cur_data > 0)
		  {
               Entered_Backspace_Sw_No_Long_Press_Proc();			  
          } 				 
        break;
		case DELETE_SW_CODE:
		break;
		case INSERT_SW_CODE:
		break;
		case RIGHT_SW_CODE:
		break;
		case LEFT_SW_CODE:
		break;
        case RESET_SW_CODE:
		  /* process for reset sw operations */
           Reset_Process();		  
        break;
        default:
			 /* error: invalid sw code received */
           ;	 
	}
}	
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 10  
-*------------------------------------------------------------*/
void Is_Numchars_Within_Limit()
{
 	if(num_chars_entered_cur_data < MAX_NUM_CHARS_IN_TEXT)
        max_input_num_chars_flag = STATE_NO;
     else
	 {
        max_input_num_chars_flag = STATE_YES; 
		/* warning:  num of input data chars has reached max num of chars allocated for cur input data  */
     }  
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 10  
-*------------------------------------------------------------*/
// LCD line select 
void LCD_Line_Select(const unsigned int line)    
{
     switch(line)
	 {
		 //Set cursor at begin of line 1 ie DDRAM address 
		case NUM_LINE1:
           Write_LCD_Command(BEGIN_LOC_LINE1);    
        break;
		 //Set cursor at begin of line 2 ie DDRAM address 
        case NUM_LINE2:		
           Write_LCD_Command(BEGIN_LOC_LINE2);   
        break;
	 }	
 }
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 10  
-*------------------------------------------------------------*/
 //write string of length on line
 void Data_Str_LCD_Disp(const char *lcd_line_buffer, const unsigned int lcd_line_buffer_len, const unsigned int line) 
 {
     unsigned int cur_char_in_text_str_index;
	 
	 // LCD line select 
     LCD_Line_Select(line);    
     for(cur_char_in_text_str_index = 0; cur_char_in_text_str_index < lcd_line_buffer_len; ++cur_char_in_text_str_index)
     {
        Write_LCD_Data(lcd_line_buffer[cur_char_in_text_str_index]);         
     }     
 }
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 3   
-*------------------------------------------------------------*/
void Reset_Process()
{
    max_input_num_chars_flag = STATE_NO;
    memset(entered_cur_input_data, sizeof(entered_cur_input_data)/sizeof(char), '\0');
    num_chars_entered_cur_data = 0; 
    key_or_sw_input_enable_flag =STATE_YES;
    lcd_avail_loc_within_limit = STATE_YES;
    reset_sw_enable_flag = STATE_YES;
    enter_sw_enable_flag = STATE_NO;
    backspace_sw_enable_flag = STATE_NO;
    keypad_keys_enable_flag = STATE_YES;
	right_sw_enable_flag = STATE_NO;
	left_sw_enable_flag = STATE_NO;
	insert_sw_enable_flag = STATE_YES;
	delete_sw_enable_flag = STATE_NO;
    memset(lcd_buffer_line1, 0, MAX_AVAIL_NUM_COLS ); 
	memset(lcd_buffer_line2, 0, MAX_AVAIL_NUM_COLS ); 
    cursor_pos_line_num = 1;
    cursor_pos_col_num = 1;
    line1_num_chars = 0;
    line2_num_chars = 0;
    Write_LCD_Command(0x01); //clear display
	Goto_XY_LCD_Input(NUM_LINE1, NUM_COL1);
    Write_LCD_Command(0x0E); // display on , cursor and blinking OFF
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
