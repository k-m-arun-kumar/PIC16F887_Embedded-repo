/**************************************************************************
   FILE          :    port.h
 
   PURPOSE       :    port header - define port and its pin assignment.
 
   AUTHOR        :     K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :    port header - user interface to external device, such as LED, Switch,
 	connection to other microcontroller via RS232, USB, etc. 
 To avoid this header file to be included more than once, conditional directive is used  
	
  CHANGE LOGS     :  
	   
 **************************************************************************/
#ifndef _PORT_H
#define _PORT_H

#define  KEYPAD_PHONE_COL1    RA0
#define  KEYPAD_PHONE_COL2    RA1
#define  KEYPAD_PHONE_COL3    RA2
#define  KEYPAD_PHONE_ROWA    RA3
#define  KEYPAD_PHONE_ROWB    RA4
#define  KEYPAD_PHONE_ROWC    RA5
#define  KEYPAD_PHONE_ROWD    RA6

#define RESET_SW              RA7
#define BACKSPACE_SW          RC0
#define DELETE_SW             RC1
#define INSERT_SW             RC2
#define ENTER_SW              RC3
#define RIGHT_CURSOR_SW       RC4
#define LEFT_CURSOR_SW        RC5

#define RS_PIN                RE0
#define RW_PIN                RE1
#define EN_PIN                RE2

#define LCD_PORT              PORTD
#define LCD_PORT_GPIO         TRISD 
#endif 

/*------------------------------------------------------------------*-
  ---------------------- END OF FILE --------------------------------
-*------------------------------------------------------------------*/
