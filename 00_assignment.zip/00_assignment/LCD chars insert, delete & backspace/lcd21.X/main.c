/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    : In LCD, use delete, backspace and insert operation by using DELETE_SW, BACKSPACE_SW and INSERT_SW switches respectively
  at text, which is displayed in LCD. Max number of chars in text should be equal 30 in the LCD. Text is entered through keypad. 
	 
AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  : 
                       										
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "main.h"
#include "port.h"
#include "text_oper.h"
#include "lcd.h"
#include "string.h"

extern char lcd_buffer_line1[];
extern char lcd_buffer_line2[];

char key_or_sw_input_enable_flag = STATE_YES, backspace_sw_enable_flag = STATE_NO, delete_sw_enable_flag = STATE_NO, insert_sw_enable_flag = STATE_YES, \
        enter_sw_enable_flag = STATE_NO ,reset_sw_enable_flag = STATE_YES, right_sw_enable_flag = STATE_NO, left_sw_enable_flag = STATE_NO, \
        cur_data_can_also_input_nonnum_key = STATE_YES, keypad_keys_enable_flag = STATE_YES, max_input_num_chars_flag = STATE_NO;
		
extern char cur_pressed_key_or_sw;

/*------------------------------------------------------------*-
FUNCTION NAME  : main

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 
-*------------------------------------------------------------*/

void main()
{
	char keypad_char[]   = {'1','2', '3', '4', '5', '6','7','8','9','*', '0', '#'};
	
    TRISA = 0x87;
	PORTA = 0x00;
	TRISB = 0x00;
	PORTB = 0x00;
    TRISC = 0xBF;
	PORTC = 0x00;
    LCD_PORT_GPIO = 0x00;
	LCD_PORT = 0x00;
	TRISE = 0x03;
	PORTE = 0x00;
    ANSEL = 0x00;
	ANSELH = 0x00;
	
    LCD_Init();
	// Flush buffers before starting something new on it
    memset(lcd_buffer_line1, 0, MAX_AVAIL_NUM_COLS ); 
	memset(lcd_buffer_line2, 0, MAX_AVAIL_NUM_COLS ); 
	
   	Goto_XY_LCD_Input(NUM_LINE1, NUM_COL1);
	Write_LCD_Command(0x0E);
	
    for(;;)
    {
		
    if(key_or_sw_input_enable_flag == STATE_YES)
    { 
        Is_Numchars_Within_Limit();  
	    KEYPAD_PHONE_ROWA = 1;
        KEYPAD_PHONE_ROWB  = 0;
        KEYPAD_PHONE_ROWC  = 0;
        KEYPAD_PHONE_ROWD  = 0; 
        if(KEYPAD_PHONE_COL1 == KEY_PRESSED)
        {
	         cur_pressed_key_or_sw = keypad_char[0];//latest pressed key/switch					 
	         if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
             {	
		 
			      Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw); 					
		     } 		  
        }
        if(KEYPAD_PHONE_COL2 == KEY_PRESSED)
        {
		    cur_pressed_key_or_sw = keypad_char[1];//latest pressed key/switch
		    if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
            {
		         Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw);					
		    } 		  
        } 
        if(KEYPAD_PHONE_COL3 == KEY_PRESSED)
        {
	        cur_pressed_key_or_sw = keypad_char[2];//latest pressed key/switch					
	        if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
            {
		      	Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw);				
		    } 		  
        } 
        KEYPAD_PHONE_ROWA = 0;
        KEYPAD_PHONE_ROWB  = 1;
        KEYPAD_PHONE_ROWC  = 0;
        KEYPAD_PHONE_ROWD  = 0; 
        if(KEYPAD_PHONE_COL1 == KEY_PRESSED)
        {
		    cur_pressed_key_or_sw = keypad_char[3];//latest pressed key/switch					  
		    if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
            {
		        Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw);					
		    } 		  
        } 
        if(KEYPAD_PHONE_COL2 == KEY_PRESSED)
        {
	        cur_pressed_key_or_sw = keypad_char[4];//latest pressed key/switch					  
            if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
            {
		        Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw);					
		    } 		  
        } 
        if(KEYPAD_PHONE_COL3 == KEY_PRESSED)
        {
	        cur_pressed_key_or_sw = keypad_char[5];//latest pressed key/switch					  
	        if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
            {
		      	Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw);						
		    } 		  
        }  
        KEYPAD_PHONE_ROWA = 0;
        KEYPAD_PHONE_ROWB  = 0;
        KEYPAD_PHONE_ROWC  = 1;
        KEYPAD_PHONE_ROWD  = 0; 
        if(KEYPAD_PHONE_COL1 == KEY_PRESSED)
        {
	      	cur_pressed_key_or_sw = keypad_char[6];//latest pressed key/switch
			if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
            {
		       Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw);						
		    } 		  
        } 
        if(KEYPAD_PHONE_COL2 == KEY_PRESSED)
        {
	        cur_pressed_key_or_sw = keypad_char[7];//latest pressed key/switch					 
	        if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
            {
	            Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw);				
	        } 		  
        } 
        if(KEYPAD_PHONE_COL3 == KEY_PRESSED)
        {
	        cur_pressed_key_or_sw = keypad_char[8];//latest pressed key/switch
	        if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
            {
	        	Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw);					
		    } 		  
        } 
        KEYPAD_PHONE_ROWA = 0;
        KEYPAD_PHONE_ROWB  = 0;
        KEYPAD_PHONE_ROWC  = 0;
        KEYPAD_PHONE_ROWD  = 1; 
        if(KEYPAD_PHONE_COL1 == KEY_PRESSED)
        {
	       cur_pressed_key_or_sw = keypad_char[9];//latest pressed key/switch
		   if(keypad_keys_enable_flag == STATE_YES && cur_data_can_also_input_nonnum_key == STATE_YES && max_input_num_chars_flag ==STATE_NO )
           {
	            Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw);					
		   } 		  
        } 
        if(KEYPAD_PHONE_COL2 == KEY_PRESSED)
        {
		    cur_pressed_key_or_sw = keypad_char[10];//latest pressed key/switch
		    if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
            {
		       	Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw);			
		    } 		  
        }                                               
        if(KEYPAD_PHONE_COL3 == KEY_PRESSED)
        {
			cur_pressed_key_or_sw = keypad_char[11];//latest pressed key/switch
        	if(keypad_keys_enable_flag == STATE_YES && cur_data_can_also_input_nonnum_key == STATE_YES && max_input_num_chars_flag ==STATE_NO )
            {
		       	Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw);					
		    } 		  
        }    
        if(ENTER_SW == KEY_PRESSED)
        {
	     	 cur_pressed_key_or_sw = ENTER_SW_CODE;//latest pressed key/switch
		    if(enter_sw_enable_flag == STATE_YES)
			{	 
	            max_input_num_chars_flag = STATE_NO;
				After_Switch_Stoke_Proc(cur_pressed_key_or_sw); 	      		 
            }
		}							 
        if(BACKSPACE_SW == KEY_PRESSED )		 
        {
            cur_pressed_key_or_sw = BACKSPACE_SW_CODE;//latest pressed key/switch
		  	if(backspace_sw_enable_flag == STATE_YES)
		    {
				After_Switch_Stoke_Proc(cur_pressed_key_or_sw); 
            }					  
        }
		if(DELETE_SW == KEY_PRESSED )		 
        {
            cur_pressed_key_or_sw = DELETE_SW_CODE;//latest pressed key/switch
		  	if(delete_sw_enable_flag == STATE_YES)
		    {
				After_Switch_Stoke_Proc(cur_pressed_key_or_sw); 
            }					  
        }
		if(INSERT_SW == KEY_PRESSED )		 
        {
            cur_pressed_key_or_sw = INSERT_SW_CODE;//latest pressed key/switch
		  	if(insert_sw_enable_flag == STATE_YES)
		    {
				After_Switch_Stoke_Proc(cur_pressed_key_or_sw); 
            }					  
        }
		if(LEFT_CURSOR_SW == KEY_PRESSED )
        {
	        cur_pressed_key_or_sw = LEFT_SW_CODE;//latest pressed key/switch
		    if(left_sw_enable_flag == STATE_YES)
			{	  
	             After_Switch_Stoke_Proc(cur_pressed_key_or_sw);
            }		
        }
		if(RIGHT_CURSOR_SW == KEY_PRESSED )
        {
	        cur_pressed_key_or_sw = RIGHT_SW_CODE; //latest pressed key/switch
		    if(right_sw_enable_flag == STATE_YES)
			{	  
	             After_Switch_Stoke_Proc(cur_pressed_key_or_sw);
            }		
        }
        if(RESET_SW == KEY_PRESSED )
        {
	        cur_pressed_key_or_sw = RESET_SW_CODE;//latest pressed key/switch
		    if(reset_sw_enable_flag == STATE_YES)
			{	  
	             After_Switch_Stoke_Proc(cur_pressed_key_or_sw);
            }		
        }
    }	   
    } 
}

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/	 
