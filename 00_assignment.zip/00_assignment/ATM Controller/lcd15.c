/* ********************************************************************
FILE                   : lcd15.c

PROGRAM DESCRIPTION    :  a preset PIN and account number is set by default in code.
Entered password in keypad is displayed in  LCD. Use RESET_SW to reset Process, if any problem arises and start afresh. 
USe Enter SW to end input and entered data is at end.
  At first Welcome message to be displayed, when ACCOUNT_SW is pressed, account number is entered.
If entered account number is correct, then ask for PIN  and if entered PIN is correct,
then display . If account number is incorrect and ask to reenter account number.
After 3 failed iteration on entered account number, stop reenter of account number and display visit bank. 
If no key is pressed for longer duration or key has been pressed for long duration, display timeout and display visit bank.
After 3 failed iteration on entered PIN number,stop reenter of PIN number and display visit bank.
After displayed Auth Status, wait for predetermined time, and then display welcome message and wait for ACCOUNT_SW to be pressed to enter account number.
After that RESET_SW is pressed to restart the process, if any problem arises. 
Used Timer0(executes key stoke proc ) and Timer1 (executes long key press proc and no key press proc ) with status check . 
Cannot do when both timer uses status check for timer expiry as processor loops for timer to expiry,
 when expired for predefined time executes Appl(auth fsm) proc, which does waiting for key stroke,
 without timer for no key stroke you can do decrement count, when count ends timeout for no key press has happened.
You can do when 2 timers are used and 1 timer or no timer uses status check for timer expiry and rest uses interrupt.

Used Timer0(executes  Key Press) and Timer1 (executes Long_Key_Press_Proc) with status check. 
Cannot do when both timer uses status check for timer expiry as processor loops for timer to expiry,
 when expired for predefined time executes Appl(auth fsm) proc, which does waiting for key stroke,
 without timer for no key stroke you can do decrement count, when count ends timeout for no key press has happened.
You can do when 2 timers are used and 1 timer or no timer uses status check for timer expiry and rest uses interrupt 

AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : fix issue of timer to get precise time using timer. Use PIC16F887-repo->05_timer->timer17.X->timer.c as base code to get precise time using timer.

NOTE                  : CODE MODIFICATED WITH BASE FROM PIC16F887-repo->00_assignment->Single Account auth
 
USED                  :    
                       
CHANGE LOGS           : 

*****************************************************************************/   

#define HI_TECH_COMPILER
#ifdef HI_TECH_COMPILER
  #include <pic.h>
  __CONFIG(0x2CE4);
#else // XC8 compiler
  #include <xc.h>
#endif

#include <string.h>


#define MAX_ROW_KEYPAD              4
#define MAX_COL_KEYPAD              3
#define  KEYPAD_PHONE_COL1  RA0
#define  KEYPAD_PHONE_COL2  RA1
#define  KEYPAD_PHONE_COL3  RA2
#define  KEYPAD_PHONE_ROWA RA3
#define  KEYPAD_PHONE_ROWB RA4
#define  KEYPAD_PHONE_ROWC RA5
#define  KEYPAD_PHONE_ROWD RA6

#define  LONG_PRESS_KEY_LED_PIN           RA7  
#define  NO_KEY_PRESS_LED_PIN             RE0 
#define  INTERNAL_ERROR_LED_PIN           RE1 

#define RS_PIN                                 RD0
#define RW_PIN                                 RD1
#define EN_PIN                                 RD2

#define ENTER_SW                               RD3
#define RESET_SW                               RD4 
#define BACKSPACE_SW                           RD5 
#define ACCOUNT_SW                             RD6
                                                      
#define LCD_PORT                              PORTC

#define LED_OFF                                  (0)
#define LED_ON                                   (1)  
#define KEY_PRESSED                              (1) 
#define KEY_NOT_PRESSED                          (0)
#define STATE_YES                               ('y')
#define STATE_NO                                ('n')  
/* should status be displayed on or off for error, warning and current time left and its count of long key press, no key press, 
  time within auth process should succeed or failed,  time within PIN should be changed */
#define STATUS_DISP_ON                            (1)  
#define STATUS_DISP_OFF                           (0) 


#define DISP_FLAG_NUM_DIGIT1                   (1)
#define DISP_FLAG_NUM_DIGIT2                   (2)
#define DISP_FLAG_NUM_DIGIT3                   (3)
#define DISP_FLAG_NUM_DIGIT4                   (4)
#define DISP_FLAG_NUM_DIGIT5                   (5)
#define DISP_FLAG_HEX_DIGIT1                   (6)
#define DISP_FLAG_HEX_DIGIT2                   (7)
#define DISP_FLAG_HEX_DIGIT3                   (8)
#define DISP_FLAG_HEX_DIGIT4                   (9) 

/* for 20 * 4 LCD disp */                             
#define BEGIN_LOC_LINE1                      (0X80)
#define BEGIN_LOC_LINE2                      (0xC0)
#define BEGIN_LOC_LINE3                      (0x94) 
#define BEGIN_LOC_LINE4                      (0xD4)
#define END_LOC_LINE1                        (0x93)
#define END_LOC_LINE2                        (0xD3)
#define END_LOC_LINE3                        (0xA7) 
#define END_LOC_LINE4                        (0xE7)

/* num cols = num of chars in a line */
#define MAX_COUNT_DELAY_TIME_LCDPULSE     (1000U)
#define MAX_AVAIL_NUM_COLS                    (20)
#define CONFIGURE_MAX_NUM_LINES               (4)
#define MAX_AVAIL_NUM_LINES                   (4) 
#define MAX_AVAIL_NUM_CHARS_IN_LCD        (MAX_AVAIL_NUM_COLS * MAX_AVAIL_NUM_LINES) 
#define CONFIGURE_MAX_NUM_COLS             (MAX_AVAIL_NUM_COLS)
#define CONFIGURE_MAX_NUM_CHARS_IN_LCD    (CONFIGURE_MAX_NUM_LINES * CONFIGURE_MAX_NUM_COLS ) 
#define MAX_NUM_CHARS_INPUT_DATA          (MAX_AVAIL_NUM_COLS)  

#define INVALID_DATA              (0)
#define ALL_LINES                  (0)
#define NUM_LINE1                  (1)
#define NUM_LINE2                  (2)
#define NUM_LINE3                  (3)
#define NUM_LINE4                  (4)
#define NUM_COL1                   (1)


#define _XTAL_FREQ               (4000000UL)
// TIMER1 expires every 50ms and every LONG_PRESS_KEY_PERIOD calls Long_Press_Key_Proc(),if timer1 runs 
#define TIMER1_TICK_MS           (50UL) 
// Timer0 expires every 2ms and every AUTH_CALL_PERIOD calls Auth_Proc(),if timer1 does not runs and exits Auth_Proc()
#define TIMER0_TICK_MS           (2UL) 
#define TIME_UNIT              (1000UL)
#define OSC_PER_INST                (4)
#define INC1          (unsigned long)((unsigned long)(_XTAL_FREQ * TIMER1_TICK_MS) / (unsigned long)(OSC_PER_INST * TIME_UNIT)) 
#define INC0          (unsigned int)((unsigned long)(_XTAL_FREQ * TIMER0_TICK_MS) / (unsigned long)(OSC_PER_INST * TIME_UNIT))
 
#define TMR1_OFF_STATE             (0)
#define TMR1_MODE_NO_KEY_PRESS     (1)
#define TMR1_MODE_LONG_PRESS_KEY   (2)
   
// every 500ms Auth_Proc() is called if Timer1 does not run
#define AUTH_CALL_PERIOD              (500UL) 
// if no key is pressed, time for No key is press increments by AUTH_CALL_FACTOR_PER_SEC for every second
#define AUTH_CALL_FACTOR_PER_SEC       (1000UL/AUTH_CALL_PERIOD)
//UPDATE_TIME0 configured for 500 msec
#define UPDATE_TIME0                  (AUTH_CALL_PERIOD/TIMER0_TICK_MS)

#define NO_KEY_PRESS_PERIOD          (500UL) 
#define NO_KEY_PRESS_FACTOR_PER_SEC  (1000UL/NO_KEY_PRESS_PERIOD)
//UPDATE_TIME1_NO_KEY_PRESS configured for 500 msec
#define UPDATE_TIME1_NO_KEY_PRESS          (NO_KEY_PRESS_PERIOD/TIMER1_TICK_MS)

// every 500ms Long_Key_Press_Proc() is called if Timer1 runs
#define LONG_PRESS_KEY_PERIOD          (500UL)
#define LONG_PRESS_KEY_FACTOR_PER_SEC  (1000UL/LONG_PRESS_KEY_PERIOD)
//UPDATE_TIME1_LONG_PRESS_KEY configured for 500 msec
#define UPDATE_TIME1_LONG_PRESS_KEY  (LONG_PRESS_KEY_PERIOD/TIMER1_TICK_MS)

#define NO_ERROR_OCCURED               (0)
#define WARNING_OCCURED                (1)
#define ERROR_OCCURED                  (2)
#define FATAL_OCCURED                  (3)


/* codes for error or fatal errors , low 16 BIT */
#define NO_ERROR_CODE                              (0x0000UL)
#define ERR_SW_CODE                            (0x0001UL)
#define ERR_ENTERKEY_DISP_FORMAT_CODE          (0x0002UL)
#define ERR_AUTH_FSM_STATE_CODE                (0x0004UL)
#define ERR_AUTH_DISP_FSM_STATE_CODE           (0x0008UL)
#define ERR_START_LINE_CUR_DATA_CODE           (0x0010UL)
#define ERR_CUR_INPUT_DATA_LOC_CODE            (0x0020UL)
#define ERR_LCD_DISP_NUM_FORMAT_CODE           (0x0040UL)
#define ERR_CUR_INPUT_LOC_CODE                 (0x0080UL)
#define ERR_CUR_DISP_LOC_CODE                  (0x0100UL) 
#define ERR_START_DATA_LOC_GREATER_END_DATA_LOC_CODE (0x4000UL)
#define ERR_TRY_TORUN_TMR1_ALREADY_RUNNING_CODE       (0x8000UL)
/* codes for  warning */
#define WARN_ENTERED_KEY_TRY_ATEND_CONF_LINE_CODE        (0x0200UL)
       
#define WARN_CONF_CHARS_EXCEED_MAX_AVAIL_CHARS_CODE      (0x0800UL) 
#define WARN_DATA_CHARS_REACHED_MAX_ALLOC_CHARS_CODE     (0x1000UL)
#define WARN_DATA_CHARS_NOT_WITHIN_LIMIT                 (0x2000UL)


/* all below defines datas specifies full specified line */
#define WELCOME_MSG_LINE_NUM          NUM_LINE1
#define WELCOME_MSG_START_COL_NUM     NUM_COL1
#define ACCOUNT_MSG_LINE_NUM          NUM_LINE1 
#define ACCOUNT_MSG_START_COL_NUM     NUM_COL1
#define PIN_MSG_LINE_NUM              NUM_LINE1 
#define FAILED_AUTH_REASON_LINE_NUM   NUM_LINE1
#define SUCCESS_AUTH_LINE_NUM         NUM_LINE1 
#define PIN_MSG_LINE_NUM              NUM_LINE1
#define FAILED_SET_PIN_LINE_NUM          NUM_LINE1	
#define ERROR_LINE_NUM                   NUM_LINE4  
#define ACCOUNT_ENTRY_START_LINE_NUM     NUM_LINE2
#define ACCOUNT_ENTRY_START_COL_NUM      NUM_COL1
// ACCOUNT_ENTRY_START_LOC = loc of ACCOUNT_ENTRY_START_LINE_NUM and ACCOUNT_ENTRY_START_COL_NUM
#define ACCOUNT_ENTRY_START_LOC          BEGIN_LOC_LINE2 
   
// ACCOUNT_MSG_START_LOC = loc of ACCOUNT_MSG_LINE_NUM and ACCOUNT_MSG_START_COL_NUM
#define ACCOUNT_MSG_START_LOC            BEGIN_LOC_LINE1 
#define PIN_ENTRY_START_LINE_NUM         NUM_LINE2
#define PIN_ENTRY_START_COL_NUM          NUM_COL1 
#define FAILED_AUTH_LINE_NUM             NUM_LINE2
#define DISP_BLANK_LINE3_NUM             NUM_LINE3
#define DISP_BLANK_LINE4_NUM             NUM_LINE4
#define LONG_PRESSKEY_TIMEOUT_LINE_NUM   NUM_LINE3
//#define NO_KEYPRESS_TIMEOUT_LINE_NUM     NUM_LINE3
#define NO_KEYPRESS_TIMEOUT_LINE_NUM     NUM_LINE4
#define AUTH_TIMEOUT_LINE_NUM            NUM_LINE4
#define SET_PIN_TIMEOUT_LINE_NUM         NUM_LINE4

#define ANY_DATA_DISP                 (1)
#define BLANK_LINE_DISP               (2)
#define NO_KEY_PRESS_TIMEOUT_DISP     (3)   
#define LONG_PRESS_TIMEOUT_DISP       (4)     
#define AUTH_PROCESS_TIMEOUT_DISP     (5) 
#define SET_PIN_TIMEOUT_DISP          (6)
#define AUTH_STATUS_DISP              (7)  
#define ERROR_DISP                    (8)
#define WARNING_DISP                  (9)
#define FATAL_DISP                    (10) 

#define ENTER_KEY_PLAIN_DISP_FORMAT    (1)
#define ENTER_KEY_HIDDEN_DISP_FORMAT   (2) 

#define ENTER_SW_CODE                 ('E')
#define BACKSPACE_SW_CODE             ('B')
#define ACCOUNT_SW_CODE               ('A')
#define RESET_SW_CODE                 ('R') 
#define HIDDEN_KEY_DISP_CHAR          ('X')
#define NUM_CHARS_TRACE_CODE           (5)

/* disp_status_time_or_error[] index ie disp_status_time_or_error[LONG_PRESS_TIME_STATUS_DISP_INDEX] = STATUS_DISP_ON, \
   then long press time status is displayed */
#define ERROR_STATUS_DISP_INDEX             (0)
#define LONG_PRESS_TIME_STATUS_DISP_INDEX   (1)
#define NO_KEY_PRESS_TIME_STATUS_DISP_INDEX (2)
#define AUTH_TIME_STATUS_DISP_INDEX         (3)
#define SET_PIN_TIME_STATUS_DISP_INDEX      (4)

#define GIVEN_CHARS_MAX_CONFIG_LINES_AND_COLS (1)
#define GIVEN_XY_MAX_CONFIG_LINES_AND_COLS    (2)
#define GIVEN_CHARS_MAX_XY                    (3)

/* if  NUM_INPUTDATA_CHARS == GIVEN_CHARS_MAX_CONFIG_LINES_AND_COLS, then calc cur input data parameters by 
  using given max num of chars from start cur data input line and start cur data input col. 
  If conf max num of chars for cur input's data > max avail num of chars, then  alloc cur data input max num of chars  = max avail num of chars,
  whereas  max avail num of chars = num of chars from cur input's data start line and cur input's data start col till end of config lines and cols, else   
  then  alloc num of chars for input data =  given conf max num of chars for cur input's data.
  
   if  NUM_INPUTDATA_CHARS ==  GIVEN_XY_MAX_CONFIG_LINES_AND_COLS, then calc cur input data parameters by using given cur data input start line, cur data input start col ,
   next data start line, and next data start col. 
   XY(Cur input data's end line, ur input data's end col) = previous pos of XY( next data start line, and next data start col).
   max configured cur input's data max input chars =  num of chars from   XY(Cur input data's start line, Cur input data's start col) to XY(Cur input data's end line, cur input data's end col).
   max avail chars = num of chars  from cur data input start line and  cur data input start col,till end of config max lines and conf  max cols. 
   If  max configured cur input's data max input chars > max avail chars, then    alloc max num of chars for cur input data =  max avail chars, 
   else, alloc max num of chars for input data =  max configured cur input's data max input chars.
   
   if  NUM_INPUTDATA_CHARS ==  GIVEN_CHARS_MAX_XY, then calc cur input data parameters by using given cur data input start line,  cur data input start col , 
   next data start line, next data start col, and conf num of chars for cur input data.  
    XY(Cur input data's end line, ur input data's end col) = previous pos of XY( next data start line, and next data start col).
	max avail num of chars = num of chars  chars from cur data input start line and  cur data input start col, till XY(Cur input data's end line, ur input data's end col).
    If conf max num of chars for cur input data > max avail num of chars ,  then  alloc num of chars for cur input data =  max avail num of chars, 
    else max allocated data = given  conf num of chars for cur input data */
     
#define  NUM_INPUTDATA_CHARS        GIVEN_CHARS_MAX_CONFIG_LINES_AND_COLS

#define MAX_NUM_ACC_DATA_INPUT_TRY        (3U)
#define MAX_NUM_PIN_DATA_INPUT_TRY        (3U) 
#define MAX_COUNT_LONG_PRESSKEY_TIMEOUT   (3U)  
#define MAX_PIN_NUM_CHARS                 (5)
#define MAX_ACCOUNT_NUM_CHARS             (24)

#define MAX_TIMEOUT_NO_KEY_PRESS         (10)  
#define MAX_TIMEOUT_LONG_PRESS_KEY       (5)  

 
unsigned int disp_status_time_or_error[] = {STATUS_DISP_ON, STATUS_DISP_ON, STATUS_DISP_ON,STATUS_DISP_OFF,STATUS_DISP_OFF};
 
void Delay_Time_ByCount(unsigned int Delay_Time_Count_count);
void LCD_Pulse ();
void Write_LCD_Command (const unsigned int Write_LCD_Command);
void Write_LCD_Data(const char lcd_disp_ch);
void Data_Str_Disp_LCD(const char *lcd_disp_str);
void Data_Num_Disp_LCD(const unsigned int lcd_datanum_disp_format, const unsigned long lcd_disp_data_int);
void Data_4Digit_Hex_Disp_LCD(const unsigned long lcd_disp_data_int);
void Goto_XY_LCD_Disp(const unsigned int start_line_num, const unsigned int start_col_num);
void Goto_XY_LCD_Disp_Err(const unsigned int start_line_num, const unsigned int start_col_num);
void Goto_XY_Disp_LCD20(unsigned int start_line_num, unsigned int start_col_num);
void Goto_XY_Disp_LCD16(unsigned int start_line_num, unsigned int start_col_num);
void Goto_XY_LCD_Input(unsigned int start_line_num, unsigned int start_col_num);
void Goto_XY_Input_LCD_20(unsigned int start_line_num, unsigned int start_col_num);
void From_Loc_to_XY_LCD(const unsigned int loc_lcd, unsigned int * const loc_lcd_line_num, unsigned int * const loc_lcd_col_num );
void From_XY_To_Loc_LCD(const unsigned int start_line_num, const unsigned int start_col_num, unsigned int * const lcd_loc);
void LCD_Init();
void Init_Const_Data();
void Reset_Process();
void Prescale_Timer1();     
void Timer1_Tick();
void Timer0_Tick();
void Prescale_Timer0();
void Run_Timer1(const unsigned int set_timer1_mode );
void Run_Timer0();
void Stop_Timer1();
void Stoke_Rcvd_Tmr1_Long_Press_Proc();
void Error_or_Warning_Proc(const char *error_trace, const unsigned int warn_or_error_format, const unsigned int warning_or_error_data);
void Disp_Status_Fsm();
void Auth_Fsm_Proc();
void After_Key_Stoke_Proc(const char pressed_key);
void After_Switch_Stoke_Proc(const char pressed_key);
void Entered_Key_No_Long_Press_Proc(const char pressed_key);
void Entered_Backspace_Sw_No_Long_Press_Proc();
void Auth_Proc();
void Long_Press_Key_Proc();
void Check_Long_Pressed_Key();
void No_Key_Press_Proc();
void Check_No_Key_Press();

void Is_Numchars_Within_Limit();
void Cur_Input_Data_ByXY_Calc_Para(const unsigned int cur_data_entry_start_line_num, const unsigned int cur_data_entry_start_col_num, \
  const unsigned int next_data_start_line_num, const unsigned int next_data_start_col_num); 
void Cur_Input_Data_ByNumChars_Calc_Para(const unsigned int cur_data_entry_start_line_num, const unsigned int cur_data_entry_start_col_num, \
  const unsigned int configured_cur_data_input_max_num_chars);
 void Cur_Input_Data_ByCharsXY_Calc_Para(const unsigned int cur_data_entry_start_line_num, const unsigned int cur_data_entry_start_col_num, \
const unsigned int configured_cur_data_input_max_num_chars,const unsigned int next_data_start_line_num, const unsigned int next_data_start_col_num);   
void Set_Cur_Loc_LCD(const char set_input_loc_flag, const unsigned int set_input_loc, const char set_disp_loc_flag, const unsigned int set_disp_loc);
void Reset_Cur_Input_Data_Para();

enum auth_fsm {ACCOUNT_FSM=1,PIN_FSM, AUTH_SUCCESS_FSM};
enum status_fsm {INITIAL = 0,INVALID_ACCOUNT,INVALID_PIN, TIMEOUT_LONG_KEY_PRESS,TIMEOUT_NO_KEY_PRESS,AUTH_SUCCESS};

unsigned int prescale_timer1 = 0x01, prescale_shift_timer1= 0, timer1_mode = TMR1_OFF_STATE;
unsigned int prescale_timer0 =  0x02, prescale_shift_timer0= 0;
unsigned long int num_calls_timer0 = 0, num_calls_timer1 = 0, timer1_init = 0, count_update_long_press_per_sec = 0, count_update_no_key_per_sec = 0 ;

char keypad_char[]   = {'1','2', '3', '4', '5', '6','7','8','9','*', '0', '#'};
const char default_account[] = {"56789"};       
const char enter_account_msg_disp[] =  {"Enter Account"},enter_pin_msg_disp[] = {"Enter PIN"}, default_pin[] = "1234";
const char auth_success_msg_disp[] = "Successful Auth", incorrect_auth_msg_disp[] = "Visit Bank";
const char reenter_acc_msg_disp[]= "Reenter Account",reenter_pin_msg_disp[] = "Reenter PIN";   
const char max_acc_try_msg_disp[]=  "Max Acc Exceed", max_pin_try_msg_disp[] = {"Max PIN Exceed"};
const char auth_timeout_msg_disp[] =  "Timeout:" ,error_no_key_press_msg_disp[]="No Key",error_long_key_press_msg_disp[]="L Key";
/*line_blank_disp[] num of blank spaces = max nums of chars in a line in a lcd and start loc is begin loc of that line */
const char secs_msg_disp[] = "Secs", timeout_long_press_msg_disp[] = {" TOUT:L Key "}, timeout_no_key_msg_disp[] = {"TOUT:NO Key "}, \
 line_blank_disp[] = {"                    "}, time_msg_disp[] = {"T"}, count_msg_disp[] = " C", error_msg_disp[] = "ERR ", \
 warning_msg_disp[] = "WRN ", fatal_msg_disp[] = "FTL ", welcome_msg_disp[] = "Welcome";   
 
char can_lcd_disp_flag = STATE_YES, key_or_sw_input_enable_flag = STATE_YES, max_input_num_chars_flag = STATE_NO,timeout_long_pressed_key_flag = STATE_NO,timeout_nokey_press_flag = STATE_NO, \
 disp_status_flag = STATE_NO, need_input_flag = STATE_YES, detect_presskey_flag = STATE_NO, cur_data_can_also_input_nonnum_key = STATE_NO, cur_data_echo_inputkey_inlcd = STATE_YES, \
lcd_avail_loc_within_limit = STATE_YES,  reset_sw_enable_flag = STATE_NO, enter_sw_enable_flag = STATE_NO, backspace_sw_enable_flag = STATE_NO, account_sw_enable_flag = STATE_YES,
keypad_keys_enable_flag = STATE_NO;
/* overwrite_line_flag[0] = MASTER control of overwrite on all lines in LCD, if STATE_NO, you cannot write in all lines in LCD, 
if STATE_YES, then, if particular line eg for line 2, write_disp_flag[2] =STATE_YES, then write in that line, else cannot write in that line and max for 4 lines 
yet to implement overwrite_line_flag, at present no need */
char overwrite_line_flag[] = {STATE_YES,STATE_YES,STATE_YES,STATE_YES,STATE_YES,'\0'};


unsigned int cur_disp_lcd_loc = BEGIN_LOC_LINE1, cur_input_lcd_loc = BEGIN_LOC_LINE2, num_chars_entered_cur_data = 0; 
char entered_cur_input_data[MAX_NUM_CHARS_INPUT_DATA + 1], cur_pressed_key_or_sw = '\0' ;
unsigned int count_cur_input_data_try = 0, count_long_press_key_timeout = 0, max_num_cur_data_input_try = 0; 
enum auth_fsm auth_fsm_state = ACCOUNT_FSM; 
enum status_fsm status_disp_fsm =INITIAL;  
/* currently displayed data in each line starts from 1 ie use array index as line num for us. index 0 can be used as all lines */
unsigned int cur_line_disp_data[] = {ANY_DATA_DISP, ANY_DATA_DISP, ANY_DATA_DISP, BLANK_LINE_DISP, BLANK_LINE_DISP};
 
unsigned int time_msg_disp_len , count_msg_disp_len, long_press_timeout_msg_disp_len,  start_col_long_press_timeout_msg_disp, start_col_long_press_time_disp, \
 start_col_long_press_count_msg_disp, start_col_long_press_count_disp, start_col_long_press_time_msg_disp, start_col_error_code, start_col_blank_space, start_col_error_msg,
 start_col_no_key_time_msg_disp, start_col_no_key_time_disp;
 
unsigned int internal_error_state = NO_ERROR_OCCURED;

unsigned int auth_timeout_msg_len, start_col_reason_timeout_msg_disp; 

unsigned int cur_data_input_start_loc, cur_data_input_end_loc, cur_data_input_end_line_num, cur_data_input_end_col_num, cur_data_input_max_num_chars_allocated, \
 cur_data_input_line_num, cur_data_input_col_num, cur_data_input_start_line_num, cur_data_input_start_col_num; 

unsigned int time_left_no_key_press = MAX_TIMEOUT_NO_KEY_PRESS, time_left_long_press_key = MAX_TIMEOUT_LONG_PRESS_KEY;
unsigned int cur_data_lcd_enterchar_disp_format =  ENTER_KEY_PLAIN_DISP_FORMAT ;

unsigned long int error_or_warning_code = NO_ERROR_CODE; 

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 3   
-*------------------------------------------------------------*/
void Reset_Process()
{
  
  max_input_num_chars_flag = STATE_NO;
  timeout_long_pressed_key_flag = STATE_NO; 
  timeout_nokey_press_flag = STATE_NO ; 
   
  auth_fsm_state = INITIAL;
  status_disp_fsm =INITIAL;
  
  memset(entered_cur_input_data, sizeof(entered_cur_input_data)/sizeof(char), '\0');
  num_chars_entered_cur_data = 0; 
 
  LONG_PRESS_KEY_LED_PIN = LED_OFF;
  NO_KEY_PRESS_LED_PIN = LED_OFF; 
  count_update_long_press_per_sec = 0;
  count_update_no_key_per_sec = 0;  
  time_left_no_key_press = MAX_TIMEOUT_NO_KEY_PRESS;
  time_left_long_press_key = MAX_TIMEOUT_LONG_PRESS_KEY;   
  num_calls_timer0 = 0; 
  num_calls_timer1 = 0;
  disp_status_flag = STATE_NO;  
  need_input_flag = STATE_YES; 
  detect_presskey_flag = STATE_NO; 
  
  count_cur_input_data_try = 0;
  can_lcd_disp_flag = STATE_YES;
  key_or_sw_input_enable_flag =STATE_YES;
  time_left_no_key_press = MAX_TIMEOUT_NO_KEY_PRESS;
  time_left_long_press_key = MAX_TIMEOUT_LONG_PRESS_KEY;
   
  lcd_avail_loc_within_limit = STATE_YES;
  Stop_Timer1();  
  timer1_mode = TMR1_OFF_STATE;
  reset_sw_enable_flag = STATE_NO;
  enter_sw_enable_flag = STATE_NO;
  backspace_sw_enable_flag = STATE_NO;
  account_sw_enable_flag = STATE_YES;
  keypad_keys_enable_flag = STATE_NO;
  
  Set_Cur_Loc_LCD(STATE_YES, ACCOUNT_ENTRY_START_LOC,STATE_YES, ACCOUNT_MSG_START_LOC );    
  count_long_press_key_timeout = 0; 
  cur_line_disp_data[LONG_PRESSKEY_TIMEOUT_LINE_NUM] = BLANK_LINE_DISP;
  //cur_line_disp_data[NO_KEYPRESS_TIMEOUT_LINE_NUM] = BLANK_LINE_DISP;
  //cur_line_disp_data[AUTH_TIMEOUT_LINE_NUM] = BLANK_LINE_DISP; 
  cur_line_disp_data[ALL_LINES] = ANY_DATA_DISP;
  Write_LCD_Command(0x01); //clear display
  Write_LCD_Command(0x0C); // display on , cursor and blinking OFF
  
  Goto_XY_LCD_Disp(WELCOME_MSG_LINE_NUM, WELCOME_MSG_START_COL_NUM);
  Data_Str_Disp_LCD(welcome_msg_disp);  
  
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 4  
-*------------------------------------------------------------*/
void After_Key_Stoke_Proc(const char pressed_key)
{
   
   Stop_Timer1();
   time_left_no_key_press = MAX_TIMEOUT_NO_KEY_PRESS;   
   detect_presskey_flag = STATE_NO;  
   

   if(timeout_long_pressed_key_flag == STATE_NO)
   {
	   time_left_long_press_key = MAX_TIMEOUT_LONG_PRESS_KEY; 
	   
       Entered_Key_No_Long_Press_Proc(pressed_key); 
	   if(disp_status_time_or_error[LONG_PRESS_TIME_STATUS_DISP_INDEX] == STATUS_DISP_ON && \
	      cur_line_disp_data[LONG_PRESSKEY_TIMEOUT_LINE_NUM] == LONG_PRESS_TIMEOUT_DISP)
	   {	   
          Goto_XY_LCD_Disp(LONG_PRESSKEY_TIMEOUT_LINE_NUM,NUM_COL1 );
		  Data_Str_Disp_LCD(line_blank_disp);
	      cur_line_disp_data[LONG_PRESSKEY_TIMEOUT_LINE_NUM] = BLANK_LINE_DISP;		  
	   }
	   if(disp_status_time_or_error[NO_KEY_PRESS_TIME_STATUS_DISP_INDEX] == STATUS_DISP_ON && \
	     cur_line_disp_data[NO_KEYPRESS_TIMEOUT_LINE_NUM] == NO_KEY_PRESS_TIMEOUT_DISP)
	   {
		  Goto_XY_LCD_Disp(NO_KEYPRESS_TIMEOUT_LINE_NUM, NUM_COL1);	  
		  Data_Str_Disp_LCD(line_blank_disp);
          cur_line_disp_data[NO_KEYPRESS_TIMEOUT_LINE_NUM] = BLANK_LINE_DISP;	 
       }       	  				   
   }
   
	if(count_long_press_key_timeout < MAX_COUNT_LONG_PRESSKEY_TIMEOUT)
      timeout_long_pressed_key_flag = STATE_NO;
    else 
       timeout_long_pressed_key_flag = STATE_YES;   
   
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 5   
-*------------------------------------------------------------*/  
void After_Switch_Stoke_Proc(const char pressed_sw)
{
	Stop_Timer1();
	time_left_no_key_press =MAX_TIMEOUT_NO_KEY_PRESS;
	detect_presskey_flag = STATE_NO;	
	if(timeout_long_pressed_key_flag == STATE_NO)
    {
		time_left_long_press_key = MAX_TIMEOUT_LONG_PRESS_KEY;
        if(disp_status_time_or_error[LONG_PRESS_TIME_STATUS_DISP_INDEX] == STATUS_DISP_ON && \
		 cur_line_disp_data[LONG_PRESSKEY_TIMEOUT_LINE_NUM] == LONG_PRESS_TIMEOUT_DISP)
	     {	   
              Goto_XY_LCD_Disp(LONG_PRESSKEY_TIMEOUT_LINE_NUM,NUM_COL1);
			  Data_Str_Disp_LCD(line_blank_disp);
	          cur_line_disp_data[LONG_PRESSKEY_TIMEOUT_LINE_NUM] = BLANK_LINE_DISP;		          
	      }
	/*	if(disp_status_time_or_error[NO_KEY_PRESS_TIME_STATUS_DISP_INDEX] == STATUS_DISP_ON && \
	     cur_line_disp_data[NO_KEYPRESS_TIMEOUT_LINE_NUM] == NO_KEY_PRESS_TIMEOUT_DISP)
	   {
		  Goto_XY_LCD_Disp(NO_KEYPRESS_TIMEOUT_LINE_NUM, NUM_COL1);	  
		  Data_Str_Disp_LCD(line_blank_disp);
          cur_line_disp_data[NO_KEYPRESS_TIMEOUT_LINE_NUM] = BLANK_LINE_DISP;	 
       } */   
	       switch(pressed_sw)
		  {
			  case ACCOUNT_SW_CODE:
			     Write_LCD_Command(0x01);
				 auth_fsm_state = ACCOUNT_FSM;
			     Goto_XY_LCD_Disp(ACCOUNT_MSG_LINE_NUM, ACCOUNT_MSG_START_COL_NUM);
                 Data_Str_Disp_LCD(enter_account_msg_disp);
                 #if( NUM_INPUTDATA_CHARS == GIVEN_CHARS_MAX_CONFIG_LINES_AND_COLS)
                    Cur_Input_Data_ByNumChars_Calc_Para(ACCOUNT_ENTRY_START_LINE_NUM, ACCOUNT_ENTRY_START_COL_NUM, MAX_ACCOUNT_NUM_CHARS);
                 #elif(NUM_INPUTDATA_CHARS == GIVEN_XY_MAX_CONFIG_LINES_AND_COLS)
  /* ACCOUNT INPUT DATA max num of input account chars = num of chars from start pos (entry start line, entry start col) till end of that line */  
                     Cur_Input_Data_ByXY_Calc_Para(ACCOUNT_ENTRY_START_LINE_NUM, ACCOUNT_ENTRY_START_COL_NUM, ACCOUNT_ENTRY_START_LINE_NUM + 1, NUM_COL1 );
                  #else 
                	  /*NUM_INPUTDATA_CHARS = GIVEN_CHARS_MAX_XY */
                  /* ACCOUNT INPUT DATA's max num of input account chars = min(num of chars from start pos (entry start line, entry start col) till end of that line, MAX_ACCOUNT_NUM_CHARS ) */ 
                 	Cur_Input_Data_ByCharsXY_Calc_Para(ACCOUNT_ENTRY_START_LINE_NUM, ACCOUNT_ENTRY_START_COL_NUM, MAX_ACCOUNT_NUM_CHARS, ACCOUNT_ENTRY_START_LINE_NUM + 1 , NUM_COL1); 
                 #endif
				 Goto_XY_LCD_Input(ACCOUNT_ENTRY_START_LINE_NUM, ACCOUNT_ENTRY_START_COL_NUM); 
                 Write_LCD_Command(0x0E);
                 max_num_cur_data_input_try= MAX_NUM_ACC_DATA_INPUT_TRY;
                 cur_data_can_also_input_nonnum_key = STATE_NO;
                 cur_data_echo_inputkey_inlcd = STATE_YES;
                 cur_data_lcd_enterchar_disp_format =  ENTER_KEY_PLAIN_DISP_FORMAT ;
                 account_sw_enable_flag = STATE_NO;	
                 keypad_keys_enable_flag = STATE_YES;
                				 
              break;      					
			  case ENTER_SW_CODE:
			   /*  Process for valid Enter sw stroke */
			    if(num_chars_entered_cur_data > 0)
				{
			      entered_cur_input_data[num_chars_entered_cur_data] = '\0';
				  enter_sw_enable_flag = STATE_NO;
	              backspace_sw_enable_flag = STATE_NO;
				  reset_sw_enable_flag = STATE_YES;
                  Auth_Fsm_Proc(); 
                  memset(entered_cur_input_data, sizeof(entered_cur_input_data)/sizeof(char), '\0');
                  num_chars_entered_cur_data = 0;
				  enter_sw_enable_flag = STATE_NO;
                  backspace_sw_enable_flag = STATE_NO;
				}  
              break;
              case BACKSPACE_SW_CODE:				  
			  
              /* Process for valid Backspace */
			  if(num_chars_entered_cur_data > 0)
			  {
                Entered_Backspace_Sw_No_Long_Press_Proc();			  
              } 				 
            break;
            case RESET_SW_CODE:
			  /* process for reset sw operations when within long press timeout error occurs, reset sw is released */
               Reset_Process();
			   reset_sw_enable_flag = STATE_NO;
               break;
             default:
			 
               Error_or_Warning_Proc("05.01", ERROR_OCCURED, ERR_SW_CODE );			 
               ;/* error: invalid sw code received */
			 			   
	     }		 
	}
	if(count_long_press_key_timeout < MAX_COUNT_LONG_PRESSKEY_TIMEOUT)
       timeout_long_pressed_key_flag = STATE_NO;
    else 
      timeout_long_pressed_key_flag = STATE_YES;	
}	
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 6  
-*------------------------------------------------------------*/
void Long_Press_Key_Proc()
{
   if(++count_update_long_press_per_sec % LONG_PRESS_KEY_FACTOR_PER_SEC == 0 )
   { 
       count_update_long_press_per_sec = 0;
       --time_left_long_press_key;   	 
	   
       /* data is constant for a while, so if data is const,at lcd const data is displayed only once until const data at that line has changed */
	  if(disp_status_time_or_error[LONG_PRESS_TIME_STATUS_DISP_INDEX] == STATUS_DISP_ON && \
	    cur_line_disp_data[LONG_PRESSKEY_TIMEOUT_LINE_NUM] == BLANK_LINE_DISP)  
       {
		   Goto_XY_LCD_Disp(LONG_PRESSKEY_TIMEOUT_LINE_NUM, NUM_COL1);
		   switch(cur_data_lcd_enterchar_disp_format)
		   {
			 case ENTER_KEY_PLAIN_DISP_FORMAT:
    			 Write_LCD_Data(cur_pressed_key_or_sw);
		     	break;
			case ENTER_KEY_HIDDEN_DISP_FORMAT:
                Write_LCD_Data(HIDDEN_KEY_DISP_CHAR);			
		        break; 
			default:
            	Error_or_Warning_Proc("06.01", ERROR_OCCURED, ERR_ENTERKEY_DISP_FORMAT_CODE);
				/* error invalid enter key disp format */
		   }   
		   Goto_XY_LCD_Disp(LONG_PRESSKEY_TIMEOUT_LINE_NUM, start_col_long_press_timeout_msg_disp); 
		   Data_Str_Disp_LCD(timeout_long_press_msg_disp);
		   Goto_XY_LCD_Disp(LONG_PRESSKEY_TIMEOUT_LINE_NUM, start_col_long_press_time_msg_disp );	
		   Data_Str_Disp_LCD(time_msg_disp); 
           Goto_XY_LCD_Disp(LONG_PRESSKEY_TIMEOUT_LINE_NUM, start_col_long_press_count_msg_disp);
		   Data_Str_Disp_LCD(count_msg_disp); 
		   cur_line_disp_data[LONG_PRESSKEY_TIMEOUT_LINE_NUM] = LONG_PRESS_TIMEOUT_DISP;
		  /* to get data at cur_input_lcd_loc*/
           Write_LCD_Command(cur_input_lcd_loc);
	       Write_LCD_Command(0x0C);       		   
      }
	   /* disp variable data every time at loc, if line has long press key data */
	  if( disp_status_time_or_error[LONG_PRESS_TIME_STATUS_DISP_INDEX] == STATUS_DISP_ON && \
	     cur_line_disp_data[LONG_PRESSKEY_TIMEOUT_LINE_NUM] == LONG_PRESS_TIMEOUT_DISP)   
	   {
		   Goto_XY_LCD_Disp(LONG_PRESSKEY_TIMEOUT_LINE_NUM, start_col_long_press_time_disp ); 
           Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT2, time_left_long_press_key);           
           Goto_XY_LCD_Disp(LONG_PRESSKEY_TIMEOUT_LINE_NUM, start_col_long_press_count_disp ); 
           Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT2, count_long_press_key_timeout);          
       }
      /* if(disp_status_time_or_error[NO_KEY_PRESS_TIME_STATUS_DISP_INDEX] == STATUS_DISP_ON && \
	     cur_line_disp_data[NO_KEYPRESS_TIMEOUT_LINE_NUM] == NO_KEY_PRESS_TIMEOUT_DISP)
	   {
		  Goto_XY_LCD_Disp(NO_KEYPRESS_TIMEOUT_LINE_NUM, NUM_COL1);	  
		  Data_Str_Disp_LCD(line_blank_disp);
          cur_line_disp_data[NO_KEYPRESS_TIMEOUT_LINE_NUM] = BLANK_LINE_DISP;	 
       } */	   
       if(time_left_long_press_key == 0)
       {
		   timeout_long_pressed_key_flag = STATE_YES;		  
		   if(++count_long_press_key_timeout < MAX_COUNT_LONG_PRESSKEY_TIMEOUT)
		   {
			   time_left_long_press_key = MAX_TIMEOUT_LONG_PRESS_KEY;
               if(disp_status_time_or_error[LONG_PRESS_TIME_STATUS_DISP_INDEX] == STATUS_DISP_ON && \
			    cur_line_disp_data[LONG_PRESSKEY_TIMEOUT_LINE_NUM] == LONG_PRESS_TIMEOUT_DISP)		   
	           {
				   Goto_XY_LCD_Disp(LONG_PRESSKEY_TIMEOUT_LINE_NUM, start_col_long_press_time_disp ); 
                   Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT2, time_left_long_press_key); 
		           Goto_XY_LCD_Disp(LONG_PRESSKEY_TIMEOUT_LINE_NUM, start_col_long_press_count_disp ); 
                   Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT2, count_long_press_key_timeout);  
               }		   
		   }
		   else
		   {	   
	             LONG_PRESS_KEY_LED_PIN = LED_ON; 
			  	 cur_line_disp_data[ALL_LINES] = ANY_DATA_DISP;	
				 Stop_Timer1();
			     if(cur_pressed_key_or_sw != RESET_SW_CODE)
			     {	 
			      status_disp_fsm =  TIMEOUT_LONG_KEY_PRESS; 
	              disp_status_flag = STATE_YES;			    		  
                  Disp_Status_Fsm();
                }
                else
                {
				  /* process for reset sw operation after long key press error with last pressed is  reset sw  */
				  Reset_Process();
			   } 				  
		   }			  
      }	
   }  
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 8   
-*------------------------------------------------------------*/
void Auth_Fsm_Proc()
{
    switch(auth_fsm_state)
    {
       case ACCOUNT_FSM: 
	   if(++count_cur_input_data_try <= max_num_cur_data_input_try)
       {
		  Write_LCD_Command(0x01); 
		 
         if(strcmp(entered_cur_input_data,default_account)== 0)
         {
			 /* start up for PIN_FSM to get pin data */
			Goto_XY_LCD_Disp(PIN_MSG_LINE_NUM, NUM_COL1 );
			Data_Str_Disp_LCD(enter_pin_msg_disp);
            auth_fsm_state = PIN_FSM;
			#if (NUM_INPUTDATA_CHARS == GIVEN_CHARS_MAX_CONFIG_LINES_AND_COLS)
			  Cur_Input_Data_ByNumChars_Calc_Para(PIN_ENTRY_START_LINE_NUM, PIN_ENTRY_START_COL_NUM, MAX_PIN_NUM_CHARS);
			#elif (NUM_INPUTDATA_CHARS == GIVEN_XY_MAX_CONFIG_LINES_AND_COLS)
			/* PIN INPUT DATA max num of input pin chars = num of chars from start pos (entry start line, entry start col) till end of that line */ 	
			  Cur_Input_Data_ByXY_Calc_Para(PIN_ENTRY_START_LINE_NUM, PIN_ENTRY_START_COL_NUM, PIN_ENTRY_START_LINE_NUM + 1, NUM_COL1);
		    #else
             /*	(NUM_INPUTDATA_CHARS = GIVEN_CHARS_MAX_XY)*/
		     /* PIN INPUT DATA max num of input pin chars =  min(num of chars from start pos (entry start line, entry start col) till end of that line, MAX_PIN_NUM_CHARS) */ 
			   Cur_Input_Data_ByCharsXY_Calc_Para(PIN_ENTRY_START_LINE_NUM, PIN_ENTRY_START_COL_NUM, MAX_PIN_NUM_CHARS,PIN_ENTRY_START_LINE_NUM + 1, NUM_COL1 );	
			#endif
			Goto_XY_LCD_Input(PIN_ENTRY_START_LINE_NUM, PIN_ENTRY_START_COL_NUM);	
		    cur_data_can_also_input_nonnum_key = STATE_NO;
			cur_data_echo_inputkey_inlcd = STATE_YES;
			cur_data_lcd_enterchar_disp_format = ENTER_KEY_HIDDEN_DISP_FORMAT ;
			count_cur_input_data_try = 0;
            Write_LCD_Command(0x0E); // insert cursor on at cur_input_lcd_loc
		    max_num_cur_data_input_try = MAX_NUM_PIN_DATA_INPUT_TRY;                                                                    
         } 
         else
         {
			 if(count_cur_input_data_try <= max_num_cur_data_input_try - 1)
			 {	 
			    Goto_XY_LCD_Disp(ACCOUNT_MSG_LINE_NUM, ACCOUNT_MSG_START_COL_NUM );
                Data_Str_Disp_LCD(reenter_acc_msg_disp);				
                Goto_XY_LCD_Input(ACCOUNT_ENTRY_START_LINE_NUM, ACCOUNT_ENTRY_START_COL_NUM);
                Write_LCD_Command(0x0E); // insert cursor on at cur_input_lcd_loc		       
			}
            else
            {
				status_disp_fsm = INVALID_ACCOUNT;
		        disp_status_flag = STATE_YES;               		
			}     				
         }
	   }
       else	
       {
		   status_disp_fsm = INVALID_ACCOUNT;
		   disp_status_flag = STATE_YES;                      
	   }		   
        break;
       case  PIN_FSM:
	     if(++count_cur_input_data_try <= max_num_cur_data_input_try)
         {
            Write_LCD_Command(0x01);
            if(strcmp(entered_cur_input_data,default_pin)== 0)
            {
				 /* start up for AUTH_SUCCESS_FSM  */
               count_cur_input_data_try = 0;
               auth_fsm_state = AUTH_SUCCESS_FSM;
			   cur_data_echo_inputkey_inlcd = STATE_YES;
			   cur_data_lcd_enterchar_disp_format = ENTER_KEY_PLAIN_DISP_FORMAT ;
               status_disp_fsm = AUTH_SUCCESS;
			   /* Update  use Cur_Input_Data_Set_Parameters()	to next data input's max and min loc parameters to be entered, if any in AUTH_SUCCESS_FSM */
			   cur_data_can_also_input_nonnum_key = STATE_YES;
			   disp_status_flag = STATE_YES;              			   
            } 
            else
            {
				if(count_cur_input_data_try <= max_num_cur_data_input_try - 1)
			    {
			      Goto_XY_LCD_Disp(PIN_MSG_LINE_NUM, NUM_COL1 );
                  Data_Str_Disp_LCD(reenter_pin_msg_disp);				  
                  Goto_XY_LCD_Input(PIN_ENTRY_START_LINE_NUM,NUM_COL1);
                  Write_LCD_Command(0x0E); // insert cursor on at cur_input_lcd_loc		         
			    }
                else
                {
				    status_disp_fsm = INVALID_PIN; 
			        disp_status_flag = STATE_YES;   	
                }				
            }
		  }
		  else
		  {
			  status_disp_fsm = INVALID_PIN; 
			  disp_status_flag = STATE_YES;             
          }			  
          break; 
       case  AUTH_SUCCESS_FSM:	     
         break; 
       default:
         Error_or_Warning_Proc("08.01", FATAL_OCCURED, ERR_AUTH_FSM_STATE_CODE);
        /* error: invalid auth fsm state */	
		     	
           ;
    }    
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 9  
-*------------------------------------------------------------*/
void Disp_Status_Fsm()
{
	if(can_lcd_disp_flag == STATE_YES)
    {	

	   Write_LCD_Command(0x01); //clear display    
	   Write_LCD_Command(0x0C);
	   
	   switch(status_disp_fsm)
       {
          case INVALID_ACCOUNT:
		     Goto_XY_LCD_Disp(FAILED_AUTH_REASON_LINE_NUM,NUM_COL1 );
			 Data_Str_Disp_LCD(max_acc_try_msg_disp);
			 Goto_XY_LCD_Disp(FAILED_AUTH_LINE_NUM, NUM_COL1); 
			  Data_Str_Disp_LCD(incorrect_auth_msg_disp);
             break;
         case INVALID_PIN:
		     Goto_XY_LCD_Disp(FAILED_AUTH_REASON_LINE_NUM,NUM_COL1 ); 
             Data_Str_Disp_LCD(max_pin_try_msg_disp);		 
             Goto_XY_LCD_Disp(FAILED_AUTH_LINE_NUM, NUM_COL1);
			 Data_Str_Disp_LCD(incorrect_auth_msg_disp);	
             break;
	     case TIMEOUT_LONG_KEY_PRESS:
		     Goto_XY_LCD_Disp(FAILED_AUTH_REASON_LINE_NUM, NUM_COL1);
			 Data_Str_Disp_LCD(auth_timeout_msg_disp);
		     Goto_XY_LCD_Disp(FAILED_AUTH_REASON_LINE_NUM, start_col_reason_timeout_msg_disp);
             Data_Str_Disp_LCD(error_long_key_press_msg_disp);		 
			 Goto_XY_LCD_Disp(FAILED_AUTH_LINE_NUM, NUM_COL1);
			 Data_Str_Disp_LCD(incorrect_auth_msg_disp);		
             break;
	     case TIMEOUT_NO_KEY_PRESS:	
           	Goto_XY_LCD_Disp(FAILED_AUTH_REASON_LINE_NUM, NUM_COL1);
			Data_Str_Disp_LCD(auth_timeout_msg_disp);	 
		  	Goto_XY_LCD_Disp(FAILED_AUTH_REASON_LINE_NUM, start_col_reason_timeout_msg_disp);
			Data_Str_Disp_LCD(error_no_key_press_msg_disp);	
			Goto_XY_LCD_Disp(FAILED_AUTH_LINE_NUM, NUM_COL1);
			Data_Str_Disp_LCD(incorrect_auth_msg_disp);			
			break;
         case AUTH_SUCCESS:
		    Goto_XY_LCD_Disp(SUCCESS_AUTH_LINE_NUM,NUM_COL1 );
			Data_Str_Disp_LCD(auth_success_msg_disp);
			break;
		 default:
             ;
            Error_or_Warning_Proc("09.01", FATAL_OCCURED, ERR_AUTH_DISP_FSM_STATE_CODE);  
           /* error: invalid auth disp status */            	  		   
      }
	  	  
   }
   /* waiting for reset sw input and parameters set for just before reset process */
   cur_line_disp_data[LONG_PRESSKEY_TIMEOUT_LINE_NUM] = BLANK_LINE_DISP;
   cur_line_disp_data[NO_KEYPRESS_TIMEOUT_LINE_NUM] = BLANK_LINE_DISP;
   time_left_long_press_key = MAX_TIMEOUT_LONG_PRESS_KEY;
   time_left_no_key_press = MAX_TIMEOUT_NO_KEY_PRESS;
   count_long_press_key_timeout = 0;
   can_lcd_disp_flag = STATE_NO;
   key_or_sw_input_enable_flag = STATE_NO; 
   need_input_flag = STATE_NO; 
   cur_data_lcd_enterchar_disp_format = ENTER_KEY_PLAIN_DISP_FORMAT;   
   reset_sw_enable_flag = STATE_YES;
   keypad_keys_enable_flag = STATE_NO;
   Stop_Timer1();
} 
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 10  
-*------------------------------------------------------------*/
void Is_Numchars_Within_Limit()
{
 	/* num char < valid char as when num chars <= max valid, and num char == max valid, then you can entry key and 
	and num char  =  max valid + 1, now you cannot input key */	
	
	
	if(num_chars_entered_cur_data < cur_data_input_max_num_chars_allocated)
        max_input_num_chars_flag = STATE_NO;
     else
	 {
        max_input_num_chars_flag = STATE_YES; 
		/* warning:  num of input data chars has reached max num of chars allocated for cur input data  */
     }  
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 11  
-*------------------------------------------------------------*/
void Entered_Key_No_Long_Press_Proc(const char key_data)
{
	/* make sure that entered key is within max available lcd loc and line, currently cur_data_input_max_num_chars_allocated 
	 sures that entered key is within max available lcd loc and within max line */
	 unsigned int cur_input_loc_line_num, cur_input_loc_col_num, next_input_loc_line_num, next_input_loc_col_num;
	
   if(cur_data_echo_inputkey_inlcd == STATE_YES)
   {
	   Write_LCD_Command(cur_input_lcd_loc);
	  
	    Write_LCD_Command(0x0E);// insert cursor on at cur_input_lcd_loc
	   // Write_LCD_Command(0x0C);
       switch(cur_data_lcd_enterchar_disp_format)
       {
         case ENTER_KEY_PLAIN_DISP_FORMAT:
           Write_LCD_Data(key_data);
        break;
        case ENTER_KEY_HIDDEN_DISP_FORMAT:
          Write_LCD_Data(key_data);
          Delay_Time_ByCount(20000);
          Write_LCD_Command(cur_input_lcd_loc); 
          Write_LCD_Data(HIDDEN_KEY_DISP_CHAR);
        break;
		default:
          Error_or_Warning_Proc("11.01", ERROR_OCCURED, ERR_ENTERKEY_DISP_FORMAT_CODE);  
		  /* error: invalid lcd enter char disp format */		             
      }
	  
	 From_Loc_to_XY_LCD(cur_input_lcd_loc, &cur_input_loc_line_num, &cur_input_loc_col_num);
	 if(cur_input_loc_line_num == CONFIGURE_MAX_NUM_LINES && cur_input_loc_col_num == CONFIGURE_MAX_NUM_COLS)
	 {	 
		/* reached  end of max configured line and valid key is pressed, retain same loc position */ 
		Error_or_Warning_Proc("11.02", WARNING_OCCURED, WARN_ENTERED_KEY_TRY_ATEND_CONF_LINE_CODE);
	 }
	 else
	 {
		 /* put cur input lcd loc to next location */
		 if(cur_input_loc_col_num == CONFIGURE_MAX_NUM_COLS)
		 {	 
			next_input_loc_line_num = cur_input_loc_line_num + 1;
			next_input_loc_col_num = NUM_COL1;
		 }
         else
         {
			 next_input_loc_line_num = cur_input_loc_line_num;
			 next_input_loc_col_num = cur_input_loc_col_num + 1;
		 }	
		 From_XY_To_Loc_LCD(next_input_loc_line_num, next_input_loc_col_num, &cur_input_lcd_loc);
		 
        entered_cur_input_data[num_chars_entered_cur_data] =key_data;   
        ++num_chars_entered_cur_data; 	 
           		
	 }   		 
	  /* keep track of cur_input_lcd_loc as baskspace we need to -- it and also disp timeouts with.
 	  LCD automatically increments due to loc_command(0x06)in our case as after eg Write_LCD_Command(0x80)
	  ie set DDRAM */      
      enter_sw_enable_flag = STATE_YES;
      backspace_sw_enable_flag = STATE_YES;	     
  }
}     
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 12   
-*------------------------------------------------------------*/
void Entered_Backspace_Sw_No_Long_Press_Proc()
{
	unsigned int cur_input_loc_line_num, cur_input_loc_col_num, previous_input_loc_line_num, previous_input_loc_col_num;
	
	lcd_avail_loc_within_limit = STATE_YES;	
       	
    if(num_chars_entered_cur_data > 0 && num_chars_entered_cur_data <= cur_data_input_max_num_chars_allocated )
    {
	    From_Loc_to_XY_LCD(cur_input_lcd_loc, &cur_input_loc_line_num, &cur_input_loc_col_num);
	   if(cur_input_loc_line_num == NUM_LINE1 && cur_input_loc_col_num == NUM_COL1)
	   {	 
		 /* reached begin of line 1 and valid backspace is pressed, retain same loc position */ 
	   }
	   else
	   {
		 /* put cur input lcd loc to one location back from current loc */
		 if(cur_input_loc_col_num == NUM_COL1)
		 {	 
			 previous_input_loc_line_num = cur_input_loc_line_num - 1;
			 previous_input_loc_col_num = CONFIGURE_MAX_NUM_COLS;
		 }
         else
         {
			 previous_input_loc_line_num = cur_input_loc_line_num;
			 previous_input_loc_col_num = cur_input_loc_col_num - 1;
		 }	
		 From_XY_To_Loc_LCD(previous_input_loc_line_num, previous_input_loc_col_num, &cur_input_lcd_loc);
		 
         /* do clear last char operation */
		 entered_cur_input_data[num_chars_entered_cur_data] = '\0'; 
		  /* to get key at previous location */
         Write_LCD_Command(cur_input_lcd_loc);
         --num_chars_entered_cur_data;
         Write_LCD_Data(' '); 
         Write_LCD_Command(0x10); //shift cursor to left  	 
           		
	  }  
	  Write_LCD_Command(cur_input_lcd_loc);
      Write_LCD_Command(0x0E);	
   }
}    
/*------------------------------------------------------------*
FUNCTION NAME  : main

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 1   
-*------------------------------------------------------------*/

void main()
{                               
      TRISA = 0x07;
      PORTA = 0x00;
	  /* to leave T1G pin in portb as input to PIC ie RB5 = 1 in TRISB  to run timer 1, if timer1 conf ie T1CON = (0xC5) was set run timer1. 
        if T1G pin in portb is 0 ie RB5 = 0	in TRISB, even if timer1 is conf ie T1CON = (0xC5) was set to run timer1, timer1 will not run.
        T1G pin is input to PIC to control run Timer1, if gate control for Timer 1 to run is enabled. 
		If T1CON = (0x85),  gate control for Timer 1 is disabled, so T1G pin can have used for other purpose */
	  TRISB = 0x00;
	  PORTB = 0x00;
      TRISC = 0x00;
      PORTC = 0x00;
       TRISD  = 0x78;
       PORTD = 0x00;
       TRISE = 0x00;
       PORTE = 0x00;
       ANSEL = 0x00;
       ANSELH = 0x00;
       LCD_Init();
       Init_Const_Data();
       Reset_Process();
       Run_Timer0();
       for(;;)
       {  
          //Timer0_Tick(); // commited  due to stack overflow and Timer0_Tick() contents are inserted below
		   while(T0IF == 0);
               T0IF = 0;
            TMR0= (256UL) - (INC0/prescale_timer0);
	        if(++num_calls_timer0 >= UPDATE_TIME0)
            {
				num_calls_timer0 = 0; 	
				// Auth_Proc();
               while(key_or_sw_input_enable_flag == STATE_YES)
               { 
                   Is_Numchars_Within_Limit();  
	               KEYPAD_PHONE_ROWA = 1;
                   KEYPAD_PHONE_ROWB  = 0;
                   KEYPAD_PHONE_ROWC  = 0;
                   KEYPAD_PHONE_ROWD  = 0; 
                  if(KEYPAD_PHONE_COL1 == KEY_PRESSED)
                  {
		              cur_pressed_key_or_sw = keypad_char[0];//latest pressed key/switch					 
		             if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                     {
						Stoke_Rcvd_Tmr1_Long_Press_Proc(); 						
                         while(KEYPAD_PHONE_COL1 ==KEY_PRESSED)
		                 {
			               Check_Long_Pressed_Key();
                           if(timeout_long_pressed_key_flag == STATE_YES)
                           {
			            		break;
                           }                  
		                }
			            After_Key_Stoke_Proc(cur_pressed_key_or_sw);					
		            } 		  
                 }
                 if(KEYPAD_PHONE_COL2 == KEY_PRESSED)
                 {
		             cur_pressed_key_or_sw = keypad_char[1];//latest pressed key/switch
					 if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                     {
		            	 Stoke_Rcvd_Tmr1_Long_Press_Proc(); 
                         while(KEYPAD_PHONE_COL2 ==KEY_PRESSED)
		                 {
		            	    Check_Long_Pressed_Key();
                           if(timeout_long_pressed_key_flag == STATE_YES)
                           {
			         	    	break;
                           }                  
		                 }
			            After_Key_Stoke_Proc(cur_pressed_key_or_sw);					
		             } 		  
                  } 
                 if(KEYPAD_PHONE_COL3 == KEY_PRESSED)
                 {
	        	     cur_pressed_key_or_sw = keypad_char[2];//latest pressed key/switch					
	        	     if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                     {
		            	 Stoke_Rcvd_Tmr1_Long_Press_Proc(); 
                         while(KEYPAD_PHONE_COL3 ==KEY_PRESSED)
		                 {
			                 Check_Long_Pressed_Key();
                            if(timeout_long_pressed_key_flag == STATE_YES)
                            {
			            		break;
                            }                  
		                 }
		             	After_Key_Stoke_Proc(cur_pressed_key_or_sw);				
		             } 		  
                  } 
                  KEYPAD_PHONE_ROWA = 0;
                  KEYPAD_PHONE_ROWB  = 1;
                  KEYPAD_PHONE_ROWC  = 0;
                  KEYPAD_PHONE_ROWD  = 0; 
                 if(KEYPAD_PHONE_COL1 == KEY_PRESSED)
                  {
		              cur_pressed_key_or_sw = keypad_char[3];//latest pressed key/switch					  
		             if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                     {
		            	Stoke_Rcvd_Tmr1_Long_Press_Proc();  
                        while(KEYPAD_PHONE_COL1 ==KEY_PRESSED)
		                {
			               Check_Long_Pressed_Key();
                          if(timeout_long_pressed_key_flag == STATE_YES)
                          {
			            		break;
                          }                  
		               }
			           After_Key_Stoke_Proc(cur_pressed_key_or_sw);					
		             } 		  
                  } 
                  if(KEYPAD_PHONE_COL2 == KEY_PRESSED)
                  {
	       	           cur_pressed_key_or_sw = keypad_char[4];//latest pressed key/switch					  
                      if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                      {
		              	Stoke_Rcvd_Tmr1_Long_Press_Proc();  
                         while(KEYPAD_PHONE_COL2 ==KEY_PRESSED)
		                 {
		    	             Check_Long_Pressed_Key();
                            if(timeout_long_pressed_key_flag == STATE_YES)
                            {
		    	        		break;
                            }                  
		                 }
		    	        After_Key_Stoke_Proc(cur_pressed_key_or_sw);					
		             } 		  
                   } 
                  if(KEYPAD_PHONE_COL3 == KEY_PRESSED)
                  {
	            	  cur_pressed_key_or_sw = keypad_char[5];//latest pressed key/switch					  
	            	  if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                      {
		            	 Stoke_Rcvd_Tmr1_Long_Press_Proc(); 
                        while(KEYPAD_PHONE_COL3 ==KEY_PRESSED)
		                {
		            	    Check_Long_Pressed_Key();
                            if(timeout_long_pressed_key_flag == STATE_YES)
                            {
		            			break;
                            }                  
		                }
		            	After_Key_Stoke_Proc(cur_pressed_key_or_sw);						
		             } 		  
                  }  
                  KEYPAD_PHONE_ROWA = 0;
                  KEYPAD_PHONE_ROWB  = 0;
                  KEYPAD_PHONE_ROWC  = 1;
                  KEYPAD_PHONE_ROWD  = 0; 
                 if(KEYPAD_PHONE_COL1 == KEY_PRESSED)
                 {
	            	  cur_pressed_key_or_sw = keypad_char[6];//latest pressed key/switch
					  if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                      {
		             	 Stoke_Rcvd_Tmr1_Long_Press_Proc(); 
                         while(KEYPAD_PHONE_COL1 ==KEY_PRESSED)
		                 {
		             	    Check_Long_Pressed_Key();
                           if(timeout_long_pressed_key_flag == STATE_YES)
                           {
		    	        		break;
                           }                  
	                     }
		               	After_Key_Stoke_Proc(cur_pressed_key_or_sw);					
		              } 		  
                  } 
                  if(KEYPAD_PHONE_COL2 == KEY_PRESSED)
                  {
	            	  cur_pressed_key_or_sw = keypad_char[7];//latest pressed key/switch					 
	            	  if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                      {
	            		 Stoke_Rcvd_Tmr1_Long_Press_Proc(); 
                         while(KEYPAD_PHONE_COL2 ==KEY_PRESSED)
	               	     {
	            		    Check_Long_Pressed_Key();
                           if(timeout_long_pressed_key_flag == STATE_YES)
                           {
	            				break;
                           }                  
	            	    }
	             		After_Key_Stoke_Proc(cur_pressed_key_or_sw);					
	            	  } 		  
                   } 
                   if(KEYPAD_PHONE_COL3 == KEY_PRESSED)
                   {
	              	  cur_pressed_key_or_sw = keypad_char[8];//latest pressed key/switch
	          	      if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                      {
	        	    	 Stoke_Rcvd_Tmr1_Long_Press_Proc(); 
                         while(KEYPAD_PHONE_COL3 ==KEY_PRESSED)
	         	         {
	        	    	    Check_Long_Pressed_Key();
                            if(timeout_long_pressed_key_flag == STATE_YES)
							{	
 		    			         break;
                            }                  
						 }
		                 After_Key_Stoke_Proc(cur_pressed_key_or_sw);					
		               } 		  
                    } 
                    KEYPAD_PHONE_ROWA = 0;
                    KEYPAD_PHONE_ROWB  = 0;
                     KEYPAD_PHONE_ROWC  = 0;
                    KEYPAD_PHONE_ROWD  = 1; 
                    if(KEYPAD_PHONE_COL1 == KEY_PRESSED)
                    {
	             	   cur_pressed_key_or_sw = keypad_char[9];//latest pressed key/switch
					   
	             	  if(keypad_keys_enable_flag == STATE_YES && cur_data_can_also_input_nonnum_key == STATE_YES&& max_input_num_chars_flag ==STATE_NO )
                      {
	            		 Stoke_Rcvd_Tmr1_Long_Press_Proc(); 
                         while(KEYPAD_PHONE_COL1 ==KEY_PRESSED)
		                 {
		             	    Check_Long_Pressed_Key();
                            if(timeout_long_pressed_key_flag == STATE_YES)
                            {
		             			break;
                           }                  
	            	     }
		             	 After_Key_Stoke_Proc(cur_pressed_key_or_sw);					
		               } 		  
                     } 
                     if(KEYPAD_PHONE_COL2 == KEY_PRESSED)
                      {
		                 cur_pressed_key_or_sw = keypad_char[10];//latest pressed key/switch
						
		                 if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                         {
		                	Stoke_Rcvd_Tmr1_Long_Press_Proc();  
                             while(KEYPAD_PHONE_COL2 ==KEY_PRESSED)
		                     {
		                	    Check_Long_Pressed_Key();
                                if(timeout_long_pressed_key_flag == STATE_YES)
                                {
		                   			break;
                                 }                  
	                         }
		                	After_Key_Stoke_Proc(cur_pressed_key_or_sw);				
		                  } 		  
                       }                                               
                       if(KEYPAD_PHONE_COL3 == KEY_PRESSED)
                       {
	                  	  cur_pressed_key_or_sw = keypad_char[11];//latest pressed key/switch
						  
	                   	  if(keypad_keys_enable_flag == STATE_YES && cur_data_can_also_input_nonnum_key == STATE_YES && max_input_num_chars_flag ==STATE_NO )
                          {
	                  		 Stoke_Rcvd_Tmr1_Long_Press_Proc(); 
                             while(KEYPAD_PHONE_COL3 ==KEY_PRESSED)
		                     {
		                  	    Check_Long_Pressed_Key();
                                 if(timeout_long_pressed_key_flag == STATE_YES)
                                {
		                			break;
                                }                  
	                        }
		                	After_Key_Stoke_Proc(cur_pressed_key_or_sw);					
		                  } 		  
                        }    
    
                        if(ENTER_SW == KEY_PRESSED)
                        {
	                    	 cur_pressed_key_or_sw = ENTER_SW_CODE;//latest pressed key/switch
							 if(enter_sw_enable_flag == STATE_YES)
							 {	 
	                    	    Stoke_Rcvd_Tmr1_Long_Press_Proc(); 
	                    	    max_input_num_chars_flag = STATE_NO;
								
                                while(ENTER_SW == KEY_PRESSED )
                                { 
                                   Check_Long_Pressed_Key();
                                   if(timeout_long_pressed_key_flag == STATE_YES)
                                   {                                    
                                       break;
                                   }                  
		                        }
		                        After_Switch_Stoke_Proc(cur_pressed_key_or_sw); 	      		 
                             }
						}							 
                         if(BACKSPACE_SW ==KEY_PRESSED )		 
                         {
                            cur_pressed_key_or_sw = BACKSPACE_SW_CODE;//latest pressed key/switch
						   	if(backspace_sw_enable_flag == STATE_YES)
						    {
						        Stoke_Rcvd_Tmr1_Long_Press_Proc(); 
                                while(BACKSPACE_SW == KEY_PRESSED ) 
	                            {    
                                   Check_Long_Pressed_Key();
                                    if(timeout_long_pressed_key_flag == STATE_YES)  
						            {     
                  	  		            break;
                                    }                              
		                        }
		                        After_Switch_Stoke_Proc(cur_pressed_key_or_sw); 
                             }					  
                         }
                         if(ACCOUNT_SW ==KEY_PRESSED )		 
                         {
                            cur_pressed_key_or_sw = ACCOUNT_SW_CODE;//latest pressed key/switch
						   	if(account_sw_enable_flag == STATE_YES)
						    {					
                                
						       Stoke_Rcvd_Tmr1_Long_Press_Proc(); 
                                while(ACCOUNT_SW == KEY_PRESSED ) 
	                            {    
                                    Check_Long_Pressed_Key();
                                    if(timeout_long_pressed_key_flag == STATE_YES)  
						            {     
                  	  		            break;
                                    }                              
		                        }
		                        After_Switch_Stoke_Proc(cur_pressed_key_or_sw); 
                             }					  
                         }						 
						if(status_disp_fsm != INITIAL && cur_line_disp_data[ALL_LINES] == ANY_DATA_DISP )
                        { 
	  	                   Disp_Status_Fsm(); 
		                   cur_line_disp_data[ALL_LINES] = AUTH_STATUS_DISP;     
                        } 
			 	        if(need_input_flag == STATE_YES && detect_presskey_flag != STATE_YES)
                        { 
                            Check_No_Key_Press();            
                        }
                    }                    
                   if(RESET_SW ==KEY_PRESSED )
                   {
	                  cur_pressed_key_or_sw = RESET_SW_CODE;//latest pressed key/switch
					  if(reset_sw_enable_flag == STATE_YES)
					  {	  
	                      Stoke_Rcvd_Tmr1_Long_Press_Proc(); 
                          while(RESET_SW == KEY_PRESSED ) 
	                      {  
                 	          Check_Long_Pressed_Key();
                              if(timeout_long_pressed_key_flag == STATE_YES)  
		                      {                   	  		 
                                    break;
                               } 		   
	                      }
                          After_Switch_Stoke_Proc(cur_pressed_key_or_sw);	
					  }							
                   }		
              } 
	    }	  
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 7   
-*------------------------------------------------------------*/
void Check_No_Key_Press()
{
    if(timer1_mode == TMR1_OFF_STATE)
	{
        Run_Timer1(TMR1_MODE_NO_KEY_PRESS);		
    }
	if(timer1_mode == TMR1_MODE_NO_KEY_PRESS)
	{
		while(TMR1IF == 0);		                
		
		TMR1IF = 0;
		timer1_init = (65536) - (INC1/prescale_timer1); 
        TMR1H = timer1_init / 256;
        TMR1L = timer1_init % 256; 
		
        if(++num_calls_timer1 >= UPDATE_TIME1_NO_KEY_PRESS)
        {
		     No_Key_Press_Proc();                			 
             num_calls_timer1 = 0;        
       }	 
	}
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 45   
-*------------------------------------------------------------*/
void No_Key_Press_Proc()
{
    if(++count_update_no_key_per_sec % NO_KEY_PRESS_FACTOR_PER_SEC == 0 )
   { 
       count_update_no_key_per_sec = 0;
       --time_left_no_key_press;   	 
	   
       /* data is constant for a while, so if data is const,at lcd const data is displayed only once until const data at that line has changed */
	  if(disp_status_time_or_error[NO_KEY_PRESS_TIME_STATUS_DISP_INDEX] == STATUS_DISP_ON && \
	    cur_line_disp_data[NO_KEYPRESS_TIMEOUT_LINE_NUM] == BLANK_LINE_DISP)  
       {
		   Goto_XY_LCD_Disp(NO_KEYPRESS_TIMEOUT_LINE_NUM, NUM_COL1); 
		   Data_Str_Disp_LCD(timeout_no_key_msg_disp);
		   Goto_XY_LCD_Disp(NO_KEYPRESS_TIMEOUT_LINE_NUM, start_col_no_key_time_msg_disp );	
		   Data_Str_Disp_LCD(time_msg_disp);            
		   cur_line_disp_data[NO_KEYPRESS_TIMEOUT_LINE_NUM] = NO_KEY_PRESS_TIMEOUT_DISP;
		  /* to get data at cur_input_lcd_loc*/
           Write_LCD_Command(cur_input_lcd_loc);
	       Write_LCD_Command(0x0C);       		   
       }	   
	   
	   /* disp variable data every time at loc, if line has long press key data */
	  if( disp_status_time_or_error[NO_KEY_PRESS_TIME_STATUS_DISP_INDEX] == STATUS_DISP_ON && \
	     cur_line_disp_data[NO_KEYPRESS_TIMEOUT_LINE_NUM] == NO_KEY_PRESS_TIMEOUT_DISP)   
	   {
		   Goto_XY_LCD_Disp(NO_KEYPRESS_TIMEOUT_LINE_NUM, start_col_no_key_time_disp ); 
           Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT2, time_left_no_key_press);  
       }		   
       if(time_left_no_key_press == 0)
       {
		   timeout_nokey_press_flag = STATE_YES;
		   Stop_Timer1();
		   NO_KEY_PRESS_LED_PIN = LED_ON; 
	       cur_line_disp_data[ALL_LINES] = ANY_DATA_DISP;			    
	       status_disp_fsm =  TIMEOUT_NO_KEY_PRESS; 
	       disp_status_flag = STATE_YES;			    		  
           Disp_Status_Fsm();
               	  
      }	
   }  
}	

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 2   
-*------------------------------------------------------------*/
void Check_Long_Pressed_Key()
{
	unsigned long int count = 0; 
	
    //  Timer1_Tick(); // commited due to stack overflow, Timer1_Tick() contents are inserted as below
	 if(timer1_mode == TMR1_OFF_STATE)
	    Run_Timer1(TMR1_MODE_LONG_PRESS_KEY);	
    if(timer1_mode == TMR1_MODE_LONG_PRESS_KEY)
	 {
		
	    while(TMR1IF == 0);		                
		
		TMR1IF = 0;
		timer1_init = (65536) - (INC1/prescale_timer1); 
        TMR1H = timer1_init / 256;
        TMR1L = timer1_init % 256; 
		
        if(++num_calls_timer1 >= UPDATE_TIME1_LONG_PRESS_KEY)
        {
		     Long_Press_Key_Proc();                			 
             num_calls_timer1 = 0;        
        }	 
	}	   
} 

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 15  
-*------------------------------------------------------------*/
void Run_Timer1(const unsigned int set_timer1_mode )
{
	
  if(timer1_mode == TMR1_OFF_STATE)
  {
	/*internal timer1 clock  with 1:1 prescale,Timer1 counts when gate(T1G) is high 
     Timer1 counting is controlled by the Timer1 Gate function and no gate input is feed
     and enable timer1*/
	 
	  TMR1H = 0;
      TMR1L = 0;
	  TMR1IF = 0;
	  timer1_mode = set_timer1_mode;
	  /* for T1G gate based  timer 1 running control, Timer1 runs when T1G is high. If T1G is low, timer1 pauses counting */
	 // T1CON =0xC5; 

	 /*internal timer1 clock  with 1:1 prescale, gate(T1G) control for Timer1 is disabled  and enable timer1 and timer 1 runs Timer1 runs */
      T1CON =0x85;   
      prescale_timer1 = 0x01;
      prescale_shift_timer1= 0;
      Prescale_Timer1();
      timer1_init = (65536UL) - (INC1/prescale_timer1); 
      TMR1H = timer1_init / 256UL;
      TMR1L = timer1_init % 256UL; 
      num_calls_timer1 = 0;  
  }
  else
  {
	  /* dont run the timer1 if timer1 is already running  */
	  /* error: try to run timer1, which is not in off state */
	  Error_or_Warning_Proc("15.01", FATAL_OCCURED, ERR_TRY_TORUN_TMR1_ALREADY_RUNNING_CODE);
  }	  
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 45  
-*------------------------------------------------------------*/
 void Stoke_Rcvd_Tmr1_Long_Press_Proc()   
 {
	 Stop_Timer1();
	 detect_presskey_flag = STATE_YES; // key press has been detected 	 
 }

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 16  
-*------------------------------------------------------------*/
void Stop_Timer1()
{
	if(timer1_mode != TMR1_OFF_STATE)
	{	
	   timer1_mode = TMR1_OFF_STATE;
	   T1CON = 0x80;
	}   
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 17  
-*------------------------------------------------------------*/
void Prescale_Timer1()
{
   if(T1CKPS0 == 1)
   {
      prescale_shift_timer1 |= 0x01;           
   }
   if(T1CKPS1 == 1)
   {
     prescale_shift_timer1 |= 0x02;
   }  
   prescale_timer1 = prescale_timer1  << prescale_shift_timer1;                                                      
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 18   
-*------------------------------------------------------------*/
void Prescale_Timer0()
{
   if(PS0 == 1)
   {
      prescale_shift_timer0 |= 0x01;           
   }
   if(PS1 == 1)
   {
     prescale_shift_timer0 |= 0x02;
   }  
   if(PS2 == 1)
   {
     prescale_shift_timer0 |= 0x04;
   } 
   prescale_timer0 = prescale_timer0  << prescale_shift_timer0;                                                       
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 19  
-*------------------------------------------------------------*/
void Run_Timer0()
{
   T0CS  = 0; // Internal Clock
   PSA = 0 ;//PRESCALE SET for timer 0
   PS0 = 0; //prescaler 1:8 
   PS1 = 1;
   PS2 = 0;
   prescale_timer0 =  0x02;
   prescale_shift_timer0= 0;
   Prescale_Timer0();
   TMR0= (256UL) - (INC0/prescale_timer0);
   num_calls_timer0 = 0;
   
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 20   
-*------------------------------------------------------------*/
void Init_Const_Data()
{
	/* in var defination only const expression will be used for var initialzation,
	so in var definition, strlen() cannot be used for var initialzation */
	
    time_msg_disp_len = strlen(time_msg_disp);
    count_msg_disp_len = strlen(count_msg_disp);
	long_press_timeout_msg_disp_len = strlen(timeout_long_press_msg_disp); 
    /*start_col_time_long_press_msg_disp = 2 = 1(cur_pressed_key_or_sw) + 1 (next loc) */	  
	start_col_long_press_timeout_msg_disp = sizeof(char) + 1; 
    start_col_long_press_time_msg_disp = long_press_timeout_msg_disp_len + start_col_long_press_timeout_msg_disp;
	/* loc for long press time msg disp = time_long_press_disp_len
    + 2( char of cur_pressed_key_or_sw(1) + col starts from 1 for us but for uC col starts from 0 so 1 is added) */
	start_col_long_press_time_disp = start_col_long_press_time_msg_disp + time_msg_disp_len;
	 /* count msg disp at loc = start loc of disp_loc_long_press_time + 2(2 space for display 2 digit time)  */
	start_col_long_press_count_msg_disp = start_col_long_press_time_disp + 2;
    start_col_long_press_count_disp = start_col_long_press_count_msg_disp + count_msg_disp_len; 
	
	 start_col_no_key_time_msg_disp = strlen(timeout_no_key_msg_disp) + 1;
	 start_col_no_key_time_msg_disp, start_col_no_key_time_disp = strlen(timeout_no_key_msg_disp) + 1 + strlen(time_msg_disp);
	 
	 auth_timeout_msg_len = strlen(auth_timeout_msg_disp);
	 // 1 (next loc)
	 start_col_reason_timeout_msg_disp = auth_timeout_msg_len + NUM_COL1; 
	 start_col_error_msg  = strlen(error_msg_disp) + 1;
	
	 start_col_blank_space =  start_col_error_msg + NUM_CHARS_TRACE_CODE;
	  /* (1) = 1 BLANK SPACE */
	 start_col_error_code =  start_col_blank_space + 1 ; 
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void LCD_Init()
{
    Write_LCD_Command(0x30);
    Write_LCD_Command(0x30);
    Write_LCD_Command(0x30);
    Write_LCD_Command(0x38);
    Write_LCD_Command(0x01);
    Write_LCD_Command(0x0E); //insert cursor on at cur_input_lcd_loc
	//Write_LCD_Command(0x0C);
    Write_LCD_Command(0x06);                                       
}     

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 23   
-*------------------------------------------------------------*/
  void Write_LCD_Command (unsigned int cmd)
  {
	  unsigned long int  time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	  
       RW_PIN = 0;
       RS_PIN = 0; 
       LCD_PORT = cmd;
      // LCD_Pulse();
	  EN_PIN = 1;
	  while(time_delay--);
    // Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);
      EN_PIN = 0;
	  time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	  while(time_delay--);
   //  Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);
 }
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 24   
-*------------------------------------------------------------*/
 void Write_LCD_Data(const char ch)
{
	unsigned long int  time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	// performance degraded if many data is written to LCD, to check if write loc is within avail disp loc
	// if(lcd_avail_loc_within_limit == STATE_YES) 
	{	
      RW_PIN = 0;
      RS_PIN = 1;
      LCD_PORT =ch;
     // LCD_Pulse();
      EN_PIN = 1;
	  while(time_delay--);
    // Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);
     EN_PIN = 0;
	 time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	  while(time_delay--);
   //  Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);	 
	}
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 25   
-*------------------------------------------------------------*/

void Data_Str_Disp_LCD(const char *char_ptr)
{ 
       while(*char_ptr)
       {
            Write_LCD_Data(*(char_ptr++));
       }
     
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 27  
-*------------------------------------------------------------*/
void Delay_Time_ByCount( unsigned int time_delay)
{
       while(time_delay--);
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 26  
-*------------------------------------------------------------*/
void Data_Num_Disp_LCD(const unsigned int lcd_datanum_disp_format, const unsigned long lcd_disp_data_int)
{
    unsigned int tens_thousand_digit,thousands_digit, hundreds_digit,tens_digit, unit_digit;
    unsigned long num = lcd_disp_data_int;
    char num_data[] ={'0','1','2','3','4','5','6','7','8','9'};  
	char hex_data[] ={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'}; 
    switch(lcd_datanum_disp_format)
	{
	  case DISP_FLAG_NUM_DIGIT5: 
		  num =  lcd_disp_data_int % 100000;
		  tens_thousand_digit = (unsigned int)(num / (unsigned long)(10000));
          Write_LCD_Data(num_data[tens_thousand_digit]);
	  case DISP_FLAG_NUM_DIGIT4:
	      num = lcd_disp_data_int % 10000;
	      thousands_digit = (unsigned int)(num / (unsigned long)(1000));
	      Write_LCD_Data(num_data[thousands_digit]); 
	  case DISP_FLAG_NUM_DIGIT3: 
		  num = lcd_disp_data_int % 1000;
	      hundreds_digit = (unsigned int) (num / (unsigned long) (100));
	      Write_LCD_Data(num_data[hundreds_digit]);
	  case DISP_FLAG_NUM_DIGIT2:
          num = lcd_disp_data_int % 100;
          tens_digit = (unsigned int) (num / 10);
          Write_LCD_Data(num_data[tens_digit]); 		  
	  case DISP_FLAG_NUM_DIGIT1:
	     unit_digit = (unsigned int) (lcd_disp_data_int % 10);
         Write_LCD_Data(num_data[unit_digit]); 
	  break;
	  case DISP_FLAG_HEX_DIGIT4:
	      /*  ( 16 * 16 * 16 *16 )  = 0 as divide by zero warning */
	      //num = lcd_disp_data_int % ( 16 * 16 * 16 *16 );
          thousands_digit = (num / (16 * 16 * 16));
	      Write_LCD_Data(hex_data[thousands_digit]);
	  case DISP_FLAG_HEX_DIGIT3:
	      num = lcd_disp_data_int %(unsigned long)(16 * 16 * 16);
	      hundreds_digit = (unsigned int) (num / (unsigned long) (16 * 16));
	      Write_LCD_Data(hex_data[hundreds_digit]);
	  case DISP_FLAG_HEX_DIGIT2:
	      num = lcd_disp_data_int %(unsigned long)(16 * 16);
          tens_digit = (unsigned int) (num / 16);
          Write_LCD_Data(hex_data[tens_digit]);
	  case DISP_FLAG_HEX_DIGIT1: 
	      unit_digit = (unsigned int) (lcd_disp_data_int % 16);
          Write_LCD_Data(hex_data[unit_digit]);    
	  break;
	  default:
	     Error_or_Warning_Proc("26.01", WARNING_OCCURED, ERR_LCD_DISP_NUM_FORMAT_CODE);
		     /* Warning invalid lcd_disp flag */
	    ;
	}   	
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 44  
-*------------------------------------------------------------*/
void Data_4Digit_Hex_Disp_LCD(const unsigned long lcd_disp_data_int)
{
	unsigned int tens_thousand_digit,thousands_digit, hundreds_digit,tens_digit, unit_digit;
    unsigned long num = lcd_disp_data_int;
	char hex_data[] ={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
	
	thousands_digit = (num / (16 * 16 * 16));
	Write_LCD_Data(hex_data[thousands_digit]);
	num = lcd_disp_data_int %(unsigned long)(16 * 16 * 16);
	hundreds_digit = (unsigned int) (num / (unsigned long) (16 * 16));
	Write_LCD_Data(hex_data[hundreds_digit]);
	num = lcd_disp_data_int %(unsigned long)(16 * 16);
    tens_digit = (unsigned int) (num / 16);
    Write_LCD_Data(hex_data[tens_digit]);
	unit_digit = (unsigned int) (lcd_disp_data_int % 16);
    Write_LCD_Data(hex_data[unit_digit]);    
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 28  
-*------------------------------------------------------------*/
/* make sure that loc are within avail lcd loc limit */
void Set_Cur_Loc_LCD(const char set_input_loc_flag,const unsigned int set_input_loc, const char set_disp_loc_flag, const unsigned int set_disp_loc)
{
   if(set_input_loc_flag == STATE_YES)  
     cur_input_lcd_loc = set_input_loc;
   if(set_disp_loc_flag == STATE_YES)
     cur_disp_lcd_loc = set_disp_loc; 
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 29   
-*------------------------------------------------------------*/
void Goto_XY_LCD_Disp(const unsigned int start_line_num, const unsigned int start_col_num)
{
	/* max 4 lines and 20 columns */
	/* for us, lcd line starts from 1, but for uC, line starts from 0 */
	/* for us, lcd col starts from 1, but for uC, col starts from 0 */
    unsigned int start_line_lcd = start_line_num - 1, start_col_lcd = start_col_num - 1, error_disp_start_loc; 
	lcd_avail_loc_within_limit = STATE_YES;
	
   if(start_line_num <= CONFIGURE_MAX_NUM_LINES && start_col_num <= CONFIGURE_MAX_NUM_COLS )
   {
      switch(start_line_num)
	 {
		 case NUM_LINE1:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE1;
		   break;
		 case NUM_LINE2:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE2;
		   break;
		 case NUM_LINE3:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE3;
		   break;
		  case NUM_LINE4:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE4;
		   break;		 
	 }	
      cur_disp_lcd_loc = cur_disp_lcd_loc + start_col_lcd;
      Write_LCD_Command(cur_disp_lcd_loc);       
   }
   else
   {
	   /* error due to invalid lcd DISP loc  */
	     lcd_avail_loc_within_limit = STATE_NO;		
		 Error_or_Warning_Proc("29.01", FATAL_OCCURED, ERR_CUR_DISP_LOC_CODE);        		
   }	   
} 
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 30   
-*------------------------------------------------------------*/ 
void Goto_XY_LCD_Input(unsigned int start_line_num,unsigned int start_col_num)
{
	/* for us, lcd line starts from 1, but for uC, line starts from 0 */
	/* for us, lcd col starts from 1, but for uC, col starts from 0 */
    unsigned int start_line_lcd = start_line_num - 1, start_col_lcd = start_col_num - 1; 
	
	/* max 4 lines and 20 columns */
	lcd_avail_loc_within_limit = STATE_YES;
	if( start_line_num <= CONFIGURE_MAX_NUM_LINES &&  start_col_num <= CONFIGURE_MAX_NUM_COLS )
   {
     switch(start_line_num)
	 {
		 case NUM_LINE1:
		   cur_input_lcd_loc = BEGIN_LOC_LINE1;
		   break;
		 case NUM_LINE2:
		   cur_input_lcd_loc = BEGIN_LOC_LINE2;
		   break;
		 case NUM_LINE3:
		   cur_input_lcd_loc = BEGIN_LOC_LINE3;
		   break;
		  case NUM_LINE4:
		   cur_input_lcd_loc = BEGIN_LOC_LINE4;
		   break; 		  
	 }
	 cur_input_lcd_loc = cur_input_lcd_loc + start_col_lcd;
     Write_LCD_Command(cur_input_lcd_loc); 	 	   
  }
  else
  {
	   /* error due to invalid Lcd loc  */	
	   lcd_avail_loc_within_limit = STATE_NO;
	   Error_or_Warning_Proc("30.01", FATAL_OCCURED, ERR_CUR_INPUT_LOC_CODE);
	  
  }	  
} 

 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 43   
-*------------------------------------------------------------*/
void Goto_XY_LCD_Disp_Err(const unsigned int start_line_num, const unsigned int start_col_num)
{
	/* max 4 lines and 20 columns */
	/* for us, lcd line starts from 1, but for uC, line starts from 0 */
	/* for us, lcd col starts from 1, but for uC, col starts from 0 */
    unsigned int start_line_lcd = start_line_num - 1, start_col_lcd = start_col_num - 1, error_disp_start_loc; 
	lcd_avail_loc_within_limit = STATE_YES;
	
   if(start_line_num <= MAX_AVAIL_NUM_LINES && start_col_num <= MAX_AVAIL_NUM_COLS )
   {
      switch(start_line_num)
	 {
		 case NUM_LINE1:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE1;
		   break;
		 case NUM_LINE2:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE2;
		   break;
		 case NUM_LINE3:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE3;
		   break;
		  case NUM_LINE4:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE4;
		   break;		 
	 }	
      cur_disp_lcd_loc = cur_disp_lcd_loc + start_col_lcd;
      Write_LCD_Command(cur_disp_lcd_loc);       
   }
   else
   {
	   /* ERROR: loc exceeds max avail loc in lcd*/
   }
}  

 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 31   
-*------------------------------------------------------------*/
void From_XY_To_Loc_LCD(const unsigned int start_line_num, const unsigned int start_col_num, unsigned int * const lcd_loc)
{
	/* max 4 lines and 20 columns */
	   
	lcd_avail_loc_within_limit = STATE_YES;
	
   if(start_line_num <= CONFIGURE_MAX_NUM_LINES && start_col_num <= CONFIGURE_MAX_NUM_COLS )
   {
      switch(start_line_num)
	 {
		 case NUM_LINE1:
		   *lcd_loc = BEGIN_LOC_LINE1;
		   break;
		 case NUM_LINE2:
		   *lcd_loc = BEGIN_LOC_LINE2;
		   break;
		 case NUM_LINE3:
		   *lcd_loc= BEGIN_LOC_LINE3;
		   break;
		  case NUM_LINE4:
		  *lcd_loc = BEGIN_LOC_LINE4;
		   break;		 
	 }	
      *lcd_loc = *lcd_loc + start_col_num - 1;           
   }
   else
   {
	    lcd_avail_loc_within_limit = STATE_NO;
		/* error: due to loc_lcd's line num > max configured line nums */	
		 Error_or_Warning_Proc("31.01", FATAL_OCCURED, ERR_CUR_INPUT_DATA_LOC_CODE);
	   		
   }	   
} 
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void From_Loc_to_XY_LCD(const unsigned int loc_lcd, unsigned int * const loc_lcd_line_num, unsigned int * const loc_lcd_col_num  )
{
	/* loc_lcd's corrosponding line num and col num */
	
	lcd_avail_loc_within_limit = STATE_YES;
	
	if(CONFIGURE_MAX_NUM_LINES <= MAX_AVAIL_NUM_LINES)
	{	
    	if(loc_lcd >= BEGIN_LOC_LINE1 && loc_lcd <= END_LOC_LINE1)
	    {
		     *loc_lcd_line_num = NUM_LINE1;
	         *loc_lcd_col_num = loc_lcd + 1 - BEGIN_LOC_LINE1;		    
	    }
       if(loc_lcd >= BEGIN_LOC_LINE2 && loc_lcd <= END_LOC_LINE2)
	   {
	     	*loc_lcd_line_num = NUM_LINE2;
		    *loc_lcd_col_num = loc_lcd + 1 - BEGIN_LOC_LINE2; 		
	   }     
	   if(loc_lcd >= BEGIN_LOC_LINE3 && loc_lcd <= END_LOC_LINE3)
	   {
		   	*loc_lcd_line_num = NUM_LINE3;
		  	*loc_lcd_col_num = loc_lcd + 1 - BEGIN_LOC_LINE3;			
	   }
       if(loc_lcd >= BEGIN_LOC_LINE4 && loc_lcd <= END_LOC_LINE4)
	   {
		  	*loc_lcd_line_num = NUM_LINE4;
		   	*loc_lcd_col_num = loc_lcd + 1 - BEGIN_LOC_LINE4;				
	   }	  
   } 
   else
   {
	   /* error: configured max lines > 4 */
	   
   }      
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 33   
-*------------------------------------------------------------*/
/* process to to do when a error or warning has occured */
void Error_or_Warning_Proc(const char *error_trace, const unsigned int warn_or_error_format, const unsigned int warning_or_error_data)
{
	 error_or_warning_code |= warning_or_error_data; 
     INTERNAL_ERROR_LED_PIN = LED_ON;	
	 
	 if(disp_status_time_or_error[ERROR_STATUS_DISP_INDEX] == STATUS_DISP_ON )
	 {
        Goto_XY_LCD_Disp_Err(ERROR_LINE_NUM, NUM_COL1);
		Data_Str_Disp_LCD(error_trace);		
		Goto_XY_LCD_Disp_Err(ERROR_LINE_NUM, start_col_blank_space);
		Write_LCD_Data(' ');
		Goto_XY_LCD_Disp_Err(ERROR_LINE_NUM, start_col_error_code);
		Data_4Digit_Hex_Disp_LCD(error_or_warning_code);		
	 }
	switch(warn_or_error_format)
	{
		case WARNING_OCCURED:	
         if(disp_status_time_or_error[ERROR_STATUS_DISP_INDEX] == STATUS_DISP_ON )
	     { 
		    Goto_XY_LCD_Disp_Err(ERROR_LINE_NUM, start_col_error_msg);			   
	        Data_Str_Disp_LCD(warning_msg_disp);
			cur_line_disp_data[ERROR_LINE_NUM] = WARNING_DISP;	
            internal_error_state = WARNING_OCCURED;			
		 }	
		 /*warning occured, process to do  */
        break;
		case ERROR_OCCURED:
		  if(disp_status_time_or_error[ERROR_STATUS_DISP_INDEX] == STATUS_DISP_ON )
	      { 
		    Goto_XY_LCD_Disp_Err(ERROR_LINE_NUM, start_col_error_msg);		   
	        Data_Str_Disp_LCD(error_msg_disp);
			cur_line_disp_data[ERROR_LINE_NUM] = ERROR_DISP;
			internal_error_state = ERROR_OCCURED;	
		  }	
		  /*error occured, process to do  */
		break;
        case FATAL_OCCURED:	            
		if(disp_status_time_or_error[ERROR_STATUS_DISP_INDEX] == STATUS_DISP_ON )
	     { 
		    Goto_XY_LCD_Disp_Err(ERROR_LINE_NUM, start_col_error_msg);			   
	        Data_Str_Disp_LCD(fatal_msg_disp);
			internal_error_state = FATAL_OCCURED;	
			cur_line_disp_data[ERROR_LINE_NUM] = FATAL_DISP;
		 }	  
		 /* fatal error occured, process to do  */ 
		break;
        default:
         ;
         /* warning invalid error or warning format*/			    
	}
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 42   
-*------------------------------------------------------------*/
void Reset_Cur_Input_Data_Para()
{
  cur_data_input_start_loc = INVALID_DATA;
  cur_data_input_end_loc = INVALID_DATA;
  cur_data_input_end_line_num = INVALID_DATA;
  cur_data_input_end_col_num = INVALID_DATA;
  cur_data_input_max_num_chars_allocated = INVALID_DATA;
  cur_data_input_line_num = INVALID_DATA;
  cur_data_input_col_num = INVALID_DATA;
  cur_data_input_start_line_num = INVALID_DATA;
  cur_data_input_start_col_num	= INVALID_DATA;
}
#if (NUM_INPUTDATA_CHARS == GIVEN_CHARS_MAX_CONFIG_LINES_AND_COLS)
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 34   
-*------------------------------------------------------------*/	
void Cur_Input_Data_ByNumChars_Calc_Para(const unsigned int cur_data_entry_start_line_num, const unsigned int cur_data_entry_start_col_num, \
  const unsigned int configured_cur_data_input_max_num_chars)
{
	/* FIND MAX loc at which data can be entered from input_data_entry_start_loc and max num of chars can be entered from input_data_entry_start_loc,
	max loc's line num and max loc's column num */
    unsigned int max_configure_inputdata_num_chars_left_from_next_line,  max_loc_line_datainput, max_loc_col_datainput, input_data_entry_start_loc, \
    	max_avail_inputdata_num_chars_start_line, max_avail_num_chars_from_next_line, max_avail_data_input_end_col_numchars,\
		max_avail_num_chars_in_end_line, max_avail_data_input_numchars; 		
	
	
	lcd_avail_loc_within_limit = STATE_YES;	
	 Reset_Cur_Input_Data_Para();
	 
   if(cur_data_entry_start_line_num <= CONFIGURE_MAX_NUM_LINES && cur_data_entry_start_col_num <= CONFIGURE_MAX_NUM_COLS) 
   { 	  	        
        max_avail_inputdata_num_chars_start_line = CONFIGURE_MAX_NUM_COLS + 1 - cur_data_entry_start_col_num;		
		max_avail_num_chars_from_next_line = (CONFIGURE_MAX_NUM_LINES - cur_data_entry_start_line_num) * CONFIGURE_MAX_NUM_COLS;
		
		if(cur_data_entry_start_line_num == CONFIGURE_MAX_NUM_LINES)
		{
			max_avail_data_input_numchars = max_avail_inputdata_num_chars_start_line;
		}	
		else
		{	
		    max_avail_data_input_numchars = max_avail_inputdata_num_chars_start_line + max_avail_num_chars_from_next_line; 
		}	
		if(max_avail_data_input_numchars < configured_cur_data_input_max_num_chars )
		{
			cur_data_input_max_num_chars_allocated = max_avail_data_input_numchars; 
			//  Error_or_Warning_Proc("34.01", WARNING_OCCURED, WARN_DATA_CHARS_REACHED_MAX_ALLOC_CHARS_CODE);
            /*error: exceeds max_avail_data_input_numchars < configured_cur_data_input_max_num_chars */	
			
			 cur_data_input_end_line_num = CONFIGURE_MAX_NUM_LINES;
			 cur_data_input_end_col_num = CONFIGURE_MAX_NUM_COLS;
		}
        else
        {
			cur_data_input_max_num_chars_allocated = configured_cur_data_input_max_num_chars;
			if(max_avail_inputdata_num_chars_start_line >= configured_cur_data_input_max_num_chars)
			{
				 cur_data_input_end_line_num = cur_data_entry_start_line_num;
				 cur_data_input_end_col_num  = cur_data_entry_start_col_num + configured_cur_data_input_max_num_chars - 1;
            }
            else
			{				
		    	max_configure_inputdata_num_chars_left_from_next_line = configured_cur_data_input_max_num_chars - max_avail_inputdata_num_chars_start_line;
			    cur_data_input_end_line_num = (max_configure_inputdata_num_chars_left_from_next_line / CONFIGURE_MAX_NUM_COLS) + 1 + cur_data_entry_start_line_num;
			    cur_data_input_end_col_num = max_configure_inputdata_num_chars_left_from_next_line % (CONFIGURE_MAX_NUM_COLS + 1);
			}	
        }
        From_XY_To_Loc_LCD(cur_data_input_end_line_num, cur_data_input_end_col_num, &cur_data_input_end_loc);
		cur_data_input_start_col_num = cur_data_entry_start_col_num;
		cur_data_input_start_line_num = cur_data_entry_start_line_num;
		From_XY_To_Loc_LCD(cur_data_input_start_line_num, cur_data_input_start_col_num, &cur_data_input_start_loc);
        		
   }
   else
   {
	 //  Error_or_Warning_Proc("34.02", ERROR_OCCURED, ERR_CUR_INPUT_DATA_LOC_CODE);
	   /* error invalid lcd loc not within limit */ 
        lcd_avail_loc_within_limit = STATE_NO; 	  
   }
}

#elif (NUM_INPUTDATA_CHARS == GIVEN_XY_MAX_CONFIG_LINES_AND_COLS)
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 35   
-*------------------------------------------------------------*/	
void Cur_Input_Data_ByXY_Calc_Para(const unsigned int cur_data_entry_start_line_num, const unsigned int cur_data_entry_start_col_num, \
 const unsigned int next_data_start_line_num, const unsigned int next_data_start_col_num)
{
	
    unsigned int max_configure_inputdata_num_chars_left_from_next_line,  max_loc_line_datainput, max_loc_col_datainput, input_data_entry_start_loc, \
    	max_avail_inputdata_num_chars_start_line, max_avail_num_chars_from_next_line, max_avail_data_input_end_line_num, max_avail_data_input_end_col_numchars,\
		max_avail_num_chars_in_end_line, num_chars_inbetween_start_end_lines, cur_data_entry_end_line_num,  cur_data_entry_end_col_num;	
	
	
	lcd_avail_loc_within_limit = STATE_YES;
	 Reset_Cur_Input_Data_Para();
	 
   if( ((next_data_start_line_num <= MAX_AVAIL_NUM_LINES && next_data_start_col_num <= MAX_AVAIL_NUM_COLS )  ||  \
        next_data_start_line_num <= MAX_AVAIL_NUM_LINES + 1 && next_data_start_col_num == NUM_COL1 ) && \
       cur_data_entry_start_line_num <= CONFIGURE_MAX_NUM_LINES && cur_data_entry_start_col_num <= CONFIGURE_MAX_NUM_COLS )
      
   {
	  if(next_data_start_col_num == NUM_COL1)
	  {
		  cur_data_entry_end_col_num = CONFIGURE_MAX_NUM_COLS;
		  cur_data_entry_end_line_num = next_data_start_line_num - 1;
	  }
      else
      {
		  cur_data_entry_end_col_num = next_data_start_col_num - 1;
		  cur_data_entry_end_line_num = next_data_start_line_num;
	  }	
	  
	  if( (cur_data_entry_start_line_num == cur_data_entry_end_line_num && cur_data_entry_start_col_num < cur_data_entry_end_col_num )|| cur_data_entry_start_line_num < cur_data_entry_end_line_num  )
	  {  
         cur_data_input_start_col_num = cur_data_entry_start_col_num;
	     cur_data_input_start_line_num = cur_data_entry_start_line_num;
	     From_XY_To_Loc_LCD(cur_data_input_start_line_num, cur_data_input_start_col_num, &cur_data_input_start_loc);
         if(cur_data_entry_end_line_num > CONFIGURE_MAX_NUM_LINES)
         {
			cur_data_input_end_line_num =  CONFIGURE_MAX_NUM_LINES;
			/* warning : end line data input exceed configured max line  */
			// Error_or_Warning_Proc("35.01", WARNING_OCCURED, WARN_DATA_CHARS_REACHED_MAX_ALLOC_CHARS_CODE);
		    		
	     }
         else	
			cur_data_input_end_line_num =  cur_data_entry_end_line_num; 
		
		if(cur_data_entry_end_col_num > CONFIGURE_MAX_NUM_COLS)
         {
			cur_data_input_end_col_num =  CONFIGURE_MAX_NUM_COLS;
			/* warning : end col data input exceed configured max col  */
		    // Error_or_Warning_Proc("35.02", WARNING_OCCURED, WARN_DATA_CHARS_REACHED_MAX_ALLOC_CHARS_CODE);
		    		
	     }
        else	
			cur_data_input_end_col_num =  cur_data_entry_end_col_num; 
		if(cur_data_entry_start_line_num < cur_data_entry_end_line_num)
		{
			num_chars_inbetween_start_end_lines = (cur_data_input_end_line_num - cur_data_entry_start_line_num - 1) * CONFIGURE_MAX_NUM_COLS;
			max_avail_inputdata_num_chars_start_line =  CONFIGURE_MAX_NUM_COLS + 1 - cur_data_entry_start_col_num;	
			cur_data_input_max_num_chars_allocated = num_chars_inbetween_start_end_lines + max_avail_inputdata_num_chars_start_line + cur_data_input_end_col_num; 
		}
        else
        {	          
			cur_data_input_max_num_chars_allocated =  cur_data_entry_end_col_num - cur_data_entry_start_col_num + 1;
        }			
		From_XY_To_Loc_LCD(cur_data_input_end_line_num, cur_data_input_end_col_num, &cur_data_input_end_loc);
		 		 
	 }
     else
     {
	    // Error_or_Warning_Proc("35.03", ERROR_OCCURED, ERR_START_DATA_LOC_GREATER_END_DATA_LOC_CODE );
	   /* error invalid start data input loc > end data input loc */ 
	   lcd_avail_loc_within_limit = STATE_NO; 
    }	   
   } 
   else
   {
	 //  Error_or_Warning_Proc("35.04", ERROR_OCCURED, ERR_CUR_INPUT_DATA_LOC_CODE);
	   /* error invalid lcd loc not within limit */ 
        lcd_avail_loc_within_limit = STATE_NO; 
	   
   }
}
#else 
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : (NUM_INPUTDATA_CHARS = GIVEN_CHARS_MAX_XY)

Func ID        : 36   
-*------------------------------------------------------------*/	
void Cur_Input_Data_ByCharsXY_Calc_Para(const unsigned int cur_data_entry_start_line_num, const unsigned int cur_data_entry_start_col_num, \
const unsigned int configured_cur_data_input_max_num_chars, const unsigned int next_data_start_line_num, const unsigned int next_data_start_col_num)
{
  unsigned int max_configure_inputdata_num_chars_left_from_next_line,  max_loc_line_datainput, max_loc_col_datainput, input_data_entry_start_loc, \
   	max_avail_inputdata_num_chars_start_line,  max_avail_data_input_end_line_num, max_avail_data_input_end_col_numchars,configured_cur_data_input_max_num_chars_from_next_line,\
	max_avail_num_chars_in_end_line, num_chars_inbetween_start_end_lines, cur_data_entry_end_line_num,  cur_data_entry_end_col_num, cur_data_max_avail_numchars;
		
	lcd_avail_loc_within_limit = STATE_YES;
	Reset_Cur_Input_Data_Para();
	 
    if( ((next_data_start_line_num <= MAX_AVAIL_NUM_LINES && next_data_start_col_num <= MAX_AVAIL_NUM_COLS )  ||  \
        next_data_start_line_num <= MAX_AVAIL_NUM_LINES + 1 && next_data_start_col_num == NUM_COL1 ) && \
       cur_data_entry_start_line_num <= CONFIGURE_MAX_NUM_LINES && cur_data_entry_start_col_num <= CONFIGURE_MAX_NUM_COLS )	 
    {
		if(next_data_start_col_num == NUM_COL1)
	     {
		    cur_data_entry_end_col_num = CONFIGURE_MAX_NUM_COLS;
		    cur_data_entry_end_line_num = next_data_start_line_num - 1;
	     }
         else
         {
		    cur_data_entry_end_col_num = next_data_start_col_num - 1;
		    cur_data_entry_end_line_num = next_data_start_line_num;
	     }
	    if( (cur_data_entry_start_line_num == cur_data_entry_end_line_num && cur_data_entry_start_col_num < cur_data_entry_end_col_num )|| cur_data_entry_start_line_num < cur_data_entry_end_line_num  )
	    {
			if(cur_data_entry_end_line_num > CONFIGURE_MAX_NUM_LINES)
            {
		    	cur_data_input_end_line_num =  CONFIGURE_MAX_NUM_LINES;
		    	/* warning : end line data input exceed configured max line  */
			    // Error_or_Warning_Proc("36.01", WARNING_OCCURED, WARN_DATA_CHARS_REACHED_MAX_ALLOC_CHARS_CODE);		    		
	        }
            else
			{				
		    	cur_data_input_end_line_num =  cur_data_entry_end_line_num; 
			}
		    if(cur_data_entry_end_col_num > CONFIGURE_MAX_NUM_COLS)
            {
		    	cur_data_input_end_col_num =  CONFIGURE_MAX_NUM_COLS;
		    	/* warning : end col data input exceed configured max col  */
		       // Error_or_Warning_Proc("36.02", WARNING_OCCURED, WARN_DATA_CHARS_REACHED_MAX_ALLOC_CHARS_CODE);		 		
	        }
            else
			{				
		    	cur_data_input_end_col_num =  cur_data_entry_end_col_num; 
			}
		    cur_data_input_start_col_num = cur_data_entry_start_col_num;
		    cur_data_input_start_line_num = cur_data_entry_start_line_num;
		    From_XY_To_Loc_LCD(cur_data_input_start_line_num, cur_data_input_start_col_num, &cur_data_input_start_loc); 
			
			if(cur_data_entry_start_line_num < cur_data_entry_end_line_num)
		    {
		    	num_chars_inbetween_start_end_lines = (cur_data_input_end_line_num - cur_data_entry_start_line_num - 1) * CONFIGURE_MAX_NUM_COLS;
		    	max_avail_inputdata_num_chars_start_line =  CONFIGURE_MAX_NUM_COLS + 1 - cur_data_entry_start_col_num;	
		    	cur_data_max_avail_numchars = num_chars_inbetween_start_end_lines + max_avail_inputdata_num_chars_start_line + cur_data_input_end_col_num;                					
		    }
            else
            {	          
			    cur_data_max_avail_numchars =  cur_data_entry_end_col_num - cur_data_entry_start_col_num + 1;
            }
            if(configured_cur_data_input_max_num_chars > cur_data_max_avail_numchars)
			{
			   /* warning : end col data input exceed configured max col  */
		       // Error_or_Warning_Proc("36.03", WARNING_OCCURED, WARN_DATA_CHARS_REACHED_MAX_ALLOC_CHARS_CODE);	
				cur_data_input_max_num_chars_allocated = cur_data_max_avail_numchars;
				cur_data_input_end_line_num =  cur_data_entry_end_line_num;
				cur_data_input_end_col_num =  cur_data_entry_end_col_num;
			}
            else
			{
				cur_data_input_max_num_chars_allocated = configured_cur_data_input_max_num_chars;
			    if(configured_cur_data_input_max_num_chars < max_avail_inputdata_num_chars_start_line)	
				{
					cur_data_input_end_line_num =  cur_data_entry_start_line_num;
				    cur_data_input_end_col_num =  cur_data_entry_start_col_num + configured_cur_data_input_max_num_chars - 1;					
				}
                else
				{
					configured_cur_data_input_max_num_chars_from_next_line = configured_cur_data_input_max_num_chars - max_avail_inputdata_num_chars_start_line;
					cur_data_input_end_line_num = (configured_cur_data_input_max_num_chars_from_next_line / CONFIGURE_MAX_NUM_COLS) + 1 + cur_data_input_start_line_num;
					cur_data_input_end_col_num = (configured_cur_data_input_max_num_chars_from_next_line % (CONFIGURE_MAX_NUM_COLS + 1)) ;
				}						
			}
			From_XY_To_Loc_LCD(cur_data_input_end_line_num, cur_data_input_end_col_num, &cur_data_input_end_loc);		 
		}
		else
        {
	      // Error_or_Warning_Proc("36.03", ERROR_OCCURED, ERR_START_DATA_LOC_GREATER_END_DATA_LOC_CODE );
	      /* error invalid start data input loc > end data input loc */
		   lcd_avail_loc_within_limit = STATE_NO; 
        }	   
    } 
    else
   {
	 //  Error_or_Warning_Proc("36.04", ERROR_OCCURED, ERR_CUR_INPUT_DATA_LOC_CODE);
	   /* error invalid lcd loc not within limit */ 
       lcd_avail_loc_within_limit = STATE_NO; 
   }
}
#endif
#ifdef LCD_16_OR_20_CHARS_4_LINES 
/* LCD_16_OR_20_CHARS_4_LINES code block works fine only for CONFIGURE_MAX_NUM_LINES = 4, if CONFIGURE_MAX_NUM_LINES < 4, this func checks line limit, 
  but Write_LCD_Data() in Data_Str_Disp_LCD() or other func that uses Write_LCD_Data(), after reset, if any Write_LCD_Data() is called,
  then that data is displayed  from BEGIN_LOC_LINE1 due to lcd clear, irrespective for CONFIGURE_MAX_NUM_LINES and displays next loc till END_LOC_LINE4
  and from repeats from  displays data from BEGIN_LOC_LINE1 */
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 37   
-*------------------------------------------------------------*/
void Goto_XY_Input_LCD_20(unsigned int start_line_num,unsigned int start_col_num)
{
	/* for us, lcd line starts from 1, but for uC, line starts from 0 */
	/* for us, lcd col starts from 1, but for uC, col starts from 0 */
    unsigned int start_line_lcd = start_line_num - 1, start_col_lcd = start_col_num - 1; 
	/* Specific for 4 lines, 20 chars and loc corresponding to start_line_num and start_col_num */
	/* max 4 lines and 20 columns */
   if(start_line_lcd < 4  && start_col_lcd < 20)
   {	
     cur_input_lcd_loc = BEGIN_LOC_LINE1;
	
        if(start_line_lcd & 0x02)
        {
          cur_input_lcd_loc = cur_input_lcd_loc | (1 << 4);  
	      cur_input_lcd_loc = cur_input_lcd_loc | (1 << 2); 
        } 
     
     if(start_line_lcd & 0x01)
       cur_input_lcd_loc = cur_input_lcd_loc | (1 << 6); 
    /* for 20 * 4 lcd disp */	
    /* for start_line_num = 1 & start_col_num = 1 , cur_input_lcd_loc = 0x80*/	
	/* for start_line_num = 2 & start_col_num = 1, cur_input_lcd_loc = 0xC0*/
	/* for start_line_num = 3 & start_col_num = 1, cur_input_lcd_loc = 0x94*/
	/* for start_line_num = 4 & start_col_num = 1, cur_input_lcd_loc = 0xD4*/
    cur_input_lcd_loc = cur_input_lcd_loc + start_col_lcd;
    Write_LCD_Command(cur_input_lcd_loc);
   }
   else
   {
	  // Error_or_Warning_Proc("37.01", ERROR_OCCURED, ERR_CUR_INPUT_LOC_CODE);
	   	   
   }	   
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 38   
-*------------------------------------------------------------*/
 void Goto_XY_Disp_LCD20(unsigned int start_line_num,unsigned int start_col_num)
{
	/* for us, lcd line starts from 1, but for uC, line starts from 0 */
	/* for us, lcd col starts from 1, but for uC, col starts from 0 */
    unsigned int start_line_lcd = start_line_num - 1, start_col_lcd = start_col_num - 1; 
	/* max 4 lines and 20 columns */
	/* Specific for 4 lines, 20 chars and loc corresponding to start_line_num and start_col_num */
   if(start_line_lcd < 4 && start_col_lcd < 20 )
   {
     cur_disp_lcd_loc = BEGIN_LOC_LINE1;
	 if(start_line_lcd & 0x01)
       cur_disp_lcd_loc = cur_disp_lcd_loc | (1 << 6); 
    if(start_line_lcd & 0x02)
    {
      cur_disp_lcd_loc = cur_disp_lcd_loc | (1 << 4);  
	  cur_disp_lcd_loc = cur_disp_lcd_loc | (1 << 2); 
    }    
    cur_disp_lcd_loc = cur_disp_lcd_loc + start_col_lcd;
    Write_LCD_Command(cur_disp_lcd_loc);	
   }
   else
   {
	// Error_or_Warning_Proc("38.01", ERROR_OCCURED, ERR_CUR_DISP_LOC_CODE);
	     
   }	   
} 
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 39   
-*------------------------------------------------------------*/
void Goto_XY_Disp_LCD16(unsigned int start_line_num,unsigned int start_col_num)
{
	/* for us, lcd line starts from 1, but for uC, line starts from 0 */
	/* for us, lcd col starts from 1, but for uC, col starts from 0 */
    unsigned int start_line_lcd = start_line_num - 1, start_col_lcd = start_col_num - 1;
	/* Specific for 4 lines , 16 chars and loc corresponding to start_line_num and start_col_num */
	/* max 4 lines and 16 columns */
   if(start_line_lcd < 4 && start_col_lcd < 16 )
   {
     cur_disp_lcd_loc = BEGIN_LOC_LINE1;
    if(start_line_lcd & 0x01)
       cur_disp_lcd_loc = cur_disp_lcd_loc | (1 << 6); 
    if(start_line_lcd & 0x02)
    {
      cur_disp_lcd_loc = cur_disp_lcd_loc | (1 << 4);     
    }  
	/* for 16 * 4 lcd disp */
     /* for start_line_num = 1 & start_col_num = 1, cur_disp_lcd_loc = 0x80*/	
	/* for start_line_num = 2 & start_col_num = 1, cur_disp_lcd_loc = 0xC0*/
	/* for start_line_num = 3 & start_col_num = 1, cur_disp_lcd_loc = 0x90*/
	/* for start_line_num = 4 & start_col_num = 1 , cur_disp_lcd_loc = 0xD0*/	
    cur_disp_lcd_loc = cur_disp_lcd_loc + start_col_lcd;
    Write_LCD_Command(cur_disp_lcd_loc);
   }
   else
   {
	// Error_or_Warning_Proc("39.01", ERROR_OCCURED, ERR_CUR_DISP_LOC_CODE);
	 
   }	   
}
#endif 
#ifdef STACK_OVERFLOW

 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 22   
-*------------------------------------------------------------*/
void LCD_Pulse()
{
     EN_PIN = 1;
     Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);
     EN_PIN = 0;
     Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 23   
-*------------------------------------------------------------*/
  void Write_LCD_Command (unsigned int cmd)
  {	  
       RW_PIN = 0;
       RS_PIN = 0; 
       LCD_PORT = cmd;
       LCD_Pulse();
 }
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 24   
-*------------------------------------------------------------*/
 void Write_LCD_Data(const char ch)
{
	// performance degraded if many data is written to LCD, to check if write loc is within avail disp loc
	// if(lcd_avail_loc_within_limit == STATE_YES) 
	{	
      RW_PIN = 0;
      RS_PIN = 1;
      LCD_PORT =ch;
      LCD_Pulse();     	 
	}
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 27  
-*------------------------------------------------------------*/
void Delay_Time_ByCount( unsigned int time_delay)
{
       while(time_delay--);
} 
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 40   
-*------------------------------------------------------------*/

void Timer0_Tick()
{ 
      while(T0IF == 0);
      T0IF = 0;
      TMR0= (256UL) - (INC0/prescale_timer0);
	  if(++num_calls_timer0 >= UPDATE_TIME0)
      {
	    Auth_Proc();
        num_calls_timer0 = 0;        
     } 
	 	 
}

#endif

