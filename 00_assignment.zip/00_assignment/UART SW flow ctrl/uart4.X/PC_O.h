/**************************************************************************
   FILE          :    PC_O.h
 
   PURPOSE       :   type declarations for PC_O.c .  
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   see PC_O.c for details
	
  CHANGE LOGS     :
	   
 **************************************************************************/
#ifndef _PC_O_H
#define _PC_O_H

// ------ Public function prototypes -------------------------------
void PC_LINK_O_Write_String_To_Buffer(const char* const);
void PC_LINK_O_Write_Char_To_Buffer(const char);
void PC_LINK_O_Update(void);

#endif

/*------------------------------------------------------------------*-
  ---- END OF FILE -------------------------------------------------
-*------------------------------------------------------------------*/
