/* ********************************************************************
FILE                 : Elap_232.c

PURPOSE              : 	Simple library function for keeping track of elapsed time.
                        Demo version to display time on PC screen via RS232 link.										 
	 
AUTHOR               : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS           : 

NOTE                 : 

CHANGE LOGS          :

*****************************************************************************/	
#include "main.h"
#include "appl_conf.h"
#include "Elap_232.h"
#include "PC_O.h"
#include "char_map.h"
#include "uart.h"

// ------------------- Public variable definitions -----------------
/* elapsed time in hour, minute and second */
tByte elapsed_hour;
tByte elapsed_minute;
tByte elapsed_sec;
char time_str[APPL_STR_TX_BUFFER_LEN] = "\rElapsed time: ";
tByte data_sent_uart_tx_buffer_index;  // Index of data that has been sent
tByte data_yet_sent_uart_tx_buffer_index;  // Index of data not yet send
tByte uart_tx_buffer[UART_TX_BUFFER_LEN];
// -------------------Public variable declarations --------------------
extern unsigned int cur_disp_block;

// See Char_Map.h
//extern const char CHAR_MAP_G[10]; 

/*------------------------------------------------------------*-
FUNCTION NAME  :  Elapsed_Time_RS232_Init

DESCRIPTION    :  Init function for simple library displaying elapsed
                  time on PC via RS-232 link.
	
INPUT          :  

OUTPUT         : 

NOTE           :  Precise tick intervals are only possible with certain 
  oscillator / tick interval combinations. For eg If timing is important,
  you should check the timing calculations manually by using simulator. 
	If you require both accurate baud rates and accurate EOS timing, use an
  11.0592 MHz crystal and a tick rate of 5, 10, 15, � 60 or 65 ms. 
	Such �divide by 5� tick rates are precise with an 11.0592 MHz crystal.
-*------------------------------------------------------------*/
void Elapsed_Time_RS232_Init(void)
{
   elapsed_hour = 0;
   elapsed_minute = 0;
   elapsed_sec = 0;
}
/*------------------------------------------------------------*-
FUNCTION NAME  :  Elapsed_Time_RS232_Update

DESCRIPTION    :  Function for displaying elapsed time on PC Screen.
	
INPUT          :  

OUTPUT         : 

NOTE           :  *** Must be called once per REQ_TIME_UART_TX_ELAPSED_TIME_IN_MILLI_SEC ***
	 Precise tick intervals are only possible with certain 
  oscillator / tick interval combinations. For eg If timing is important,
  you should check the timing calculations manually by using simulator. 
	If you require both accurate baud rates and accurate EOS timing, use an
  11.0592 MHz crystal and a tick rate of 5, 10, 15, � 60 or 65 ms. 
	Such �divide by 5� tick rates are precise with an 11.0592 MHz crystal.
-*------------------------------------------------------------*/
void Elapsed_Time_RS232_Update(void)     
{
	tByte i = 0;
	
   if (++elapsed_sec == 60)  
   { 
      elapsed_sec = 0;
      
      if (++elapsed_minute == 60)  
      {
         elapsed_minute = 0;
           
         if (++elapsed_hour == 24)  
         { 
            elapsed_hour = 0;
         }
      }
   }

   time_str[15] = CHAR_MAP_G[elapsed_hour / 10];
   time_str[16] = CHAR_MAP_G[elapsed_hour % 10];
   time_str[17] = ':';
   time_str[18] = CHAR_MAP_G[elapsed_minute / 10];
   time_str[19] = CHAR_MAP_G[elapsed_minute % 10];
   time_str[20] = ':';
   time_str[21] = CHAR_MAP_G[elapsed_sec / 10];
   time_str[22] = CHAR_MAP_G[elapsed_sec % 10];  
   time_str[23] = '\0';
   //PC_LINK_O_Write_String_To_Buffer(time_str);
   
   while (time_str[i] != '\0')
   {
       // PC_LINK_O_Write_Char_To_Buffer(appl_str[i]);
	   // Write to the buffer *only* if there is space  
       if (data_yet_sent_uart_tx_buffer_index < UART_TX_BUFFER_LEN)
       {
          uart_tx_buffer[data_yet_sent_uart_tx_buffer_index] = time_str[i];
          ++data_yet_sent_uart_tx_buffer_index;   
		 /*  //SHOULD_REMOVE
	     if(cur_disp_block != 4)
	     {
	        UART_Transmit_Str("D\r");		
	        cur_disp_block = 4 ;
	     }  */
       }
       else
       {
	      // (No error reporting in this simple library...)
	      //ERROR: 
		/*  //SHOULD_REMOVE 
		  if(cur_disp_block != 4)
	      {
	        UART_Transmit_Str("E\r");	
	        cur_disp_block = 4;
	      } */
       } 
      ++i;
   }
}

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
