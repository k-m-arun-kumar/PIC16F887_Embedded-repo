/* ********************************************************************
FILE                 : simple_EOS.c

PURPOSE              : Main file for Simple Embedded Operating System (sEOS) for 8051. 
                       Sets up Timer 2 to drive the simple EOS. ISR of Timer 2, which
                       calls application code. In our case, for every 1 second, send elasped 
											 time to PC via RS232 link. 
											 
																						 
	 
AUTHOR               :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS           : 

NOTE                 : implements sEOS, a simple time triggered ,nonpremptive and single application task executing embedded OS.

CHANGE LOGS          :

*****************************************************************************/	
#include "main.h"
#include "port.h"
#include "io_conf.h"
#include "simple_EOS.h"


/*------------------------------------------------------------*-
FUNCTION NAME  : sEOS_Go_To_Sleep

DESCRIPTION    :  This operating system enters 'sleep mode' between clock ticks
  to save power.  The next system tick will return the processor to the normal operating state.
	
INPUT          : none

OUTPUT         : 

NOTE           : ADAPT AS REQUIRED FOR YOUR HARDWARE.
	               once an interrupt or HW reset is received by uC, uC awakens and starts executing ISR
	               of the interrupt, then executes instruction following the sleep insrtuction which had put uC in sleep mode.
               	 
-*------------------------------------------------------------*/
void sEOS_Go_To_Sleep(void)
{
    SLEEP(); 
}

/*------------------------------------------------------------------*-
  ---- END OF FILE -------------------------------------------------
-*------------------------------------------------------------------*/	
