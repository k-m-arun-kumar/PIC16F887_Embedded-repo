/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    : Displaying elapsed time using UART. Software Flow control yet to be implemented.
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : implements sEOS, a simple time triggered ,nonpremptive and single application task executing embedded OS.                         
						
						system ticks interval in milli sec. for Every TIMER0_TICK_IN_MILLI_SEC, application Task followed by e0S(system Task)
                         is executed. 
CAUTION               :  make sure that TIMER0_TICK_IN_MILLI_SEC is large enough that uC executing maximum time 
	                     required to start and completes executing Application task and system task(sEOS_Go_To_Sleep)
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "main.h"
#include "port.h"
#include "io_conf.h"
#include "appl_conf.h"
#include "simple_EOS.h"
#include "PC_O_T1.h"
#include "Elap_232.h"
#include "uart.h"
#include "timer.h"

value_types to_disp;
unsigned int cur_disp_block = 0;

/*------------------------------------------------------------*-
FUNCTION NAME  : main

DESCRIPTION    :1: Initialize baud rate to 9600. 
                2: configure Timer Timer0  with TIMER0_TICK_IN_MILLI_SEC msec as overflow and run the Timer 0 .								
				3: put the CPU of PIC in sleep mode and Every  TIMER0_TICK_IN_MILLI_SEC when Timer0 overflow interrupt occurs, 
                4: for every REQ_TIME_UART_TX_ELAPSED_TIME_IN_MILLI_SEC, send elasped time to PC via RS 232 link							
                5: go to step 3, and repeat
								
INPUT          : none

OUTPUT         : 

NOTE           : in RS 232 port, PC must also be configured 9600 baud, 8 bit data, no parity and 1 stop bit.
-*------------------------------------------------------------*/

void main(void)
{
		 /* ========= begin : USER CODE INITIALIZE ========== */
		 // Set baud rate to 9600
    PC_LINK_O_Init_T1(9600);

    // Prepare for elapsed time measurement
     Elapsed_Time_RS232_Init(); 
		
	/* ========= end : USER CODE INITIALIZE ========== */	 
    /* Set up simple EOS. configure Timer 0 and start running Timer 0, 
		 with TIMER0_TICK_IN_MILLI_SEC time in ms ticks  */ 
    Timer0_Run(TMR0_UART_TX_TIME_STATE, REQ_TIME_UART_TX_ELAPSED_TIME_IN_MILLI_SEC);   
   // Elapsed_Time_RS232_Update();
    while(1) // Super Loop
    {
				/* uC enters SLEEP mode to save power consumed by CPU. But timers, UART and other
				peripherals continue to work after SLEEP mode */
			/* ============ PERIODIC SYSTEM TASK EXECUTION ============= */	
          // sEOS_Go_To_Sleep();  
			/* here uC does not execute. When interrupt occurs, uC executes its corresponding ISR.
              in our case, only Timer 0 overflow interrupt will occur, which executes its ISR, sEOS_ISR()	*/	
			/* ISR of Timer 0 executes application task */	
    }
}

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/	 
