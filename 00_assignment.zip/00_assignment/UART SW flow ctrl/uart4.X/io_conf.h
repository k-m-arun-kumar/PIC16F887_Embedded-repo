/**************************************************************************
   FILE          :    io_conf.h
 
   PURPOSE       :   main peripherial configuration Header
 
   AUTHOR        :   K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _IO_CONF_H
 #define _IO_CONF_H
 
 /* -------------------------------- debug conf -----------------------------------------*/
#define TRACE                                   (1U)
#define TRACE_ERROR                             (2U)
 
 /* -------------------------------- OSC Freq conf -------------------------------------*/
 #define _XTAL_FREQ                             (4000000)
 
 /* --------------------------------- module enable conf ---------------------------------*/
 
//#define TIMER1_MOD_ENABLE                      (01)
// #define TIMER2_MOD_ENABLE                      (02) 
 #define TIMER0_MOD_ENABLE                      (03)
// #define LCD_MOD_ENABLE                         (04)
// #define KEYPAD_MOD_ENABLE                      (05)
// #define CAPTURE_MOD_ENABLE                     (06)
// #define COMPARE_MOD_ENABLE                     (07)
// #define PWM_MOD_ENABLE                         (08)
 #define USART_MOD_ENABLE                       (09)
// #define ADC_MOD_ENABLE                         (10)
// #define GSM_MOD_ENABLE                         (11)
// #define COMPARATOR1_MOD_ENABLE                 (12)
// #define COMPARATOR2_MOD_ENABLE                 (13)
// #define SPI_MOD_ENABLE                         (14)
// #define I2C_MOD_ENABLE                         (15) 
// #define WATCHDOG_TIMER_MOD_ENABLE              (16)
 
 /* ------------------------------- LCD oper conf ---------------------------------------*/
 

/* -------------------------------- timer oper conf ------------------------------------*/


#define TIMER0_SET_TIME_DELAY_IN_MULTIPLE                       TIMER0_PRESET_TIME_DELAY_IN_MULTIPLE

/*TIMER0_TICK_IN_MILLI_SEC = system tick interval */
#define TIMER0_TICK_IN_MILLI_SEC                                (2)  
#define TIMER0_REQ_TIME_1_UPDATE_REACHED_IN_MILLI_SEC           TIME_UNIT_1_SEC_IN_MILLI_SEC

#define TIMER1_SET_TIME_DELAY_IN_MULTIPLE                       TIMER1_PRESET_TIME_DELAY_IN_MULTIPLE

#define TIMER1_TICK_IN_MILLI_SEC                                (10U)  
#define TIMER1_REQ_TIME_1_UPDATE_REACHED_IN_MILLI_SEC           TIME_UNIT_1_SEC_IN_MILLI_SEC

#define TIMER2_TICK_IN_MILLI_SEC                                (50U)  
#define TIMER2_REQ_TIME_1_UPDATE_REACHED_IN_MILLI_SEC           TIME_UNIT_1_SEC_IN_MILLI_SEC
 //in Timer1_Load_Init_Val_Calc() in timer1.c, change variable inc_timer1, which (directly loads initial TMR1 values ), depends on Osc freq

/* ------------------------------- uart oper conf -------------------------------------- */

//in UART_Init() in uart.c, change SPBRG, which dependc on Osc freq  and baud rate

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
