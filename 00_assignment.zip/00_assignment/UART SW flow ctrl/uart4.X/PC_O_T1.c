/* ********************************************************************
FILE                   : PC_O_T1.c

PROGRAM DESCRIPTION    :  Simple write-only PC link library Version A (generic)
   [Sends data to PC - cannot receive data from PC] via RS 232 link
                      									 
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  :  Uses the UART, and Pin 3.1 (Tx) 											
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "main.h"
#include "PC_O_T1.h"
#include "uart.h"
// ------ Public variable declarations -----------------------------

extern tByte data_sent_uart_tx_buffer_index;  
extern tByte data_yet_sent_uart_tx_buffer_index;  

/*------------------------------------------------------------*-
FUNCTION NAME  : PC_LINK_O_Init_T1

DESCRIPTION    : 
								
INPUT          : none

OUTPUT         : Uses on-chip UART hardware.

NOTE           :  
-*------------------------------------------------------------*/

void PC_LINK_O_Init_T1(const tWord BAUD_RATE)
{
   UART_Init();

   // Set up the buffers for reading and writing
   data_sent_uart_tx_buffer_index = 0;
   data_yet_sent_uart_tx_buffer_index = 0;
}

/*------------------------------------------------------------------*-
  ---- END OF FILE -------------------------------------------------
-*------------------------------------------------------------------*/
