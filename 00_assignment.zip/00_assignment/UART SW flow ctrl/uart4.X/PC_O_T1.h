/**************************************************************************
   FILE          :    PC_O_T1.h
 
   PURPOSE       :   type declarations for PC_O_T1.c .  
 
   AUTHOR        :  K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   see PC_O_T1.c for details
	
  CHANGE LOGS     :
	   
 **************************************************************************/
#ifndef _PC_O_T1_H
#define _PC_O_T1_H

#include "main.h"
// ------ Public function prototypes -------------------------------

void PC_LINK_O_Init_T1(const tWord);

#endif 

/*------------------------------------------------------------------*-
  ---- END OF FILE -------------------------------------------------
-*------------------------------------------------------------------*/

