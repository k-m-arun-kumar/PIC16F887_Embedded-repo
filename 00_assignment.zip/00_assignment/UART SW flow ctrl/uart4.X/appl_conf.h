/**************************************************************************
   FILE          :    appl_conf.h
 
   PURPOSE       :   main application configuration Header
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _APPL_CONF_H
 #define _APPL_CONF_H 
 
/*------------------------------- LCD disp conf ------------------------------------------*/


/* -------------------------------Timer state conf ---------------------------------------*/
#define TMR0_UART_TX_TIME_STATE            (0)
#define TMR0_STATE0_SERVICE_TYPE           TMR0_TIMER_INTP_SERVICE
#define TMR0_STATE0_CLK_TYPE               TMR0_CLK_SRC_INTR_OSC
#define TMR0_STATE0_PRESCALE               8 

/* ------------------------------- application conf --------------------------------------*/

#define APPL_STR_TX_BUFFER_LEN                           (30U)
// The uart tx buffer length
#define UART_TX_BUFFER_LEN                               (30u)
//for every REQ_TIME_UART_TX_ELAPSED_TIME_IN_MILLI_SEC, elasped time is send to PC via RS 232 link from uC
#define REQ_TIME_UART_TX_ELAPSED_TIME_IN_MILLI_SEC    (1000UL)    
#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
