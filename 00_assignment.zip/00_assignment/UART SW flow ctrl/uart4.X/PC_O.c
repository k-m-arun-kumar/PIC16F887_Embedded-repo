/* ********************************************************************
FILE                   : PC_O.c

PROGRAM DESCRIPTION    :  Core files for simple write-only PC link library for 8051 family
                          [Sends data to PC - cannot receive data from PC]. Uses the UART, and Pin 3.1 (Tx) 
                      									 
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 											
                                    
CHANGE LOGS           : 

*****************************************************************************/
#include "main.h"
#include "appl_conf.h"
#include "PC_O.h"
#include "Elap_232.h"
#include "uart.h"
// ------ Public variable definitions ------------------------------

 extern tByte data_sent_uart_tx_buffer_index;  // Index of data that has been sent
extern tByte data_yet_sent_uart_tx_buffer_index;  // Index of data not yet send 

// ------ Private function prototypes ------------------------------

static void PC_LINK_O_Send_Char(const char);
extern unsigned int cur_disp_block;
// ------ Private constants ----------------------------------------



// ------ Private variables ----------------------------------------

extern tByte uart_tx_buffer[UART_TX_BUFFER_LEN];

static tByte Time_count_G = 0;

/*------------------------------------------------------------*-
FUNCTION NAME  : PC_LINK_O_Update

DESCRIPTION    : Sends next character from the software transmit buffer
								
INPUT          : none

OUTPUT         : Uses on-chip UART hardware.

NOTE           :  Output-only library (Cannot receive chars)
-*------------------------------------------------------------*/
void PC_LINK_O_Update(void)
{
   // Deal with transmit bytes here
   //
   // Are there any data ready to send?
   if (data_sent_uart_tx_buffer_index < data_yet_sent_uart_tx_buffer_index)
   {
	 /* //SHOULD_REMOVE
	  if(cur_disp_block != 1)
	  {
	     UART_Transmit_Str("A\r");
	     cur_disp_block = 1 ;
	  } */
      PC_LINK_O_Send_Char(uart_tx_buffer[data_sent_uart_tx_buffer_index]); 
      ++data_sent_uart_tx_buffer_index;
	  /*//SHOULD_REMOVE
	  if(cur_disp_block != 2)
	  {
	     UART_Transmit_Str("B\r");
	     cur_disp_block = 2 ;
	  } */
   }
   else
   {
      // No data to send - just reset the buffer index
      data_yet_sent_uart_tx_buffer_index = 0;
      data_sent_uart_tx_buffer_index = 0; 
	  /*//SHOULD_REMOVE
	  if(cur_disp_block != 3)
	  {
	     UART_Transmit_Str("C\r");
	     cur_disp_block = 3 ;
	  } */
   }
}
/*------------------------------------------------------------*-
FUNCTION NAME  : PC_LINK_O_Write_String_To_Buffer

DESCRIPTION    : Copies a (null terminated) string to the character buffer.  
								
INPUT          : none

OUTPUT         : Uses on-chip UART hardware.

NOTE           : The contents of the buffer are then passed over the serial link
-*------------------------------------------------------------*/

void PC_LINK_O_Write_String_To_Buffer(const char* const appl_str)
{
   tByte i = 0;

   while (appl_str[i] != '\0')
   {
       // PC_LINK_O_Write_Char_To_Buffer(appl_str[i]);
	   // Write to the buffer *only* if there is space  
       if (data_yet_sent_uart_tx_buffer_index < UART_TX_BUFFER_LEN)
       {
          uart_tx_buffer[data_yet_sent_uart_tx_buffer_index] = appl_str[i];
          ++data_yet_sent_uart_tx_buffer_index;
          
		  //SHOULD_REMOVE
	     if(cur_disp_block != 3)
	     {
	        UART_Transmit_Str("A\r");		
	        cur_disp_block = 3 ;
	     }
            
       }
       else
       {
	      // (No error reporting in this simple library...)
	      //SHOULD_REMOVE 
		  if(cur_disp_block != 4)
	      {
	        UART_Transmit_Str("E\r");	
	        cur_disp_block = 4 ;
	      }
	      
       } 
      ++i;
   }
}
/*------------------------------------------------------------*-
FUNCTION NAME  : PC_LINK_O_Write_Char_To_Buffer

DESCRIPTION    : Stores a character in the 'write' buffer, ready for 
                later transmission
 								
INPUT          : none

OUTPUT         : Uses on-chip UART hardware.

NOTE           : The contents of the buffer are then passed over the serial link
-*------------------------------------------------------------*/
void PC_LINK_O_Write_Char_To_Buffer(const char tx_char)
{
   // Write to the buffer *only* if there is space  
   if (data_yet_sent_uart_tx_buffer_index < UART_TX_BUFFER_LEN)
   {
      uart_tx_buffer[data_yet_sent_uart_tx_buffer_index] = tx_char;
      ++data_yet_sent_uart_tx_buffer_index;     
   }
   else
   {
	    // (No error reporting in this simple library...)
	   //ERROR:
	   //SHOULD_REMOVE
	   UART_Transmit_Str("E\r");
   }
}
/*------------------------------------------------------------*-
FUNCTION NAME  : PC_LINK_O_Send_Char

DESCRIPTION    : Based on Keil sample code, with added (loop) timeouts.
  Implements Xon / Off for flow control in RS 232.
 								
INPUT          : none

OUTPUT         : Uses on-chip UART hardware.

NOTE           : 
-*------------------------------------------------------------*/
static void PC_LINK_O_Send_Char(const char to_tx_character)
{
	   char to_send_char;	   
       tLong Timeout1 = 0;	  
      
	  switch(to_tx_character)
	  {
		  case '\n':
		      to_send_char = '\r';
		  break;
          default:
		     to_send_char = to_tx_character;
	  }	
	  UART_Transmit_Char(to_send_char);     
 }
  

/*------------------------------------------------------------------*-
  ---- END OF FILE -------------------------------------------------
-*------------------------------------------------------------------*/
