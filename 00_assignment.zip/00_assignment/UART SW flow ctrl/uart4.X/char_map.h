/* ********************************************************************
FILE                 : char_map.h

PURPOSE              : This lookup table (stored in ROM) are used to convert ‘integer’ 
                      values into appropriate character codes(in 8 bit ASCII) for the LCD display 
											and RS232 link.											 
	 
AUTHOR               : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS           : 

NOTE                 : 

CHANGE LOGS          :

*****************************************************************************/	
// -------------------------  Public constants ----------------------------/
#ifndef _CHAR_MAP_H_
#define _CHAR_MAP_H_
/* control characters (in 8bit ASCII code) in appropriate integer value */
const char CHAR_MAP_G[10] 
                = {'0','1','2','3','4','5','6','7','8','9'};
#endif
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
