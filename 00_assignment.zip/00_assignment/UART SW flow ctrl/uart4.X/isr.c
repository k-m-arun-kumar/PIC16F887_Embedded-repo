/**************************************************************************
   FILE          :    isr.c
 
   PURPOSE       :   Interrupt Service Routine Library
 
   AUTHOR        :   K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 #include "main.h"
 #include "port.h"
 #include "io_conf.h"
 #include "timer.h"
 #include "uart.h"
 #include "intp_event_handle.h"  
 #include "PC_O.h"
 #include "Elap_232.h"
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void interrupt Interrupt_ISR() 
{
	#ifdef TIMER0_MOD_ENABLE
	if(T0IF == 1)
	{
          /* Must manually reset the Timer 0 overflow flag */	 
          T0IF = 0;

          //===== USER CODE - Begin (perodic(TIMER0_TICK_IN_MILLI_SEC in msec) executing application task) =======
          // Call RS-232 update function every TIMER0_TICK_IN_MILLI_SEC.
         PC_LINK_O_Update();

        // Call (application task) flow rate every TIMER0_TICK_IN_MILLI_SEC time interval.  
         if(timer0_cur_service_type & 2)
	     {
			  //timer0 is in timer mode
		 	   TMR0 = timer0_init_val; 
		      //timer0 overflow for every TIMER0_TICK_IN_MILLI_SEC ie timer0_elapsed_num_overflow_1_update var is incremented for every TIMER0_TICK_IN_MILLI_SEC elapsed
              if(++timer0_elapsed_num_overflow_1_update >= timer0_1_update) 
              {
			    if(++timer0_elapsed_num_update >= timer0_req_time_max_update)
			    {
                     /* for every REQ_TIME_UART_TX_ELAPSED_TIME_IN_MILLI_SEC */
                     Elapsed_Time_RS232_Update();
				     timer0_elapsed_num_update = 0;
					
			    }
                timer0_elapsed_num_overflow_1_update = 0;  			  
             }
		 }
      
         //===== USER CODE - End =========================================		
	}
	#endif
	if( INTCONbits.INTE == 1 && INTF == 1)           // external interrupt ISR - higher priority
	{	
	     INTCONbits.INTE = 0; //disable the INT pin external interrupt
		/*if INTF is not cleared in software, and when EXTR_INTP_SW is pressed on and after execution of External Interrupt ISR,   
		 and even when EXTR_INTP_SW is released, External Interrupt ISR keeps on been executed, until INTF, which was set, 
		 when EXTR_INTP_SW was pressed on, is cleared in software */			
        			
	    #ifdef TRACE
	       UART_Transmit_Str("External Interrupt is occurred \r");
		   UART_Transmit_Str("INTE is disabled \r"); 
	    #endif 	
		
		External_Interrupt_Occured_Appl_Proc();	
		INTF = 0;
	}
	#ifdef TIMER1_MOD_ENABLE
	if(TMR1IF)     // timer1 overflow interrupt ISR - lower prority
	{
		 TMR1IF = 0;
		 //===== USER CODE - Begin (perodic(TIMER0_TICK_IN_MILLI_SEC in msec) executing application task) =======
          // Call RS-232 update function every TIMER0_TICK_IN_MILLI_SEC.
         PC_LINK_O_Update();
		 if(timer1_cur_service_type & 2)
	     {
			  //timer1 is in timer mode
		 	   TMR1 = timer1_init_val; 
		      //timer1 overflow for every TIMER1_TICK_IN_MILLI_SEC ie timer1_elapsed_num_overflow_1_update var is incremented for every TIMER1_TICK_IN_MILLI_SEC elapsed
              if(++timer1_elapsed_num_overflow_1_update >= timer1_1_update) 
              {
			    if(++timer1_elapsed_num_update >= timer1_req_time_max_update)
			    {
				     /* for every REQ_TIME_UART_TX_ELAPSED_TIME_IN_MILLI_SEC */
                     Elapsed_Time_RS232_Update();  
					 timer1_elapsed_num_update = 0; 
			    }
                timer1_elapsed_num_overflow_1_update = 0;  			  
             }
		 }
		 else
		 {
			 //timer1 is in counter mode
			 ++tmr1_measure_pulse_upper_count;
			 
            /*  #ifdef TRACE
			        to_disp.   
	                UART_Transmit_Str("Timer1 overflow : 0x");
					UART_Transmit_Num(DISP_HEX_DIGIT4, measure_pulse_upper_count);
                    UART_Transmit_Num(DISP_HEX_DIGIT4, TMR1);
                    UART_Transmit_Char('\r');
              #endif */			 
		 }
	}
    #endif 	
	
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
