/**************************************************************************
   FILE          :    appl.h
 
   PURPOSE       :    Application Header
 
   AUTHOR        :   K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _APPL_H
 #define _APPL_H
 
/* ---------------------- macro defination ------------------------------------------------ */

#define QUANTITY_1_LITRE_IN_MILLI_LITRE          (1000UL)

/* ---------------------- data type defination --------------------------------------------- */

typedef enum {
	STATUS_INVALID, STATUS_MILK_LOW_HEIGHT, STATUS_MILK_HIGH_HEIGHT, STATUS_MILK_RESERVE, STATUS_MILK_VESSEL_DETECTED, STATUS_MILK_DRAINED, \
	STATUS_MILK_DRAINED_LOW, STATUS_MILK_DRAINED_HIGH
} status_vending_types;

typedef enum {
  RCVD_CHAR_DONT_DISP_FORMAT, RCVD_CHAR_PLAIN_DISP_FORMAT, RCVD_CHAR_HIDDEN_DISP_FORMAT  	
} rcvd_char_disp_format_types;

typedef enum {
	FSM_MILK_VENDING_IDLE = 0,FSM_MILK_VENDING_MENU_SEL, FSM_MILK_VENDING_ADD_USER, FSM_MILK_VENDING_DELETE_USER, FSM_MILK_VENDING_RECHARGE,\
	FSM_MILK_VENDING_RFID_SCAN, FSM_MILK_VENDING_ENTER_PASSWORD, FSM_MILK_VENDING_MILK_PURCHASE, FSM_MILK_VENDING_ENTER_QUANTITY, FSM_MILK_VENDING_CHECK_MILK_HEIGHT,\
	FSM_MILK_VENDING_INTIMATE_MANAGER, FSM_MILK_VENDING_DETECT_MILK_VESSEL, FSM_MILK_VENDING_DRAINING_MILK, FSM_MILK_VENDING_DEDUCE_BALANCE, FSM_MILK_VENDING_INTIMATE_CUSTOMER  
} fsm_milk_vending_states;

struct milk_customer_data_type {
	unsigned long int milk_customer_id;
	unsigned long int milk_balance_amount_in_rs;
	char customer_rfid_card_num[RFID_CARD_REQ_NUM_CHARS + 1];
	char customer_rfid_pwd[RFID_PWD_REQ_NUM_CHARS + 1];
	char customer_name[RFID_CUSTOMER_NAME_MAX_NUM_CHARS + 1];
	char customer_mobile_num[REQ_NUM_CHARS_MOBILE_NUM + 1];	
};	
typedef struct milk_customer_data_type milk_customer_data_types;

struct milk_vending_parameter_type
{
	fsm_milk_vending_states cur_fsm_milk_vending_state;
	fsm_milk_vending_states previous_fsm_milk_vending_state;
	status_vending_types vending_status;
	unsigned long int container_milk_available_in_litre;
	char manager_mobile_num[REQ_NUM_CHARS_MOBILE_NUM + 1];
    milk_customer_data_types *cur_milk_customer;	
} ;

typedef struct milk_vending_parameter_type milk_vending_parameter_types;

typedef enum {
	CUR_DATA_RESET_STATUS_WHOLE, CUR_DATA_RESET_STATUS_RETRY
} cur_data_status_reset_types;

typedef enum {
   CUR_DATA_RCV_MODE_TILL_ALLOCATED , CUR_DATA_RCV_MODE_TILL_TERMINATOR
} cur_data_rcv_mode_types;

struct cur_data_conf_parameter_types
{
	cur_data_id_types cur_data_id;
	input_dev_id_types cur_data_input_dev_id;
	output_dev_id_types cur_data_output_dev_id;
	cur_data_rcv_mode_types cur_data_rcv_mode;
	unsigned int cur_data_conf_max_num_chars_to_rcv;
	unsigned int cur_data_allocated_max_num_chars_to_rcv;
	unsigned int cur_data_input_max_num_try; 
	char cur_data_input_can_also_nonnum_key;
	rcvd_char_disp_format_types cur_data_rcvd_char_disp_format;
}; 
typedef struct cur_data_conf_parameter_types  cur_data_conf_parameter_types;

struct cur_data_status_parameter_types
{
	cur_data_id_types cur_data_id;
	unsigned int cur_data_num_chars_rcvd;
	unsigned int cur_data_input_num_try;
	char cur_data_rcvd_str[DATA_MAX_NUM_ALLOCATED_CHARS + 1];
	char cur_data_valid_end_rcvd_flag;
	char cur_data_max_allocated_num_chars_rcvd_flag;
}; 
typedef struct cur_data_status_parameter_types cur_data_status_parameter_types;

/* -------------------- public variable declaration --------------------------------------- */


bank3 extern milk_customer_data_types milk_customer_datas[];
bank3 extern milk_vending_parameter_types milk_vending_parameters;
bank2 extern cur_data_conf_parameter_types cur_data_conf_parameter;  
bank2 extern cur_data_status_parameter_types cur_data_status;

/* -------------------- public prototype declaration --------------------------------------- */

void Milk_Vending_Fsm_Proc();
void Reset_Parameters();
void Reset_Cur_Data_Status(cur_data_status_reset_types set_cur_data_status_reset_type);
int Next_Data_Conf_Parameter(const cur_data_id_types set_next_data_id, const input_dev_id_types set_next_data_input_dev_id, const output_dev_id_types set_next_data_output_dev_id, \
 const unsigned int set_next_data_max_num_chars_to_rcv, const unsigned int set_next_data_input_max_num_try, const char set_next_data_input_can_also_nonnum_key, \
 const rcvd_char_disp_format_types set_next_data_rcvd_char_disp_format);
int Str_to_Num_Conv(const char *const num_in_str, unsigned long int *num_conv_from_str );
unsigned int Str_Len(const char *const str);
int Num_to_Str_Conv(const int num_to_conv_str, const unsigned int min_num_digits_in_num_str, data_format_types cur_data_format, const char disp_sign_flag, char *num_in_str);
#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
