/* ********************************************************************
   FILE                   : lcd.c

   PROGRAM DESCRIPTION    : LCD library 
                      									 
	 
   AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
   KNOWN BUGS            : 

   NOTE                  :  										
                                    
   CHANGE LOGS           : 

*****************************************************************************/
#include "main.h"
#include "port.h"
#include "io_conf.h"
#include "lcd.h"
#include "uart.h"


char lcd_avail_loc_within_limit = STATE_YES;
unsigned int lcd_cur_disp_loc = BEGIN_LOC_LINE1, lcd_cur_input_loc = BEGIN_LOC_LINE2;
l
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void LCD_Init()
{
	/* wait for more than 15ms after LCD VSS rises to 4.5V, Busy Flag in LCD (BF) cannot be checked */
	Delay_Time_By_Count(15000UL);
    Write_LCD_Command_Cannot_Check_BF(0x30);
	/* wait for more than 4.1 ms, Busy Flag in LCD (BF) cannot be checked */
	Delay_Time_By_Count(4100UL);
    Write_LCD_Command_Cannot_Check_BF(0x30);
	/* wait for more than 100 us, Busy Flag in LCD (BF) cannot be checked */
	Delay_Time_By_Count(100);
    Write_LCD_Command_Cannot_Check_BF(0x30);
	Delay_Time_By_Count(2000UL);
	Write_LCD_Command(0x38);
	Write_LCD_Command(0x01);
	Write_LCD_Command(0x06);  
	Write_LCD_Command(0x0E);
} 
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void LCD_Write_Pulse()
{
    EN_PIN = 1;
    __delay_ms(10);
    EN_PIN = 0;
     __delay_ms(10);
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void Write_LCD_Command_Cannot_Check_BF(const unsigned int lcd_cmd)
{
   LCD_PORT_GPIO = 0x00; 
   LCD_PORT = 0x00;
   RW_PIN = 0;
   RS_PIN = 0;
   LCD_PORT = lcd_cmd; 
   LCD_Write_Pulse();   
     
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void Write_LCD_Command(const unsigned int lcd_cmd)
{
  
   //Check_LCD_Busy(); 
   LCD_PORT_GPIO = 0x00; 
   LCD_PORT = 0x00;
   RW_PIN = 0;
   RS_PIN = 0;
   LCD_PORT = lcd_cmd;
   LCD_Write_Pulse(); 
   
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void Delay_Time_By_Count(unsigned long int time_delay)
{
     while(time_delay--);
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
 void Write_LCD_Data(const char lcd_data)
{
  // Check_LCD_Busy(); 
   LCD_PORT_GPIO = 0x00; 
   LCD_PORT = 0x00;
   RW_PIN = 0;
   RS_PIN = 1;
   LCD_PORT = lcd_data;
   LCD_Write_Pulse(); 	
    
}
 
#ifdef UNUSED
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void LCD_Read_Pulse()
{
    EN_PIN = 0;
    Delay_Time_By_Count(LCD_ENABLE_PULSE_WIDTH);
    EN_PIN = 1;
    Delay_Time_By_Count(LCD_ENABLE_PULSE_WIDTH);
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void Check_LCD_Busy()
{
	unsigned int read_command;
    LCD_PORT_GPIO = 0xFF;
	LCD_PORT = 0x00;
	RW_PIN = 1;
    RS_PIN = 0; 
	
    /* busy flag = Bit 7 in LCD PORT, if busy flag == 1, wait till busy flag = 0, then any operation on LCD can be done */
   while(((read_command = Read_LCD_Command()) & 0x80) == 0x80)
   {
	   LCD_Read_Pulse();
	   LCD_Read_Pulse();
	   EN_PIN = 0;
	   Delay_Time_By_Count(LCD_ENABLE_PULSE_WIDTH);
   }	   
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
unsigned int Read_LCD_Command()
{
	 LCD_Write_Pulse();	 
	 return LCD_PORT;  
}

#endif
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 25   
-*------------------------------------------------------------*/

void Data_Str_Disp_LCD(const char *char_ptr)
{ 
       char cur_char;
	   
       while(*char_ptr)
       {
		    cur_char = *(char_ptr++);
            Write_LCD_Data(cur_char);			
       }
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 26  
-*------------------------------------------------------------*/
 void Data_Num_Disp_LCD(const unsigned int lcd_datanum_disp_format, const unsigned long lcd_disp_data_int)
{
    unsigned int tens_thousand_digit,thousands_digit, hundreds_digit,tens_digit, unit_digit;
    unsigned long num = lcd_disp_data_int;
    char num_data[] ={'0','1','2','3','4','5','6','7','8','9'};  
	char hex_data[] ={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'}; 
    switch(lcd_datanum_disp_format)
	{
	  case DISP_FLAG_NUM_DIGIT5: 
		  num =  lcd_disp_data_int ;
		  tens_thousand_digit = (unsigned int)(num / (unsigned long)(10000UL));
          Write_LCD_Data(num_data[tens_thousand_digit]);
	  case DISP_FLAG_NUM_DIGIT4:
	      num = lcd_disp_data_int % 10000UL;
	      thousands_digit = (unsigned int)(num / (unsigned long)(1000UL));
	      Write_LCD_Data(num_data[thousands_digit]); 
	  case DISP_FLAG_NUM_DIGIT3: 
		  num = lcd_disp_data_int % 1000UL;
	      hundreds_digit = (unsigned int) (num / (unsigned long) (100));
	      Write_LCD_Data(num_data[hundreds_digit]);
	  case DISP_FLAG_NUM_DIGIT2:
          num = lcd_disp_data_int % 100;
          tens_digit = (unsigned int) (num / 10);
          Write_LCD_Data(num_data[tens_digit]); 		  
	  case DISP_FLAG_NUM_DIGIT1:
	     unit_digit = (unsigned int) (lcd_disp_data_int % 10);
         Write_LCD_Data(num_data[unit_digit]); 
	  break;
	  case DISP_FLAG_HEX_DIGIT4:
	      //  ( 16 * 16 * 16 *16 )  = 0 as divide by zero warning 
	      //num = lcd_disp_data_int % ( 16 * 16 * 16 *16 );
          thousands_digit = (num / (unsigned long) (16 * 16 * 16));
	      Write_LCD_Data(hex_data[thousands_digit]);
	  case DISP_FLAG_HEX_DIGIT3:
	      num = lcd_disp_data_int %(unsigned long)(16 * 16 * 16);
	      hundreds_digit = (unsigned int) (num / (unsigned long) (16 * 16));
	      Write_LCD_Data(hex_data[hundreds_digit]);
	  case DISP_FLAG_HEX_DIGIT2:
	      num = lcd_disp_data_int %(unsigned long)(16 * 16);
          tens_digit = (unsigned int) (num / 16);
          Write_LCD_Data(hex_data[tens_digit]);
	  case DISP_FLAG_HEX_DIGIT1: 
	      unit_digit = (unsigned int) (lcd_disp_data_int % 16);
          Write_LCD_Data(hex_data[unit_digit]);    
	  break;
	  default:
	      // Warning invalid lcd_disp flag 
	    ;
	}   	
}


/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 29   
-*------------------------------------------------------------*/
void Goto_XY_LCD_Disp(const unsigned int start_line_num, const unsigned int start_col_num)
{
	/* max 4 lines and 20 columns */
	/* for us, lcd line starts from 1, but for uC, line starts from 0 */
	/* for us, lcd col starts from 1, but for uC, col starts from 0 */
    unsigned int start_line_lcd = start_line_num - 1, start_col_lcd = start_col_num - 1, error_disp_start_loc; 
	lcd_avail_loc_within_limit = STATE_YES;
	
   if(start_line_num <= CONFIGURE_MAX_NUM_LINES && start_col_num <= CONFIGURE_MAX_NUM_COLS )
   {
      switch(start_line_num)
	 {
		 case NUM_LINE1:
		   lcd_cur_disp_loc = BEGIN_LOC_LINE1;
		   break;
		 case NUM_LINE2:
		   lcd_cur_disp_loc = BEGIN_LOC_LINE2;
		   break;
		 case NUM_LINE3:
		   lcd_cur_disp_loc = BEGIN_LOC_LINE3;
		   break;
		  case NUM_LINE4:
		   lcd_cur_disp_loc = BEGIN_LOC_LINE4;
		   break;		 
	 }	
      lcd_cur_disp_loc = lcd_cur_disp_loc + start_col_lcd;
      Write_LCD_Command(lcd_cur_disp_loc);       
   }
   else
   {
	   /* error due to invalid lcd DISP loc  */
	     lcd_avail_loc_within_limit = STATE_NO;	
   }	   
} 
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 28  
-*------------------------------------------------------------*/
/* make sure that loc are within avail lcd loc limit */
void Set_Cur_Loc_LCD(const char set_input_loc_flag,const unsigned int set_input_loc, const char set_disp_loc_flag, const unsigned int set_disp_loc)
{
   if(set_input_loc_flag == STATE_YES)  
     lcd_cur_input_loc = set_input_loc;
   if(set_disp_loc_flag == STATE_YES)
     lcd_cur_disp_loc = set_disp_loc; 
}
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 30   
-*------------------------------------------------------------*/ 
void Goto_XY_LCD_Input(unsigned int start_line_num,unsigned int start_col_num)
{
	/* for us, lcd line starts from 1, but for uC, line starts from 0 */
	/* for us, lcd col starts from 1, but for uC, col starts from 0 */
    unsigned int start_line_lcd = start_line_num - 1, start_col_lcd = start_col_num - 1; 
	
	/* max 4 lines and 20 columns */
	lcd_avail_loc_within_limit = STATE_YES;
	if( start_line_num <= CONFIGURE_MAX_NUM_LINES &&  start_col_num <= CONFIGURE_MAX_NUM_COLS )
   {
     switch(start_line_num)
	 {
		 case NUM_LINE1:
		   lcd_cur_input_loc = BEGIN_LOC_LINE1;
		   break;
		 case NUM_LINE2:
		   lcd_cur_input_loc = BEGIN_LOC_LINE2;
		   break;
		 case NUM_LINE3:
		   lcd_cur_input_loc = BEGIN_LOC_LINE3;
		   break;
		  case NUM_LINE4:
		   lcd_cur_input_loc = BEGIN_LOC_LINE4;
		   break; 		  
	 }
	 lcd_cur_input_loc = lcd_cur_input_loc + start_col_lcd;
     Write_LCD_Command(lcd_cur_input_loc); 	 	   
  }
  else
  {
	   /* error due to invalid Lcd loc  */	
	   lcd_avail_loc_within_limit = STATE_NO;
  }	  
} 

 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 31   
-*------------------------------------------------------------*/
void From_XY_To_Loc_LCD(const unsigned int start_line_num, const unsigned int start_col_num, unsigned int * const lcd_loc)
{
	/* max 4 lines and 20 columns */
	   
	lcd_avail_loc_within_limit = STATE_YES;
	
   if(start_line_num <= CONFIGURE_MAX_NUM_LINES && start_col_num <= CONFIGURE_MAX_NUM_COLS )
   {
      switch(start_line_num)
	 {
		 case NUM_LINE1:
		   *lcd_loc = BEGIN_LOC_LINE1;
		   break;
		 case NUM_LINE2:
		   *lcd_loc = BEGIN_LOC_LINE2;
		   break;
		 case NUM_LINE3:
		   *lcd_loc= BEGIN_LOC_LINE3;
		   break;
		  case NUM_LINE4:
		  *lcd_loc = BEGIN_LOC_LINE4;
		   break;		 
	 }	
      *lcd_loc = *lcd_loc + start_col_num - 1;           
   }
   else
   {
	    lcd_avail_loc_within_limit = STATE_NO;
		/* error: due to loc_lcd's line num > max configured line nums */
   }	   
} 
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void From_Loc_to_XY_LCD(const unsigned int loc_lcd, unsigned int * const loc_lcd_line_num, unsigned int * const loc_lcd_col_num  )
{
	/* loc_lcd's corrosponding line num and col num */
	
	lcd_avail_loc_within_limit = STATE_YES;
	
	if(CONFIGURE_MAX_NUM_LINES <= MAX_AVAIL_NUM_LINES)
	{	
    	if(loc_lcd >= BEGIN_LOC_LINE1 && loc_lcd <= END_LOC_LINE1)
	    {
		     *loc_lcd_line_num = NUM_LINE1;
	         *loc_lcd_col_num = loc_lcd + 1 - BEGIN_LOC_LINE1;		    
	    }
       if(loc_lcd >= BEGIN_LOC_LINE2 && loc_lcd <= END_LOC_LINE2)
	   {
	     	*loc_lcd_line_num = NUM_LINE2;
		    *loc_lcd_col_num = loc_lcd + 1 - BEGIN_LOC_LINE2; 		
	   }     
	   if(loc_lcd >= BEGIN_LOC_LINE3 && loc_lcd <= END_LOC_LINE3)
	   {
		   	*loc_lcd_line_num = NUM_LINE3;
		  	*loc_lcd_col_num = loc_lcd + 1 - BEGIN_LOC_LINE3;			
	   }
       if(loc_lcd >= BEGIN_LOC_LINE4 && loc_lcd <= END_LOC_LINE4)
	   {
		  	*loc_lcd_line_num = NUM_LINE4;
		   	*loc_lcd_col_num = loc_lcd + 1 - BEGIN_LOC_LINE4;				
	   }	  
   } 
   else
   {
	   /* error: configured max lines > 4 */
	   
   }      
}

#if UNUSED
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 44  
-*------------------------------------------------------------*/
void Data_4Digit_Hex_Disp_LCD(const unsigned long lcd_disp_data_int)
{
	unsigned int tens_thousand_digit,thousands_digit, hundreds_digit,tens_digit, unit_digit;
    unsigned long num = lcd_disp_data_int;
	char hex_data[] ={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
	
	thousands_digit = (num / (16 * 16 * 16));
	Write_LCD_Data(hex_data[thousands_digit]);
	num = lcd_disp_data_int %(unsigned long)(16 * 16 * 16);
	hundreds_digit = (unsigned int) (num / (unsigned long) (16 * 16));
	Write_LCD_Data(hex_data[hundreds_digit]);
	num = lcd_disp_data_int %(unsigned long)(16 * 16);
    tens_digit = (unsigned int) (num / 16);
    Write_LCD_Data(hex_data[tens_digit]);
	unit_digit = (unsigned int) (lcd_disp_data_int % 16);
    Write_LCD_Data(hex_data[unit_digit]);    
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 43   
-*------------------------------------------------------------*/
void Goto_XY_LCD_Disp_Err(const unsigned int start_line_num, const unsigned int start_col_num)
{
	/* max 4 lines and 20 columns */
	/* for us, lcd line starts from 1, but for uC, line starts from 0 */
	/* for us, lcd col starts from 1, but for uC, col starts from 0 */
    unsigned int start_line_lcd = start_line_num - 1, start_col_lcd = start_col_num - 1, error_disp_start_loc; 
	lcd_avail_loc_within_limit = STATE_YES;
	
   if(start_line_num <= MAX_AVAIL_NUM_LINES && start_col_num <= MAX_AVAIL_NUM_COLS )
   {
      switch(start_line_num)
	 {
		 case NUM_LINE1:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE1;
		   break;
		 case NUM_LINE2:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE2;
		   break;
		 case NUM_LINE3:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE3;
		   break;
		  case NUM_LINE4:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE4;
		   break;		 
	 }	
      cur_disp_lcd_loc = cur_disp_lcd_loc + start_col_lcd;
      Write_LCD_Command(cur_disp_lcd_loc);       
   }
   else
   {
	   /* ERROR: loc exceeds max avail loc in lcd*/
   }
}  

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 33   
-*------------------------------------------------------------*/
/* process to to do when a error or warning has occured */
void Error_or_Warning_Proc(const char *error_trace, const unsigned int warn_or_error_format, const unsigned int warning_or_error_data)
{
	 error_or_warning_code |= warning_or_error_data; 
     INTERNAL_ERROR_LED_PIN = LED_ON;	
	 
	 if(disp_status_time_or_error[ERROR_STATUS_DISP_INDEX] == STATUS_DISP_ON )
	 {
        Goto_XY_LCD_Disp_Err(ERROR_LINE_NUM, NUM_COL1);
		Data_Str_Disp_LCD(error_trace);		
		Goto_XY_LCD_Disp_Err(ERROR_LINE_NUM, start_col_blank_space);
		Write_LCD_Data(' ');
		Goto_XY_LCD_Disp_Err(ERROR_LINE_NUM, start_col_error_code);
		Data_4Digit_Hex_Disp_LCD(error_or_warning_code);		
	 }
	switch(warn_or_error_format)
	{
		case WARNING_OCCURED:	
         if(disp_status_time_or_error[ERROR_STATUS_DISP_INDEX] == STATUS_DISP_ON )
	     { 
		    Goto_XY_LCD_Disp_Err(ERROR_LINE_NUM, start_col_error_msg);			   
	        Data_Str_Disp_LCD(warning_msg_disp);
			cur_line_disp_data[ERROR_LINE_NUM] = WARNING_DISP;	
            internal_error_state = WARNING_OCCURED;			
		 }	
		 /*warning occured, process to do  */
        break;
		case ERROR_OCCURED:
		  if(disp_status_time_or_error[ERROR_STATUS_DISP_INDEX] == STATUS_DISP_ON )
	      { 
		    Goto_XY_LCD_Disp_Err(ERROR_LINE_NUM, start_col_error_msg);		   
	        Data_Str_Disp_LCD(error_msg_disp);
			cur_line_disp_data[ERROR_LINE_NUM] = ERROR_DISP;
			internal_error_state = ERROR_OCCURED;	
		  }	
		  /*error occured, process to do  */
		break;
        case FATAL_OCCURED:	            
		if(disp_status_time_or_error[ERROR_STATUS_DISP_INDEX] == STATUS_DISP_ON )
	     { 
		    Goto_XY_LCD_Disp_Err(ERROR_LINE_NUM, start_col_error_msg);			   
	        Data_Str_Disp_LCD(fatal_msg_disp);
			internal_error_state = FATAL_OCCURED;	
			cur_line_disp_data[ERROR_LINE_NUM] = FATAL_DISP;
		 }	  
		 /* fatal error occured, process to do  */ 
		break;
        default:
         ;
         /* warning invalid error or warning format*/			    
	}
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 42   
-*------------------------------------------------------------*/
void Reset_Cur_Input_Data_Para()
{
  cur_data_input_start_loc = INVALID_DATA;
  cur_data_input_end_loc = INVALID_DATA;
  cur_data_input_end_line_num = INVALID_DATA;
  cur_data_input_end_col_num = INVALID_DATA;
  cur_data_conf_parameter.cur_data_allocated_max_num_chars_to_rcv = INVALID_DATA;
  cur_data_input_line_num = INVALID_DATA;
  cur_data_input_col_num = INVALID_DATA;
  cur_data_input_start_line_num = INVALID_DATA;
  cur_data_input_start_col_num	= INVALID_DATA;
}
#if (NUM_CHARS_INPUTDATA == GIVEN_CHARS_MAX_CONFIG_LINES_AND_COLS)
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 34   
-*------------------------------------------------------------*/	
void Cur_Input_Data_ByNumChars_Calc_Para(const unsigned int cur_data_entry_start_line_num, const unsigned int cur_data_entry_start_col_num, \
  const unsigned int configured_cur_data_input_max_num_chars)
{
	/* FIND MAX loc at which data can be entered from input_data_entry_start_loc and max num of chars can be entered from input_data_entry_start_loc,
	max loc's line num and max loc's column num */
    unsigned int max_configure_inputdata_num_chars_left_from_next_line,  max_loc_line_datainput, max_loc_col_datainput, input_data_entry_start_loc, \
    	max_avail_inputdata_num_chars_start_line, max_avail_num_chars_from_next_line, max_avail_data_input_end_col_numchars,\
		max_avail_num_chars_in_end_line, max_avail_data_input_numchars; 		
	
	
	lcd_avail_loc_within_limit = STATE_YES;	
	 Reset_Cur_Input_Data_Para();
	 
   if(cur_data_entry_start_line_num <= CONFIGURE_MAX_NUM_LINES && cur_data_entry_start_col_num <= CONFIGURE_MAX_NUM_COLS) 
   { 	  	        
        max_avail_inputdata_num_chars_start_line = CONFIGURE_MAX_NUM_COLS + 1 - cur_data_entry_start_col_num;		
		max_avail_num_chars_from_next_line = (CONFIGURE_MAX_NUM_LINES - cur_data_entry_start_line_num) * CONFIGURE_MAX_NUM_COLS;
		
		if(cur_data_entry_start_line_num == CONFIGURE_MAX_NUM_LINES)
		{
			max_avail_data_input_numchars = max_avail_inputdata_num_chars_start_line;
		}	
		else
		{	
		    max_avail_data_input_numchars = max_avail_inputdata_num_chars_start_line + max_avail_num_chars_from_next_line; 
		}	
		if(max_avail_data_input_numchars < configured_cur_data_input_max_num_chars )
		{
			cur_data_conf_parameter.cur_data_allocated_max_num_chars_to_rcv = max_avail_data_input_numchars; 
			//  Error_or_Warning_Proc("34.01", WARNING_OCCURED, WARN_DATA_CHARS_REACHED_MAX_ALLOC_CHARS_CODE);
            /*error: exceeds max_avail_data_input_numchars < configured_cur_data_input_max_num_chars */	
			
			 cur_data_input_end_line_num = CONFIGURE_MAX_NUM_LINES;
			 cur_data_input_end_col_num = CONFIGURE_MAX_NUM_COLS;
		}
        else
        {
			cur_data_conf_parameter.cur_data_allocated_max_num_chars_to_rcv = configured_cur_data_input_max_num_chars;
			if(max_avail_inputdata_num_chars_start_line >= configured_cur_data_input_max_num_chars)
			{
				 cur_data_input_end_line_num = cur_data_entry_start_line_num;
				 cur_data_input_end_col_num  = cur_data_entry_start_col_num + configured_cur_data_input_max_num_chars - 1;
            }
            else
			{				
		    	max_configure_inputdata_num_chars_left_from_next_line = configured_cur_data_input_max_num_chars - max_avail_inputdata_num_chars_start_line;
			    cur_data_input_end_line_num = (max_configure_inputdata_num_chars_left_from_next_line / CONFIGURE_MAX_NUM_COLS) + 1 + cur_data_entry_start_line_num;
			    cur_data_input_end_col_num = max_configure_inputdata_num_chars_left_from_next_line % (CONFIGURE_MAX_NUM_COLS + 1);
			}	
        }
        From_XY_To_Loc_LCD(cur_data_input_end_line_num, cur_data_input_end_col_num, &cur_data_input_end_loc);
		cur_data_input_start_col_num = cur_data_entry_start_col_num;
		cur_data_input_start_line_num = cur_data_entry_start_line_num;
		From_XY_To_Loc_LCD(cur_data_input_start_line_num, cur_data_input_start_col_num, &cur_data_input_start_loc);
        		
   }
   else
   {
	 //  Error_or_Warning_Proc("34.02", ERROR_OCCURED, ERR_CUR_INPUT_DATA_LOC_CODE);
	   /* error invalid lcd loc not within limit */ 
        lcd_avail_loc_within_limit = STATE_NO; 	  
   }
}

#elif (NUM_CHARS_INPUTDATA == GIVEN_XY_MAX_CONFIG_LINES_AND_COLS)
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 35   
-*------------------------------------------------------------*/	
void Cur_Input_Data_ByXY_Calc_Para(const unsigned int cur_data_entry_start_line_num, const unsigned int cur_data_entry_start_col_num, \
 const unsigned int next_data_start_line_num, const unsigned int next_data_start_col_num)
{
	
    unsigned int max_configure_inputdata_num_chars_left_from_next_line,  max_loc_line_datainput, max_loc_col_datainput, input_data_entry_start_loc, \
    	max_avail_inputdata_num_chars_start_line, max_avail_num_chars_from_next_line, max_avail_data_input_end_line_num, max_avail_data_input_end_col_numchars,\
		max_avail_num_chars_in_end_line, num_chars_inbetween_start_end_lines, cur_data_entry_end_line_num,  cur_data_entry_end_col_num;	
	
	
	lcd_avail_loc_within_limit = STATE_YES;
	 Reset_Cur_Input_Data_Para();
	 
   if( ((next_data_start_line_num <= MAX_AVAIL_NUM_LINES && next_data_start_col_num <= MAX_AVAIL_NUM_COLS )  ||  \
        next_data_start_line_num <= MAX_AVAIL_NUM_LINES + 1 && next_data_start_col_num == NUM_COL1 ) && \
       cur_data_entry_start_line_num <= CONFIGURE_MAX_NUM_LINES && cur_data_entry_start_col_num <= CONFIGURE_MAX_NUM_COLS )
      
   {
	  if(next_data_start_col_num == NUM_COL1)
	  {
		  cur_data_entry_end_col_num = CONFIGURE_MAX_NUM_COLS;
		  cur_data_entry_end_line_num = next_data_start_line_num - 1;
	  }
      else
      {
		  cur_data_entry_end_col_num = next_data_start_col_num - 1;
		  cur_data_entry_end_line_num = next_data_start_line_num;
	  }	
	  
	  if( (cur_data_entry_start_line_num == cur_data_entry_end_line_num && cur_data_entry_start_col_num < cur_data_entry_end_col_num )|| cur_data_entry_start_line_num < cur_data_entry_end_line_num  )
	  {  
         cur_data_input_start_col_num = cur_data_entry_start_col_num;
	     cur_data_input_start_line_num = cur_data_entry_start_line_num;
	     From_XY_To_Loc_LCD(cur_data_input_start_line_num, cur_data_input_start_col_num, &cur_data_input_start_loc);
         if(cur_data_entry_end_line_num > CONFIGURE_MAX_NUM_LINES)
         {
			cur_data_input_end_line_num =  CONFIGURE_MAX_NUM_LINES;
			/* warning : end line data input exceed configured max line  */
			// Error_or_Warning_Proc("35.01", WARNING_OCCURED, WARN_DATA_CHARS_REACHED_MAX_ALLOC_CHARS_CODE);
		    		
	     }
         else	
			cur_data_input_end_line_num =  cur_data_entry_end_line_num; 
		
		if(cur_data_entry_end_col_num > CONFIGURE_MAX_NUM_COLS)
         {
			cur_data_input_end_col_num =  CONFIGURE_MAX_NUM_COLS;
			/* warning : end col data input exceed configured max col  */
		    // Error_or_Warning_Proc("35.02", WARNING_OCCURED, WARN_DATA_CHARS_REACHED_MAX_ALLOC_CHARS_CODE);
		    		
	     }
        else	
			cur_data_input_end_col_num =  cur_data_entry_end_col_num; 
		if(cur_data_entry_start_line_num < cur_data_entry_end_line_num)
		{
			num_chars_inbetween_start_end_lines = (cur_data_input_end_line_num - cur_data_entry_start_line_num - 1) * CONFIGURE_MAX_NUM_COLS;
			max_avail_inputdata_num_chars_start_line =  CONFIGURE_MAX_NUM_COLS + 1 - cur_data_entry_start_col_num;	
			cur_data_conf_parameter.cur_data_allocated_max_num_chars_to_rcv = num_chars_inbetween_start_end_lines + max_avail_inputdata_num_chars_start_line + cur_data_input_end_col_num; 
		}
        else
        {	          
			cur_data_conf_parameter.cur_data_allocated_max_num_chars_to_rcv =  cur_data_entry_end_col_num - cur_data_entry_start_col_num + 1;
        }			
		From_XY_To_Loc_LCD(cur_data_input_end_line_num, cur_data_input_end_col_num, &cur_data_input_end_loc);
		 		 
	 }
     else
     {
	    // Error_or_Warning_Proc("35.03", ERROR_OCCURED, ERR_START_DATA_LOC_GREATER_END_DATA_LOC_CODE );
	   /* error invalid start data input loc > end data input loc */ 
	   lcd_avail_loc_within_limit = STATE_NO; 
    }	   
   } 
   else
   {
	 //  Error_or_Warning_Proc("35.04", ERROR_OCCURED, ERR_CUR_INPUT_DATA_LOC_CODE);
	   /* error invalid lcd loc not within limit */ 
        lcd_avail_loc_within_limit = STATE_NO; 
	   
   }
}
#else 
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : (NUM_CHARS_INPUTDATA = GIVEN_CHARS_MAX_XY)

Func ID        : 36   
-*------------------------------------------------------------*/	
void Cur_Input_Data_ByCharsXY_Calc_Para(const unsigned int cur_data_entry_start_line_num, const unsigned int cur_data_entry_start_col_num, \
const unsigned int configured_cur_data_input_max_num_chars, const unsigned int next_data_start_line_num, const unsigned int next_data_start_col_num)
{
  unsigned int max_configure_inputdata_num_chars_left_from_next_line,  max_loc_line_datainput, max_loc_col_datainput, input_data_entry_start_loc, \
   	max_avail_inputdata_num_chars_start_line,  max_avail_data_input_end_line_num, max_avail_data_input_end_col_numchars,configured_cur_data_input_max_num_chars_from_next_line,\
	max_avail_num_chars_in_end_line, num_chars_inbetween_start_end_lines, cur_data_entry_end_line_num,  cur_data_entry_end_col_num, cur_data_max_avail_numchars;
		
	lcd_avail_loc_within_limit = STATE_YES;
	Reset_Cur_Input_Data_Para();
	 
    if( ((next_data_start_line_num <= MAX_AVAIL_NUM_LINES && next_data_start_col_num <= MAX_AVAIL_NUM_COLS )  ||  \
        next_data_start_line_num <= MAX_AVAIL_NUM_LINES + 1 && next_data_start_col_num == NUM_COL1 ) && \
       cur_data_entry_start_line_num <= CONFIGURE_MAX_NUM_LINES && cur_data_entry_start_col_num <= CONFIGURE_MAX_NUM_COLS )	 
    {
		if(next_data_start_col_num == NUM_COL1)
	     {
		    cur_data_entry_end_col_num = CONFIGURE_MAX_NUM_COLS;
		    cur_data_entry_end_line_num = next_data_start_line_num - 1;
	     }
         else
         {
		    cur_data_entry_end_col_num = next_data_start_col_num - 1;
		    cur_data_entry_end_line_num = next_data_start_line_num;
	     }
	    if( (cur_data_entry_start_line_num == cur_data_entry_end_line_num && cur_data_entry_start_col_num < cur_data_entry_end_col_num )|| cur_data_entry_start_line_num < cur_data_entry_end_line_num  )
	    {
			if(cur_data_entry_end_line_num > CONFIGURE_MAX_NUM_LINES)
            {
		    	cur_data_input_end_line_num =  CONFIGURE_MAX_NUM_LINES;
		    	/* warning : end line data input exceed configured max line  */
			    // Error_or_Warning_Proc("36.01", WARNING_OCCURED, WARN_DATA_CHARS_REACHED_MAX_ALLOC_CHARS_CODE);		    		
	        }
            else
			{				
		    	cur_data_input_end_line_num =  cur_data_entry_end_line_num; 
			}
		    if(cur_data_entry_end_col_num > CONFIGURE_MAX_NUM_COLS)
            {
		    	cur_data_input_end_col_num =  CONFIGURE_MAX_NUM_COLS;
		    	/* warning : end col data input exceed configured max col  */
		       // Error_or_Warning_Proc("36.02", WARNING_OCCURED, WARN_DATA_CHARS_REACHED_MAX_ALLOC_CHARS_CODE);		 		
	        }
            else
			{				
		    	cur_data_input_end_col_num =  cur_data_entry_end_col_num; 
			}
		    cur_data_input_start_col_num = cur_data_entry_start_col_num;
		    cur_data_input_start_line_num = cur_data_entry_start_line_num;
		    From_XY_To_Loc_LCD(cur_data_input_start_line_num, cur_data_input_start_col_num, &cur_data_input_start_loc); 
			
			if(cur_data_entry_start_line_num < cur_data_entry_end_line_num)
		    {
		    	num_chars_inbetween_start_end_lines = (cur_data_input_end_line_num - cur_data_entry_start_line_num - 1) * CONFIGURE_MAX_NUM_COLS;
		    	max_avail_inputdata_num_chars_start_line =  CONFIGURE_MAX_NUM_COLS + 1 - cur_data_entry_start_col_num;	
		    	cur_data_max_avail_numchars = num_chars_inbetween_start_end_lines + max_avail_inputdata_num_chars_start_line + cur_data_input_end_col_num;                					
		    }
            else
            {	          
			    cur_data_max_avail_numchars =  cur_data_entry_end_col_num - cur_data_entry_start_col_num + 1;
            }
            if(configured_cur_data_input_max_num_chars > cur_data_max_avail_numchars)
			{
			   /* warning : end col data input exceed configured max col  */
		       // Error_or_Warning_Proc("36.03", WARNING_OCCURED, WARN_DATA_CHARS_REACHED_MAX_ALLOC_CHARS_CODE);	
				cur_data_conf_parameter.cur_data_allocated_max_num_chars_to_rcv = cur_data_max_avail_numchars;
				cur_data_input_end_line_num =  cur_data_entry_end_line_num;
				cur_data_input_end_col_num =  cur_data_entry_end_col_num;
			}
            else
			{
				cur_data_conf_parameter.cur_data_allocated_max_num_chars_to_rcv = configured_cur_data_input_max_num_chars;
			    if(configured_cur_data_input_max_num_chars < max_avail_inputdata_num_chars_start_line)	
				{
					cur_data_input_end_line_num =  cur_data_entry_start_line_num;
				    cur_data_input_end_col_num =  cur_data_entry_start_col_num + configured_cur_data_input_max_num_chars - 1;					
				}
                else
				{
					configured_cur_data_input_max_num_chars_from_next_line = configured_cur_data_input_max_num_chars - max_avail_inputdata_num_chars_start_line;
					cur_data_input_end_line_num = (configured_cur_data_input_max_num_chars_from_next_line / CONFIGURE_MAX_NUM_COLS) + 1 + cur_data_input_start_line_num;
					cur_data_input_end_col_num = (configured_cur_data_input_max_num_chars_from_next_line % (CONFIGURE_MAX_NUM_COLS + 1)) ;
				}						
			}
			From_XY_To_Loc_LCD(cur_data_input_end_line_num, cur_data_input_end_col_num, &cur_data_input_end_loc);		 
		}
		else
        {
	      // Error_or_Warning_Proc("36.03", ERROR_OCCURED, ERR_START_DATA_LOC_GREATER_END_DATA_LOC_CODE );
	      /* error invalid start data input loc > end data input loc */
		   lcd_avail_loc_within_limit = STATE_NO; 
        }	   
    } 
    else
   {
	 //  Error_or_Warning_Proc("36.04", ERROR_OCCURED, ERR_CUR_INPUT_DATA_LOC_CODE);
	   /* error invalid lcd loc not within limit */ 
       lcd_avail_loc_within_limit = STATE_NO; 
   }
}
#endif
#endif
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
