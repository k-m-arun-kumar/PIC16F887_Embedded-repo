/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    :  SMART MILK VENDING MACHINE
 
  At any time, when a logout key('#') key is pressed, then ask for confirmation to logout and if user pressed confirm key('*'), 
  then logout the session, else any other key pressed, then retain same session. A milk customer has only one activated RFID tag for transaction. At first, 
  welcome message is displayed in LCD. When a user types any 2 digit number entered through keypad, then display main menu for selection for milk customer menu and administation menu.
  If milk customer selects milk customer menu, then milk customer swipes RFID tag on the RFID reader module, which is interfaced to the micro controller with serial interfacing
  and microcontroller reads the information from the RFID reader or module and if valid successfully for milk customer's RFID card, then asks PIN or OTP
  (new RFID card number activated and received OTP by SMS). Milk customer enters PIN or OTP through keypad. If milk customer is authenticated successfully, 
  and if OTP was used for verification, then display operation to change PIN. If milk customer is authenticated successfully, and if PIN was used for verification, 
  then display milk customer menu for selection for milk purchase, change PIN and balance amount enquiry. In change PIN operation, set and confirm new PIN.
  If milk customer selects milk purchase, then check milk level(height) in milk container by using the level sensor, and whenever the milk level is going out of range,
  then it will send Short Message Service (SMS) to the manager's registered mobile number of the vending machine in milk purchase center. If milk level(height) is within valid range 
  and if balance amount of milk customer is within valid range, then asks how many liters does it required, which will be shown on the LCD of the screen. 
  Then milk customer required to enter the required number of liters through keypad which act as an input to the micro controller. After reading entered the required number of liters, 
  which is valid and within range and then microconroller calculates amount to be charged for entered the required number of liters and then the microcontroller will check in the RFID 
  smart card, for the required balance amount remaining by deducted the amount to be charged for entered the required number of liters, and then if balance amount after to be deducted
  amount is sufficiently available, then if milk customer's vessel is placed at milk drained point and sensed by proximity sensor, then the milk will be drained out for quantity of milk 
  drained approximately equal to entered quantity of milk by milk customer. Quantity of milk drained is sensed by flow sensor. If quantity of milk drained is within range of 
  entered quantity of milk by milk customer +/- tolerance, then deduce the amount charged for entered the number of liters purchased by the logged in milk customer.
  Then intimate by GSM SMS to milk customer's registered mobile number about info balance amount, amount deduced and number of liters purchased in Milk purchase center's unique ID. 
  If there is balance amount is not sufficiently available, then the error led or caution. If admin pressed administration menu selection, then admin enters admin user name through UART 
  and if validated successfully, then admin enters admin user name's password through UART, and then if admin is authenticated, then in UART display menu for selection for
  add milk customer menu, delete a milk customer menu, modify data for a milk customer menu and recharge amount for a milk customer (with input data as key is milk customer id).
  In Admin enters data through UART. In modify data for a milk customer menu, milk customer gives input data as key is milk customer id and if existing milk customer, 
  then selection for change milk customer's registered mobile number, change milk customer's name, reset PIN, block RFID card number and new RFID card number. 
  In change milk customer name after manual name verification of documents. In block RFID Card Number operation, milk customer gives input on milk cust id and if milk customer
  correctly answered question asked by admin based on info, which was included in add of that milk customer operation and then current RFID card number is blocked
  and PIN for that RFID tag is invalid and milk customer can apply for new RFID Card Number and if new RFID Card Number is received by milk customer and activated, then intimate by GSM SMS
  to milk customer's registered mobile number about info on OTP. Then in milk customer menu, then milk customer swipes RFID tag and if valid successfully for milk customer's new RFID card, 
  then asks OTP. If milk customer is authenticated successfully, then display operaton to change PIN. In change PIN operation, set and confirm new PIN. 
  Then milk customer can do transaction based on new PIN. 
 
                     									 	 
AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : in this program, data's max num of chars allocated and data max num of chars conf are same. 
                        Refer lcd_14 for data's max num of chars allocated < data max num of chars conf, 
   						if available data's max num of chars < data max num of chars conf.
						Switch debounce, long key press and no key press timeout is not implemented.
                        long key press and no key press timeout are implemented in PIC16F887-repo->00_assignment->Single Account auth  
                        Operation of addition and deletion of max 2 milk user. 
						There is a only one admin user name. 
						Milk container is vertical cylindrical shaped tank and nett capacity of milk container must be less than 65 Litre, due to only max long integer(16 bit) of uC is supported.
                        To support higher net capacity of nett capacity of milk container, uC should support floating point operation or 32bit integer.						.
						Data terminator char is enter char					
                        A milk customer has only one activated RFID tag for transaction.
						
CHANGE LOGS           : 

*****************************************************************************/

#include "main.h"
#include "port.h"
#include "appl_conf.h" 
#include "lcd.h"
#include "uart.h"
#include "appl.h"

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.
// 'C' source line config statements
//#pragma config FOSC = XT    // Oscillator Selection bits (XT oscillator)
#pragma config WDTE = OFF   // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF  // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOREN = OFF  // Brown-out Reset Enable bit (BOR disabled)
#pragma config LVP = OFF    // Low-Voltage In-Circuit Serial Programming Enable bit
#pragma config CPD = OFF    // Data EEPROM Memory Code Protection bit
#pragma config WRT = OFF    // Flash Program Memory Write Enable bits
#pragma config CP = OFF     // Flash Program Memory Code Protection bit

void LCD_Const_Disp();
void IO_Init();

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void main()
{	

   IO_Init();  
     
   /* commited due to stack overflow  */
   LCD_Init(); 	
   LCD_Const_Disp();
   
   UART_Init();
   milk_vending_parameters.cur_fsm_milk_vending_state = FSM_MILK_VENDING_IDLE;
   while(1)
   {
       Milk_Vending_Fsm_Proc();
   }   
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void IO_Init()
{
   LCD_PORT_GPIO = 0x00;
   LCD_PORT = 0x00;   
   TRISE = 0x00;
   PORTE = 0x00;
   
   TRISBbits.TRISB1 = 1;
   TRISBbits.TRISB2 = 1;
   TRISBbits.TRISB3 = 1;
   TRISBbits.TRISB4 = 0;
   KEYPAD_PHONE_ROWA = 0;
   TRISBbits.TRISB5 = 0;
   KEYPAD_PHONE_ROWB = 0;
   TRISBbits.TRISB6 = 0;
   KEYPAD_PHONE_ROWC = 0;
   TRISBbits.TRISB7 = 0;
   KEYPAD_PHONE_ROWD = 0;
   TRISAbits.TRISA1 = 0;
   PROCESS_OVER_LED = LED_ON;
   TRISAbits.TRISA4 = 1;
   TRISAbits.TRISA6 = 0;
   MILK_DRAINING_LED = LED_OFF;
   TRISAbits.TRISA7 = 1;
   TRISCbits.TRISC0 = 0;
   MILK_DRAIN_VALVE = STATE_OFF;
   TRISCbits.TRISC1 = 0;
   ERROR_LED = LED_OFF;
   TRISCbits.TRISC2 = 1;
   
   ADCON0 = 0b00000001;
   ADCON1 = 0x00;    
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void LCD_Const_Disp()
{
	const char signal_rep_disp[] = "V";
	
	Goto_XY_LCD_Disp(NUM_LINE1, NUM_COL1);
	Data_Str_Disp_LCD("ADC Channel 0 Output");	       
    Goto_XY_LCD_Disp(SIGCH0_LINE_NUM,SIGNAL_DECPT_COL_NUM );
	Write_LCD_Data('.');
	Goto_XY_LCD_Disp(SIGCH0_LINE_NUM,SIGNAL_DISP_COL_NUM);
	Data_Str_Disp_LCD(signal_rep_disp);	
	Goto_XY_LCD_Disp(SIGCH0_LINE_NUM,PERCENT_DECPT_COL_NUM);
	Write_LCD_Data('.');
    Goto_XY_LCD_Disp(SIGCH0_LINE_NUM,PERCENT_DISP_COL_NUM);
	Write_LCD_Data('%');	
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
