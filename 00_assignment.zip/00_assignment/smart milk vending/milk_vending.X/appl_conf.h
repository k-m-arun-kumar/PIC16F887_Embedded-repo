/**************************************************************************
   FILE          :    appl_conf.h
 
   PURPOSE       :   main application configuration Header
 
   AUTHOR        :     K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _APPL_CONF_H
 #define _APPL_CONF_H 
 
/*------------------------------- LCD disp conf ------------------------------------------*/

#define SIGCH0_LINE_NUM           (NUM_LINE2)
#define SIGNAL_DECPT_COL_NUM      (NUM_COL1 + 4)
#define SIGNAL_FRAC_COL_NUM       (SIGNAL_DECPT_COL_NUM + 1)
#define SIGNAL_DISP_COL_NUM       (SIGNAL_FRAC_COL_NUM + 1)    
#define PERCENT_INT_COL_NUM       (SIGNAL_DISP_COL_NUM + 4)
#define PERCENT_DECPT_COL_NUM     (PERCENT_INT_COL_NUM + 3)
#define PERCENT_FRAC_COL_NUM      (PERCENT_DECPT_COL_NUM + 1) 
#define PERCENT_DISP_COL_NUM      (PERCENT_FRAC_COL_NUM + 2) 

#define RFID_PWD_MSG_LINE_NUM       NUM_LINE2
#define RFID_PWD_GET_LINE_NUM       NUM_LINE3
#define MILK_QUANTITY_MSG_LINE_NUM  NUM_LINE2
#define MILK_QUANTITY_GET_LINE_NUM  NUM_LINE3
#define CUSTOMER_NAME_DISP_LINE_NUM NUM_LINE1

#define LCD_BEGIN_LOC_ECHO_UART_RCVD_STR   BEGIN_LOC_LINE2

/* -------------------------------Timer state conf ---------------------------------------*/

typedef enum {
	TMR1_STOP_STATE, TMR1_MILK_DRAINING_STATE 
 } timer1_run_states;

/* ---------------------------------- ADC channel && input signal val conf -------------- */

#define CONTAINER_MILK_HEIGHT_CH0        ADC_CH_00

/* external Vref+ pin voltage = MAX_ANALOG_VALUE_CH0 and  external Vref- pin voltage = MIN_ANALOG_VALUE_CH0 */
#define MAX_ANALOG_VALUE_CH0           (5U)
#define MIN_ANALOG_VALUE_CH0           (0U)
#define FULL_SCALE_ANALOG_VAL_CH0     (MAX_ANALOG_VALUE_CH0 - MIN_ANALOG_VALUE_CH0)

/* ------------------------------- application conf --------------------------------------*/

#define HIDDEN_KEY_DISP_CHAR                  ('X') 
#define INVALID_MILK_CUSTOMER_ID              (0UL)
#define DATA_TERMINATOR_CHAR                  ENTER_CHAR
#define DATA_MAX_NUM_ALLOCATED_CHARS          (15U) 

typedef enum {
  CUR_DATA_ID_INVALID, CUR_DATA_ID_RFID_CARD_NUM, CUR_DATA_ID_RFID_PWD, CUR_DATA_ID_MILK_QUANTITY	
} cur_data_id_types;

#define RFID_CARD_REQ_NUM_CHARS                                 (6U)
#define RFID_CARD_INPUT_MAX_NUM_TRY                              (1U)
#define RFID_PWD_REQ_NUM_CHARS                                   (4U) 
#define RFID_PWD_INPUT_MAX_NUM_TRY                               (3U)
#define MILK_QUANTITY_MAX_NUM_CHARS                              (2U) 
#define MILK_QUANTITY_INPUT_MAX_NUM_TRY                          (3U)

#define RFID_CUSTOMER_NAME_MAX_NUM_CHARS                        (10U)
#define REQ_NUM_CHARS_MOBILE_NUM                                (10U) 
                 
#define CUSTOMER_MIN_MILK_QUANTITY_IN_LITRE                     (1UL)
#define CUSTOMER_MAX_MILK_QUANTITY_IN_LITRE                     (10UL)                               
#define REQ_TIME_CUSTOMER_MIN_MILK_QUANTITY_DRAIN_IN_MILLI_SEC   (1000UL)
#define CUSTOMER_MIN_QUANTITY_MILK_AMOUNT_IN_RS                 (40UL)
#define CONF_CUSTOMER_MIN_BALANCE_AMT_IN_RS                    (100UL)

// milk container is vertical cylindrical shaped tank = volume_in_litre * 1000 = pi * cylinder_radius_in_cm * cylinder_radius_in_cm * height_in_cm 
#define MILK_CONTAINER_NETT_CAPACITY_IN_LITRE                   (55UL)
#define MILK_CONTAINER_DIAMETER_IN_CM                           (20UL)
#define MILK_MAX_HEIGHT_MILK_CONTAINER_IN_CM                   (175UL) 
#define MILK_MIN_HEIGHT_MILK_CONTAINER_IN_CM                     (0UL)

#define TOLERANCE_LIMIT_MILK_QUANTITY_IN_MILLI_LITRE            (50UL)

#define CONF_MILK_LOW_LIMIT_HEIGHT_MILK_CONTAINER_IN_CM          (35UL)
//actual value for CONF_MILK_LOW_LIMIT_HEIGHT_MILK_CONTAINER_ENCODED_VAL = 204.6
// =  ((CONF_MILK_LOW_LIMIT_HEIGHT_MILK_CONTAINER_IN_CM * 1023) / (MILK_MAX_HEIGHT_MILK_CONTAINER_IN_CM - MILK_MIN_HEIGHT_MILK_CONTAINER_IN_CM)) - MILK_MIN_HEIGHT_MILK_CONTAINER_IN_CM 
#define CONF_MILK_LOW_LIMIT_HEIGHT_MILK_CONTAINER_ENCODED_VAL   (205UL) 
#define CONF_MILK_HIGH_LIMIT_HEIGHT_MILK_CONTAINER_IN_CM        (140UL)
//actual value for CONF_MILK_HIGH_LIMIT_HEIGHT_MILK_CONTAINER_ENCODED_VAL = 818.4
#define CONF_MILK_HIGH_LIMIT_HEIGHT_MILK_CONTAINER_ENCODED_VAL   (818UL)

#define CONF_CONTAINER_RESERVE_LOW_LIMIT_MILK_QUANTITY_IN_LITRE (6UL)
#define CONF_CONTAINER_LOW_LIMIT_MILK_QUANTITY_IN_LITRE        (11UL) 
//actual value for CONF_CONTAINER_MILK_LOW_LIMIT_HEIGHT_ENCODED_VAL = 204.6
#define CONF_CONTAINER_MILK_LOW_LIMIT_HEIGHT_ENCODED_VAL       (205UL)
#define CONF_CONTAINER_HIGH_LIMIT_MILK_QUANTITY_IN_LITRE        (44UL) 
//actual value for CONF_CONTAINER_MILK_HIGH_LIMIT_HEIGHT_ENCODED_VAL = 818.4
#define CONF_CONTAINER_MILK_HIGH_LIMIT_HEIGHT_ENCODED_VAL      (818UL) 


// milk container is vertical cylindrical shaped tank = volume_in_litre * 1000 = pi * cylinder_radius_in_cm * cylinder_radius_in_cm * height_in_cm 
/*#define MILK_CONTAINER_NETT_CAPACITY_IN_LITRE               (1100UL)
#define MILK_CONTAINER_DIAMETER_IN_CM                          (100UL)
#define MILK_MAX_HEIGHT_MILK_CONTAINER_IN_CM                   (140UL) 
#define MILK_MIN_HEIGHT_MILK_CONTAINER_IN_CM                     (0UL)


#define CONF_MILK_MIN_LIMIT_HEIGHT_MILK_CONTAINER_IN_CM          (7UL)
//actual value for CONF_MILK_MIN_LIMIT_HEIGHT_MILK_CONTAINER_ENCODED_VAL = 51.15
// = ((CONF_MILK_MIN_LIMIT_HEIGHT_MILK_CONTAINER_IN_CM * 1023) / (MILK_MAX_HEIGHT_MILK_CONTAINER_IN_CM - MILK_MIN_HEIGHT_MILK_CONTAINER_IN_CM)) - MILK_MIN_HEIGHT_MILK_CONTAINER_IN_CM 
#define CONF_MILK_MIN_LIMIT_HEIGHT_MILK_CONTAINER_ENCODED_VAL   (52UL) 
#define CONF_MILK_MAX_LIMIT_HEIGHT_MILK_CONTAINER_IN_CM        (126UL)
//actual value for CONF_MILK_MAX_LIMIT_HEIGHT_MILK_CONTAINER_ENCODED_VAL = 920.7
#define CONF_MILK_MAX_LIMIT_HEIGHT_MILK_CONTAINER_ENCODED_VAL  (920UL) 


#define CONF_CONTAINER_MIN_LIMIT_MILK_QUANTITY_IN_LITRE        (55UL) 
//actual value for CONF_CONTAINER_MILK_MIN_LIMIT_HEIGHT_ENCODED_VAL = 51.15
#define CONF_CONTAINER_MILK_MIN_LIMIT_HEIGHT_ENCODED_VAL       (52UL)
#define CONF_CONTAINER_MAX_LIMIT_MILK_QUANTITY_IN_LITRE       (990UL) 
//actual value for CONF_CONTAINER_MILK_MAX_LIMIT_HEIGHT_ENCODED_VAL = 920.7
#define CONF_CONTAINER_MILK_MIN_LIMIT_HEIGHT_ENCODED_VAL       (920UL) */
    

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
