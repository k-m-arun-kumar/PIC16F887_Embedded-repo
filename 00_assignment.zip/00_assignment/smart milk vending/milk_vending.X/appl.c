/**************************************************************************
   FILE          :    appl.c
 
   PURPOSE       :   Application 
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 #include "main.h"
 #include "port.h"
 #include "io_conf.h"
 #include "adc.h"
 #include "appl_conf.h"
 #include "lcd.h"
 #include "uart.h"
 #include "timer.h"
 #include "appl.h"
 #include "keyboard.h"
 #include "string.h"
 
 cur_data_conf_parameter_types cur_data_conf_parameter;
 cur_data_status_parameter_types cur_data_status;
 milk_customer_data_types milk_customer_datas[1] = {1, 150, "987654", "1234","Ganesha","9988776655"};
 milk_vending_parameter_types milk_vending_parameters;

 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : change SPBRG depending on  Osc freq  and baud rate 

Func ID        : 21   
-*------------------------------------------------------------*/
void Milk_Vending_Fsm_Proc()
{
	int rcvd_status_int;
	unsigned long rcvd_adc_channel_value, timer1_run_time ;
	unsigned long analog_val_in_digital_int_ch[3], analog_val_in_digital_frac_ch[3];
	unsigned int percent_int_ch[1], percent_frac_ch[1];	
	static unsigned long int entered_milk_quantity_in_litre = 0;	
	static unsigned long int amount_to_deduce = 0;
	char to_transmit_sms_info[50], deduced_amt_str[6],balance_amt_str[6], quantity_purchased_str[4];
	
    switch(milk_vending_parameters.cur_fsm_milk_vending_state)
    {
        case FSM_MILK_VENDING_IDLE:
           Reset_Parameters();
		   milk_vending_parameters.cur_milk_customer = NULL;
		   milk_vending_parameters.vending_status = STATUS_INVALID;
		   milk_vending_parameters.previous_fsm_milk_vending_state = FSM_MILK_VENDING_IDLE;
		   milk_vending_parameters.cur_fsm_milk_vending_state = FSM_MILK_VENDING_MENU_SEL;
		   
		   #ifdef TRACE
			  UART_Transmit_Str("FSM_MILK_VENDING_MENU_SEL state \r");
		   #endif
		   
		break;
        case FSM_MILK_VENDING_MENU_SEL: 
           Write_LCD_Command(0x01);	              
           Next_Data_Conf_Parameter(CUR_DATA_ID_RFID_CARD_NUM, INPUT_DEV_ID_UART, OUTPUT_DEV_ID_LCD, \
     		   RFID_CARD_REQ_NUM_CHARS, RFID_CARD_INPUT_MAX_NUM_TRY, STATE_NO, RCVD_CHAR_PLAIN_DISP_FORMAT); 		
		   ERROR_LED = LED_OFF;
		   PROCESS_OVER_LED = LED_OFF;
		  
		   #ifdef TRACE
			  UART_Transmit_Str("ERROR LED and PROCESS_OVER LED are OFF \r");
		   #endif		   
	       
	       UART_Transmit_Str("Swip RFID : ");		   
		   uart_rcv_enable_flag = STATE_YES;	
		   milk_vending_parameters.previous_fsm_milk_vending_state = FSM_MILK_VENDING_MENU_SEL;
           milk_vending_parameters.cur_fsm_milk_vending_state = FSM_MILK_VENDING_RFID_SCAN;
		   
		   #ifdef TRACE
			  UART_Transmit_Str("FSM_MILK_VENDING_RFID_SCAN state \r");
		   #endif
        break;	
		case FSM_MILK_VENDING_RFID_SCAN:
		   if(cur_data_status.cur_data_input_num_try < cur_data_conf_parameter.cur_data_input_max_num_try)
		   {
               if(cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag == STATE_NO && cur_data_status.cur_data_valid_end_rcvd_flag == STATE_NO) 
			       rcvd_status_int = UART_Receive_Str();
			   if(rcvd_status_int != SUCCESS)
			   {
				   ERROR_LED = LED_ON;
					   
				   #ifdef TRACE_ERROR
				      UART_Transmit_Str("ERROR LED is ON \r");
				   #endif	
				   
				   milk_vending_parameters.previous_fsm_milk_vending_state = FSM_MILK_VENDING_RFID_SCAN;
				   milk_vending_parameters.cur_fsm_milk_vending_state = FSM_MILK_VENDING_IDLE;
                   break;
			   }
		       if(strcmp(cur_data_status.cur_data_rcvd_str, milk_customer_datas[0].customer_rfid_card_num) == 0)
		       {
		           Write_LCD_Command(0x01);
				   Reset_Parameters();
				   Next_Data_Conf_Parameter(CUR_DATA_ID_RFID_PWD, INPUT_DEV_ID_KEYBOARD, OUTPUT_DEV_ID_LCD, RFID_PWD_REQ_NUM_CHARS, \
				         RFID_PWD_INPUT_MAX_NUM_TRY, STATE_NO, RCVD_CHAR_HIDDEN_DISP_FORMAT );
				   Goto_XY_LCD_Disp(RFID_PWD_MSG_LINE_NUM, NUM_COL1);		 
		           Data_Str_Disp_LCD("Enter password ");
				   Goto_XY_LCD_Input(RFID_PWD_GET_LINE_NUM, NUM_COL1);
				   Write_LCD_Command(0x0E);	
				   milk_vending_parameters.cur_milk_customer = &milk_customer_datas[0];
		           keyboard_input_enable_flag = STATE_YES;
				   backspace_sw_enable_flag = STATE_YES; 
	               enter_sw_enable_flag = STATE_YES;
				   
				   milk_vending_parameters.previous_fsm_milk_vending_state = FSM_MILK_VENDING_RFID_SCAN;
		           milk_vending_parameters.cur_fsm_milk_vending_state = FSM_MILK_VENDING_ENTER_PASSWORD;
				 
				   #ifdef TRACE
			          UART_Transmit_Str("FSM_MILK_VENDING_ENTER_PASSWORD state \r");
		           #endif
		        }
	            else
		        {
					Write_LCD_Command(0x01);
					Reset_Cur_Data_Status(CUR_DATA_RESET_STATUS_RETRY);
					++cur_data_status.cur_data_input_num_try;
					UART_Transmit_Str("Reswip RFID : "); 
		        }
		   }
		   else
		   {
			   ERROR_LED = LED_ON;
					   
			   #ifdef TRACE_ERROR
			      UART_Transmit_Str("ERR: max try for RFID card > limit \r");	
                  UART_Transmit_Str("ERROR LED is ON \r");				  
			   #endif	
			   
			   milk_vending_parameters.previous_fsm_milk_vending_state = FSM_MILK_VENDING_RFID_SCAN;
			   milk_vending_parameters.cur_fsm_milk_vending_state = FSM_MILK_VENDING_IDLE;
		   }
	    break;
        case FSM_MILK_VENDING_ENTER_PASSWORD:
           if(cur_data_status.cur_data_input_num_try < cur_data_conf_parameter.cur_data_input_max_num_try)
		   {
			   rcvd_status_int = Keyboard_Proc();
			   if(rcvd_status_int != SUCCESS)
			   {
				      ERROR_LED = LED_ON;
					   
				      #ifdef TRACE_ERROR
				        UART_Transmit_Str("ERROR LED is ON \r");
				      #endif	
					  
					  milk_vending_parameters.previous_fsm_milk_vending_state = FSM_MILK_VENDING_ENTER_PASSWORD;
				      milk_vending_parameters.cur_fsm_milk_vending_state = FSM_MILK_VENDING_IDLE;					  
                      break;
		       }
			   if(cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag == STATE_YES || cur_data_status.cur_data_valid_end_rcvd_flag == STATE_YES)
               {
			       if(strcmp(cur_data_status.cur_data_rcvd_str, milk_vending_parameters.cur_milk_customer->customer_rfid_pwd) == 0)
		           {	
                         Write_LCD_Command(0x01);
						 Reset_Parameters();				         
						 Goto_XY_LCD_Disp(CUSTOMER_NAME_DISP_LINE_NUM, NUM_COL1);
                         Data_Str_Disp_LCD("Hi ");						 
						 Data_Str_Disp_LCD(milk_vending_parameters.cur_milk_customer->customer_name);
						 
						 milk_vending_parameters.previous_fsm_milk_vending_state = FSM_MILK_VENDING_ENTER_PASSWORD;
			             milk_vending_parameters.cur_fsm_milk_vending_state = FSM_MILK_VENDING_MILK_PURCHASE;  
						 
						 #ifdef TRACE
			                UART_Transmit_Str("FSM_MILK_VENDING_MILK_PURCHASE state \r");
		                 #endif 
			       }
			       else
			       {
	 			          Write_LCD_Command(0x01);
				          Reset_Cur_Data_Status(CUR_DATA_RESET_STATUS_RETRY);
				          Goto_XY_LCD_Disp(RFID_PWD_MSG_LINE_NUM, NUM_COL1);
				          Data_Str_Disp_LCD("Reenter password");
				          Goto_XY_LCD_Input(RFID_PWD_GET_LINE_NUM, NUM_COL1);
				          Write_LCD_Command(0x0E);				 
				          ++cur_data_status.cur_data_input_num_try;
	               }
		       }
		   }
           else
           {
                ERROR_LED = LED_ON;
			   
			    #ifdef TRACE_ERROR
				     UART_Transmit_Str("ERR: max try for RFID pwd > limit \r"); 
                      UART_Transmit_Str("ERROR LED is ON \r");					 
			    #endif
				
				milk_vending_parameters.previous_fsm_milk_vending_state = FSM_MILK_VENDING_ENTER_PASSWORD;
			    milk_vending_parameters.cur_fsm_milk_vending_state = FSM_MILK_VENDING_IDLE;   
           }
		break;
	    case FSM_MILK_VENDING_MILK_PURCHASE:
		   if(milk_vending_parameters.cur_milk_customer->milk_balance_amount_in_rs >= CONF_CUSTOMER_MIN_BALANCE_AMT_IN_RS + CUSTOMER_MIN_QUANTITY_MILK_AMOUNT_IN_RS)
		   {	
                Write_LCD_Command(0x01);
				Next_Data_Conf_Parameter(CUR_DATA_ID_MILK_QUANTITY, INPUT_DEV_ID_KEYBOARD, OUTPUT_DEV_ID_LCD, MILK_QUANTITY_MAX_NUM_CHARS, \
				         MILK_QUANTITY_INPUT_MAX_NUM_TRY, STATE_NO, RCVD_CHAR_PLAIN_DISP_FORMAT);
				Goto_XY_LCD_Disp(MILK_QUANTITY_MSG_LINE_NUM, NUM_COL1);	 	 
				Data_Str_Disp_LCD("Enter Quantity");
				Goto_XY_LCD_Input(MILK_QUANTITY_GET_LINE_NUM, NUM_COL1);
				Write_LCD_Command(0x0E);				         
		        keyboard_input_enable_flag = STATE_YES;
				backspace_sw_enable_flag = STATE_YES; 
	            enter_sw_enable_flag = STATE_YES;
                milk_vending_parameters.cur_fsm_milk_vending_state = FSM_MILK_VENDING_ENTER_QUANTITY;
				
				#ifdef TRACE
			       UART_Transmit_Str("FSM_MILK_VENDING_ENTER_QUANTITY state \r");
		        #endif 
		   }
		   else
		   {
			    ERROR_LED = LED_ON;
			   
			    #ifdef TRACE_ERROR
				   UART_Transmit_Str("ERROR LED is ON \r");
			       UART_Transmit_Str("ERR: customer id - ");
				   UART_Transmit_Num(DISP_FLAG_NUM_DIGIT5, milk_vending_parameters.cur_milk_customer->milk_customer_id );
				   UART_Transmit_Char(' ');
				   UART_Transmit_Str("for conf min + min qty amt > balance : ");
			       UART_Transmit_Num(DISP_FLAG_NUM_DIGIT5, milk_vending_parameters.cur_milk_customer->milk_balance_amount_in_rs);
				   UART_Transmit_Char(ENTER_CHAR);
			    #endif
				
				milk_vending_parameters.cur_fsm_milk_vending_state = FSM_MILK_VENDING_IDLE;   
		   }
		   milk_vending_parameters.previous_fsm_milk_vending_state = FSM_MILK_VENDING_MILK_PURCHASE;
		break;
		
        case FSM_MILK_VENDING_ENTER_QUANTITY:
           if(cur_data_status.cur_data_input_num_try < cur_data_conf_parameter.cur_data_input_max_num_try)
		   {
	           rcvd_status_int = Keyboard_Proc();
			   if(rcvd_status_int != SUCCESS)
			   {
				   ERROR_LED = LED_ON;
					   
				   #ifdef TRACE_ERROR
				     UART_Transmit_Str("ERROR LED is ON \r");
				   #endif	
				   
				   milk_vending_parameters.previous_fsm_milk_vending_state = FSM_MILK_VENDING_ENTER_QUANTITY;
				   milk_vending_parameters.cur_fsm_milk_vending_state = FSM_MILK_VENDING_IDLE;
                   break;
		       } 
			   if(cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag == STATE_YES || cur_data_status.cur_data_valid_end_rcvd_flag == STATE_YES)
               {
			       rcvd_status_int = Str_to_Num_Conv(cur_data_status.cur_data_rcvd_str, &entered_milk_quantity_in_litre);
                   if(rcvd_status_int == FAILURE || entered_milk_quantity_in_litre == 0 || entered_milk_quantity_in_litre < CUSTOMER_MIN_MILK_QUANTITY_IN_LITRE || entered_milk_quantity_in_litre > CUSTOMER_MAX_MILK_QUANTITY_IN_LITRE || ((entered_milk_quantity_in_litre % CUSTOMER_MIN_MILK_QUANTITY_IN_LITRE) != 0))
				   {	
                       	ERROR_LED = LED_ON;
						
				       #ifdef TRACE_ERROR
					       UART_Transmit_Str("ERR: Invalid milk quantity : ");
						   UART_Transmit_Num(DISP_FLAG_NUM_DIGIT5, entered_milk_quantity_in_litre);
						   UART_Transmit_Char('\r');	
                           UART_Transmit_Str("ERROR LED is ON \r");  						   
				       #endif	
					   
				       Write_LCD_Command(0x01);
				       Reset_Cur_Data_Status(CUR_DATA_RESET_STATUS_RETRY);
				       Goto_XY_LCD_Disp(MILK_QUANTITY_MSG_LINE_NUM, NUM_COL1);
				       Data_Str_Disp_LCD("Reenter quantity");
				       Goto_XY_LCD_Input(MILK_QUANTITY_GET_LINE_NUM, NUM_COL1);
				       Write_LCD_Command(0x0E);				 
				       ++cur_data_status.cur_data_input_num_try;
				   }
				   else
				   {
					   Write_LCD_Command(0x01);
					   Reset_Parameters();
					   amount_to_deduce = (entered_milk_quantity_in_litre / CUSTOMER_MIN_MILK_QUANTITY_IN_LITRE) * CUSTOMER_MIN_QUANTITY_MILK_AMOUNT_IN_RS ;
					   if(milk_vending_parameters.cur_milk_customer->milk_balance_amount_in_rs >= amount_to_deduce + CONF_CUSTOMER_MIN_BALANCE_AMT_IN_RS )
		               {
			               milk_vending_parameters.previous_fsm_milk_vending_state = FSM_MILK_VENDING_ENTER_QUANTITY;
			               milk_vending_parameters.cur_fsm_milk_vending_state = FSM_MILK_VENDING_CHECK_MILK_HEIGHT; 
				
				           #ifdef TRACE
			                  UART_Transmit_Str("FSM_MILK_VENDING_CHECK_MILK_HEIGHT state \r");
		                   #endif 
		               }
					   else
					   {
						   	ERROR_LED = LED_ON;
						
				            #ifdef TRACE_ERROR
					           UART_Transmit_Str("ERR: amt to deduce + conf min > balance : ");
						       UART_Transmit_Num(DISP_FLAG_NUM_DIGIT5, milk_vending_parameters.cur_milk_customer->milk_balance_amount_in_rs);
						       UART_Transmit_Char('\r');	
                               UART_Transmit_Str("ERROR LED is ON \r");  						   
				            #endif	
						    
					   }
				   }
			    }
		    }
		    else
		    {
			   ERROR_LED = LED_ON;
					   
			   #ifdef TRACE_ERROR
			      UART_Transmit_Str("ERR: max try for quantity > limit \r"); 
			      UART_Transmit_Str("ERROR LED is ON \r");
			   #endif
			   
			   milk_vending_parameters.previous_fsm_milk_vending_state = FSM_MILK_VENDING_ENTER_QUANTITY;
			   milk_vending_parameters.cur_fsm_milk_vending_state = FSM_MILK_VENDING_IDLE;
		    }
	    break;
		case FSM_MILK_VENDING_CHECK_MILK_HEIGHT:
		    rcvd_adc_channel_value = ADC_Start_Conv(ADC_POLLING_SERVICE, ADC_CLK_SRC_OSC_32, ADC_CHANNEL_SEL, CONTAINER_MILK_HEIGHT_CH0, ADC_RESULT_RIGHT_FMT, ADC_VREF_NEG_SRC_EXTR, ADC_VREF_PLUS_SRC_EXTR); 
			analog_val_in_digital_ch[0] = rcvd_adc_channel_value;
	        Encoded_To_Actual_Analog_Val_Calc(analog_val_in_digital_ch[0], FULL_SCALE_ANALOG_VAL_CH0, MIN_ANALOG_VALUE_CH0,\
		            &analog_val_in_digital_int_ch[0], &analog_val_in_digital_frac_ch[0] );
		    UART_Transmit_Str("ADC Channel 0 Output : "); 
	        //Goto_XY_LCD_Disp(SIGCH0_LINE_NUM, NUM_COL1);
	        UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, analog_val_in_digital_int_ch[0]);
		    UART_Transmit_Char('.');
	        //Goto_XY_LCD_Disp(SIGCH0_LINE_NUM, SIGNAL_FRAC_COL_NUM);
	        UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, analog_val_in_digital_frac_ch[0]);
		    UART_Transmit_Str("V , ");
		  
	        Encoded_To_Percent_Calc(analog_val_in_digital_ch[0], &percent_int_ch[0], &percent_frac_ch[0] );
	         //Goto_XY_LCD_Disp(SIGCH0_LINE_NUM, PERCENT_INT_COL_NUM);
	        UART_Transmit_Num(DISP_FLAG_NUM_DIGIT3, percent_int_ch[0] );
		    UART_Transmit_Char('.');
	         //Goto_XY_LCD_Disp(SIGCH0_LINE_NUM, PERCENT_FRAC_COL_NUM);
	        UART_Transmit_Num(DISP_FLAG_NUM_DIGIT1, percent_frac_ch[0] );			
		    UART_Transmit_Str("% \r");
		    if(rcvd_adc_channel_value < CONF_MILK_LOW_LIMIT_HEIGHT_MILK_CONTAINER_ENCODED_VAL )
			{
                 ERROR_LED = LED_ON;
			     milk_vending_parameters.vending_status = STATUS_MILK_LOW_HEIGHT;
				 
			    #ifdef TRACE_ERROR
			      UART_Transmit_Str("ERR: milk level < conf milk low level \r"); 
			      UART_Transmit_Str("ERROR LED is ON \r");
			    #endif					
				
			    milk_vending_parameters.cur_fsm_milk_vending_state = FSM_MILK_VENDING_INTIMATE_MANAGER; 
				milk_vending_parameters.previous_fsm_milk_vending_state = FSM_MILK_VENDING_CHECK_MILK_HEIGHT;	
				
				#ifdef TRACE
			      UART_Transmit_Str("FSM_MILK_VENDING_INTIMATE_MANAGER state \r");
		        #endif
				
				break;
			}		
			if( rcvd_adc_channel_value > CONF_MILK_HIGH_LIMIT_HEIGHT_MILK_CONTAINER_ENCODED_VAL )
			{
				ERROR_LED = LED_ON;
			    milk_vending_parameters.vending_status = STATUS_MILK_HIGH_HEIGHT;
				
			    #ifdef TRACE_ERROR
			      UART_Transmit_Str("ERR: milk level > conf milk high limit \r"); 
			      UART_Transmit_Str("ERROR LED is ON \r");
			    #endif
				
				milk_vending_parameters.cur_fsm_milk_vending_state = FSM_MILK_VENDING_INTIMATE_MANAGER;
				milk_vending_parameters.previous_fsm_milk_vending_state = FSM_MILK_VENDING_CHECK_MILK_HEIGHT;	
				
				#ifdef TRACE
			      UART_Transmit_Str("FSM_MILK_VENDING_INTIMATE_MANAGER state \r");
		        #endif
				
				break;
			}
            switch( milk_vending_parameters.previous_fsm_milk_vending_state)
			{
				case FSM_MILK_VENDING_ENTER_QUANTITY:
				    Encoded_To_Actual_Analog_Val_Calc(analog_val_in_digital_ch[0], MILK_CONTAINER_NETT_CAPACITY_IN_LITRE, 0,\
		                   &analog_val_in_digital_int_ch[0], &analog_val_in_digital_frac_ch[0]);
					milk_vending_parameters.container_milk_available_in_litre = analog_val_in_digital_int_ch[0];	   
					if(milk_vending_parameters.container_milk_available_in_litre >= entered_milk_quantity_in_litre + CONF_CONTAINER_LOW_LIMIT_MILK_QUANTITY_IN_LITRE)
					{
						milk_vending_parameters.cur_fsm_milk_vending_state = FSM_MILK_VENDING_DETECT_MILK_VESSEL;
						
                        #ifdef TRACE
			                UART_Transmit_Str("FSM_MILK_VENDING_DETECT_MILK_VESSEL state \r");
		                #endif 						
					}
					else
					{
						ERROR_LED = LED_ON;
						
						#ifdef TRACE_ERROR
				           UART_Transmit_Str("ERROR LED is ON \r");
				        #endif
						
					    if(milk_vending_parameters.container_milk_available_in_litre  >= entered_milk_quantity_in_litre + CONF_CONTAINER_RESERVE_LOW_LIMIT_MILK_QUANTITY_IN_LITRE)
						{	
				            #ifdef TRACE_ERROR
				               UART_Transmit_Str("ERR: Milk to be drained some in reserve\r");
						    #endif
							
						    milk_vending_parameters.vending_status =  STATUS_MILK_RESERVE;
						    milk_vending_parameters.cur_fsm_milk_vending_state = FSM_MILK_VENDING_DETECT_MILK_VESSEL;
						
                            #ifdef TRACE
			                   UART_Transmit_Str("FSM_MILK_VENDING_DETECT_MILK_VESSEL state \r");
		                    #endif
						   						   
				        }
						else
						{	
					       
                           #ifdef TRACE_ERROR
				              UART_Transmit_Str("ERR: avail qty - ");
				              UART_Transmit_Num(DISP_FLAG_NUM_DIGIT5,milk_vending_parameters.container_milk_available_in_litre );
							  UART_Transmit_Str(" , reserve + entered qty : ");
							  UART_Transmit_Num(DISP_FLAG_NUM_DIGIT5, entered_milk_quantity_in_litre + CONF_CONTAINER_RESERVE_LOW_LIMIT_MILK_QUANTITY_IN_LITRE);
						      UART_Transmit_Char('\r');	
						   #endif	 
						   
				           milk_vending_parameters.cur_fsm_milk_vending_state = FSM_MILK_VENDING_IDLE;
						}
					}
				break;
                default:
				   ERROR_LED = LED_ON;
					   
				   #ifdef TRACE_ERROR
				      UART_Transmit_Str("ERR: invalid previous fsm state in check height \r"); 
				      UART_Transmit_Str("ERROR LED is ON \r");
				   #endif
				  
				   milk_vending_parameters.cur_fsm_milk_vending_state = FSM_MILK_VENDING_IDLE;
			}
            milk_vending_parameters.previous_fsm_milk_vending_state = FSM_MILK_VENDING_CHECK_MILK_HEIGHT;		
		break;
		case FSM_MILK_VENDING_DETECT_MILK_VESSEL:		 
           	while(milk_vending_parameters.vending_status != STATUS_MILK_VESSEL_DETECTED)
	    	{
		        if(VESSEL_DETECT_SW == KEY_PRESSED )
                {
                     while(VESSEL_DETECT_SW == KEY_PRESSED );
                     milk_vending_parameters.vending_status = STATUS_MILK_VESSEL_DETECTED;					 
                     timer1_run_time = (entered_milk_quantity_in_litre / CUSTOMER_MIN_MILK_QUANTITY_IN_LITRE) * REQ_TIME_CUSTOMER_MIN_MILK_QUANTITY_DRAIN_IN_MILLI_SEC ;                  
					 MILK_DRAIN_VALVE = STATE_ON;
                     MILK_DRAINING_LED = LED_ON;
                     Timer1_Run(TMR1_MILK_DRAINING_STATE, timer1_run_time, TMR1_INTP_SERVICE, TMR1_GATE_CTRL_DISABLE, TMR1_INPUT_CLK_PRESCALE_8, TMR1_LP_OSC_DISABLE, TMR1_CLK_SRC_INTR_OSC);
                }
		    }
		    milk_vending_parameters.previous_fsm_milk_vending_state = FSM_MILK_VENDING_DETECT_MILK_VESSEL;
		    milk_vending_parameters.cur_fsm_milk_vending_state = FSM_MILK_VENDING_DRAINING_MILK;
			
			#ifdef TRACE
			      UART_Transmit_Str("FSM_MILK_VENDING_DRAINING_MILK state \r");
		    #endif
			
        break;
        case FSM_MILK_VENDING_DRAINING_MILK:
          	 while(milk_vending_parameters.vending_status != STATUS_MILK_DRAINED);
             MILK_DRAIN_VALVE = STATE_OFF;
             MILK_DRAINING_LED = LED_OFF; 
			 milk_vending_parameters.previous_fsm_milk_vending_state = FSM_MILK_VENDING_DRAINING_MILK;
             milk_vending_parameters.cur_fsm_milk_vending_state = FSM_MILK_VENDING_DEDUCE_BALANCE;
			 
        	#ifdef TRACE
			      UART_Transmit_Str("FSM_MILK_VENDING_DEDUCE_BALANCE state \r");
		    #endif		
			
        break;
		case FSM_MILK_VENDING_DEDUCE_BALANCE:
            // rcvd_adc_channel_value in milli litre = data calculated from milk flow sensor for simulation purpose, rcvd_adc_channel_value is fixed
		    rcvd_adc_channel_value = entered_milk_quantity_in_litre	* QUANTITY_1_LITRE_IN_MILLI_LITRE;		
		    if(rcvd_adc_channel_value <  entered_milk_quantity_in_litre * QUANTITY_1_LITRE_IN_MILLI_LITRE - TOLERANCE_LIMIT_MILK_QUANTITY_IN_MILLI_LITRE)
			{
                 ERROR_LED = LED_ON;
			     milk_vending_parameters.vending_status = STATUS_MILK_DRAINED_LOW;
				 
			    #ifdef TRACE_ERROR
			      UART_Transmit_Str("ERR: milk drained < entered milk qty + tolerance \r"); 
			      UART_Transmit_Str("ERROR LED is ON \r");
			    #endif					
				
			    milk_vending_parameters.cur_fsm_milk_vending_state = FSM_MILK_VENDING_INTIMATE_MANAGER; 
				milk_vending_parameters.previous_fsm_milk_vending_state = FSM_MILK_VENDING_DEDUCE_BALANCE;	
				
				#ifdef TRACE
			      UART_Transmit_Str("FSM_MILK_VENDING_INTIMATE_MANAGER state \r");
		        #endif	
				
				break;
			}		
			if( rcvd_adc_channel_value > entered_milk_quantity_in_litre * QUANTITY_1_LITRE_IN_MILLI_LITRE + TOLERANCE_LIMIT_MILK_QUANTITY_IN_MILLI_LITRE )
			{
				ERROR_LED = LED_ON;
			    milk_vending_parameters.vending_status = STATUS_MILK_DRAINED_HIGH;
				
			    #ifdef TRACE_ERROR
			      UART_Transmit_Str("ERR: milk drained > entered milk qty + tolerance \r"); 
			      UART_Transmit_Str("ERROR LED is ON \r");
			    #endif
				
				milk_vending_parameters.cur_fsm_milk_vending_state = FSM_MILK_VENDING_INTIMATE_MANAGER;
				milk_vending_parameters.previous_fsm_milk_vending_state = FSM_MILK_VENDING_DEDUCE_BALANCE;
				
				#ifdef TRACE
			      UART_Transmit_Str("FSM_MILK_VENDING_INTIMATE_MANAGER state \r");
		        #endif
				
				break;
			}
            milk_vending_parameters.cur_milk_customer->milk_balance_amount_in_rs -= amount_to_deduce;
            
            milk_vending_parameters.cur_fsm_milk_vending_state = FSM_MILK_VENDING_INTIMATE_CUSTOMER;
			milk_vending_parameters.previous_fsm_milk_vending_state = FSM_MILK_VENDING_DEDUCE_BALANCE;	

           	#ifdef TRACE
			   UART_Transmit_Str("FSM_MILK_VENDING_INTIMATE_CUSTOMER state \r");
		    #endif		
			
		break;
        case FSM_MILK_VENDING_INTIMATE_CUSTOMER:
		   strcpy(to_transmit_sms_info,  "deducted Rs ");
		   rcvd_status_int = Num_to_Str_Conv(amount_to_deduce, 3, DATA_IN_DECIMAL_FORMAT, ' ', deduced_amt_str);
		   if(rcvd_status_int != SUCCESS)
		   {
			   ERROR_LED = LED_ON;
					   
			   #ifdef TRACE_ERROR
				   UART_Transmit_Str("ERROR LED is ON \r");
			   #endif
			   
			   milk_vending_parameters.previous_fsm_milk_vending_state = FSM_MILK_VENDING_INTIMATE_CUSTOMER;  
			   milk_vending_parameters.cur_fsm_milk_vending_state = FSM_MILK_VENDING_IDLE;
			   break;
		   }
		   strcat(to_transmit_sms_info, deduced_amt_str);
		   strcat(to_transmit_sms_info, "\nQuantity - ");
		   rcvd_status_int = Num_to_Str_Conv(entered_milk_quantity_in_litre, 3, DATA_IN_DECIMAL_FORMAT, ' ', quantity_purchased_str );
		   strcat(to_transmit_sms_info, quantity_purchased_str);
		   strcat(to_transmit_sms_info, " L \nBalance Rs ");
		   rcvd_status_int = Num_to_Str_Conv(milk_vending_parameters.cur_milk_customer->milk_balance_amount_in_rs, 3, DATA_IN_DECIMAL_FORMAT, ' ', balance_amt_str );
		   strcat(to_transmit_sms_info, balance_amt_str);
           GSM_Transmit_SMS(milk_vending_parameters.cur_milk_customer->customer_mobile_num, to_transmit_sms_info);
		   PROCESS_OVER_LED = LED_ON;
		   
		   #ifdef TRACE
		       UART_Transmit_Str("PROCESS OVER is ON \r");
		   #endif
		   
		   milk_vending_parameters.previous_fsm_milk_vending_state = FSM_MILK_VENDING_INTIMATE_CUSTOMER;	
           milk_vending_parameters.cur_fsm_milk_vending_state= FSM_MILK_VENDING_IDLE;
        break;
		case FSM_MILK_VENDING_INTIMATE_MANAGER:
		   switch(milk_vending_parameters.vending_status)
		   {
			   case STATUS_MILK_LOW_HEIGHT:
			      strcpy(to_transmit_sms_info,"WARN: milk height low\n");
			   break;
               case STATUS_MILK_HIGH_HEIGHT:
			      strcpy(to_transmit_sms_info,"WARN: milk height high\n");
			   break;
               case STATUS_MILK_RESERVE:
			      strcpy(to_transmit_sms_info,"WARN: milk height Reserve\n");
			   break;
			   case STATUS_MILK_DRAINED_LOW:
			      strcpy(to_transmit_sms_info,"WARN: milk drained low\n");
			   break;
			   case STATUS_MILK_DRAINED_HIGH:
			      strcpy(to_transmit_sms_info,"WARN: milk drained high\n");
			   break;
		   }
		   GSM_Transmit_SMS(milk_vending_parameters.manager_mobile_num, to_transmit_sms_info);
			
		   milk_vending_parameters.previous_fsm_milk_vending_state = FSM_MILK_VENDING_INTIMATE_MANAGER;	   
           milk_vending_parameters.cur_fsm_milk_vending_state= FSM_MILK_VENDING_IDLE;
        break;
    }   
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void Reset_Parameters()
{
	Reset_Cur_Data_Status(CUR_DATA_RESET_STATUS_WHOLE);
    Reset_Keyboard_Parameters();
	Reset_UART_Parameters();
	//memset(lcd_const_disp_flag, STATE_NO, sizeof(lcd_const_disp_flag)/ sizeof(char));	
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void Reset_Cur_Data_Status(cur_data_status_reset_types set_cur_data_status_reset_type)
{
	switch(set_cur_data_status_reset_type)
	{
		case CUR_DATA_RESET_STATUS_WHOLE:
		  cur_data_status.cur_data_id = CUR_DATA_ID_INVALID;
	      cur_data_conf_parameter.cur_data_id = CUR_DATA_ID_INVALID;
		  cur_data_status.cur_data_input_num_try = 0;
		break;  
	}
	memset(cur_data_status.cur_data_rcvd_str, NULL_CHAR, sizeof(cur_data_status.cur_data_rcvd_str)/sizeof(char));
	cur_data_status.cur_data_num_chars_rcvd = 0;
	cur_data_status.cur_data_valid_end_rcvd_flag = STATE_NO;
	cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag = STATE_NO;
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
int Next_Data_Conf_Parameter(const cur_data_id_types set_next_data_id, const input_dev_id_types set_next_data_input_dev_id, const output_dev_id_types set_next_data_output_dev_id, \
 const unsigned int set_next_data_max_num_chars_to_rcv, const unsigned int set_next_data_input_max_num_try, const char set_next_data_input_can_also_nonnum_key, \
 const rcvd_char_disp_format_types set_next_data_rcvd_char_disp_format)
{
	if(set_next_data_max_num_chars_to_rcv == CHARS_RCV_TILL_TERMINATOR_CHAR_MODE)
	{
		cur_data_conf_parameter.cur_data_rcv_mode = CUR_DATA_RCV_MODE_TILL_TERMINATOR;
		cur_data_conf_parameter.cur_data_allocated_max_num_chars_to_rcv = DATA_MAX_NUM_ALLOCATED_CHARS;
		cur_data_conf_parameter.cur_data_conf_max_num_chars_to_rcv = DATA_MAX_NUM_ALLOCATED_CHARS;
	}
	else
	{
		if(set_next_data_max_num_chars_to_rcv <= DATA_MAX_NUM_ALLOCATED_CHARS)
		{
		   cur_data_conf_parameter.cur_data_rcv_mode = CUR_DATA_RCV_MODE_TILL_ALLOCATED;
		   cur_data_conf_parameter.cur_data_allocated_max_num_chars_to_rcv = set_next_data_max_num_chars_to_rcv;
		   cur_data_conf_parameter.cur_data_conf_max_num_chars_to_rcv = set_next_data_max_num_chars_to_rcv;
		}
	    else
		{
			#ifdef TRACE_ERROR
			    UART_Transmit_Str("ERR: set max chars to enter > configured \r");
			#endif
			return FAILURE;
		}
	}
    cur_data_status.cur_data_id = set_next_data_id;
    cur_data_conf_parameter.cur_data_id = set_next_data_id;
	cur_data_conf_parameter.cur_data_input_dev_id = set_next_data_input_dev_id;
	cur_data_conf_parameter.cur_data_output_dev_id = set_next_data_output_dev_id;
	cur_data_conf_parameter.cur_data_input_max_num_try = set_next_data_input_max_num_try;
	cur_data_conf_parameter.cur_data_input_can_also_nonnum_key = set_next_data_input_can_also_nonnum_key;
	cur_data_conf_parameter.cur_data_rcvd_char_disp_format = set_next_data_rcvd_char_disp_format;
    return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
int Str_to_Num_Conv(const char *const num_in_str, unsigned long int *num_conv_from_str )
{
	 unsigned long int num = 0, place = 1;
	 int cur_unit;
	 unsigned int num_chars = 0, cur_digit= 0, ten = 10, pos = 0;
	 
	 num_chars = Str_Len(num_in_str);
     place = 1;
     pos = num_chars - 1;
     cur_unit = num_in_str[pos] - ZERO_CHAR;
	 if(cur_unit < 0 ||  cur_unit > 9 )
	 {
		 #ifdef TRACE_ERROR
		    UART_Transmit_Str("ERR: 1: Non numeric char in str_to_num\r");
		 #endif
		 *num_conv_from_str = 0; 
		 return FAILURE;
	 }	
     num = place * cur_unit;
     for(cur_digit = 1; cur_digit < num_chars; ++cur_digit)
     {
         place =  place * ten;
         pos = num_chars - 1 - cur_digit;
         cur_unit = num_in_str[pos] - ZERO_CHAR;
	     if(cur_unit < 0 ||  cur_unit > 9 )
	     {
			 #ifdef TRACE_ERROR
		       UART_Transmit_Str("ERR: 2: Non numeric char in str_to_num \r");
		     #endif
			  *num_conv_from_str = 0;
			 return FAILURE;
		 }			 
         num += (cur_unit * place);     
     }
	 *num_conv_from_str = num; 
     return SUCCESS;
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
unsigned int Str_Len(const char *const str)
{
    unsigned int num_chars = 0;
	
    while(*(str + num_chars++));
    return num_chars - 1;
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
int Num_to_Str_Conv(const int num_to_conv_str, const unsigned int min_num_digits_in_num_str, data_format_types cur_data_format, const char disp_sign_flag, char *num_in_str)
{
	char num_data[] ={'0','1','2','3','4','5','6','7','8','9'};  
	char hex_data[] ={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'}; 
	char sign_flag, first_non_zero_digit_flag = 'n';
	unsigned int cur_digit, place_val, cur_num_digits_left, num_in_str_index = 1;
    int num = num_to_conv_str;
	
	switch(cur_data_format)
	{
		case DATA_IN_DECIMAL_FORMAT:
		  place_val = 10000U;
		  cur_num_digits_left = 5; 
		  while(cur_num_digits_left > 0 )
		  {
			   cur_digit = (num / place_val);
			   if(cur_num_digits_left <= min_num_digits_in_num_str)
			   {   
		          num_in_str[num_in_str_index] = (num_data[cur_digit]); 				  
				  ++num_in_str_index;
			   }
			   else
			   {
				  if(first_non_zero_digit_flag == STATE_NO && cur_digit != 0 )
			      {
				     first_non_zero_digit_flag = STATE_YES;					 
			      }	
                  if(first_non_zero_digit_flag == STATE_YES)
				  {		
                      num_in_str[num_in_str_index] = (num_data[cur_digit]);
					   ++num_in_str_index;
				  }
			   }			  
			  --cur_num_digits_left;
			  num = num_to_conv_str % place_val;
			  place_val /= 10;
		  }			  
		break;
		case DATA_IN_HEXA_FORMAT:
		  place_val = 16 * 16 * 16;
		  cur_num_digits_left = 4; 
		  while(cur_num_digits_left > 0 )
	      {
	          cur_digit = (num / place_val);
	          if(cur_num_digits_left <= min_num_digits_in_num_str)
			  {
				  num_in_str[ num_in_str_index] = (hex_data[cur_digit]); 
				  ++num_in_str_index;
			  }
	          else
	          {
		          if(first_non_zero_digit_flag == STATE_NO && cur_digit != 0 )
			      {
					 first_non_zero_digit_flag = STATE_YES;
			      }	
                  if(first_non_zero_digit_flag == STATE_YES)
				  {					  
				      num_in_str[ num_in_str_index] = (hex_data[cur_digit]); 
					  ++num_in_str_index;
				  }
			  }			  
			  --cur_num_digits_left;
			  num = num_to_conv_str % place_val;
			  place_val /= 16;
		  }	
		break;
		default:
		   #ifdef TRACE_ERROR
		      UART_Transmit_Str("ERR: num to str invalid data in format \r");
		   #endif 	
		   
		   num_in_str[0] = NULL_CHAR; 
		  return FAILURE;
	}
	switch(disp_sign_flag)
	{
		case 'y':
		  if(num_to_conv_str > 0)
			num_in_str[0] = '+';
		 else if (num_to_conv_str < 0) 
            num_in_str[0] = '-';
         else // 0
           num_in_str[0] = ' '; 
		break;
		default:
		  num_in_str[0] = disp_sign_flag;
	}
	num_in_str[num_in_str_index] = NULL_CHAR;	
	return SUCCESS;
}

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
