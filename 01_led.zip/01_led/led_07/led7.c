/* ********************************************************************
FILE                   : led7.c

PROGRAM DESCRIPTION    :                 									 
	 
AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
 
USED                  :             
            Desktop OS: Windows 7 Professional (32 bit) (Intel x64)
                   IDE: Developed by using Microchip's MPLAB IDE v8.6 
                   CAD: Simulated and tested in Proteus 8.0 Professional.                    
                       
CHANGE LOGS           : 

DISCLAIMER            :

*****************************************************************************/

#include   <pic.h>
void delay_time(unsigned int );
void main()
{
        int i= 0;
         PORTA = 0x00;
         TRISA = 0x00;
         ANSEL = 0x00;
        ANSELH = 0x00;
       while(1)
       {
          for(i = 0; i < 9;++i)
         {
             PORTA = 1 << i ;
             delay_time(1000);
         }
         for(i = 0;i<9;++i)
        {
              PORTA =  0X80    >> i;
              delay_time(1000);                                                                           
        }
        }
     return ;
}
void delay_time(unsigned int time)
{
      int i = 0, j = 0;
      for(i =0; i < time; ++i)
           for(j =0; j < 100; ++j);
     return;
}
