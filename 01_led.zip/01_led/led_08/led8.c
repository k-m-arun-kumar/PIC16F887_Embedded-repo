/* ********************************************************************
FILE                   : led8.c

PROGRAM DESCRIPTION    :                 									 
	 
AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
 
USED:              IDE: Developed by using Microchip's MPLAB IDE v8.6 
                   CAD: Simulated in Proteus 8.0 Professional 
                   HW : Tested in PIC development board by www.alselectro.com 
		    Programmer: PICkit 3 
                       
CHANGE LOGS           : 

*****************************************************************************/

#include   <pic.h>
#define _XTAL_FREQ (4000000)
__CONFIG(0X2CE4);
void delay_time(unsigned int );
void main()
{
        int i= 0;
         unsigned int mask =   0x00;               
         PORTA = 0x00;
         TRISA = 0x00;
         ANSEL = 0x00;
        ANSELH = 0x00;
        __delay_ms(300);
       while(1)
       {
          for(i = 0; i < 4;++i)
         {
             PORTA = PORTA | (0x01 << i) ;
             __delay_ms(3000);
         }
         for(i = 1;i < 5;++i)
        {
              PORTA =  PORTA  & (0x0F  >> i);
              __delay_ms(3000);                                                                           
        }
        }
     return ;
}
void delay_time(unsigned int time)
{
      int i = 0, j = 0;
      for(i =0; i < time; ++i)
           for(j =0; j < 100; ++j);
     return;
}
