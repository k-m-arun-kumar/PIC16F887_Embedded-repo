/* ********************************************************************
FILE                   : led9.c

PROGRAM DESCRIPTION    :                 									 
	 
AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
 
USED:              IDE: Developed by using Microchip's MPLAB IDE V8.6
                   CAD: Simulated in Proteus 8.0 Professional 
                   HW : Tested in PIC development board by www.alselectro.com 
		    Programmer: PICkit 3 
                       
CHANGE LOGS           : 

*****************************************************************************/
#include   <pic.h>
void delay_time(unsigned int );
void main()
{
        int i= 0;
         unsigned int mask =   0x00;               
         PORTA = 0x00;
         TRISA = 0x00;
         ANSEL = 0x00;
        ANSELH = 0x00;
       while(1)
       {
          for(i = 0; i < 4;++i)
         {
             PORTA =  0x01 << i ;
             PORTA = PORTA |  0x80 >> i;
             delay_time(1000);
         }
         PORTA = 0x00;
        delay_time(1000);
         for(i = 0;i<4;++i)
        {
              PORTA = 0x10 << i ;
              PORTA = PORTA |  0x08 >> i; 
              delay_time(1000);                                                                           
        }
       PORTA = 0x00;
       delay_time(1000);
        }
     return ;
}
void delay_time(unsigned int time)
{
      int i = 0, j = 0;
      for(i =0; i < time; ++i)
           for(j =0; j < 100; ++j);
     return;
}
