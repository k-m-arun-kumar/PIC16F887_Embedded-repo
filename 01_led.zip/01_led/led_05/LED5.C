/* ********************************************************************
FILE                   : LED5.c

PROGRAM DESCRIPTION    :                 									 
	 
AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
 
USED:             
            Desktop OS: Windows 7 Professional (32 bit) (Intel X64)
                   IDE: Developed by using Microchip's MPLAB IDE v8.6
                   CADD: Simulated in Proteus 8.0 Professional                    
                       
CHANGE LOGS           : 

*****************************************************************************/
#include <pic.h>
void delay_time(unsigned int );
void main()
{
        int i= 0, j,arr[] = {0x00,0x01,0x03,0x07, 0x0F, 0x1F,0x3F,0x7F,0xFF,0x7F,0x3F, 0x1F, 0x0F, 0x07, 0x03, 0x01 };
         PORTA = 0x00;
         TRISA = 0x00;
         ANSEL = 0x00;
        ANSELH = 0x00;
       j = sizeof(arr)/sizeof(int);
        while(1)
       {
          for(i = 0; i < j;++i)
         {
             PORTA = arr[i] ;
             delay_time(1000);
         }
        }
     return ;
}
void delay_time(unsigned int time)
{
      int i = 0, j = 0;
      for(i =0; i < time; ++i)
           for(j =0; j < 100; ++j);
     return;
}
