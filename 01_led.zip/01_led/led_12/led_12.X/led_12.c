/* ********************************************************************
FILE                   : led_12.c

PROGRAM DESCRIPTION    :                 									 
	 
AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
 
USED:              IDE: Developed by using Microchip's MPLAB X IDE 
              Compiler: MPLAB XC8 compiler.  
                   CADD: Simulated in Proteus 8.3 Professional                   
                       
CHANGE LOGS           : 

*****************************************************************************/

#include   <xc.h>

/* refer corresponding pic uC's data sheet or header file in compiler's folder name as include. In our case, refer in pic16f887 data sheet or xc8 compiler's folder name include, 
   find pic16f887.h or if file exist, pic16f887_legacy.h .
   In pic16f887 data sheet or pic16f887.h, 0x0085 (file address in Special function registers)is location in register address of TRISA and 
   0x0005(file address in Special function registers) is location in register address of PORTA. */

#define LED_TRIS_PINS_ADDR                (0x0085)
#define _XTAL_FREQ                        (4000000)
typedef union 
{
	 unsigned int tris_byte;
	 struct tris_pin
	 {
		 unsigned int tris_pin_0: 1;
		 unsigned int tris_pin_1: 1;
		 unsigned int tris_pin_2: 1;
		 unsigned int tris_pin_3: 1;
		 unsigned int tris_pin_4: 1;
		 unsigned int tris_pin_5: 1;
		 unsigned int tris_pin_6: 1;
		 unsigned int tris_pin_7: 1;
	 } tris_pins;
} LED_TRIS_PINS;

volatile LED_TRIS_PINS *LED_TRIS  = (LED_TRIS_PINS *) LED_TRIS_PINS_ADDR;

typedef union 
{
	 unsigned int port_byte;
	 struct port_pin
	 {
		 unsigned int port_pin_0: 1;
		 unsigned int port_pin_1: 1;
		 unsigned int port_pin_2: 1;
		 unsigned int port_pin_3: 1;
		 unsigned int port_pin_4: 1;
		 unsigned int port_pin_5: 1;
		 unsigned int port_pin_6: 1;
		 unsigned int port_pin_7: 1;
	 } port_pins;
} LED_PORT_PINS;

volatile LED_PORT_PINS *LED_PORT  = (LED_PORT_PINS *) (LED_TRIS_PINS_ADDR & 0x000F);
	
void delay_time(unsigned int );
void main()
{
	unsigned int i;  
	
	LED_TRIS->tris_byte = 0x00;
	LED_PORT->port_byte = 0x00;
	
	ANSEL = 0x00;
    ANSELH = 0x00;
    __delay_ms(300);
	
    while(1)
    { 
        for(i=0;i<8;i++)
        {
           LED_PORT->port_byte  = 0x01 << i;
           __delay_ms(3000); 
		}		   
    }
}       
void delay_time(unsigned int time)
{
      int i = 0, j = 0;
      for(i =0; i < time; ++i)
           for(j =0; j < 100; ++j);
     return;
}
