/* ********************************************************************
FILE                   : LED3.c

PROGRAM DESCRIPTION    :                 									 
	 
AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
 
USED:          

            Desktop OS: Windows 7 Professional (32 bit) (Intel X64)
                   IDE: Developed by using Microchip's MPLAB IDE v8.6
                   CADD: Simulated in Proteus 8.0 Professional 
                   HW : Tested OK in PIC development board by www.alselectro.com 
		    Programmer: PICkit 3 
                       
CHANGE LOGS           : 

*****************************************************************************/
#include <pic.h>
#define _XTAL_FREQ (4000000)
__CONFIG(0X2CE4);
int i;
void delay_time(unsigned int);
void main()
{
     TRISA = 0x00; 
     PORTA = 0x00;
   
     ANSEL = 0x00;
     ANSELH = 0x00;
     __delay_ms(300);
     while(1)
    { 
for(i=0;i<4;i++)
{
PORTA=0x01<<i;
 __delay_ms(3000);  
}

 
}
}

void delay_time(unsigned int time_delay)
{
     int i = 0, j=0;
      for(i = 0; i < time_delay; ++i)
           for(j =0; j < 100; ++j);
     return;
}
