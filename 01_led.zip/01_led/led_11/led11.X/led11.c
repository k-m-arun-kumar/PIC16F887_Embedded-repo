/* ********************************************************************
FILE                   : led11.c

PROGRAM DESCRIPTION    :                 									 
	 
AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
 
USED:              IDE: Developed by using Microchip's MPLAB X IDE 
              Compiler: mplab xc8 compiler.  
                   CADD: Simulated in Proteus 8.3 Professional                   
                       
CHANGE LOGS           : 

*****************************************************************************/
#include   <pic.h>
void delay_time(unsigned int );
void main()
{
        unsigned int i= 0;
         TRISA = 0x00;      
         PORTA = 0x00;
         
         ANSEL = 0x00;
        ANSELH = 0x00;
       while(1)
       {
          for(i = 0; i < 8;++i)
         {
             PORTA =  PORTA| 0x01u << i ;           
             delay_time(1000);
         }
        PORTA = 0x00;
        delay_time(1000);        
      }
     return ;
}
void delay_time(unsigned int time)
{
      unsigned int i = 0, j = 0;
      for(i =0; i < time; ++i)
           for(j =0; j < 100; ++j);
     return;
}
