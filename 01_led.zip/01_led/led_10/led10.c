/* ********************************************************************
FILE                   : led10.c

PROGRAM DESCRIPTION    :                 									 
	 
AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
 
USED:              IDE: Developed by using Microchip's MPLAB IDE v8.6
                   CAD: Simulated in Proteus 8.0 Professional 
                  
                       
CHANGE LOGS           : 

*****************************************************************************/

#include   <pic.h>
void delay_time(unsigned int );
void main()
{
        int i= 0;
         unsigned int temp;            
         PORTA = 0x00;
         TRISA = 0x00;
         ANSEL = 0x00;
        ANSELH = 0x00;
       while(1)
       {
          for(i = 0; i < 4;++i)
         {
             PORTA =  PORTA| 0x01 << i ;
             PORTA = PORTA |  0x80 >> i;
             delay_time(1000);
         }
         for(i = 1;i<4;++i)
        {
            // temp has lower nibble of PORTA
              temp = PORTA & 0x0F;
              PORTA = PORTA & 0xF0 << i ;
              PORTA = PORTA   | (temp &  0x0F >> i); 
              delay_time(1000);                                                                           
        }
          PORTA = 0x00;
          delay_time(1000);        
      }
     return ;
}
void delay_time(unsigned int time)
{
      int i = 0, j = 0;
      for(i =0; i < time; ++i)
           for(j =0; j < 100; ++j);
     return;
}
