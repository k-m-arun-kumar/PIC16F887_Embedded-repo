/* ********************************************************************
FILE                   : LED2.c

PROGRAM DESCRIPTION    : 2 LEDs blinking               									 
	 
AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
 
USED:              
            Desktop OS: Windows 7 Professional (32 bit) (X64)       
     			   IDE: Developed by using Microchip's MPLAB IDE v8.6
                   CADD: Simulated in Proteus 8.0 Professional 
                   HW : Tested OK in PIC development board by www.alselectro.com 
		    Programmer: PICkit 3 
                       
CHANGE LOGS           : 

*****************************************************************************/
#include <pic.h>
#define LED1 RA0
#define LED2 RA1
#define _XTAL_FREQ (4000000)
__CONFIG(0X2CE4);
void delay_time(unsigned int );
void main()
{
       TRISA  = 0x00;    
      PORTA = 0x00;
     
      ANSEL = 0x00;
     ANSELH = 0x00;
	 __delay_ms(300);
     while(1)
    {
            LED1=1;
            __delay_ms(4000);
            LED1= 0;
            LED2 =1;
            __delay_ms(4000);
            LED2=0;          
    }
   return;
}

void delay_time(unsigned int time_delay)
{
        int i = 0, j=0;
        for (i=0; i < time_delay; ++i)
              for(j =0; j < 100; ++j);
       return;
}
