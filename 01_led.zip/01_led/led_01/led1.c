/* ********************************************************************
FILE                   : led1.c

PROGRAM DESCRIPTION    :  1 LED blinking                     									 
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran

LAST CODED DATE       : 16th March 2018
	 
KNOWN BUGS            : 

NOTE                  : 

Hardware Tools and Software tools used are:             
            Desktop OS: Windows 7 Professional (32 bit) (desktop motherboard of Intel X64)        
 				   IDE: Developed by using Microchip's MPLAB IDE v8.6 
			  Compiler: Hi-Tech C Compiler.	   
                   CADD: Simulated and tested OK in Proteus 8.0 Professional 
                   HW : Tested OK in PIC development board by www.alselectro.com 
		    Programmer: PICkit 3  
			
			
CHANGE LOGS           : 

*****************************************************************************/
#include <pic.h>
#define LED          RA0
#define _XTAL_FREQ  (4000000)
__CONFIG(0X2CE4);
void delay_time(unsigned int );
void main()
{
      TRISAbits.TRISA0 =0;        	
           
      //for pic16f877a and if ansel does not work try adcon
      /* 
      ADCON0  = 0X00;
      ADCON1 = 0X00; */

      ANSEL = 0X00;
      ANSELH = 0X00; 
	 
      while(1)
      {
            LED = 1;
           __delay_ms(5000);
		   //delay_time(30000);
           LED = 0;
           __delay_ms(5000);
		   //delay_time(30000);
      }

}

void delay_time(unsigned int time)
{
     int i = 0, j =0;
     for(i = 0; i < time; ++i)
         for(j = 0; j < 100; ++j);
    return;
}
