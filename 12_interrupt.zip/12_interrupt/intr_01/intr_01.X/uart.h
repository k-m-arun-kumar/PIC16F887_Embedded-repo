/**************************************************************************
   FILE          :    uart.h
 
   PURPOSE       :    UART Header
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran  
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _UART_H
 #define _UART_H
 
/* ---------------------- macro defination ------------------------------------------------ */
#define DISP_FLAG_NUM_DIGIT1                   (1U)
#define DISP_FLAG_NUM_DIGIT2                   (2U)
#define DISP_FLAG_NUM_DIGIT3                   (3U)
#define DISP_FLAG_NUM_DIGIT4                   (4U)
#define DISP_FLAG_NUM_DIGIT5                   (5U)
#define DISP_FLAG_HEX_DIGIT1                   (6U)
#define DISP_FLAG_HEX_DIGIT2                   (7U)
#define DISP_FLAG_HEX_DIGIT3                   (8U)
#define DISP_FLAG_HEX_DIGIT4                   (9U) 

 /* -------------------- public prototype declaration --------------------------------------- */
void UART_Init();
void UART_Transmit_Char(const char transmit_char);
void UART_Transmit_Str(const char *transmit_str);
char UART_Receive_Char();
void UART_Transmit_Num(const unsigned int uart_datanum_disp_format, const unsigned long uart_disp_data_int);

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
