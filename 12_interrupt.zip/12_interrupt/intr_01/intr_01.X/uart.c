/**************************************************************************
   FILE          :    uart.c
 
   PURPOSE       :   UART Library
 
   AUTHOR        :     K.M. Arun Kumar alias Arunkumar Murugeswaran  
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 #include "main.h"
 #include "lcd.h"
 #include "uart.h"
 
#define ERROR_LINE_NUM     NUM_LINE4

 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/

void UART_Init()
{
	SPBRG = 25;  /* (_XTAL_FREQ /(16 * baud_rate)) - 1,  Osc freq = 4MHz, Baud Rate = 2400  */
	BRG16 = 0 ;  /* 8-bit Baud Rate Generator is used */
	BRGH  = 0;   /* Fast baud rate */
	SPEN  = 1;   /* enable serial port pins */
	SYNC  = 0;   /* Asynchrous mode */ 
	CREN  = 1;   /* enable continuous receive */	
	TXEN  = 0;   /* reset transmitter */
	TXEN  = 1;   /* enable transmitter */
	
	SREN  = 0;   /* single receive disabled */	
	TXIE  = 0;   /* disable transmit interrupt */
	RCIE  = 1;   /* enable receiver interrupt */
	TX9   = 0;   /* 8 bit transmission */
	RX9   = 0;   /* 8 bit reception */
	
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void UART_Transmit_Char(const char transmit_char)
{
	TXREG = transmit_char;	
	while(TRMT == 0); /* wait as TSR is full */	
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void UART_Transmit_Str(const char *transmit_str)
{
	while(*transmit_str)
	{
		 UART_Transmit_Char(*transmit_str); 		 	
		 ++transmit_str;
	}		
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
char UART_Receive_Char()
{
	char receive_char = 0;
	const char framing_error_msg_disp[] = "FERR", overrun_error_msg_disp[] = "OERR";
	
	/* overrun error has occured */
	if(OERR == 1)
	{
		/* internal error : overrun error has occurred */
		
		//SHOULD_REMOVE
		Goto_XY_LCD_Disp(ERROR_LINE_NUM, NUM_COL1);
	    Data_Str_Disp_LCD(overrun_error_msg_disp);
		UART_Transmit_Str("ERR: OERR\r ");	
		
		CREN = 0; /* clear (CREN) continuous reception flag to clear OERR flag */
		CREN = 1; /* enable (CREN) continuous reception flag to continue receive datas */
	}
	while(RCIF == 0);	
	
	/* received char has framing error */
 	if(FERR == 1)  
    {  
       receive_char = RCREG;
	   /* internal error: framing error has occurred */
	   
	   //SHOULD_REMOVE
	   Goto_XY_LCD_Disp(ERROR_LINE_NUM, NUM_COL1);
	   Data_Str_Disp_LCD(framing_error_msg_disp);
	   UART_Transmit_Str("ERR: FERR\r ");	
	   
	   return 0;
 	}
	receive_char = RCREG;
	/* echo received char in virtual terminal */
	UART_Transmit_Char(receive_char);
	return receive_char;
}


/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void UART_Transmit_Num(const unsigned int uart_datanum_disp_format, const unsigned long uart_disp_data_int)
{
    unsigned int tens_thousand_digit,thousands_digit, hundreds_digit,tens_digit, unit_digit;
    unsigned long num = uart_disp_data_int;
    char num_data[] ={'0','1','2','3','4','5','6','7','8','9'};  
	char hex_data[] ={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'}; 
    switch(uart_datanum_disp_format)
	{
	  case DISP_FLAG_NUM_DIGIT5: 
		  num =  uart_disp_data_int ;
		  tens_thousand_digit = (unsigned int)(num / (unsigned long)(10000UL));
          UART_Transmit_Char(num_data[tens_thousand_digit]);
	  case DISP_FLAG_NUM_DIGIT4:
	      num = uart_disp_data_int % 10000UL;
	      thousands_digit = (unsigned int)(num / (unsigned long)(1000UL));
	      UART_Transmit_Char(num_data[thousands_digit]); 
	  case DISP_FLAG_NUM_DIGIT3: 
		  num = uart_disp_data_int % 1000UL;
	      hundreds_digit = (unsigned int) (num / (unsigned long) (100));
	      UART_Transmit_Char(num_data[hundreds_digit]);
	  case DISP_FLAG_NUM_DIGIT2:
          num = uart_disp_data_int % 100;
          tens_digit = (unsigned int) (num / 10);
          UART_Transmit_Char(num_data[tens_digit]); 		  
	  case DISP_FLAG_NUM_DIGIT1:
	     unit_digit = (unsigned int) (uart_disp_data_int % 10);
         UART_Transmit_Char(num_data[unit_digit]); 
	  break;
	  case DISP_FLAG_HEX_DIGIT4:
	      //  ( 16 * 16 * 16 *16 )  = 0 as divide by zero warning 
	      //num = uart_disp_data_int % ( 16 * 16 * 16 *16 );
          thousands_digit = (num / (unsigned long) (16 * 16 * 16));
	      UART_Transmit_Char(hex_data[thousands_digit]);
	  case DISP_FLAG_HEX_DIGIT3:
	      num = uart_disp_data_int %(unsigned long)(16 * 16 * 16);
	      hundreds_digit = (unsigned int) (num / (unsigned long) (16 * 16));
	      UART_Transmit_Char(hex_data[hundreds_digit]);
	  case DISP_FLAG_HEX_DIGIT2:
	      num = uart_disp_data_int %(unsigned long)(16 * 16);
          tens_digit = (unsigned int) (num / 16);
          UART_Transmit_Char(hex_data[tens_digit]);
	  case DISP_FLAG_HEX_DIGIT1: 
	      unit_digit = (unsigned int) (uart_disp_data_int % 16);
          UART_Transmit_Char(hex_data[unit_digit]);    
	  break;
	  default:
	      // Warning invalid lcd_disp flag 
	    ;
	}   			
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
