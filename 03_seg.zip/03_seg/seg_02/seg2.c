/* ********************************************************************
FILE                   : seg2.c

PROGRAM DESCRIPTION    : DISPLAY periodic hexa digit in a 7 segment LED of  common cathode  for every sw press 							 
	 
AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
 
USED:              
             Desktop OS: Windows 7 Professional (32 bit) (Intel X64)       
     			   IDE: Developed by using Microchip's MPLAB IDE v8.6
                   CADD: Simulated in Proteus 8.0 Professional 
                   HW : Tested OK in PIC development board by www.alselectro.com 
		    Programmer: PICkit 3 
                       
CHANGE LOGS           : 

*****************************************************************************/
#include <pic.h>
#define  DIGIT_SW        RC0
#define _XTAL_FREQ   (4000000)
#define SEVEN_SEG_PORT    PORTB
#define SEG_UNIT_DIGIT_PIN     RA0
__CONFIG(0x2ce4);
void  main()
{
         unsigned int k = 0,digit[]   = {0x3F, 0x06, 0x5B, 0x4F,0x66,0x6D, 0x7D, 0x07, 0x7F, 0x6F, 0x77, 0x7C, 0x39, 0x5E, 0x79, 0x71};
		 TRISB = 0x00;
		 SEVEN_SEG_PORT = 0X00;
		 TRISAbits.TRISA0 = 0;
		 SEG_UNIT_DIGIT_PIN = 0;
         TRISCbits.TRISC0 = 1;
		 DIGIT_SW = 0;
		 
        ANSEL = 0x00;
        ANSELH = 0x00;
        while(1)
        {
			SEG_UNIT_DIGIT_PIN = 1;
           if( DIGIT_SW== 1)
           {
              __delay_ms(50);
			  if(DIGIT_SW== 1)
			  {
				  while(DIGIT_SW == 1);
			      SEVEN_SEG_PORT = digit[k++];
			  }
           }
           if(k >= 16)
             k  =0;      
    }                                                                              
}
