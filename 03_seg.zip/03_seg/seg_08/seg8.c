/* ********************************************************************
FILE                   : seg8.c

PROGRAM DESCRIPTION    : for every SW_INC press increment display NUMBER, in a 7 segment LED 2 digit multiplexed.  
for every SW_DEC press decrement display number, in a 7 segment LED 2 digit multiplexed. 		 
	 
AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
 
USED:              
             Desktop OS: Windows 7 Professional (32 bit) (Intel X64)       
     			   IDE: Developed by using Microchip's MPLAB IDE v8.6
                   CADD: Simulated in Proteus 8.0 Professional 
                                        
CHANGE LOGS           : 

*****************************************************************************/
#include <pic.h>
#define SW_INC     RA0
#define SW_DEC   RA1
#define UNIT_DIGIT_PIN    RB0
#define TENS_DIGIT_PIN    RB1
#define SEVEN_SEG_PORT    PORTC
#define STATE_YES        'y'
#define STATE_NO         'n'

#define _XTAL_FREQ       (4000000)
__CONFIG(0x2ce4);
char sw_enable_flag = STATE_YES,
void delay_time(unsigned int );
void display_num(int );
void main()
{
     int num =  -1 ;
	 TRISC = 0x00;
     TRISA = 0x03;
     TRISB = 0x00;
     PORTA  = 0x00;
     SEVEN_SEG_PORT = 0x00;
     PORTB = 0x00;
    
      ANSEL = 0x00;
      ANSELH = 0x00;
      for(;;)
      {
        if(sw_enable_flag == STATE_YES && SW_INC == 1)
        {  
              while(SW_INC == 1);
              sw_enable_flag = STATE_NO;			  
			  if(num >= 99)
                    num  = -1;    
            ++num;  
             display_num(num);
       }
        if(sw_enable_flag == STATE_YES && SW_DEC == 1)
        {  
             while(SW_DEC == 1);
			 sw_enable_flag = STATE_NO;
			 if(num <= 0)
                    num  =100;  
            --num; 
              display_num(num);
       }   
   }
}
void display_num(int num)
{
        unsigned int unit_digit, tens_digit;
        unsigned int digit[]   = {0x3F, 0x06, 0x5B, 0x4F,0x66,0x6D, 0x7D, 0x07, 0x7F, 0x6F};
       unsigned int trig[] = {0x01, 0x02};

         tens_digit = num /10;
        UNIT_DIGIT_PIN = 1;
       TENS_DIGIT_PIN = 0;
         /* instead of triggering individial pins of 7 seg 4 digit multiplexed LED as above, 
          below commented line is used to trigger it at same time ,if others non trig pins of 7 seg
          does not cause  any side effects*/
         // PORTB |= (0x03 & ~trig[1]);  
       SEVEN_SEG_PORT = digit[tens_digit];   
       delay_time(30000);

       unit_digit = num %10;
        UNIT_DIGIT_PIN = 0;
       TENS_DIGIT_PIN = 1;
         /* instead of triggering individial pins of 7 seg 4 digit multiplexed LED as above, 
          below commented line is used to trigger it at same time,if others non trig pins of 7 seg
          does not cause  any side effects  */
         // PORTB |= (0x0F & ~trig[0]);
       SEVEN_SEG_PORT = digit[unit_digit];
        delay_time(10000);
		sw_enable_flag = STATE_YES;
}
void delay_time(unsigned int time_delay)
{
         while (time_delay--);
}
