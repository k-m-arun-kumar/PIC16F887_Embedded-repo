 
  /* ********************************************************************
FILE                   : seg3.c

PROGRAM DESCRIPTION    :  DISPLAY increase hexa digit in a 7 segment LED of  common cathode  for every SW_INC press and 
                          decrease hexa digit in a 7 segment LED of  common cathode  for every SW_DEC press							 
	 
AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
 
USED:              
             Desktop OS: Windows 7 Professional (32 bit) (Intel X64)       
     			   IDE: Developed by using Microchip's MPLAB IDE v8.6
                   CADD: Simulated in Proteus 8.0 Professional 
                   HW : Tested OK in PIC development board by www.alselectro.com 
		    Programmer: PICkit 3 
                       
CHANGE LOGS           : 

*****************************************************************************/  
#include <pic.h>
#define   SW_INC RC0
#define   SW_DEC RC1
#define _XTAL_FREQ   (4000000)
#define SEVEN_SEG_PORT    PORTB
#define SEG_UNIT_DIGIT_PIN     RA0

void    main()
{
         unsigned int digit[]   = {0x3F, 0x06, 0x5B, 0x4F,0x66,0x6D, 0x7D, 0x07, 0x7F, 0x6F, 0x77, 0x7C, 0x39, 0x5E, 0x79, 0x71};
         int k = -1;		 
		 TRISB = 0x00;
		 SEVEN_SEG_PORT = 0X00;
		 TRISAbits.TRISA0 = 0;
		 SEG_UNIT_DIGIT_PIN = 0;
         TRISCbits.TRISC0 = 1;
		 SW_INC = 0;
		 TRISCbits.TRISC1 = 1;
		 SW_DEC = 0;
		 
          
        ANSEL = 0x00;
       ANSELH = 0x00;
    while(1)
    {
		SEG_UNIT_DIGIT_PIN = 1;
        if(SW_INC == 1)
        {
              if(k >= 15)
                    k  = -1; 
              SEVEN_SEG_PORT = digit[++k];
              while(SW_INC == 1);           
       }
        if(SW_DEC == 1)
        {
              if(k <= 0)
                k  =16;  
             PORTC = digit[--k];
             while(SW_DEC == 1);           
       }   
    }                                                                              
}
