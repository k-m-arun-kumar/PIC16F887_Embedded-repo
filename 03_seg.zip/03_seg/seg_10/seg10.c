/* ********************************************************************
FILE                   : seg10.c

PROGRAM DESCRIPTION    : in keypad phone with row reference, scan each key for a press and if pressed, then display corresponding num in a 7 seg LED common cathode 	 
	 
AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
 
USED:              
             Desktop OS: Windows 7 Professional (32 bit) (Intel X64)       
     			   IDE: Developed by using Microchip's MPLAB IDE v8.6
                   CADD: Simulated in Proteus 8.0 Professional 
                 
CHANGE LOGS           : 

*****************************************************************************/
#include <pic.h>
#define MAX_ROW  4
#define MAX_COL   3
#define  SEG_LED_PORT        PORTC
#define  KEYPAD_PHONE_COL1  RA0
#define  KEYPAD_PHONE_COL2  RA1
#define  KEYPAD_PHONE_COL3  RA2
#define  KEYPAD_PHONE_ROWA RA3
#define  KEYPAD_PHONE_ROWB RA4
#define  KEYPAD_PHONE_ROWC RA5
#define  KEYPAD_PHONE_ROWD RA6
void main()
{
       TRISA = 0x07;
       TRISC = 0x00;
       PORTA = 0x00;
       PORTC = 0x00;
       ANSEL = 0x00;
       ANSELH = 0x00;
       unsigned int digit[]   = {0x3F, 0x06, 0x5B, 0x4F,0x66,0x6D, 0x7D, 0x07, 0x7F, 0x6F};
       for(;;)
      {
              KEYPAD_PHONE_ROWA = 1;
                KEYPAD_PHONE_ROWB  = 0;
                KEYPAD_PHONE_ROWC  = 0;
                KEYPAD_PHONE_ROWD  = 0; 
                    if(KEYPAD_PHONE_COL1 == 1)
                         SEG_LED_PORT   =    digit[1];
                   if (KEYPAD_PHONE_COL2 == 1)
                         SEG_LED_PORT   =    digit[2];
                     if (KEYPAD_PHONE_COL3 == 1)
                         SEG_LED_PORT   =    digit[3]; 

              KEYPAD_PHONE_ROWA = 0;
                KEYPAD_PHONE_ROWB  = 1;
                KEYPAD_PHONE_ROWC  = 0;
                KEYPAD_PHONE_ROWD  = 0; 
                    if(KEYPAD_PHONE_COL1 == 1)
                         SEG_LED_PORT   =    digit[4];
                   if (KEYPAD_PHONE_COL2 == 1)
                         SEG_LED_PORT   =    digit[5];
                     if (KEYPAD_PHONE_COL3 == 1)
                         SEG_LED_PORT   =    digit[6]; 

                KEYPAD_PHONE_ROWA = 0;
                KEYPAD_PHONE_ROWB  = 0;
                KEYPAD_PHONE_ROWC  = 1;
                KEYPAD_PHONE_ROWD  = 0; 
                    if(KEYPAD_PHONE_COL1 == 1)
                         SEG_LED_PORT   =    digit[7];
                   if (KEYPAD_PHONE_COL2 == 1)
                         SEG_LED_PORT   =    digit[8];
                     if (KEYPAD_PHONE_COL3 == 1)
                         SEG_LED_PORT   =    digit[9]; 
 
                KEYPAD_PHONE_ROWA = 0;
                KEYPAD_PHONE_ROWB  = 0;
                KEYPAD_PHONE_ROWC  = 0;
                KEYPAD_PHONE_ROWD  = 1; 
                  
                   if (KEYPAD_PHONE_COL2 == 1)
                       SEG_LED_PORT   =  digit[0];  
      }                
     
}
