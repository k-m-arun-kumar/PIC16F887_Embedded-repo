/* */
 
 /* ********************************************************************
FILE                   : adc5.c

PROGRAM DESCRIPTION    :  potentiometer analog value corresponding digital encoded value (output of ADC) should display in LCD.
 * dc motor should run in forward direction when encoded value of pot is less than 512. 
 * if encoded value reaches above 512 motor should be not run ie if percentage is < 50% motor should run in forward direction, else motor is off 

AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
                                  
                       
CHANGE LOGS           : 

*****************************************************************************/ 
#include <xc.h>
#define RS_PIN                                 RD0
#define RW_PIN                                 RD1
#define EN_PIN                                 RD2
#define LCD_PORT                              PORTC

#define RELAY_MOTOR_FWD_RUN_PIN                 RE0 
#define RELAY_ON                                (1)
#define RELAY_OFF                               (0)
 
#define DISP_FLAG_NUM_DIGIT1                   (1)
#define DISP_FLAG_NUM_DIGIT2                   (2)
#define DISP_FLAG_NUM_DIGIT3                   (3)
#define DISP_FLAG_NUM_DIGIT4                   (4)
#define DISP_FLAG_NUM_DIGIT5                   (5)
#define DISP_FLAG_HEX_DIGIT1                   (6)
#define DISP_FLAG_HEX_DIGIT2                   (7)
#define DISP_FLAG_HEX_DIGIT3                   (8)
#define DISP_FLAG_HEX_DIGIT4                   (9) 

/* for 20 * 4 LCD disp */                             
#define BEGIN_LOC_LINE1                      (0X80)
#define BEGIN_LOC_LINE2                      (0xC0)
#define BEGIN_LOC_LINE3                      (0x94) 
#define BEGIN_LOC_LINE4                      (0xD4)
#define END_LOC_LINE1                        (0x93)
#define END_LOC_LINE2                        (0xD3)
#define END_LOC_LINE3                        (0xA7) 
#define END_LOC_LINE4                        (0xE7)

/* num cols = num of chars in a line */
#define MAX_COUNT_DELAY_TIME_LCDPULSE     (1000U)
#define MAX_AVAIL_NUM_COLS                    (20)
#define CONFIGURE_MAX_NUM_LINES               (4)
#define MAX_AVAIL_NUM_LINES                   (4) 
#define MAX_AVAIL_NUM_CHARS_IN_LCD        (MAX_AVAIL_NUM_COLS * MAX_AVAIL_NUM_LINES) 
#define CONFIGURE_MAX_NUM_COLS             (MAX_AVAIL_NUM_COLS)
#define CONFIGURE_MAX_NUM_CHARS_IN_LCD    (CONFIGURE_MAX_NUM_LINES * CONFIGURE_MAX_NUM_COLS ) 
#define MAX_NUM_CHARS_INPUT_DATA          (MAX_AVAIL_NUM_COLS)  

#define INVALID_DATA               (0)
#define ALL_LINES                  (0)
#define NUM_LINE1                  (1)
#define NUM_LINE2                  (2)
#define NUM_LINE3                  (3)
#define NUM_LINE4                  (4)
#define NUM_COL1                   (1)


#define SIGCH0_LINE_NUM           (NUM_LINE2)
#define MOTOR_STATUS_LINE_NUM     (NUM_LINE3) 
#define SIGNAL_DECPT_COL_NUM      (NUM_COL1 + 4)
#define SIGNAL_FRAC_COL_NUM       (SIGNAL_DECPT_COL_NUM + 1)
#define SIGNAL_DISP_COL_NUM       (SIGNAL_FRAC_COL_NUM + 1)    
#define PERCENT_INT_COL_NUM       (SIGNAL_DISP_COL_NUM + 4)
#define PERCENT_DECPT_COL_NUM     (PERCENT_INT_COL_NUM + 3)
#define PERCENT_FRAC_COL_NUM      (PERCENT_DECPT_COL_NUM + 1) 
#define PERCENT_DISP_COL_NUM      (PERCENT_FRAC_COL_NUM + 1) 
#define MOTOR_STATUS_COL_NUM      (NUM_COL1 + 7)

#define MAX_ENCODED_FWD_RUN        (511UL) 
#define MAX_ANALOG_VALUE_CHANNEL     (20U)
#define MIN_ANALOG_VALUE_CHANNEL     (0U)
#define FULL_SCALE_VALUE_CHANNEL     ((MAX_ANALOG_VALUE_CHANNEL) - (MIN_ANALOG_VALUE_CHANNEL))

void Delay_Time_ByCount(unsigned int Delay_Time_Count_count);
void LCD_Init();
void LCD_Pulse ();
void Write_LCD_Command (const unsigned int Write_LCD_Command);
void Write_LCD_Data(const char lcd_disp_ch);
void Data_Str_Disp_LCD(const char *lcd_disp_str);
void Data_Num_Disp_LCD(const unsigned int lcd_datanum_disp_format, const unsigned long lcd_disp_data_int);
void Init_ADC_Channel(const unsigned int );
#ifdef SWITCH_CHANNEL
    void Read_ADC_Channel(unsigned int adc_channel);
#else
	unsigned long Read_ADC_Channel(unsigned int adc_channel);
#endif
void Read_ADC_Channel0();
void Read_ADC_Channel1();
void Encoded_To_Actual_Analog_Val_Calc(const unsigned long adc_value, unsigned long *const analog_val_in_digital_int, unsigned long *const analog_val_in_digital_frac );
void Encoded_To_Percent_Calc(const unsigned long adc_value, unsigned int *const percent_int, unsigned int *const percent_frac );
void LCD_Const_Disp();
void Goto_XY_LCD_Disp(const unsigned int start_line_num, const unsigned int start_col_num);
unsigned int adc_channel;
unsigned long adc_value_ch0, analog_val_in_digital_ch0; 
unsigned int cur_disp_lcd_loc = BEGIN_LOC_LINE1;

void main()
{
	unsigned long analog_val_in_digital_int_ch0, analog_val_in_digital_frac_ch0;
	unsigned int percent_int_ch0, percent_frac_ch0;	
	const char motor_off_msg_disp[] = "OFF", motor_fwd_run_msg_disp[] = "FWD",motor_rev_run_msg_disp[] = "REV"; 
	TRISA = 0x01;
	PORTA = 0x00; 
	TRISC = 0x00;
	PORTC = 0x00;
	TRISD = 0x00;
	PORTD = 0x00;
	TRISE = 0X00;
	PORTE = 0x00;
	ANSEL = 0X01;
	ANSELH = 0x00;
	LCD_Init(); 	
	LCD_Const_Disp();
	
	for(;;)
    {    
        adc_channel = 0;
		adc_value_ch0 =  Read_ADC_Channel(adc_channel);
		Encoded_To_Actual_Analog_Val_Calc(adc_value_ch0,&analog_val_in_digital_int_ch0,&analog_val_in_digital_frac_ch0 );		
		Goto_XY_LCD_Disp(SIGCH0_LINE_NUM, NUM_COL1);
		Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT4, analog_val_in_digital_int_ch0);		
		Goto_XY_LCD_Disp(SIGCH0_LINE_NUM, SIGNAL_FRAC_COL_NUM);
		Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT1, analog_val_in_digital_frac_ch0);
       		
		Encoded_To_Percent_Calc(adc_value_ch0,&percent_int_ch0,&percent_frac_ch0 );
		Goto_XY_LCD_Disp(SIGCH0_LINE_NUM, PERCENT_INT_COL_NUM);
		Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT3,percent_int_ch0 );		
		Goto_XY_LCD_Disp(SIGCH0_LINE_NUM, PERCENT_FRAC_COL_NUM);
		Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT1,percent_frac_ch0 );      
        
        if(adc_value_ch0 <= MAX_ENCODED_FWD_RUN)
        {			
          RELAY_MOTOR_FWD_RUN_PIN = RELAY_ON;
		  Goto_XY_LCD_Disp(MOTOR_STATUS_LINE_NUM, MOTOR_STATUS_COL_NUM);
		  Data_Str_Disp_LCD(motor_fwd_run_msg_disp); 
		} 
        else 
		{	
          RELAY_MOTOR_FWD_RUN_PIN = RELAY_OFF;  
          Goto_XY_LCD_Disp(MOTOR_STATUS_LINE_NUM, MOTOR_STATUS_COL_NUM);
		  Data_Str_Disp_LCD(motor_off_msg_disp);
        }		  
       	Delay_Time_ByCount(1000uL);		
	}		
}

void Init_ADC_Channel(const unsigned int adc_channel)
{
	unsigned int adc_channel_reg = adc_channel << 2;
    /* Fosc/32, corresponding channel, not yet start ADC, enable ADC channel */	
	ADCON0 = adc_channel_reg | 0x80 | 0x01;
	/* right justified, Vref+ and Vref- as internal */
    ADCON1 = 0x80; 
}
unsigned long Read_ADC_Channel(unsigned int adc_channel)
{
	unsigned int adc_value_least_byte, adc_value_most_byte;
	unsigned long adc_value_channel;
	/* Init_ADC_Channel should be called at the time of reading that ADC channel,
	if Init_ADC_Channel called at reset point ie before while(1), then last ADC channel that called
	Init_ADC_Channel() will effect ADC conversion, other ADC channels that called Init_ADC_Channel()
    before last channel's call on Init_ADC_Channel(), will not do ADC conversion */
	Init_ADC_Channel(adc_channel);
	/* After the analog input channel is selected (or changed), an A/D acquisition must be done before the conversion
		     can be started, minimum A/D acquisition time = 5us */
	Delay_Time_ByCount(1000ul);
	/* Start ADC conversion for specific channel*/
	GO = 1;
	while(GO == 1);
	/* ADC conversion has completed*/
	adc_value_least_byte = ADRESL;
	adc_value_most_byte = ADRESH & 0x03u;
	switch(adc_value_most_byte)
	{
		case 0x00:
		  adc_value_channel = adc_value_least_byte;
		  break;
		case 0x01:
          adc_value_channel = adc_value_least_byte + 256u;
		  break;	
		case 0x02:
          adc_value_channel = adc_value_least_byte + 512u;
		  break; 
		case 0x03:
          adc_value_channel = adc_value_least_byte + 768u;
		  break; 
	}
	return adc_value_channel;
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 29   
-*------------------------------------------------------------*/
void Encoded_To_Actual_Analog_Val_Calc(const unsigned long adc_value, unsigned long *const analog_val_in_digital_int, unsigned long *const analog_val_in_digital_frac   )
{
	unsigned long remainder_val;	
	*analog_val_in_digital_int = ((FULL_SCALE_VALUE_CHANNEL * adc_value) / (1024ul -1))  + MIN_ANALOG_VALUE_CHANNEL;
	remainder_val = (FULL_SCALE_VALUE_CHANNEL * adc_value) %(1024ul -1);
	*analog_val_in_digital_frac = ((remainder_val * 10) /(1024ul -1));
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 29   
-*------------------------------------------------------------*/
void Encoded_To_Percent_Calc(const unsigned long adc_value, unsigned int *const percent_int, unsigned int *const percent_frac )
{
	unsigned int remainder_val;
	unsigned long temp_percent_int;
	temp_percent_int =  (100 * adc_value); 
	*percent_int = (100 * adc_value) / (1024ul - 1);
	remainder_val = temp_percent_int % (1024ul - 1 );
	*percent_frac = (remainder_val * 10) /(1024ul - 1);
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 29   
-*------------------------------------------------------------*/
void Goto_XY_LCD_Disp(const unsigned int start_line_num, const unsigned int start_col_num)
{
	/* max 4 lines and 20 columns */
	/* for us, lcd line starts from 1, but for uC, line starts from 0 */
	/* for us, lcd col starts from 1, but for uC, col starts from 0 */
    unsigned int start_line_lcd = start_line_num - 1, start_col_lcd = start_col_num - 1, error_disp_start_loc; 
		
   if(start_line_num <= CONFIGURE_MAX_NUM_LINES && start_col_num <= CONFIGURE_MAX_NUM_COLS )
   {
      switch(start_line_num)
	 {
		 case NUM_LINE1:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE1;
		   break;
		 case NUM_LINE2:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE2;
		   break;
		 case NUM_LINE3:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE3;
		   break;
		  case NUM_LINE4:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE4;
		   break;		 
	 }	
      cur_disp_lcd_loc = cur_disp_lcd_loc + start_col_lcd;
      Write_LCD_Command(cur_disp_lcd_loc);       
   }
   else
   {
	   /* error due to invalid lcd DISP loc  */    
		        		
   }	   
}
void LCD_Const_Disp()
{
	const char signal_rep_disp[] = "V", motor_msg_disp[] = "MOTOR: ";
	
	Goto_XY_LCD_Disp(NUM_LINE1, NUM_COL1);
	Data_Str_Disp_LCD("ADC Channel 0 Output");       
   
	Goto_XY_LCD_Disp(SIGCH0_LINE_NUM,SIGNAL_DECPT_COL_NUM );
	Write_LCD_Data('.');	
    Goto_XY_LCD_Disp(SIGCH0_LINE_NUM,SIGNAL_DISP_COL_NUM);
	Data_Str_Disp_LCD(signal_rep_disp);		
	Goto_XY_LCD_Disp(SIGCH0_LINE_NUM,PERCENT_DECPT_COL_NUM);
	Write_LCD_Data('.');
   	Goto_XY_LCD_Disp(SIGCH0_LINE_NUM,PERCENT_DISP_COL_NUM);
	Write_LCD_Data('%');
	Goto_XY_LCD_Disp(MOTOR_STATUS_LINE_NUM, NUM_COL1);
	Data_Str_Disp_LCD(motor_msg_disp); 
	
}
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void LCD_Init()
{
    Write_LCD_Command(0x30);
    Write_LCD_Command(0x30);
    Write_LCD_Command(0x30);
    Write_LCD_Command(0x38);
    Write_LCD_Command(0x01);
    Write_LCD_Command(0x0C); //insert cursor on at cur_input_lcd_loc
	//Write_LCD_Command(0x0C);
    Write_LCD_Command(0x06);                                       
}     

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 23   
-*------------------------------------------------------------*/
  void Write_LCD_Command (unsigned int cmd)
  {
	  unsigned long int  time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	  
       RW_PIN = 0;
       RS_PIN = 0; 
       LCD_PORT = cmd;
      // LCD_Pulse();
	  EN_PIN = 1;
	  while(time_delay--);
    // Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);
      EN_PIN = 0;
	  time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	  while(time_delay--);
   //  Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);
 }
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 24   
-*------------------------------------------------------------*/
 void Write_LCD_Data(const char ch)
{
	unsigned long int  time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	// performance degraded if many data is written to LCD, to check if write loc is within avail disp loc
	// if(lcd_avail_loc_within_limit == STATE_YES) 
	{	
      RW_PIN = 0;
      RS_PIN = 1;
      LCD_PORT =ch;
     // LCD_Pulse();
      EN_PIN = 1;
	  while(time_delay--);
    // Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);
     EN_PIN = 0;
	 time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	  while(time_delay--);
   //  Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);	 
	}
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 25   
-*------------------------------------------------------------*/

void Data_Str_Disp_LCD(const char *char_ptr)
{ 
       while(*char_ptr)
       {
            Write_LCD_Data(*(char_ptr++));
       }
     
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 27  
-*------------------------------------------------------------*/
void Delay_Time_ByCount( unsigned int time_delay)
{
       while(time_delay--);
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 26  
-*------------------------------------------------------------*/
void Data_Num_Disp_LCD(const unsigned int lcd_datanum_disp_format, const unsigned long lcd_disp_data_int)
{
    unsigned int tens_thousand_digit,thousands_digit, hundreds_digit,tens_digit, unit_digit;
    unsigned long num = lcd_disp_data_int;
    char num_data[] ={'0','1','2','3','4','5','6','7','8','9'};  
	char hex_data[] ={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'}; 
    switch(lcd_datanum_disp_format)
	{
	  case DISP_FLAG_NUM_DIGIT5: 
		  num =  lcd_disp_data_int % 100000;
		  tens_thousand_digit = (unsigned int)(num / (unsigned long)(10000));
          Write_LCD_Data(num_data[tens_thousand_digit]);
	  case DISP_FLAG_NUM_DIGIT4:
	      num = lcd_disp_data_int % 10000;
	      thousands_digit = (unsigned int)(num / (unsigned long)(1000));
	      Write_LCD_Data(num_data[thousands_digit]); 
	  case DISP_FLAG_NUM_DIGIT3: 
		  num = lcd_disp_data_int % 1000;
	      hundreds_digit = (unsigned int) (num / (unsigned long) (100));
	      Write_LCD_Data(num_data[hundreds_digit]);
	  case DISP_FLAG_NUM_DIGIT2:
          num = lcd_disp_data_int % 100;
          tens_digit = (unsigned int) (num / 10);
          Write_LCD_Data(num_data[tens_digit]); 		  
	  case DISP_FLAG_NUM_DIGIT1:
	     unit_digit = (unsigned int) (lcd_disp_data_int % 10);
         Write_LCD_Data(num_data[unit_digit]); 
	  break;
	  case DISP_FLAG_HEX_DIGIT4:
	      /*  ( 16 * 16 * 16 *16 )  = 0 as divide by zero warning */
	      //num = lcd_disp_data_int % ( 16 * 16 * 16 *16 );
          thousands_digit = (num / (16 * 16 * 16));
	      Write_LCD_Data(hex_data[thousands_digit]);
	  case DISP_FLAG_HEX_DIGIT3:
	      num = lcd_disp_data_int %(unsigned long)(16 * 16 * 16);
	      hundreds_digit = (unsigned int) (num / (unsigned long) (16 * 16));
	      Write_LCD_Data(hex_data[hundreds_digit]);
	  case DISP_FLAG_HEX_DIGIT2:
	      num = lcd_disp_data_int %(unsigned long)(16 * 16);
          tens_digit = (unsigned int) (num / 16);
          Write_LCD_Data(hex_data[tens_digit]);
	  case DISP_FLAG_HEX_DIGIT1: 
	      unit_digit = (unsigned int) (lcd_disp_data_int % 16);
          Write_LCD_Data(hex_data[unit_digit]);    
	  break;
	  default:
	     /* Warning invalid lcd_disp flag */
	    ;
	}   	
}
