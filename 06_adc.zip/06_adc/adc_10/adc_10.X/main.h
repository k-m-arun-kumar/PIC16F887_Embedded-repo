/**************************************************************************
   FILE          :    main.h
 
   PURPOSE       :    project header.  
 
   AUTHOR        :     K.M.Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   PROJECT header- groups the key information about the mcrocontroller device you have used, along with other key
parameters � such as the oscillator frequency and commonly used information such as common data types in the project
	
  CHANGE LOGS     :
	   
 **************************************************************************/
 
 /* to avoid this header file to be included more than once, conditional directive is used  */
#ifndef _MAIN_H
#define _MAIN_H

/* Must include the appropriate microcontroller header file here .
 In most case, microcontroller header is also a device header.
 device header will include the addresses of the special function registers (SFRs) used for port access, plus similar
 details for other on-chip components such as analog-to-digital converters*/
  // Must include the appropriate microcontroller header file here
//#define HI_TECH_COMPILER
#ifdef HI_TECH_COMPILER
  #include <pic.h>
  __CONFIG(0x2CE4);
#else // XC8 compiler
  #include <xc.h>
#endif

#define LED_OFF                                  (0)
#define LED_ON                                   (1) 
 
#define KEY_PRESSED                              (1) 
#define KEY_NOT_PRESSED                          (0)

#define STATE_YES                               ('y')
#define STATE_NO                                ('n')
#define STATE_INVALID                           ('X')

#define DATA_STATE_UNKNOWN                      (0U)
#define DATA_STATE_INVALID                      (1U)
#define DATA_STATE_VALID                        (2U)

#define DISP_FLAG_NUM_DIGIT1                   (1U)
#define DISP_FLAG_NUM_DIGIT2                   (2U)
#define DISP_FLAG_NUM_DIGIT3                   (3U)
#define DISP_FLAG_NUM_DIGIT4                   (4U)
#define DISP_FLAG_NUM_DIGIT5                   (5U)
#define DISP_FLAG_HEX_DIGIT1                   (6U)
#define DISP_FLAG_HEX_DIGIT2                   (7U)
#define DISP_FLAG_HEX_DIGIT3                   (8U)
#define DISP_FLAG_HEX_DIGIT4                   (9U) 

// Number of oscillations required to execute per instruction or increment a timer 
// 4 � Original PIC 16f887
#define OSC_PER_INST                            (4)

#define TIME_UNIT_1_SEC_IN_MILLI_SEC                   (1000UL)

typedef unsigned char tByte;
typedef unsigned int tWord;
typedef unsigned long tLong;

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
