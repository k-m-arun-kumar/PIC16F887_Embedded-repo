/**************************************************************************
   FILE          :    isr.c
 
   PURPOSE       :   Interrupt Service Routine Library
 
   AUTHOR        :    K.M.Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 #include "main.h"
 #include "port.h"
 #include "uart.h" 
 #include "adc.h"
 #include "io_conf.h"
 #include "intp_event_handle.h" 
 
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void interrupt Interrupt_ISR() 
{
	unsigned int adc_value_least_byte, adc_value_most_byte;
	unsigned long adc_value_channel;		
	
	if(ADIF == 1) //A/D interrupt ADC conversion complete (ADIF must be cleared in software). ADC ISR
	{	
	   ADIF = 0;
	   adc_value_least_byte = ADRESL;
	   adc_value_most_byte = ADRESH & 0x03u; //A/D for PIC16F887 is 10 bit
	   switch(adc_value_most_byte)
	   {
		  case 0x00:
		     adc_value_channel = adc_value_least_byte;
		  break;
		  case 0x01:
             adc_value_channel = adc_value_least_byte + 256u;
		  break;	
		  case 0x02:
             adc_value_channel = adc_value_least_byte + 512u;
		  break; 
		  case 0x03:
             adc_value_channel = adc_value_least_byte + 768u;
		  break; 
	   }	   
	   PIE1bits.ADIE = 0;   // disable A/D Converter (ADC) Interrupt 
	   
	   #ifdef TRACE
	      UART_Transmit_Str("ADC converted for channel : ");
		  UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, adc_cur_channel );
		  UART_Transmit_Str(" , val : ");
		  UART_Transmit_Num(DISP_FLAG_NUM_DIGIT4, adc_value_channel );
		  UART_Transmit_Char('\r');
		  UART_Transmit_Str("ADIE is disabled \r");     
	   #endif
	   ADC_Conv_Over_Appl_Proc(adc_value_channel);	   	  
    }
    
}

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
