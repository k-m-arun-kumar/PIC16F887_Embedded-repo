/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    : 
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  
                       										
                                    
CHANGE LOGS           : 

*****************************************************************************/
// PIC16F887 Configuration Bit Settings
// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.
// 'C' source line config statements

// CONFIG1
#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
//#pragma config FOSC = HS        // Oscillator Selection bits (HS oscillator: High-speed crystal/resonator on RA6/OSC2/CLKOUT and RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = ON       // Power-up Timer Enable bit (PWRT enabled)
#pragma config MCLRE = ON       // RE3/MCLR pin function select bit (RE3/MCLR pin function is MCLR)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = ON        // Internal External Switchover bit (Internal/External Switchover mode is enabled)
#pragma config FCMEN = ON       // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is enabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

#include "main.h"
#include "port.h"
#include "io_conf.h"
#include "appl_conf.h"
#include "lcd.h"
#include "adc.h"
#include "uart.h"

 //__CONFIG(0x2ce2);
value_types to_disp;
/*------------------------------------------------------------*-
FUNCTION NAME  : main

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 
-*------------------------------------------------------------*/

void main()
{
    unsigned long r_at_ch_encoded_val, r_at_ch_instant_volt_int, r_at_ch_instant_volt_frac, max_r_at_ch_encoded_value = 0, temp_int, temp_frac, i;
	unsigned int r_source_rms_volt;
	
    ANSEL = 0x01;
    ANSELH = 0x00;
	UART_Init();
    LCD_Init();
		   
    while(1)
	{    

        ADC_Conf_Channel(R_RMS_VOLTAGE_CH);		
	    ADC_Start_Conv(&adc_cur_parameters[R_RMS_VOLTAGE_CH]);
		Encoded_To_Actual_Analog_Val_Calc(adc_cur_parameters[adc_cur_channel].adc_value_channel, FULL_SCALE_ANALOG_VAL_CH0, MIN_ANALOG_VALUE_CH0, &r_at_ch_instant_volt_int, &r_at_ch_instant_volt_frac );
		
		to_disp.unsigned_val.value_long = adc_cur_parameters[adc_cur_channel].adc_value_channel;
		UART_Transmit_Num(DISP_UNSIGN_NUM_DIGIT4, to_disp );
		UART_Transmit_Str("  ");
		
		to_disp.signed_val.val_in_bytes.value_byte[0] = r_at_ch_instant_volt_int;
		UART_Transmit_Num(DISP_SIGN_NUM_DIGIT3, to_disp );
		UART_Transmit_Str("  ");
		
		to_disp.signed_val.val_in_bytes.value_byte[0] = r_at_ch_instant_volt_frac;
		UART_Transmit_Num(DISP_SIGN_NUM_DIGIT3, to_disp );
		UART_Transmit_Str("  ");
		UART_Transmit_Char(ENTER_CHAR);
		
       /* temp_int = r_at_ch_instant_volt_int * 4; // (30k + 10k) / 10k =   voltage divider
	    temp_int -= 1;  // 0.7V + 0.7V = voltage drop across 2 forward diodes
	    temp_int *= 14;  // 220v(r phase rms voltage )/(11.1v(NO LOAD VOLTAGE at output of voltage transformer for 220v) * sqrt(2)[sinosidual peak voltage to voltage rms conversion factor]);
		
		temp_frac = r_at_ch_instant_volt_frac * 4; 
		r_source_rms_volt = temp_int;
		
		to_disp.signed_val.val_in_bytes.value_byte[0] = r_source_rms_volt;
		UART_Transmit_Num(DISP_SIGN_NUM_DIGIT3, to_disp );
		UART_Transmit_Char(ENTER_CHAR);	*/
       
    }
}
/*------------------------------------------------------------*-
FUNCTION NAME  : Write_Bit

DESCRIPTION     : write bit valve to data's bit, without affecting other bits of data .
                . 0 is the least bit pos and 7 is the most bit pos 

INPUT          : 

OUTPUT         : none

NOTE           : 
-*------------------------------------------------------------*/
void Write_Bit_in_Data(unsigned int *data, const unsigned int bit_pos, const unsigned int set_bit_val )
{
       if (set_bit_val == 1)
       {
          Set_Bit_in_Data(data, bit_pos);
          return;
       }
       Clear_Bit_in_Data(data, bit_pos ); 
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/	 
