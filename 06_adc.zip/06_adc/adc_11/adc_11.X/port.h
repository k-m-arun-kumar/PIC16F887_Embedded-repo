/**************************************************************************
   FILE          :    port.h
 
   PURPOSE       :    port header - define port and its pin assignment.
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :    port header - user interface to external device, such as LED, Switch,
 	connection to other microcontroller via RS232, USB, etc. 
 To avoid this header file to be included more than once, conditional directive is used  
	
  CHANGE LOGS     :  
	   
 **************************************************************************/
#ifndef _PORT_H
#define _PORT_H

#define RS_PIN                           RE0
#define RW_PIN                           RE1
#define EN_PIN                           RE2

#define LCD_PORT                         PORTD
#define LCD_PORT_GPIO                    TRISD 

#define ADC_READY_LED                     RB2 
#define ADC_CH0_PROC_OVER_LED             RB3 
#define TIME_WAIT_LED                     RB4   
#endif 

/*------------------------------------------------------------------*-
  ---- END OF FILE -------------------------------------------------
-*------------------------------------------------------------------*/
