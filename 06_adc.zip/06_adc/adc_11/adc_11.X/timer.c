/**************************************************************************
   FILE          :    timer.c
 
   PURPOSE       :   Timer Library
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 #include "main.h"
 #include "timer.h"
 #include "uart.h"
 #include "io_conf.h"
 
unsigned int timer1_prescale = 1, timer1_prescale_shift= 0, timer1_elapsed_num_update = 0 ;
unsigned long int  timer1_init_val = 0, timer1_elapsed_num_overflow_1_update = 0, timer1_1_update = 0, timer1_max_num_overflow =0, timer1_req_time_max_update = 0;
timer1_run_states  timer1_cur_run_state= TMR1_STOP_STATE, timer1_last_run_state_before_stop = TMR1_STOP_STATE;
unsigned long int timer1_req_time_delay_in_milli_sec;
timer1_service_types timer1_cur_service_type;

 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void Timer1_Run(const timer1_run_states set_timer1_run_mode, const unsigned long int set_req_time_delay_in_milli_sec, const timer1_service_types set_timer1_service, const timer1_gate_control_types set_gate_control_type, \
  const timer1_input_clock_prescaler_types set_timer1_input_clock_prescaler_type, const timer1_LP_osc_control_types set_timer1_LP_osc_control_type, const timer1_clock_sources set_timer1_clock_source  )
{
	  unsigned long int set_timer1_tick_in_milli_sec = TIMER1_TICK_IN_MILLI_SEC;
	  unsigned long int set_timer1_req_time_1_update_in_milli_sec = TIMER1_REQ_TIME_1_UPDATE_REACHED_IN_MILLI_SEC;
	  unsigned long int timer1_remainder; 
	  
	  Timer1_Stop();    	 
	  TMR1H = 0;
      TMR1L = 0;
	  TMR1IF = 0;
	  timer1_cur_run_state = timer1_last_run_state_before_stop = set_timer1_run_mode;	  
	  T1CON =  set_gate_control_type | set_timer1_clock_source |  set_timer1_LP_osc_control_type | set_timer1_input_clock_prescaler_type; 
	  Timer1_Prescale();
      Timer1_Load_Init_Val_Calc(set_timer1_tick_in_milli_sec);	  	  
	  timer1_elapsed_num_overflow_1_update = 0;
	  timer1_1_update = set_timer1_req_time_1_update_in_milli_sec /set_timer1_tick_in_milli_sec;
      timer1_remainder = set_req_time_delay_in_milli_sec % set_timer1_req_time_1_update_in_milli_sec;	  
	  if( timer1_remainder == 0)
	  {
		  //set_req_time_delay_in_milli_sec is in multiples of  set_timer1_req_time_1_update_in_milli_sec
		  timer1_req_time_delay_in_milli_sec = set_req_time_delay_in_milli_sec;		  	 
	  }
	  else
	  {
		  //set_req_time_delay_in_milli_sec is not in multiples of  set_timer1_req_time_1_update_in_milli_sec
		  #if TIMER1_SET_TIME_DELAY_IN_MULTIPLE == TIMER1_PRESET_TIME_DELAY_IN_MULTIPLE
		    //timer1_req_time_delay_in_milli_sec is previous valid req_time_delay_in_milli_sec, which is multiple of set_timer1_req_time_1_update_in_milli_sec
		     timer1_req_time_delay_in_milli_sec = set_req_time_delay_in_milli_sec - timer1_remainder;
		  #else //TIMER1_SET_TIME_DELAY_IN_MULTIPLE == TIMER1_POSTSET_TIME_DELAY_IN_MULTIPLE
		     //timer1_req_time_delay_in_milli_sec is next valid req_time_delay_in_milli_sec, which is multiple of set_timer1_req_time_1_update_in_milli_sec
             timer1_req_time_delay_in_milli_sec = set_req_time_delay_in_milli_sec - timer1_reminder + set_timer1_req_time_1_update_in_milli_sec ;	
          #endif	
	  }
	  timer1_req_time_max_update = timer1_req_time_delay_in_milli_sec / set_timer1_req_time_1_update_in_milli_sec;
	  timer1_cur_service_type = set_timer1_service;
	  switch(timer1_cur_service_type) 
	  {
         case TMR1_INTP_SERVICE:		  
           PIE1bits.TMR1IE = 1; //Enables the Timer1 overflow interrupt 
		   INTCONbits.PEIE = 1;  //Enables all unmasked peripherals interrupts   
           INTCONbits.GIE = 1;  //Enables all unmasked interrupts 
	  
           #ifdef TRACE
	         UART_Transmit_Str("TMR1IE, PEIE & GIE are enabled, interrupt service \r"); 
	       #endif	       
  	     break;
	     case TMR1_POLLING_SERVICE:
		    PIE1bits.TMR1IE = 0; //disable the Timer1 overflow interrupt 
		   #ifdef TRACE
	          UART_Transmit_Str("TMR1IE is disabled, polling service \r"); 
	       #endif
		 break;
	  }
	   #ifdef TRACE
         UART_Transmit_Str("T1CON config : 0x");
         UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, T1CON);
	     UART_Transmit_Char('\r');
         UART_Transmit_Str("Timer1 start running set for expiry : ");
         UART_Transmit_Num(DISP_FLAG_NUM_DIGIT5, timer1_req_time_delay_in_milli_sec); 
	     UART_Transmit_Str(" millisecs \r");          	  
      #endif
	  
      T1CONbits.TMR1ON = 1 ; //Enables Timer1 and timer1 runs
}   
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void Timer1_Stop()
{
	//if(timer1_cur_run_state != TMR1_STOP_STATE)
	{
	   T1CONbits.TMR1ON = 0 ; //stops Timer1.
	   PIE1bits.TMR1IE = 0; //disable the Timer1 overflow interrupt 
	   TMR1IF = 0;
	   timer1_cur_run_state = TMR1_STOP_STATE;
	   timer1_cur_service_type = TMR1_INVALID_SERVICE;
	   
	   //Commited due to stack overflow
	  /* #ifdef TRACE 
	     UART_Transmit_Str("Timer1 is stopped \r");
	   #endif */	 
	}   
}	
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void Timer1_Prescale()
{
	unsigned int i;
	
   timer1_prescale = 1;
   timer1_prescale_shift= 0;
   if(T1CKPS0 == 1)
   {
      timer1_prescale_shift |= 0x01;           
   }
   if(T1CKPS1 == 1)
   {
     timer1_prescale_shift |= 0x02;
   }
   for(i = 1; i <= timer1_prescale_shift; ++i)
   {
      timer1_prescale *= 2;
   }  
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void Timer1_Load_Init_Val_Calc(const unsigned long int set_timer1_tick_in_milli_sec)
{
	unsigned long int inc_timer1;
	unsigned int timer1_adjust_init_val;
	
/*	#ifdef TRACE
       UART_Transmit_Str("Timer1 Prescaler : ");
       UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, timer1_prescale );
	   UART_Transmit_Char('\r');		
    #endif */
   
	switch(timer1_prescale)
    {
	   case 1:
	      timer1_adjust_init_val = 2;
       break;
	   case 2:
          timer1_adjust_init_val = 1;
       break;
       default:  // for timer1_prescale > 2 , timer1_adjust_init_val = 0;
          timer1_adjust_init_val = 0;	   
    } 
    /* for timer0, TMR0 = (256 - ((timerPeriod_in_sec * Fosc_in_Hertz)/(4*prescaler)) + timer0_adjust_init_val), 
	where timer0_adjust_init_val = 2 for prescaler = 1, timer0_adjust_init_val =  1 for prescaler = 2,  timer0_adjust_init_val = 0 for prescaler > 2 */
    // inc_timer1  =      (unsigned long)((unsigned long)(_XTAL_FREQ * set_timer1_tick_in_milli_sec ) / (unsigned long)(OSC_PER_INST * TIME_UNIT_1_SEC_IN_MILLI_SEC  )) 
	inc_timer1 = 1000ul * set_timer1_tick_in_milli_sec; // for 1000ul = 4MHz / (4 * 1000), when _XTAL_FREQ  = 4MHz  
    timer1_init_val = ((65535UL) - (inc_timer1/timer1_prescale)) + 1 + timer1_adjust_init_val; 
    TMR1H = timer1_init_val / 256UL;
    TMR1L = timer1_init_val % 256UL; 
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
