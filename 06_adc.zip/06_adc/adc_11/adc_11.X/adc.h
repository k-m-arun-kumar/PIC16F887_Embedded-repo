/**************************************************************************
   FILE          :    adc.h
 
   PURPOSE       :    Analog to Digital library Header
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _ADC_H
 #define _ADC_H
 
 /* ---------------------- macro defination ------------------------------------------------ */
 
typedef enum {
	ADC_CH_00 = 0, ADC_CH_01, ADC_CH_02, ADC_CH_03, ADC_CH_04, ADC_CH_05, ADC_CH_06, ADC_CH_07, ADC_CH_08, ADC_CH_09, ADC_CH_10, ADC_CH_11, ADC_CH_12, ADC_CH_13   
} adc_channels;
  
/* ---------------------- data type defination --------------------------------------------- */

typedef enum {
	ADC_INVALID_SERVICE, ADC_INTP_SERVICE, ADC_POLLING_SERVICE
} adc_service_types;
	
 typedef enum {
	ADC_CLK_SRC_OSC_2 = 0b00000000, //A/D Conversion Clock, FOSC/2 
	ADC_CLK_SRC_OSC_8 = 0b01000000, //A/D Conversion Clock, FOSC/8 
	ADC_CLK_SRC_OSC_32 = 0b10000000, //A/D Conversion Clock, FOSC/32 
	ADC_CLK_SRC_OSC_INTR = 0b11000000 //A/D Conversion Clock, FRC (clock derived from a dedicated internal oscillator = 500 kHz max)
 } adc_clk_src_types;
 
  typedef enum {
	ADC_CHANNEL_SEL = 0b00000000, //Analog Channel Select
	ADC_CHANNEL_CVEF = 0b00111000, //Programmable on-chip voltage reference(CVREF) module (% of VDD)
	ADC_CHANNEL_FIXED_VREF = 0b0011110000 //Fixed Ref (0.6 volt fixed reference)
 } adc_channel_types;
 
 
  typedef enum {
	ADC_RESULT_RIGHT_FMT = 0b10000000, //A/D Conversion Result Format is Right justified
	ADC_RESULT_LEFT_FMT = 0b00000000, // A/D Conversion Result Format is left justified
 } adc_result_format_justfied_types;
 
 typedef enum {
	ADC_VREF_NEG_SRC_EXTR = 0b00100000, //source for Voltage Reference- is VREF- pin(external)
	ADC_VREF_NEG_SRC_INTR = 0b00000000 //source for Voltage Reference- is VSS (internal)
 } adc_vref_neg_src_types;
 
 typedef enum {
	ADC_VREF_PLUS_SRC_EXTR = 0b00010000, //source for Voltage Reference+ is VREF+ pin(external)
	ADC_VREF_PLUS_SRC_INTR = 0b00000000  //source for Voltage Reference+ is VDD (internal)
 } adc_vref_plus_src_types;
 
 /* -------------------- public variable declaration --------------------------------------- */
 
extern adc_channels adc_cur_channel;	
extern unsigned long analog_val_in_digital_ch[2]; 
extern adc_service_types adc_cur_service_type;

 /* -------------------- public prototype declaration --------------------------------------- */
void ADC_Start_Conv(const adc_service_types set_adc_service_type, const adc_clk_src_types  set_adc_clk_src_type, const adc_channel_types set_adc_channel_type, const adc_channels set_adc_channel,\
  const adc_result_format_justfied_types set_adc_result_format_justfied_type, const adc_vref_neg_src_types set_adc_vref_neg_src_type, const adc_vref_plus_src_types set_adc_vref_plus_src_type);
void ADC_Disable();
char Is_ADC_Converting();
void Encoded_To_Actual_Analog_Val_Calc(const unsigned long adc_value, unsigned long int full_scale_analog_val, \
   unsigned long int min_analog_val, unsigned long *const analog_val_in_digital_int, unsigned long *const analog_val_in_digital_frac );
void Encoded_To_Percent_Calc(const unsigned long adc_value, unsigned int *const percent_int, unsigned int *const percent_frac );   
void ADC_Conv_Over_Appl_Proc(unsigned long adc_value_channel);


#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
