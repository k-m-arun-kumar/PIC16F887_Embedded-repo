/**************************************************************************
   FILE          :    lcd.h
 
   PURPOSE       :    LCD Header
 
   AUTHOR        :     K.M. Arun Kumar alias Arunkumar Murugeswaran  
 
  KNOWN BUGS     :
	
  NOTE           :   20 * 4 LCD 
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 /* to avoid this header file to be included more than once, conditional directive is used  */
#ifndef _LCD_H
#define _LCD_H

/* refer LCD data sheet for write mode, read mode and instruction exec time */
#define LCD_WRITE_ENABLE_PULSE_IN_USEC       (1)
#define LCD_ADDR_SETUP_IN_USEC               (1)
#define LCD_ENABLE_PULSE_BEFORE_WRITE_IN_USEC (1)
#define LCD_DATA_SETUP_IN_USEC               (1)
#define LCD_WRITE_ENABLE_PULSE_DELAY_IN_USEC (1)
#define LCD_CLEAR_EXEC_IN_USEC             (1650)
#define LCD_CURSOR_RETURN_EXEC_IN_USEC     (1650)
#define LCD_OTHER_INST_EXEC_IN_USEC          (40)

#define INVALID_DATA               (0)
#define ALL_LINES                  (0)
#define NUM_LINE1                  (1)
#define NUM_LINE2                  (2)
#define NUM_LINE3                  (3)
#define NUM_LINE4                  (4)

#define NUM_COL1                   (1)

#define STATE_YES                   ('y')
#define STATE_NO                    ('n')

extern char lcd_avail_loc_within_limit;
extern unsigned int cur_disp_lcd_loc , cur_input_lcd_loc ;

/* -------------------- public prototype declaration --------------------------------------- */
void Delay_Time_By_Count(unsigned long int delay_time_in_count);
void LCD_Write_Pulse();
void LCD_Read_Pulse();
void Write_LCD_Command_NO_BF(const unsigned int lcd_cmd);
void Write_LCD_Command(const unsigned int lcd_cmd);
void Write_LCD_Data(const char lcd_disp_ch);
void LCD_Disp_Str(const char *lcd_disp_str);
void LCD_Disp_Num(const disp_num_types lcd_datanum_disp_format, const value_types lcd_disp_data_int);
void Goto_XY_LCD_Disp(const unsigned int start_line_num, const unsigned int start_col_num);
void Goto_XY_LCD_Input(unsigned int start_line_num, unsigned int start_col_num);
void From_Loc_to_XY_LCD(const unsigned int loc_lcd, unsigned int * const loc_lcd_line_num, unsigned int * const loc_lcd_col_num );
void From_XY_To_Loc_LCD(const unsigned int start_line_num, const unsigned int start_col_num, unsigned int * const lcd_loc);
void LCD_Init();
void Check_LCD_Busy();
unsigned int Read_LCD_Command();
void LCD_Clear_Screen();


#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
