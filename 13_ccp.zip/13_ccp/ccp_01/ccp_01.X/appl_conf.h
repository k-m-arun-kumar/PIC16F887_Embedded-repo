/**************************************************************************
   FILE          :    appl_conf.h
 
   PURPOSE       :   main application configuration Header
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran  
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _APPL_CONF_H
 #define _APPL_CONF_H 
 
/*------------------------------- LCD disp conf ------------------------------------------*/


/* -------------------------------Timer state conf ---------------------------------------*/
#define TMR2_PWM_STATE                     (0)
#define TMR2_STATE0_SERVICE_TYPE           TMR2_PWM_POLLING_SERVICE
#define TMR2_STATE0_PRESCALE               TMR2_PRESCALE_16
/* valid range for postscale is 1 to 16 */
#define TMR2_STATE0_POSTSCALE              1

/* ---------------------------------- ADC input signal val conf -------------------------- */

#define MAX_ANALOG_VALUE_CH0           (5U)
#define MIN_ANALOG_VALUE_CH0           (0U)
#define FULL_SCALE_ANALOG_VAL_CH0     (MAX_ANALOG_VALUE_CH0 - MIN_ANALOG_VALUE_CH0)

/* ------------------------------- application conf --------------------------------------*/

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
