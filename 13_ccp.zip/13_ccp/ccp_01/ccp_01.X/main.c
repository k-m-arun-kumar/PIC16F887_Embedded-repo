/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    :  
                     									 	 
AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran  
	 
KNOWN BUGS            : 

NOTE                  : 												
                       
                       
CHANGE LOGS           : 

*****************************************************************************/

#include "main.h"
#include "port.h"
#include "timer.h"
#include "adc.h"
#include "uart.h"
#include "io_conf.h"
#include "appl_conf.h"
value_types adc_value;

void LCD_Const_Disp();
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void main()
{	

   LCD_PORT_GPIO = 0x00;
   LCD_PORT = 0x00;   
   TRISE = 0x00;
   PORTE = 0x00;
   TRISBbits.TRISB1 = 0;
   TRISCbits.TRISC2 = 0; //CCP1's PWM 
   
   ANSEL = 0b00000001;
   ANSELH = 0x00;  
    
   /* commited due to stack overflow  */
   /* LCD_Init(); 	
   LCD_Const_Disp(); */
   UART_Init(); 
   
   ADC_READY_LED = LED_ON;
     
   PR2 = 0XFF;   //pwm period
   CCP1CON = 0x0D;
   __delay_ms(300); 
    Timer2_Run(TMR2_PWM_STATE, 0 );	
   while(1)
   {
	   if(ADCON0bits.GO == 0)
	   {
		   ADC_READY_LED = LED_OFF;
		   #ifdef TRACE 
		      UART_Transmit_Str("ADC_CONV \r");
		   #endif
           ADC_Start_Conv(ADC_POLLING_SERVICE, ADC_CLK_SRC_OSC_32, ADC_CHANNEL_SEL, ADC_CH_00, ADC_RESULT_RIGHT_FMT, ADC_VREF_NEG_SRC_INTR, ADC_VREF_PLUS_SRC_INTR);
		   while(ADCON0bits.GO == 1 || ADIF == 0);
		   #ifdef TRACE 
		      UART_Transmit_Str("ADC_READY \r");
		   #endif
		   ADC_READY_LED = LED_ON;
		   ADIF = 0;
		   adc_value.unsigned_val.val_in_bytes.value_byte[0] = ADRESL;
	       adc_value.unsigned_val.val_in_bytes.value_byte[1] = ADRESH & 0x03u; //A/D for PIC16F887 is 10 bit		   
		  
		  /* update PWM duty cycle value */
		   CCPR1L =  (unsigned int) (adc_value.unsigned_val.value_long >> 2) ;
		   CCP1CONbits.DC1B0 = adc_value.unsigned_val.val_in_bits.value_bit_8;
		   CCP1CONbits.DC1B1 = adc_value.unsigned_val.val_in_bits.value_bit_9;		  		   
	   }
   }   
}


/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
