/* ********************************************************************
FILE                   : gsm1.c

PROGRAM DESCRIPTION    :  when a char is typed in virtual terminal, and that char is received in PIC, then send a GSM SMS with a predefined text message to a GSM mobile number

AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
                                  
                       
CHANGE LOGS           : 

*****************************************************************************/  
#include <xc.h>
#include "string.h"
#define RS_PIN                           RE0
#define RW_PIN                           RE1
#define EN_PIN                           RE2
#define LCD_PORT                         PORTD
#define LCD_PORT_GPIO                    TRISD 

#define LED_OFF                                  (0)
#define LED_ON                                   (1)  
#define KEY_PRESSED                              (1) 
#define KEY_NOT_PRESSED                          (0)
#define STATE_YES                               ('y')
#define STATE_NO                                ('n')  

#define DISP_FLAG_NUM_DIGIT1                   (1)
#define DISP_FLAG_NUM_DIGIT2                   (2)
#define DISP_FLAG_NUM_DIGIT3                   (3)
#define DISP_FLAG_NUM_DIGIT4                   (4)
#define DISP_FLAG_NUM_DIGIT5                   (5)
#define DISP_FLAG_HEX_DIGIT1                   (6)
#define DISP_FLAG_HEX_DIGIT2                   (7)
#define DISP_FLAG_HEX_DIGIT3                   (8)
#define DISP_FLAG_HEX_DIGIT4                   (9) 

/* for 20 * 4 LCD disp */                             
#define BEGIN_LOC_LINE1                      (0X80)
#define BEGIN_LOC_LINE2                      (0xC0)
#define BEGIN_LOC_LINE3                      (0x94) 
#define BEGIN_LOC_LINE4                      (0xD4)
#define END_LOC_LINE1                        (0x93)
#define END_LOC_LINE2                        (0xD3)
#define END_LOC_LINE3                        (0xA7) 
#define END_LOC_LINE4                        (0xE7)

/* num cols = num of chars in a line */
#define MAX_COUNT_DELAY_TIME_LCDPULSE     (1000UL)
#define MAX_AVAIL_NUM_COLS                    (20)
#define CONFIGURE_MAX_NUM_LINES               (4)
#define MAX_AVAIL_NUM_LINES                   (4) 
#define MAX_AVAIL_NUM_CHARS_IN_LCD        (MAX_AVAIL_NUM_COLS * MAX_AVAIL_NUM_LINES) 
#define CONFIGURE_MAX_NUM_COLS             (MAX_AVAIL_NUM_COLS)
#define CONFIGURE_MAX_NUM_CHARS_IN_LCD    (CONFIGURE_MAX_NUM_LINES * CONFIGURE_MAX_NUM_COLS ) 
#define MAX_NUM_CHARS_INPUT_DATA          (MAX_AVAIL_NUM_COLS)  

#define INVALID_DATA              (0)
#define ALL_LINES                  (0)
#define NUM_LINE1                  (1)
#define NUM_LINE2                  (2)
#define NUM_LINE3                  (3)
#define NUM_LINE4                  (4)
#define NUM_COL1                   (1)
#define ERROR_LINE_NUM           NUM_LINE2  


#define LCD_ENABLE_PULSE_WIDTH            (1000ul)
//__CONFIG(0x3F3A);


void Delay_Time_By_Count(unsigned long int);
void LCD_Write_Pulse();
void LCD_Read_Pulse();
unsigned int Read_LCD_Command();
void Write_LCD_Command_Cannot_Check_BF(const unsigned int lcd_cmd);
void Write_LCD_Command (const unsigned int);
void Write_LCD_Data(const char);
void Data_Str_LCD_Disp(const char * );
void LCD_Init();
void Goto_XY_LCD_Disp(const unsigned int start_line_num, const unsigned int start_col_num);

void Init_UART();
void Transmit_UART(const char transmit_char);
char Receive_UART();
void GSM_Transmit_SMS(const char *send_SMS_to_mobile_number, const char *transmit_sms_message_str);
unsigned int read_command;

char lcd_avail_loc_within_limit = STATE_YES;
unsigned int cur_disp_lcd_loc = BEGIN_LOC_LINE1, cur_input_lcd_loc = BEGIN_LOC_LINE2;
void main()
{
	char received_uart_char;
	
   PORTD=0x00;
   TRISD=0X00;
   PORTC=0x00;
   TRISC=0X80;
   PORTE=0X00;
   TRISE=0X00;
   ANSEL=0X00;
   ANSELH=0X00;
   LCD_Init();
   Init_UART();
   while(1)
   {
	   
     received_uart_char = Receive_UART();
     GSM_Transmit_SMS("+91255841202", "HAI, I am Arun ....");
   }
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/

void Init_UART()
{
	SPBRG = 23;  /* (_XTAL_FREQ /(16 * baud_rate) ) - 1,  Osc freq = 3686400 Hz, Baud Rate = 9600  */
	BRG16 = 0 ; 
	BRGH  = 1;   /* Fast baud rate */
	SYNC  = 0;   /* Asynchrous mode */
    SPEN  = 1;   /* enable serial port pins */
	CREN  = 1;   /* enable continuous receive */
	SREN  = 0;   /* single receive disabled */
	TXIE  = 0;   /* disable transmit interrupt */
	RCIE  = 1;   /* enable receiver interrupt */
	TX9   = 0;   /* 8 bit transmission */
	RX9   = 0;   /* 8 bit reception */
	TXEN  = 0;   /* reset transmitter */
	TXEN  = 1;   /* enable transmitter */
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void Transmit_UART(const char transmit_char)
{
	TXREG = transmit_char;	
	while(TRMT == 0); /* wait as TSR is full */	
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
char Receive_UART()
{
	char receive_char = 0;
	const char framing_error_msg_disp[] = "FERR", overrun_error_msg_disp[] = "OERR";
	
	/* overrun error has occured */
	if(OERR == 1)
	{
		/* internal error : overrun error has occured */
		Goto_XY_LCD_Disp(ERROR_LINE_NUM, NUM_COL1);
	    Data_Str_LCD_Disp(overrun_error_msg_disp);
		CREN = 0; /* clear (CREN) continuous reception flag to clear OERR flag */
		CREN = 1; /* enable (CREN) continuous reception flag to continue receive datas */
	}
	while(RCIF == 0);	
	
	/* received char has framing error */
 	if(FERR == 1)  
    {  
       receive_char = RCREG;
	   /* internal error: framming error has occured */
	   Goto_XY_LCD_Disp(ERROR_LINE_NUM, NUM_COL1);
	   Data_Str_LCD_Disp(framing_error_msg_disp);
	   return 0;
 	}
	receive_char = RCREG;
	/* echo received char in virtual terminal */
	Transmit_UART(receive_char);
	return receive_char;
}

void GSM_Transmit(const char *gsm_transmit_str)
{
    while(*gsm_transmit_str)
   {
      TXREG = *gsm_transmit_str;
      while(TRMT == 0);  /* wait as TSR is full */	  
	   ++gsm_transmit_str; 
   }
}
void GSM_Transmit_SMS(const char *send_SMS_to_mobile_number, const char *transmit_sms_message_str)
{
   Transmit_UART('\r'); // send carriage return
   Transmit_UART('\n'); // send new line feed
   GSM_Transmit("AT");  // Check GSM is ready to use
   Transmit_UART('\r'); // send carriage return
   Transmit_UART('\n'); // send new line feed
  
   GSM_Transmit("AT+CMGF=1"); // send command for presentation format of message from modem as text = 1, PDU = 0. 
   Transmit_UART('\r');
   Transmit_UART('\n');
   GSM_Transmit("AT+CMGS="); // send command to send message from modem to network
   Transmit_UART('\"');
   GSM_Transmit(send_SMS_to_mobile_number);  // mobile number
   Transmit_UART('\"');
   Transmit_UART('\r');
   Transmit_UART('\n');
   GSM_Transmit(">");
   GSM_Transmit(transmit_sms_message_str); //send >along with transmit_sms_message_str to send_SMS_to_mobile_number
   
   Transmit_UART('\r');
   Transmit_UART('\n');
}


void LCD_Init()
{
	/* wait for more than 15ms after LCD VSS rises to 4.5V, Busy Flag in LCD (BF) cannot be checked */
	Delay_Time_By_Count(15000UL);
    Write_LCD_Command_Cannot_Check_BF(0x30);
	/* wait for more than 4.1 ms, Busy Flag in LCD (BF) cannot be checked */
	Delay_Time_By_Count(4100UL);
    Write_LCD_Command_Cannot_Check_BF(0x30);
	/* wait for more than 100 us, Busy Flag in LCD (BF) cannot be checked */
	Delay_Time_By_Count(100);
    Write_LCD_Command_Cannot_Check_BF(0x30);
	Write_LCD_Command(0x38);
	Write_LCD_Command(0x01);
	Write_LCD_Command(0x0E);
	Write_LCD_Command(0x06);  
	
}  
void LCD_Write_Pulse()
{
    EN_PIN = 1;
    Delay_Time_By_Count(LCD_ENABLE_PULSE_WIDTH);
    EN_PIN = 0;
    Delay_Time_By_Count(LCD_ENABLE_PULSE_WIDTH);
}
void LCD_Read_Pulse()
{
    EN_PIN = 0;
    Delay_Time_By_Count(LCD_ENABLE_PULSE_WIDTH);
    EN_PIN = 1;
    Delay_Time_By_Count(LCD_ENABLE_PULSE_WIDTH);	
}
void Write_LCD_Command_Cannot_Check_BF(const unsigned int lcd_cmd)
{
   RW_PIN = 0;
   RS_PIN = 0; 
   LCD_PORT = lcd_cmd;
   LCD_Write_Pulse();
}

void Check_LCD_Busy()
{
    LCD_PORT_GPIO = 0xFF;
	LCD_PORT = 0x00;
	RW_PIN = 1;
    RS_PIN = 0;
    
    /* busy flag = Bit 7 in LCD PORT, if busy flag == 1, wait till busy flag = 0, then any operation on LCD can be done */
   while(((read_command = Read_LCD_Command()) & 0x80) == 0x80)
   {
	   LCD_Read_Pulse();
	   LCD_Read_Pulse();
	   EN_PIN = 0;
	   Delay_Time_By_Count(LCD_ENABLE_PULSE_WIDTH);
   }	   
}
void Write_LCD_Command(const unsigned int lcd_cmd)
{
   Check_LCD_Busy();
   LCD_PORT_GPIO = 0x00;
   LCD_PORT = 0x00;
   RW_PIN = 0;
   RS_PIN = 0; 
   LCD_PORT = lcd_cmd;
   LCD_Write_Pulse();
}
 void Write_LCD_Data(const char lcd_data)
{
	 Check_LCD_Busy();
	 LCD_PORT_GPIO = 0x00; 
     LCD_PORT = 0x00;	 
     RW_PIN = 0;
     RS_PIN = 1;
     LCD_PORT = lcd_data;
     LCD_Write_Pulse();
}
void Data_Str_LCD_Disp(const char *char_ptr)
{ 
       while(*char_ptr)
       {	           
           Write_LCD_Data(*(char_ptr++));		  
       }
}
void Delay_Time_By_Count(unsigned long int time_delay)
{
     while(time_delay--);
}
unsigned int Read_LCD_Command()
{
	 LCD_Write_Pulse();
	 read_command = LCD_PORT;	 
     return read_command;
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 29   
-*------------------------------------------------------------*/
void Goto_XY_LCD_Disp(const unsigned int start_line_num, const unsigned int start_col_num)
{
	/* max 4 lines and 20 columns */
	/* for us, lcd line starts from 1, but for uC, line starts from 0 */
	/* for us, lcd col starts from 1, but for uC, col starts from 0 */
    unsigned int start_line_lcd = start_line_num - 1, start_col_lcd = start_col_num - 1, error_disp_start_loc; 
	lcd_avail_loc_within_limit = STATE_YES;
	
   if(start_line_num <= CONFIGURE_MAX_NUM_LINES && start_col_num <= CONFIGURE_MAX_NUM_COLS )
   {
      switch(start_line_num)
	 {
		 case NUM_LINE1:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE1;
		   break;
		 case NUM_LINE2:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE2;
		   break;
		 case NUM_LINE3:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE3;
		   break;
		  case NUM_LINE4:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE4;
		   break;		 
	 }	
      cur_disp_lcd_loc = cur_disp_lcd_loc + start_col_lcd;
      Write_LCD_Command(cur_disp_lcd_loc);       
   }
   else
   {
	   /* error due to invalid lcd DISP loc  */
	     lcd_avail_loc_within_limit = STATE_NO;	
   }	   
} 
