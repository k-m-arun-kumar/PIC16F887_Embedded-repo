/* ********************************************************************
FILE                   : sw9.c

PROGRAM DESCRIPTION    :  ON_SW  to continue Glow  to  next pin, OFF_SW to switch off  the last  glowed pin 			 
	 
AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  :
 
USED:              
            Desktop OS: Windows 7 Professional (32 bit) (Intel X64)       
     			   IDE: Developed by using Microchip's MPLAB IDE v8.6 using HI TECH Compiler
                   CADD: Simulated in Proteus 8.0 Professional 
                   HW : Tested OK in PIC development board by www.alselectro.com 
		    Programmer: PICkit 3 
                       
CHANGE LOGS           : 

*****************************************************************************/
/* */
#define HI_TECH_COMPILER
#ifdef HI_TECH_COMPILER 
  #include <pic.h>
  __CONFIG(0x2ce4);
#else
   #include <xc.h> 
    // #pragma config statements should precede project file includes.
    // Use project enums instead of #define for ON and OFF.
    // 'C' source line config statements
    // PIC16F887 Configuration Bit Settings
    
    // CONFIG1
    #pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
    #pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
    #pragma config PWRTE = ON       // Power-up Timer Enable bit (PWRT enabled)
    #pragma config MCLRE = ON       // RE3/MCLR pin function select bit (RE3/MCLR pin function is MCLR)
    #pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
    #pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
    #pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
    #pragma config IESO = ON        // Internal External Switchover bit (Internal/External Switchover mode is enabled)
    #pragma config FCMEN = ON       // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is enabled)
    #pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

   // CONFIG2
   #pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
   #pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

#endif
#define ON_SW       RB0
#define OFF_SW    RB1
#define _XTAL_FREQ (4000000)

#define KEY_NOT_PRESSED  (0U)
#define KEY_PRESSED      (1U)


void set_bit(unsigned int bit_pos, unsigned int state );
void main()
{
          unsigned int i = 0, flag_on = 0, flag_off= 1; 
          TRISA = 0x00;
          PORTA = 0x00;
		  TRISB = 0x03; 
          PORTB = 0x00;         
        
         ANSEL = 0x00;
        ANSELH = 0x00; 
       for(;;)
        {
               if(ON_SW == 1 )
               {
				   __delay_ms(50);
				   if(ON_SW == 1)
				   {
					  while(ON_SW == 1); 
                      if(i < 4)
                      {       
                         PORTA = PORTA | 0x01   << i ;
		                 ++i;
                      }
                      if(i >=4) 
                      {  
                          i = 4 ;
                      }
				   }
              } 
               if(OFF_SW  == 1 )
              {
				  __delay_ms(50);
				   if(OFF_SW == 1)
				   {             
                      while(OFF_SW == 1);   
                      if(i <=0)
                      {
                         i  =0;                                
                      } 
                      if( i > 0)
                      {   
                         --i;
                        PORTA &=  ~(0x01  << i ); 
                      } 
				   }					  
             }     
    
        }         
}
void set_bit(unsigned int bit_pos, unsigned int state )
{
	 unsigned int shift_byte =  0x01 << bit_pos ;
	 if(state == 1)
	   PORTA |=  shift_byte;
     else
	   PORTA  &= ~shift_byte;                 		 
	 
}
