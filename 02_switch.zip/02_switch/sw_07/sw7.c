/* ********************************************************************
FILE                   : sw7.c

PROGRAM DESCRIPTION    :  INTER LOCKING switch for one O/P pin						 
	 
AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
 
USED:              
            Desktop OS: Windows 7 Professional (32 bit) (Intel X64)       
     			   IDE: Developed by using Microchip's MPLAB IDE v8.6
                   CADD: Simulated in Proteus 8.0 Professional 
                   HW : Tested OK in PIC development board by www.alselectro.com 
		    Programmer: PICkit 3 
                       
CHANGE LOGS           : 

*****************************************************************************/

#include <pic.h>
#define LED      RA1
#define SW1      RA2
#define SW2      RA3
#define  RESET       RA4
#define _XTAL_FREQ (4000000)
__CONFIG(0X2CE4);

#define KEY_NOT_PRESSED  (0U)
#define KEY_PRESSED      (1U)
int flag=1,flag1=1;
void main()
{
         PORTA = 0x00;
         TRISA   = 0x1C;
          ANSEL = 0x00;
         ANSELH = 0x00;
          for(;;)
          {
               if(SW1 == 1&&  flag  ==1   )
                {    
			        __delay_ms(50);
					if(SW1 == 1)
					{
                        while(SW1 == 1 );                                  
                        LED = ~LED; 
                        if(LED == 1)   
                            flag1=0;
                        if(LED  ==0)     
                           flag1 = 1;
					}
               }
                if(SW2 ==1  && flag1 ==1 )
               {   
                     __delay_ms(50);
					 if(SW2 == 1)
					 {
                        while(SW2 == 1); 
					    LED = ~LED;
                        if(LED == 1)   
                            flag=0;
                         if(LED  ==0)     
                           flag = 1;
				     }
               }
               if(RESET ==1 )
              { 
		          __delay_ms(50);
				 if(RESET == 1)
				 {
					 while(RESET == 1);
                    flag=flag1=1;
                    LED = 0;   
				 }					
             }   
       }             
}
