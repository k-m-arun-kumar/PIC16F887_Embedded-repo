/* ********************************************************************
FILE                   : sw8.c

PROGRAM DESCRIPTION    :  					 
	 
AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
 
USED:              
            Desktop OS: Windows 7 (32 bit) (Intel X64)       
     			   IDE: Developed by using Microchip's MPLAB IDE v8.6
                   CADD: Simulated in Proteus 8.0 Professional 
                  
CHANGE LOGS           : 

*****************************************************************************/

#include <pic.h>
#define SW       RB0
#define _XTAL_FREQ (4000000)
__CONFIG(0X2CE4);

#define KEY_NOT_PRESSED  (0U)
#define KEY_PRESSED      (1U)
void delay_time(unsigned int);
void main()
{
          unsigned int i = 0;  
		   TRISA = 0x00;
          PORTA = 0x00;
		  TRISB = 0x01; 
         PORTB = 0x00;        
         ANSEL = 0x00;
        ANSELH = 0x00; 
       for(;;)
        {
               if(SW == 1)
              {
				  __delay_ms(50);
				  if(SW == 1)
				  {
                      while(SW == 1);
					  PORTA = 0x01   << i;
                     //  delay_time(1000);
                      if(i++ ==   8)    
                           i  = 0;
			       }
              }     
        }         
}
void delay_time(unsigned int time)
{
      int i = 0, j = 0;
      for(i =0; i < time; ++i)
           for(j =0; j < 100; ++j);     
}
