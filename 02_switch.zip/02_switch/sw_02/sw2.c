/* ********************************************************************
FILE                   : sw2.c

PROGRAM DESCRIPTION    : 								 
	 
AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
 
USED:              
            Desktop OS: Windows 7 Professional (32 bit) (Intel X64)       
     			   IDE: Developed by using Microchip's MPLAB IDE v8.6
                   CADD: Simulated in Proteus 8.0 Professional 
                   HW : Tested in PIC development board by www.alselectro.com 
		    Programmer: PICkit 3 
                       
CHANGE LOGS           : 

*****************************************************************************/

#include <pic.h>
#define LED1  RA0
#define LED2   RA1
#define SW_SET  RA2
#define _XTAL_FREQ (4000000)
__CONFIG(0X2CE4);

#define KEY_NOT_PRESSED  (0U)
#define KEY_PRESSED      (1U)

unsigned int Set_Switch_Press_Proc();
int i;
void main()
{
	    unsigned int return_status;
		
	   	TRISA   =  0x04;
        PORTA=0x00;
          
          ANSEL  = 0x00;
          ANSELH = 0x00;
          while(1)
          {
             if((return_status = Set_Switch_Press_Proc()) == KEY_PRESSED)
             {				 
                 if(i == 0)
                 {                                     
                     LED1  =  1;
                     LED2  =  0;
                     ++i;
                 }
            }
			 if((return_status = Set_Switch_Press_Proc()) == KEY_PRESSED) 
			 {
                if(i == 1)
                {
                     LED1  =  0;
                     LED2   = 1;
	                 i = 0;
                }
             }
		  }
         
}

unsigned int Set_Switch_Press_Proc()
{
	unsigned int return_status = KEY_NOT_PRESSED;
	unsigned long int cnt_long_key_press_timeout = 65535UL;
	
	if(SW_SET == KEY_PRESSED )
	{
	   __delay_ms(50); //switch debounce 
       if(SW_SET == KEY_PRESSED )
       {
		
	    	while( SW_SET == KEY_PRESSED && --cnt_long_key_press_timeout != 0);
		    if(cnt_long_key_press_timeout != 0)
		    {
			   return KEY_PRESSED;
	     	}
	    }
	}	  
	return KEY_NOT_PRESSED;	
}
