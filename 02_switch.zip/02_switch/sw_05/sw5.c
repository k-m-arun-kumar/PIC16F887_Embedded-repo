/* ********************************************************************
FILE                   : sw5.c

PROGRAM DESCRIPTION    :   3 WAY SWITCH						 
	 
AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
 
USED:              
            Desktop OS: Windows 7 Professional (32 bit) (Intel X64)       
     			   IDE: Developed by using Microchip's MPLAB IDE v8.6
                   CADD: Simulated in Proteus 8.0 Professional 
                    tested OK in development board
                                          
CHANGE LOGS           : 

*****************************************************************************/

/*  */
#include <pic.h>
#define LED1   RA0
#define SW1  RA1
#define SW2   RA2
#define SW3   RA3
#define _XTAL_FREQ (4000000)
__CONFIG(0X2CE4);

#define KEY_NOT_PRESSED  (0U)
#define KEY_PRESSED      (1U)
void main()
{
        
          PORTA = 0x00;
          TRISA =  0x0E;
          ANSEL  = 0x00;
          ANSELH = 0x00;
		  __delay_ms(300);
       for(;;)
       {
           if(SW1 ==1 ||  SW2 ==1 || SW3 == 1 )
           {
			  __delay_ms(50);
              if(SW1 ==1 ||  SW2 ==1 || SW3 == 1)
			  {				  
                  while(SW1  ==1 || SW2 ==1 || SW3 == 1);
			      LED1=~LED1;  
			  }
          }
     }
}
