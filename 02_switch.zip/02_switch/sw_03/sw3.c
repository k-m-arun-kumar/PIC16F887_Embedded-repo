/* ********************************************************************
FILE                   : sw3.c

PROGRAM DESCRIPTION    : toggle led for every switch press								 
	 
AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
 
USED:              
            Desktop OS: Windows 7 Professional (32 bit) (Intel X64)       
     			   IDE: Developed by using Microchip's MPLAB IDE v8.6
                   CADD: Simulated in Proteus 8.0 Professional 
                   HW : Tested OK in PIC development board by www.alselectro.com 
		    Programmer: PICkit 3 
                       
CHANGE LOGS           : 

*****************************************************************************/

#include <pic.h>
#define LED1   RA1
#define SW_SET  RA2
#define _XTAL_FREQ (4000000)
__CONFIG(0X2CE4);

#define KEY_NOT_PRESSED  (0U)
#define KEY_PRESSED      (1U)

unsigned int Set_Switch_Press_Proc();
unsigned int Reset_Switch_Press_Proc();
void main()
{
	      TRISA   =  0x04;
          PORTA = 0x00;
		
          ANSEL  = 0x00;
          ANSELH = 0x00;
       for(;;)
       {
           if((return_status = Set_Switch_Press_Proc()) == KEY_PRESSED) 
			   LED1=~LED1;
       }
}
unsigned int Set_Switch_Press_Proc()
{
	unsigned int return_status = KEY_NOT_PRESSED;
	unsigned long int cnt_long_key_press_timeout = 65535UL;
	
	if(SW_SET == KEY_PRESSED )
	{
	   __delay_ms(100); //switch debounce 
       if(SW_SET == KEY_PRESSED )
       {
		
	    	while( SW_SET == KEY_PRESSED && --cnt_long_key_press_timeout != 0);
		    if(cnt_long_key_press_timeout != 0)
		    {
			   return KEY_PRESSED;
	     	}
	    }
	}	  
	return KEY_NOT_PRESSED;	
}

unsigned int Reset_Switch_Press_Proc()
{
	unsigned int return_status = KEY_NOT_PRESSED;
	unsigned long int cnt_long_key_press_timeout = 65535UL;
	
	if(SW_RESET== KEY_PRESSED )
	{
	   __delay_ms(100); //switch debounce 
       if(SW_RESET == KEY_PRESSED )
       {
		
	    	while( SW_RESET == KEY_PRESSED && --cnt_long_key_press_timeout != 0);
		    if(cnt_long_key_press_timeout != 0)
		    {
			   return KEY_PRESSED;
	     	}
	    }
	}	  
	return KEY_NOT_PRESSED;	
}
