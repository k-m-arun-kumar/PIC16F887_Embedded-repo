/* ********************************************************************
FILE                   : sw1.c

PROGRAM DESCRIPTION    : 								 
	 
AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
 
USED:              
            Desktop OS: Windows 7 Professional (32 bit) (Intel X64)       
     		   IDE: Developed by using Microchip's MPLAB IDE v8.6
                  CADD: Simulated in Proteus 8.0 Professional 
                   HW : Tested OK in PIC development board by www.alselectro.com 
		 Programmer: PICkit 3 
                       
CHANGE LOGS           : 

*****************************************************************************/
#include <pic.h>
#define _XTAL_FREQ (4000000)
__CONFIG(0X2CE4);
#define LED    RA0
#define SW_SET     RA1
#define SW_RESET   RA2

#define KEY_NOT_PRESSED  (0U)
#define KEY_PRESSED      (1U)

unsigned int Set_Switch_Press_Proc();
unsigned int Reset_Switch_Press_Proc();
void main()
{
	unsigned int return_status;
          TRISA   =  0x06;
		  PORTA   = 0x00;
          ANSEL  = 0x00;
          ANSELH = 0x00;
		  __delay_ms(300);
          while(1)
          {
                if((return_status = Set_Switch_Press_Proc()) == KEY_PRESSED) 
                     LED = 1;              
				 if(return_status = Reset_Switch_Press_Proc() == KEY_PRESSED)
					 LED = 0;
           }
        
}

unsigned int Set_Switch_Press_Proc()
{
	unsigned int return_status = KEY_NOT_PRESSED;
	unsigned long int cnt_long_key_press_timeout = 65535UL;
	
	if(SW_SET == KEY_PRESSED )
	{
	   __delay_ms(100); //switch debounce 
       if(SW_SET == KEY_PRESSED )
       {
		
	    	while( SW_SET == KEY_PRESSED && --cnt_long_key_press_timeout != 0);
		    if(cnt_long_key_press_timeout != 0)
		    {
			   return KEY_PRESSED;
	     	}
	    }
	}	  
	return KEY_NOT_PRESSED;	
}

unsigned int Reset_Switch_Press_Proc()
{
	unsigned int return_status = KEY_NOT_PRESSED;
	unsigned long int cnt_long_key_press_timeout = 65535UL;
	
	if(SW_RESET== KEY_PRESSED )
	{
	   __delay_ms(100); //switch debounce 
       if(SW_RESET == KEY_PRESSED )
       {
		
	    	while( SW_RESET == KEY_PRESSED && --cnt_long_key_press_timeout != 0);
		    if(cnt_long_key_press_timeout != 0)
		    {
			   return KEY_PRESSED;
	     	}
	    }
	}	  
	return KEY_NOT_PRESSED;	
}
