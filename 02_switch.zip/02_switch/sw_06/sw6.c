/* ********************************************************************
FILE                   : sw6.c

PROGRAM DESCRIPTION    :  INTER LOCKING switch							 
	 
AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
 
USED:              
            Desktop OS: Windows 7 Professional (32 bit) (Intel X64)       
     			   IDE: Developed by using Microchip's MPLAB IDE v8.6
                   CADD: Simulated in Proteus 8.0 Professional 
                   HW : Tested OK in PIC development board by www.alselectro.com 
		    Programmer: PICkit 3 
                       
CHANGE LOGS           : 

*****************************************************************************/
#include <pic.h>
#define LED1    RA0
#define LED2    RA1
#define SW1      RA2
#define SW2      RA3
#define  RESET       RA4
#define _XTAL_FREQ (4000000)
__CONFIG(0X2CE4);

#define KEY_NOT_PRESSED  (0U)
#define KEY_PRESSED      (1U)
void main()
{
         PORTA = 0x00;
         TRISA   = 0x1C;
          ANSEL = 0x00;
         ANSELH = 0x00;
          for(;;)
          {
               if(SW1 == 1 && LED2 == 0 && RESET ==  0)
                {   
                   __delay_ms(50);			
                   if(SW1 == 1) 
				   {					   
                       while(SW1 == 1);
				       LED1 = ~LED1; 
				   }				   
               }
                if(SW2 == 1 && LED1 == 0 && RESET ==   0)
               {   
                   __delay_ms(50);
                  if(SW2 == 1)
				  {					  
				     while(SW2 == 1); 
					 LED2 = ~LED2;
				  }
               }
                if(RESET == 1)
               {
                    __delay_ms(50);			
                   if(RESET == 1)
				   {					   
                      while(RESET == 1); 
					  LED1 = 0;
                      LED2  = 0;
				   }
               }                                                    
          }   
}                         
