/**************************************************************************
   FILE          :    keyboard.c
 
   PURPOSE       :     
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 #include "main.h"
 #include "port.h"
 #include "uart.h"
 #include "lcd.h"
 #include "keyboard.h"
 #include "appl.h"
 #include "io_conf.h"
 #include "appl_conf.h"
 #include "string.h"
 
char cur_pressed_key_or_sw;
char keypad_keys_enable_flag = STATE_YES, keyboard_input_enable_flag = STATE_YES, enter_sw_enable_flag = STATE_NO, backspace_sw_enable_flag = STATE_NO;

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : switch debounce, long key press and no key press timeout is not implemented.
                 long key press and no key press timeout is implemented in lcd_14

Func ID        : 32   
-*------------------------------------------------------------*/
int Keyboard_Proc()
{
	char keypad_char[]   = {'1','2', '3', '4', '5', '6','7','8','9','*', '0', '#'};
	
	if(cur_data_conf_parameter.cur_data_input_dev_id == INPUT_DEV_ID_KEYBOARD && keyboard_input_enable_flag == STATE_YES) 
    {  
        switch( cur_data_conf_parameter.cur_data_rcv_mode) 
	    {
			//enter data till enter key is pressed
		    case CUR_DATA_RCV_MODE_TILL_TERMINATOR:
	           if(cur_data_status.cur_data_num_chars_rcvd + 1 > KEYPAD_CONF_MAX_NUM_CHARS_ENTERED)
	           {
		           cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag = STATE_YES;
                   cur_data_status.cur_data_valid_end_rcvd_flag = STATE_NO; 
			       return SUCCESS;
		       }
		    break;
			//enter data till max nums of chars is reached
            case CUR_DATA_RCV_MODE_TILL_ALLOCATED:	
         		if(cur_data_conf_parameter.cur_data_allocated_max_num_chars_to_rcv <= KEYPAD_CONF_MAX_NUM_CHARS_ENTERED ) 
		        {
			       if(cur_data_status.cur_data_num_chars_rcvd >= cur_data_conf_parameter.cur_data_allocated_max_num_chars_to_rcv)
			       {
				       cur_data_status.cur_data_rcvd_str[cur_data_status.cur_data_num_chars_rcvd] = NULL_CHAR;	
                       cur_data_status.cur_data_valid_end_rcvd_flag = STATE_NO;
                       cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag = STATE_YES; 					
			       }	
                }
		        else
		        {
				    #ifdef TRACE_ERROR
			           UART_Transmit_Str("ERR: keyboard set max chars to enter > configured \r");
			 	    #endif
				    return FAILURE;
		        } 
		    break;
		}			
				
	    KEYPAD_PHONE_ROWA  = STATE_ON;
        KEYPAD_PHONE_ROWB  = STATE_OFF;
        KEYPAD_PHONE_ROWC  = STATE_OFF;
        KEYPAD_PHONE_ROWD  = STATE_OFF; 
        if(KEYPAD_PHONE_COL1 == KEY_PRESSED)
        {
	        cur_pressed_key_or_sw = keypad_char[0];//latest pressed key/switch					 
	        if(keypad_keys_enable_flag == STATE_YES &&  cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag == STATE_NO && cur_data_status.cur_data_valid_end_rcvd_flag == STATE_NO)
            {
	    		 while(KEYPAD_PHONE_COL1 == KEY_PRESSED);
		         Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw);
			}  
		}			
        if(KEYPAD_PHONE_COL2 == KEY_PRESSED)
        {
		    cur_pressed_key_or_sw = keypad_char[1];//latest pressed key/switch
		    if(keypad_keys_enable_flag == STATE_YES &&  cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag == STATE_NO && cur_data_status.cur_data_valid_end_rcvd_flag == STATE_NO)
            {
	    		 while(KEYPAD_PHONE_COL2 == KEY_PRESSED);
		         Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw);
			}  
		}	
        if(KEYPAD_PHONE_COL3 == KEY_PRESSED)
        {
	        cur_pressed_key_or_sw = keypad_char[2];//latest pressed key/switch	
			if(keypad_keys_enable_flag == STATE_YES &&  cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag == STATE_NO && cur_data_status.cur_data_valid_end_rcvd_flag == STATE_NO)
            {
	    		 while(KEYPAD_PHONE_COL3 == KEY_PRESSED);
		         Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw);
			} 
		}
	    KEYPAD_PHONE_ROWA  = STATE_OFF;
        KEYPAD_PHONE_ROWB  = STATE_ON;
        KEYPAD_PHONE_ROWC  = STATE_OFF;
        KEYPAD_PHONE_ROWD  = STATE_OFF; 
		
        if(KEYPAD_PHONE_COL1 == KEY_PRESSED)
        {
		    cur_pressed_key_or_sw = keypad_char[3];//latest pressed key/switch					  
		    if(keypad_keys_enable_flag == STATE_YES &&  cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag == STATE_NO && cur_data_status.cur_data_valid_end_rcvd_flag == STATE_NO)
            {
	    		 while(KEYPAD_PHONE_COL1 ==  KEY_PRESSED);
		         Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw);
			}  
		}		        
        if(KEYPAD_PHONE_COL2 == KEY_PRESSED)
        {
	        cur_pressed_key_or_sw = keypad_char[4];//latest pressed key/switch					  
            if(keypad_keys_enable_flag == STATE_YES &&  cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag == STATE_NO && cur_data_status.cur_data_valid_end_rcvd_flag == STATE_NO)
            {
	    		 while(KEYPAD_PHONE_COL2 == KEY_PRESSED);
		         Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw);
			}  
		}	 
        if(KEYPAD_PHONE_COL3 == KEY_PRESSED)
        {
	        cur_pressed_key_or_sw = keypad_char[5];//latest pressed key/switch					  
	        if(keypad_keys_enable_flag == STATE_YES &&  cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag == STATE_NO && cur_data_status.cur_data_valid_end_rcvd_flag == STATE_NO)
            {
	    		 while(KEYPAD_PHONE_COL3 == KEY_PRESSED);
		         Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw);
			} 
		}   	  
        KEYPAD_PHONE_ROWA  = STATE_OFF;
        KEYPAD_PHONE_ROWB  = STATE_OFF;
        KEYPAD_PHONE_ROWC  = STATE_ON;
        KEYPAD_PHONE_ROWD  = STATE_OFF;
		
        if(KEYPAD_PHONE_COL1 == KEY_PRESSED)
        {
	        cur_pressed_key_or_sw = keypad_char[6];//latest pressed key/switch
			if(keypad_keys_enable_flag == STATE_YES &&  cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag == STATE_NO && cur_data_status.cur_data_valid_end_rcvd_flag == STATE_NO)
            {
	    		 while(KEYPAD_PHONE_COL1 == KEY_PRESSED);
		         Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw);
			}  
		}	
        if(KEYPAD_PHONE_COL2 == KEY_PRESSED)
        {
	        cur_pressed_key_or_sw = keypad_char[7];//latest pressed key/switch					 
	        if(keypad_keys_enable_flag == STATE_YES &&  cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag == STATE_NO && cur_data_status.cur_data_valid_end_rcvd_flag == STATE_NO )
            {
	    		 while(KEYPAD_PHONE_COL2 == KEY_PRESSED);
		         Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw);
			}  
		}	  
        if(KEYPAD_PHONE_COL3 == KEY_PRESSED)
        {
	        cur_pressed_key_or_sw = keypad_char[8];//latest pressed key/switch
	        if(keypad_keys_enable_flag == STATE_YES &&  cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag == STATE_NO && cur_data_status.cur_data_valid_end_rcvd_flag == STATE_NO && cur_data_status.cur_data_valid_end_rcvd_flag == STATE_NO)
            {
	    		 while(KEYPAD_PHONE_COL3 ==KEY_PRESSED);
		           Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw);
			} 
		}     	      
        KEYPAD_PHONE_ROWA  = STATE_OFF;
        KEYPAD_PHONE_ROWB  = STATE_OFF;
        KEYPAD_PHONE_ROWC  = STATE_OFF;
        KEYPAD_PHONE_ROWD  = STATE_ON; 
        if(KEYPAD_PHONE_COL1 == KEY_PRESSED)
        {
	        cur_pressed_key_or_sw = keypad_char[9];//latest pressed key/switch
		    if(keypad_keys_enable_flag == STATE_YES && cur_data_conf_parameter.cur_data_input_can_also_nonnum_key == STATE_YES && cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag == STATE_NO && cur_data_status.cur_data_valid_end_rcvd_flag == STATE_NO)
            {
	            while(KEYPAD_PHONE_COL1 == KEY_PRESSED);
		        Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw);
			}  
		}			
        if(KEYPAD_PHONE_COL2 == KEY_PRESSED)
        {
		    cur_pressed_key_or_sw = keypad_char[10];//latest pressed key/switch
		    if(keypad_keys_enable_flag == STATE_YES &&  cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag == STATE_NO && cur_data_status.cur_data_valid_end_rcvd_flag == STATE_NO)
            {
	    		 while(KEYPAD_PHONE_COL2 == KEY_PRESSED);
		         Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw);
			}  
		}	                                                
        if(KEYPAD_PHONE_COL3 == KEY_PRESSED)
        {
	        cur_pressed_key_or_sw = keypad_char[11];//latest pressed key/switch
			if(keypad_keys_enable_flag == STATE_YES && cur_data_conf_parameter.cur_data_input_can_also_nonnum_key == STATE_YES && cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag == STATE_NO && cur_data_status.cur_data_valid_end_rcvd_flag == STATE_NO)
            {
	            while(KEYPAD_PHONE_COL3 == KEY_PRESSED);
		        Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw);
			} 
		}     	   		  
        if(ENTER_SW == KEY_PRESSED)
        {
	     	 cur_pressed_key_or_sw = ENTER_SW_CODE;//latest pressed key/switch
		     if(enter_sw_enable_flag == STATE_YES && cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag == STATE_NO && cur_data_status.cur_data_valid_end_rcvd_flag == STATE_NO)
			 {	 
		        /* rcvd char is enter key, and act as data terminator char */
	            cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag = STATE_NO;
				cur_data_status.cur_data_valid_end_rcvd_flag = STATE_YES;
				while(ENTER_SW == KEY_PRESSED );
                After_Switch_Stoke_Proc(cur_pressed_key_or_sw); 	      		 
             }
		}							 
        if(BACKSPACE_SW == KEY_PRESSED )		 
        {
            cur_pressed_key_or_sw = BACKSPACE_SW_CODE;//latest pressed key/switch
		   	if(backspace_sw_enable_flag == STATE_YES && cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag == STATE_NO && cur_data_status.cur_data_valid_end_rcvd_flag == STATE_NO)
			{
			    while(BACKSPACE_SW == KEY_PRESSED ); 
	            After_Switch_Stoke_Proc(cur_pressed_key_or_sw); 
            }					  
        }
		return SUCCESS;
    }
	else
	{
		#ifdef TRACE_ERROR
		   UART_Transmit_Str("ERR: try to use keypad or oper sw but keypad and oper sw are disabled \r");
		#endif
	}
    return FAILURE;	
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 11  
-*------------------------------------------------------------*/
void Entered_Key_No_Long_Press_Proc(const char cur_key_char)
{
	/* make sure that entered key is within max available lcd loc and line, currently cur_data_conf_parameter.cur_data_allocated_max_num_chars_to_rcv 
	 sures that entered key is within max available lcd loc and within max line */
	 unsigned int lcd_cur_input_loc_line_num, lcd_cur_input_loc_col_num, lcd_next_input_loc_line_num, lcd_next_input_loc_col_num;
	
   if(cur_data_conf_parameter.cur_data_output_dev_id == OUTPUT_DEV_ID_LCD) 
   { 
       switch(cur_data_conf_parameter.cur_data_rcvd_char_disp_format)
       {
           case RCVD_CHAR_PLAIN_DISP_FORMAT:
		      Write_LCD_Command(lcd_cur_input_loc);	      
	          Write_LCD_Command(0x0E);// insert cursor on at lcd_cur_input_loc
	         // Write_LCD_Command(0x0C);
              Write_LCD_Data(cur_key_char);
           break;
           case RCVD_CHAR_HIDDEN_DISP_FORMAT:
		      Write_LCD_Command(lcd_cur_input_loc);	      
	          Write_LCD_Command(0x0E);// insert cursor on at lcd_cur_input_loc
	         // Write_LCD_Command(0x0C);
              Write_LCD_Data(cur_key_char);
              __delay_ms(HIDDEN_CHAR_LCD_DISP_TIME_IN_MILLI_SEC);
              Write_LCD_Command(lcd_cur_input_loc); 
              Write_LCD_Data(HIDDEN_KEY_DISP_CHAR);
           break;		  		 
        }
     }  
	 From_Loc_to_XY_LCD(lcd_cur_input_loc, &lcd_cur_input_loc_line_num, &lcd_cur_input_loc_col_num);
	 if(lcd_cur_input_loc_line_num == CONFIGURE_MAX_NUM_LINES && lcd_cur_input_loc_col_num == CONFIGURE_MAX_NUM_COLS)
	 {	 
		  /* reached end of max configured line and valid key is pressed, retain same loc position */ 
		  #ifdef TRACE_ERROR
            UART_Transmit_Str("ERR: Try get keys and reached at end of max lcd loc\r");	
          #endif			
	 }
	 else
	 {
		 /* put cur input lcd loc to next location */
		 if(lcd_cur_input_loc_col_num == CONFIGURE_MAX_NUM_COLS)
		 {	 
			lcd_next_input_loc_line_num = lcd_cur_input_loc_line_num + 1;
			lcd_next_input_loc_col_num = NUM_COL1;
		 }
         else
         {
			 lcd_next_input_loc_line_num = lcd_cur_input_loc_line_num;
			 lcd_next_input_loc_col_num = lcd_cur_input_loc_col_num + 1;
		 }	
		 From_XY_To_Loc_LCD(lcd_next_input_loc_line_num, lcd_next_input_loc_col_num, &lcd_cur_input_loc);
		 
        cur_data_status.cur_data_rcvd_str[cur_data_status.cur_data_num_chars_rcvd] = cur_key_char;   
        ++cur_data_status.cur_data_num_chars_rcvd; 	 
           		
	 }   		 
	  /* keep track of lcd_cur_input_loc as baskspace we need to -- it and also disp timeouts with.
 	  LCD automatically increments due to loc_command(0x06)in our case as after eg Write_LCD_Command(0x80)
	  ie set DDRAM */ 
	  
      enter_sw_enable_flag = STATE_YES;  
      backspace_sw_enable_flag = STATE_YES;	 
} 

 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 5   
-*------------------------------------------------------------*/  
void After_Switch_Stoke_Proc(const char pressed_sw)
{
	switch(pressed_sw)
	{
		case ENTER_SW_CODE:
		   /*  Process for valid Enter sw stroke */
		   if(cur_data_status.cur_data_num_chars_rcvd > 0)
		   {
			   cur_data_status.cur_data_rcvd_str[cur_data_status.cur_data_num_chars_rcvd] = NULL_CHAR;
			 /*  enter_sw_enable_flag = STATE_NO;
	           backspace_sw_enable_flag = STATE_NO; */
		   }  
        break;
        case BACKSPACE_SW_CODE: 
           /* Process for valid Backspace */
		   if(cur_data_status.cur_data_num_chars_rcvd > 0)
		   {
              Entered_Backspace_Sw_No_Long_Press_Proc();			  
           } 				 
        break;
        default:
			   /* error: invalid sw code received */
            ;	
	}
}	
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 12   
-*------------------------------------------------------------*/
void Entered_Backspace_Sw_No_Long_Press_Proc()
{
	unsigned int lcd_cur_input_loc_line_num, lcd_cur_input_loc_col_num, lcd_previous_input_loc_line_num, lcd_previous_input_loc_col_num;
	
	//lcd_avail_loc_within_limit = STATE_YES;	
       	
    if(cur_data_status.cur_data_num_chars_rcvd > 0 && cur_data_status.cur_data_num_chars_rcvd <= cur_data_conf_parameter.cur_data_allocated_max_num_chars_to_rcv )
    {
	    From_Loc_to_XY_LCD(lcd_cur_input_loc, &lcd_cur_input_loc_line_num, &lcd_cur_input_loc_col_num);
	   if(lcd_cur_input_loc_line_num == NUM_LINE1 && lcd_cur_input_loc_col_num == NUM_COL1)
	   {	 
		  /* reached begin of line 1 and valid backspace is pressed, retain same loc position */
		   #ifdef TRACE_ERROR
               UART_Transmit_Str("ERR: Backspace key at begin of lcd loc\r");
           #endif		   
	   }
	   else
	   {
		 /* put cur input lcd loc to one location back from current loc */
		 if(lcd_cur_input_loc_col_num == NUM_COL1)
		 {	 
			 lcd_previous_input_loc_line_num = lcd_cur_input_loc_line_num - 1;
			 lcd_previous_input_loc_col_num = CONFIGURE_MAX_NUM_COLS;
		 }
         else
         {
			 lcd_previous_input_loc_line_num = lcd_cur_input_loc_line_num;
			 lcd_previous_input_loc_col_num = lcd_cur_input_loc_col_num - 1;
		 }	
		 From_XY_To_Loc_LCD(lcd_previous_input_loc_line_num, lcd_previous_input_loc_col_num, &lcd_cur_input_loc);
		 
         /* do clear last char operation */
		 cur_data_status.cur_data_rcvd_str[cur_data_status.cur_data_num_chars_rcvd] = NULL_CHAR; 
		  /* to get key at previous location */
         Write_LCD_Command(lcd_cur_input_loc);
         --cur_data_status.cur_data_num_chars_rcvd;
         Write_LCD_Data(' '); 
         Write_LCD_Command(0x10); //shift cursor to left  	 
           		
	  }  
	  Write_LCD_Command(lcd_cur_input_loc);
      Write_LCD_Command(0x0E);	
   }
}       
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void Reset_Keyboard_Parameters()
{
	keyboard_input_enable_flag = STATE_NO;
	backspace_sw_enable_flag = STATE_NO; 
	enter_sw_enable_flag = STATE_NO;
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
