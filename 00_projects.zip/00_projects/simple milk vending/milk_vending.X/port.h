/**************************************************************************
   FILE          :    port.h
 
   PURPOSE       :    port header - define port and its pin assignment.
 
   AUTHOR        :     K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :    port header - user interface to external device, such as LED, Switch,
                      connection to other microcontroller via RS232, USB, etc. 
 	
  CHANGE LOGS     :  
	   
 **************************************************************************/
#ifndef _PORT_H
#define _PORT_H

#define RS_PIN                           RE0
#define RW_PIN                           RE1
#define EN_PIN                           RE2

#define LCD_PORT                         PORTD
#define LCD_PORT_GPIO                    TRISD 

#define  KEYPAD_PHONE_COL1              RB1
#define  KEYPAD_PHONE_COL2              RB2
#define  KEYPAD_PHONE_COL3              RB3

#define  KEYPAD_PHONE_ROWA              RB4
#define  KEYPAD_PHONE_ROWB              RB5
#define  KEYPAD_PHONE_ROWC              RB6
#define  KEYPAD_PHONE_ROWD              RB7

#define MILK_DRAINING_LED               RA1
#define ENTER_SW                        RA4
#define PROCESS_OVER_LED                RA6
#define VESSEL_DETECT_SW                RA7
#define MILK_DRAIN_VALVE                RC0
#define ERROR_LED                       RC1 
#define BACKSPACE_SW                    RC2    

#endif 

/*------------------------------------------------------------------*-
  ---- END OF FILE -------------------------------------------------
-*------------------------------------------------------------------*/
