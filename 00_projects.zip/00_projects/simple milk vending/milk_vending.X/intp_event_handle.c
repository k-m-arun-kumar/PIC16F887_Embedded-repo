/**************************************************************************
   FILE          :    intp_event_Handle.c
 
   PURPOSE       :  interrupt Event Handler Library
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 #include "main.h"
 #include "port.h"
 #include "io_conf.h"
 #include "appl_conf.h"
 #include "lcd.h"
 #include "uart.h"
 #include "adc.h"
 #include "timer.h" 
 #include "appl.h"
 
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void External_Interrupt_Occured_Appl_Proc()
{	
  	
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void Timer1_Req_Time_Expiry_Appl_Proc()
{	
    switch(timer1_last_run_state_before_stop)
	{
		case TMR1_MILK_DRAINING_STATE:
		   milk_vending_parameters.vending_status = STATUS_MILK_DRAINED;
        break;
		default:
		  #ifdef TRACE_ERROR
		      UART_Transmit_Str("ERR: invalid Timer1 last run mode \r");               			  
          #endif 		
	}	        
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void ADC_Conv_Over_Appl_Proc(unsigned long adc_value_channel)
{	
    
    
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
