/**************************************************************************
   FILE          :    keyboard.h
 
   PURPOSE       :    keyboard Header
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _KEYBOARD_H
 #define _KEYBOARD_H
 
 /* ---------------------- macro defination ------------------------------------------------ */
 
#define ENTER_SW_CODE                           ('E')
#define BACKSPACE_SW_CODE                       ('B')

#define RCVD_CHAR_PLAIN_DISP_FORMAT              (1)
#define RCVD_CHAR_HIDDEN_DISP_FORMAT             (2)  

/* ---------------------- data type defination --------------------------------------------- */


/* -------------------- public variable declaration --------------------------------------- */
 
extern char cur_pressed_key_or_sw;
extern char keypad_keys_enable_flag, keyboard_input_enable_flag, enter_sw_enable_flag, backspace_sw_enable_flag;

 /* -------------------- public prototype declaration --------------------------------------- */

int Keyboard_Proc();
void Entered_Key_No_Long_Press_Proc(const char key_data);
void Entered_Backspace_Sw_No_Long_Press_Proc();
void Reset_Keyboard_Parameters();
void After_Switch_Stoke_Proc(const char pressed_sw);

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
