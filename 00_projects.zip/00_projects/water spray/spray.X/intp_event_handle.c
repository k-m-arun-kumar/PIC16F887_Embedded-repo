/**************************************************************************
   FILE          :    intp_event_Handle.c
 
   PURPOSE       :  interrupt Event Handler Library
 
   AUTHOR        :     K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 #include "main.h"
 #include "port.h"
 #include "lcd.h"
 #include "uart.h"
 #include "adc.h"
 #include "timer.h"
 #include "keyboard.h" 
 #include "io_conf.h"
 #include "appl_conf.h"
 
 extern char manual_sw_enable_flag , keypad_sw_enable_flag;
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void External_Interrupt_Occured_Appl_Proc()
{	
  	
	
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void Timer1_Req_Time_Expiry_Appl_Proc()
{	
    switch(timer1_last_run_state_before_stop)
	{
		case TMR1_SPRAY_STATE:
		   SPRAY_PUMP_CTRL_PIN  = STATE_OFF;
		   manual_sw_enable_flag = STATE_YES_IN_CHAR;
		   keypad_sw_enable_flag = STATE_YES_IN_CHAR;
        break;
		default:
		  #ifdef TRACE_ERROR
		      UART_Transmit_Str("ERR: invalid Timer1 last run mode \r");               			  
          #endif 		
	}	        
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void ADC_Conv_Over_Appl_Proc(unsigned long adc_value_channel)
{	
     if(adc_value_channel < MIN_THRESHOLD_MOISTURE) 
     {
		 SPRAY_PUMP_CTRL_PIN = STATE_ON;
	 }	
     if(adc_value_channel > MAX_THRESHOLD_MOISTURE)	
	 {
		 SPRAY_PUMP_CTRL_PIN = STATE_OFF;
	 }		 
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
