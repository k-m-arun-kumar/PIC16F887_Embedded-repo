/**************************************************************************
   FILE          :    appl_conf.h
 
   PURPOSE       :   main application configuration Header
 
   AUTHOR        :     K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _APPL_CONF_H
 #define _APPL_CONF_H 
 
 /* -------------------------------- debug conf -----------------------------------------*/
#define TRACE                                   (1U)
#define TRACE_ERROR                             (2U)

/*------------------------------- LCD disp conf ------------------------------------------*/
#define LCD_DISP_MODE_MSG_LINE_NUM                  (NUM_LINE1)
#define LCD_DISP_MODE_DATA_LINE_NUM                 (NUM_LINE2)
#define LCD_GET_MODE_DATA_LINE_NUM                  (NUM_LINE3)
#define LCD_GET_MODE_DATA_COL_NUM                   (8)
#define LCD_DISP_TIME_MSG_LINE_NUM                  (NUM_LINE1)
#define LCD_GET_TIME_DATA_LINE_NUM                  (NUM_LINE2)
#define LCD_DISP_ERR_LINE_NUM                       (NUM_LINE4)

#define LCD_BEGIN_LOC_ECHO_UART_RCVD_STR             BEGIN_LOC_LINE2
/* ------------------------------- keypad conf -------------------------------------------*/
#define KEYPAD_CONF_MAX_NUM_CHARS_ENTERED               (4)

/* -------------------------------Timer state conf ---------------------------------------*/

#define TMR1_SPRAY_STATE                 (0)

#define TMR1_STATE0_SERVICE_TYPE          TMR1_TIMER_INTP_SERVICE
#define TMR1_STATE0_GATE_CTRL_TYPE        TMR1_GATE_CTRL_DISABLE
#define TMR1_STATE0_CLK_TYPE              TMR1_CLK_SRC_INTR_OSC
#define TMR1_STATE0_LP_OSC_ENABLE_TYPE    TMR1_LP_OSC_DISABLE

/*valid value 1,2,4,8 */
#define TMR1_STATE0_PRESCALE              (8) //Timer1 Input Clock 1:8 Prescale Value from Timer1 Clock Source

/* ---------------------------------- ADC channel && input signal val conf -------------- */

#define SOIL_MOISTURE_SENSOR           ADC_CH_00

#define MAX_ANALOG_VALUE_CH0           (5U)
#define MIN_ANALOG_VALUE_CH0           (0U)
#define FULL_SCALE_ANALOG_VAL_CH0     (MAX_ANALOG_VALUE_CH0 - MIN_ANALOG_VALUE_CH0)

/* ---------------------------------- DATA CONF ------------------------------------------*/

#define MODE_REQ_NUM_CHARS                        (1)
#define MODE_INPUT_MAX_NUM_TRY                    (3)

#define TIME_REQ_NUM_CHARS                        (4)
#define TIME_INPUT_MAX_NUM_TRY                    (3)
typedef enum {
  CUR_DATA_ID_INVALID,CUR_DATA_ID_MODE ,CUR_DATA_ID_TIME  	
} cur_data_id_types;
/* ------------------------------- application conf --------------------------------------*/
// Here we are setting up some water thersholds that we will 
// use later. Note that you will need to change these to match
// your soil type and environment. 

/* Change these values based on calibration values  depends on the operating voltage 
 Different types of soil can affect the sensor, and you may get different readings from one composition tot he next. 
 Before you start storing moisture data or triggering events based on that value, you should see what values you are actually getting from your sensor. 
 Using the sketch above, note what values your sensor outputs when the sensor is completely dry vs when the sensor is completely submerged in a shallow cup of water
*/

/* soil moisture in  */
 #define MAX_THRESHOLD_MOISTURE         (400)
 #define MIN_THRESHOLD_MOISTURE         (250)
 
 #define MIN_MANUAL_TIME_IN_SEC          (20)  
 #define MAX_MANUAL_TIME_IN_SEC          (60)  

#define HIDDEN_KEY_DISP_CHAR                  ('X') 
#define DATA_TERMINATOR_CHAR                  ENTER_CHAR
#define DATA_MAX_NUM_ALLOCATED_CHARS          (15U) 
#define HIDDEN_CHAR_LCD_DISP_TIME_IN_MILLI_SEC  (1000)
#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
