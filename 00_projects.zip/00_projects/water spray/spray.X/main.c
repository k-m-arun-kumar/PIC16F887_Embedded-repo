/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    : SOIL MOISTURE BASED WATER SPRAYING SYSTEM FOR NURSERY FARMS

                         Developed for agricultural usage for spraying of water based on soil moisture. There are two modes of operation auto mode and manual mode. 
                         In manual mode, nursery farms can set varies time for the different seeds and then based on the set time, water will be sprayed on the seeds effectively.
                         In auto mode, when soil moisture sensor reading value is less than min threshold value (for soil dry condition), then turn on the water spray pump,
                         and when soil moisture sensor reading value is more than max threshold value (for soil wet condition), then turn off the water spray pump. 

	 
AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  :                   
						
						
CAUTION               :  
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "main.h"
#include "port.h"
#include "adc.h"
#include "uart.h"
#include "timer.h"
#include "lcd.h"
#include "keyboard.h" 
#include "io_conf.h"
#include "appl_conf.h"
#include "appl.h"
#include "string.h"

 
#define AUTO_SPRAY_MODE      (1)
#define MANUAL_SPRAY_MODE     (2)
#define MANUAL_TIME_INVALID   (0)  

value_types to_disp;
cur_data_conf_parameter_types cur_data_conf_parameter;
cur_data_status_parameter_types cur_data_status;
unsigned long int manual_spray_time;
unsigned int cur_fsm_spray_state = FSM_SPRAY_IDLE;
char manual_sw_enable_flag = STATE_NO_IN_CHAR, keypad_sw_enable_flag = STATE_YES_IN_CHAR;

/*------------------------------------------------------------*-
FUNCTION NAME  : main

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 
-*------------------------------------------------------------*/

void main(void)
{
	int rcvd_status_int;
	unsigned long int entered_data;
	
	ENTER_SW_TRIS = 1;
	BACKSPACE_SW_TRIS = 1;
	KEYPAD_ROWA_TRIS = 0;
	KEYPAD_ROWB_TRIS = 0;
	KEYPAD_ROWC_TRIS = 0;
	KEYPAD_ROWD_TRIS = 0;
	KEYPAD_COL1_TRIS = 1;
	KEYPAD_COL2_TRIS = 1;
	KEYPAD_COL3_TRIS = 1; 
	KEYPAD_SW_TRIS = 1;
	MANUAL_SW_TRIS = 1;
	KEYPAD_SW_TRIS = 1;
	SPRAY_PUMP_CTRL_TRIS = 0;	
	AUTO_MODE_LED_TRIS = 0;
	ERROR_LED_TRIS = 0;
	ERROR_LED = LED_OFF;
	AUTO_MODE_LED_PIN = LED_ON;
	SPRAY_PUMP_CTRL_PIN = STATE_OFF;
	ANSEL = 0x01;
	LCD_Init(); 
	ADC_Conf_Channel(SOIL_MOISTURE_SENSOR);
	keypad_keys_enable_flag = STATE_NO_IN_CHAR;
	keyboard_input_enable_flag = STATE_NO_IN_CHAR;
	cur_fsm_spray_state = FSM_SPRAY_AUTO;
	 		
	while(1) // Super Loop
    {	
		switch(cur_fsm_spray_state)
		{
           case	FSM_SPRAY_AUTO:		
		       ADC_Start_Conv(&adc_cur_parameters[adc_cur_channel]);			   
           break;
           case FSM_SPRAY_MANUAL:
              if(manual_sw_enable_flag == STATE_YES_IN_CHAR && MANUAL_SW_PIN == KEY_PRESSED)
			  {
                  __delay_ms(50);
                  if(MANUAL_SW_PIN == KEY_PRESSED)
				  {
					  keypad_sw_enable_flag = STATE_NO_IN_CHAR;
					  while(MANUAL_SW_PIN == KEY_PRESSED);
					  manual_sw_enable_flag = STATE_NO_IN_CHAR;
                      Timer1_Run(TMR1_SPRAY_STATE, manual_spray_time); 					  
				  }
			  }				  
           break;
           case	FSM_SPRAY_ENTER_MODE:
		      if(cur_data_status.cur_data_input_num_try < cur_data_conf_parameter.cur_data_input_max_num_try)
		      {
                  rcvd_status_int = Keyboard_Proc();
			      if(rcvd_status_int != SUCCESS)
			      {
				      ERROR_LED = LED_ON;
					   
				      #ifdef TRACE_ERROR
				         UART_Transmit_Str("ERROR LED is ON \r");
				      #endif	
					  Reset_Parameters(); 
				      cur_fsm_spray_state = FSM_SPRAY_AUTO;
                      break;
			     }
			     if(cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag == STATE_YES_IN_CHAR || cur_data_status.cur_data_valid_end_rcvd_flag == STATE_YES_IN_CHAR)
                 {
					 rcvd_status_int = Str_to_Num_Conv(cur_data_status.cur_data_rcvd_str, &entered_data);
			          switch(entered_data)
					  {
						  case AUTO_SPRAY_MODE:
						      cur_fsm_spray_state = FSM_SPRAY_AUTO;
							  manual_spray_time = MANUAL_TIME_INVALID;
							  LCD_Clear_Screen();
							  Reset_Parameters();
							  keypad_sw_enable_flag = STATE_YES_IN_CHAR;
						  break;
                          case MANUAL_SPRAY_MODE:
                              LCD_Clear_Screen();
							  Reset_Parameters();
							  Next_Data_Conf_Parameter(CUR_DATA_ID_TIME, INPUT_DEV_ID_KEYBOARD, OUTPUT_DEV_ID_LCD, \
            	                 TIME_REQ_NUM_CHARS, TIME_INPUT_MAX_NUM_TRY, STATE_NO_IN_CHAR, RCVD_CHAR_PLAIN_DISP_FORMAT);
							  Goto_XY_LCD_Disp(LCD_DISP_TIME_MSG_LINE_NUM, NUM_COL1);
						      LCD_Disp_Str("Enter Manual Time ");
							  Goto_XY_LCD_Input(LCD_GET_TIME_DATA_LINE_NUM, NUM_COL1);
				              Write_LCD_Command(0x0E);	 
		                  	  cur_fsm_spray_state = FSM_SPRAY_ENTER_TIME;
                          break;
                          default:
                               LCD_Clear_Screen();
				               Reset_Cur_Data_Status(CUR_DATA_RESET_STATUS_RETRY);
				               Goto_XY_LCD_Disp(LCD_DISP_MODE_MSG_LINE_NUM, NUM_COL1);
				               LCD_Disp_Str("Reenter Mode");
				               Goto_XY_LCD_Disp(LCD_DISP_MODE_DATA_LINE_NUM, NUM_COL1);
	                           LCD_Disp_Str("Auto: 1, Manual: 2");
							   Goto_XY_LCD_Disp(LCD_GET_MODE_DATA_LINE_NUM, NUM_COL1);
							   LCD_Disp_Str("Enter: ");
							   Goto_XY_LCD_Input(LCD_GET_MODE_DATA_LINE_NUM, LCD_GET_MODE_DATA_COL_NUM);
				               Write_LCD_Command(0x0E);				 
				              ++cur_data_status.cur_data_input_num_try; 
					  }
				  }
			  }				 
			  else
              {
                   ERROR_LED = LED_ON;
			   
			       #ifdef TRACE_ERROR
				      UART_Transmit_Str("ERR: max try for  MODE > limit \r"); 
                      UART_Transmit_Str("ERROR LED is ON \r");					 
			       #endif
				   Reset_Parameters();
				   cur_fsm_spray_state = FSM_SPRAY_AUTO;
				   keypad_sw_enable_flag = STATE_YES_IN_CHAR;
              }
			
           break;
		   case FSM_SPRAY_ENTER_TIME:
              if(cur_data_status.cur_data_input_num_try < cur_data_conf_parameter.cur_data_input_max_num_try)
		      {
                  rcvd_status_int = Keyboard_Proc();
			      if(rcvd_status_int != SUCCESS)
			      {
				      ERROR_LED = LED_ON;
					   
				      #ifdef TRACE_ERROR
				         UART_Transmit_Str("ERROR LED is ON \r");
				      #endif	
					  Reset_Parameters(); 
				      cur_fsm_spray_state = FSM_SPRAY_AUTO;
					  keypad_sw_enable_flag = STATE_YES_IN_CHAR; 
                      break;
			     }
			     if(cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag == STATE_YES_IN_CHAR || cur_data_status.cur_data_valid_end_rcvd_flag == STATE_YES_IN_CHAR)
                 {
					 rcvd_status_int = Str_to_Num_Conv(cur_data_status.cur_data_rcvd_str, &entered_data);
					 if(entered_data >= MIN_MANUAL_TIME_IN_SEC && entered_data <= MAX_MANUAL_TIME_IN_SEC)
					 {
						manual_spray_time = entered_data;
			            LCD_Clear_Screen();
					    Reset_Parameters();
					    cur_fsm_spray_state = FSM_SPRAY_MANUAL; 
						manual_sw_enable_flag = STATE_YES_IN_CHAR;
						keypad_sw_enable_flag = STATE_YES_IN_CHAR;
						break;
					 }
					 if(entered_data < MIN_MANUAL_TIME_IN_SEC)
					 {
						 #ifdef TRACE_ERROR
						    to_disp.unsigned_val.value_long = MIN_MANUAL_TIME_IN_SEC;
				            UART_Transmit_Str("ERR: TIME < ");
                            UART_Transmit_Num(DISP_UNSIGN_NUM_DIGIT4, to_disp );							
                            UART_Transmit_Char('\r');					 
			             #endif
						
					 }
					 if(entered_data > MAX_MANUAL_TIME_IN_SEC)
					 {
						 #ifdef TRACE_ERROR
						    to_disp.unsigned_val.value_long = MAX_MANUAL_TIME_IN_SEC;
				            UART_Transmit_Str("ERR: TIME > ");
                            UART_Transmit_Num(DISP_UNSIGN_NUM_DIGIT4, to_disp );							
                            UART_Transmit_Char('\r');					 
			             #endif
						 
					 }
					 LCD_Clear_Screen();
				     Reset_Cur_Data_Status(CUR_DATA_RESET_STATUS_RETRY);
				     Goto_XY_LCD_Disp(LCD_DISP_TIME_MSG_LINE_NUM, NUM_COL1);
				     LCD_Disp_Str("Reenter Time");
				     Goto_XY_LCD_Input(LCD_GET_TIME_DATA_LINE_NUM, NUM_COL1);
				     Write_LCD_Command(0x0E);				 
				     ++cur_data_status.cur_data_input_num_try; 
				  }
			  }				 
			  else
              {
                   ERROR_LED = LED_ON;
			   
			       #ifdef TRACE_ERROR
				      UART_Transmit_Str("ERR: max try for time > limit \r"); 
                      UART_Transmit_Str("ERROR LED is ON \r");					 
			       #endif
				   Reset_Parameters();
				   cur_fsm_spray_state = FSM_SPRAY_AUTO;
				   keypad_sw_enable_flag = STATE_YES_IN_CHAR;
              }		      
		   break;
           default:
		      ;
		}
        if(keypad_sw_enable_flag == STATE_YES_IN_CHAR && KEYPAD_SW == KEY_PRESSED)	
		{
			__delay_ms(50);
			if(KEYPAD_SW == KEY_PRESSED)
			{
				while(KEYPAD_SW == KEY_PRESSED);
				keypad_sw_enable_flag = STATE_NO_IN_CHAR;
				cur_fsm_spray_state = FSM_SPRAY_ENTER_MODE;
	            keypad_keys_enable_flag = STATE_YES_IN_CHAR;
	            keyboard_input_enable_flag = STATE_YES_IN_CHAR;
	            Next_Data_Conf_Parameter(CUR_DATA_ID_MODE, INPUT_DEV_ID_KEYBOARD, OUTPUT_DEV_ID_LCD, MODE_REQ_NUM_CHARS, MODE_INPUT_MAX_NUM_TRY, STATE_NO_IN_CHAR, RCVD_CHAR_PLAIN_DISP_FORMAT);
	            Goto_XY_LCD_Disp(LCD_DISP_MODE_MSG_LINE_NUM, NUM_COL1);		 
	            LCD_Disp_Str("Enter spray mode");
                Goto_XY_LCD_Disp(LCD_DISP_MODE_DATA_LINE_NUM, NUM_COL1);
	            LCD_Disp_Str("Auto: 1, Manual: 2");
	            Goto_XY_LCD_Disp(LCD_GET_MODE_DATA_LINE_NUM, NUM_COL1);
	            LCD_Disp_Str("Enter: ");
	            Goto_XY_LCD_Input(LCD_GET_MODE_DATA_LINE_NUM, LCD_GET_MODE_DATA_COL_NUM);
	            Write_LCD_Command(0x0E);
			}
        }			
    }
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void Reset_Parameters()
{
	Reset_Cur_Data_Status(CUR_DATA_RESET_STATUS_WHOLE);
    Reset_Keyboard_Parameters();
	Reset_UART_Parameters();
	//memset(lcd_const_disp_flag, STATE_NO_IN_CHAR, sizeof(lcd_const_disp_flag)/ sizeof(char));	
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void Reset_Cur_Data_Status(cur_data_status_reset_types set_cur_data_status_reset_type)
{
	switch(set_cur_data_status_reset_type)
	{
		case CUR_DATA_RESET_STATUS_WHOLE:
		  cur_data_status.cur_data_id = CUR_DATA_ID_INVALID;
	      cur_data_conf_parameter.cur_data_id = CUR_DATA_ID_INVALID;
		  cur_data_status.cur_data_input_num_try = 0;
		break;  
	}
	memset(cur_data_status.cur_data_rcvd_str, NULL_CHAR, sizeof(cur_data_status.cur_data_rcvd_str)/sizeof(char));
	cur_data_status.cur_data_num_chars_rcvd = 0;
	cur_data_status.cur_data_valid_end_rcvd_flag = STATE_NO_IN_CHAR;
	cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag = STATE_NO_IN_CHAR;
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
int Next_Data_Conf_Parameter(const cur_data_id_types set_next_data_id, const input_dev_id_types set_next_data_input_dev_id, const output_dev_id_types set_next_data_output_dev_id, \
 const unsigned int set_next_data_max_num_chars_to_rcv, const unsigned int set_next_data_input_max_num_try, const char set_next_data_input_can_also_nonnum_key, \
 const unsigned int set_next_data_rcvd_char_disp_format)
{
	if(set_next_data_max_num_chars_to_rcv == CHARS_RCV_TILL_TERMINATOR_CHAR_MODE)
	{
		cur_data_conf_parameter.cur_data_rcv_mode = CUR_DATA_RCV_MODE_TILL_TERMINATOR;
		cur_data_conf_parameter.cur_data_allocated_max_num_chars_to_rcv = DATA_MAX_NUM_ALLOCATED_CHARS;
		cur_data_conf_parameter.cur_data_conf_max_num_chars_to_rcv = DATA_MAX_NUM_ALLOCATED_CHARS;
	}
	else
	{
		if(set_next_data_max_num_chars_to_rcv <= DATA_MAX_NUM_ALLOCATED_CHARS)
		{
		   cur_data_conf_parameter.cur_data_rcv_mode = CUR_DATA_RCV_MODE_TILL_ALLOCATED;
		   cur_data_conf_parameter.cur_data_allocated_max_num_chars_to_rcv = set_next_data_max_num_chars_to_rcv;
		   cur_data_conf_parameter.cur_data_conf_max_num_chars_to_rcv = set_next_data_max_num_chars_to_rcv;
		}
	    else
		{
			#ifdef TRACE_ERROR
			    UART_Transmit_Str("ERR: set max chars to enter > configured \r");
			#endif
			return FAILURE;
		}
	}
    cur_data_status.cur_data_id = set_next_data_id;
    cur_data_conf_parameter.cur_data_id = set_next_data_id;
	cur_data_conf_parameter.cur_data_input_dev_id = set_next_data_input_dev_id;
	cur_data_conf_parameter.cur_data_output_dev_id = set_next_data_output_dev_id;
	cur_data_conf_parameter.cur_data_input_max_num_try = set_next_data_input_max_num_try;
	cur_data_conf_parameter.cur_data_input_can_also_nonnum_key = set_next_data_input_can_also_nonnum_key;
	cur_data_conf_parameter.cur_data_rcvd_char_disp_format = set_next_data_rcvd_char_disp_format;
    return SUCCESS;
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
int Str_to_Num_Conv(const char *const num_in_str, unsigned long int *num_conv_from_str )
{
	 unsigned long int num = 0, place = 1;
	 int cur_unit;
	 unsigned int num_chars = 0, cur_digit= 0, ten = 10, pos = 0;
	 
	 num_chars = Str_Len(num_in_str);
     place = 1;
     pos = num_chars - 1;
     cur_unit = num_in_str[pos] - ZERO_CHAR;
	 if(cur_unit < 0 ||  cur_unit > 9 )
	 {
		 #ifdef TRACE_ERROR
		    UART_Transmit_Str("ERR: 1: Non numeric char in str_to_num\r");
		 #endif
		 *num_conv_from_str = 0; 
		 return FAILURE;
	 }	
     num = place * cur_unit;
     for(cur_digit = 1; cur_digit < num_chars; ++cur_digit)
     {
         place =  place * ten;
         pos = num_chars - 1 - cur_digit;
         cur_unit = num_in_str[pos] - ZERO_CHAR;
	     if(cur_unit < 0 ||  cur_unit > 9 )
	     {
			 #ifdef TRACE_ERROR
		       UART_Transmit_Str("ERR: 2: Non numeric char in str_to_num \r");
		     #endif
			  *num_conv_from_str = 0;
			 return FAILURE;
		 }			 
         num += (cur_unit * place);     
     }
	 *num_conv_from_str = num; 
     return SUCCESS;
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
unsigned int Str_Len(const char *const str)
{
    unsigned int num_chars = 0;
	
    while(*(str + num_chars++));
    return num_chars - 1;
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
int Num_to_Str_Conv(const int num_to_conv_str, const unsigned int min_num_digits_in_num_str, data_format_types cur_data_format, const char disp_sign_flag, char *num_in_str)
{
	char num_data[] ={'0','1','2','3','4','5','6','7','8','9'};  
	char hex_data[] ={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'}; 
	char sign_flag, first_non_zero_digit_flag = 'n';
	unsigned int cur_digit, place_val, cur_num_digits_left, num_in_str_index = 1;
    int num = num_to_conv_str;
	
	switch(cur_data_format)
	{
		case DATA_IN_DECIMAL_FORMAT:
		  place_val = 10000U;
		  cur_num_digits_left = 5; 
		  while(cur_num_digits_left > 0 )
		  {
			   cur_digit = (num / place_val);
			   if(cur_num_digits_left <= min_num_digits_in_num_str)
			   {   
		          num_in_str[num_in_str_index] = (num_data[cur_digit]); 				  
				  ++num_in_str_index;
			   }
			   else
			   {
				  if(first_non_zero_digit_flag == STATE_NO_IN_CHAR && cur_digit != 0 )
			      {
				     first_non_zero_digit_flag = STATE_YES_IN_CHAR;					 
			      }	
                  if(first_non_zero_digit_flag == STATE_YES_IN_CHAR)
				  {		
                      num_in_str[num_in_str_index] = (num_data[cur_digit]);
					   ++num_in_str_index;
				  }
			   }			  
			  --cur_num_digits_left;
			  num = num_to_conv_str % place_val;
			  place_val /= 10;
		  }			  
		break;
		case DATA_IN_HEXA_FORMAT:
		  place_val = 16 * 16 * 16;
		  cur_num_digits_left = 4; 
		  while(cur_num_digits_left > 0 )
	      {
	          cur_digit = (num / place_val);
	          if(cur_num_digits_left <= min_num_digits_in_num_str)
			  {
				  num_in_str[ num_in_str_index] = (hex_data[cur_digit]); 
				  ++num_in_str_index;
			  }
	          else
	          {
		          if(first_non_zero_digit_flag == STATE_NO_IN_CHAR && cur_digit != 0 )
			      {
					 first_non_zero_digit_flag = STATE_YES_IN_CHAR;
			      }	
                  if(first_non_zero_digit_flag == STATE_YES_IN_CHAR)
				  {					  
				      num_in_str[ num_in_str_index] = (hex_data[cur_digit]); 
					  ++num_in_str_index;
				  }
			  }			  
			  --cur_num_digits_left;
			  num = num_to_conv_str % place_val;
			  place_val /= 16;
		  }	
		break;
		default:
		   #ifdef TRACE_ERROR
		      UART_Transmit_Str("ERR: num to str invalid data in format \r");
		   #endif 	
		   
		   num_in_str[0] = NULL_CHAR; 
		  return FAILURE;
	}
	switch(disp_sign_flag)
	{
		case 'y':
		  if(num_to_conv_str > 0)
			num_in_str[0] = '+';
		 else if (num_to_conv_str < 0) 
            num_in_str[0] = '-';
         else // 0
           num_in_str[0] = ' '; 
		break;
		default:
		  num_in_str[0] = disp_sign_flag;
	}
	num_in_str[num_in_str_index] = NULL_CHAR;	
	return SUCCESS;
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/	 
