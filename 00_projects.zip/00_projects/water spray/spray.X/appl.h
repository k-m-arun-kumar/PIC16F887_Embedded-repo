/**************************************************************************
   FILE          :    appl.h
 
   PURPOSE       :    appl header - 
 
   AUTHOR        :     K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :    
 To avoid this header file to be included more than once, conditional directive is used  
	
  CHANGE LOGS     :  
	   
 **************************************************************************/
 #ifndef _APPL_H
 #define _APPL_H
 
 #define FSM_SPRAY_IDLE       (0)
#define FSM_SPRAY_AUTO       (1)
#define FSM_SPRAY_MANUAL     (2)
#define FSM_SPRAY_ENTER_MODE  (3)
#define FSM_SPRAY_ENTER_TIME  (4)

#define RCVD_CHAR_DONT_DISP_FORMAT (0)
#define RCVD_CHAR_PLAIN_DISP_FORMAT (1)
#define RCVD_CHAR_HIDDEN_DISP_FORMAT (2)
 typedef enum {
	CUR_DATA_RESET_STATUS_WHOLE, CUR_DATA_RESET_STATUS_RETRY
} cur_data_status_reset_types;

typedef enum {
   CUR_DATA_RCV_MODE_TILL_ALLOCATED , CUR_DATA_RCV_MODE_TILL_TERMINATOR
} cur_data_rcv_mode_types;

struct cur_data_conf_parameter_types
{
	cur_data_id_types cur_data_id;
	input_dev_id_types cur_data_input_dev_id;
	output_dev_id_types cur_data_output_dev_id;
	cur_data_rcv_mode_types cur_data_rcv_mode;
	unsigned int cur_data_conf_max_num_chars_to_rcv;
	unsigned int cur_data_allocated_max_num_chars_to_rcv;
	unsigned int cur_data_input_max_num_try; 
	char cur_data_input_can_also_nonnum_key;
	unsigned int cur_data_rcvd_char_disp_format;
}; 
typedef struct cur_data_conf_parameter_types  cur_data_conf_parameter_types;

struct cur_data_status_parameter_types
{
	cur_data_id_types cur_data_id;
	unsigned int cur_data_num_chars_rcvd;
	unsigned int cur_data_input_num_try;
	char cur_data_rcvd_str[DATA_MAX_NUM_ALLOCATED_CHARS + 1];
	char cur_data_valid_end_rcvd_flag;
	char cur_data_max_allocated_num_chars_rcvd_flag;
}; 
typedef struct cur_data_status_parameter_types cur_data_status_parameter_types;

extern cur_data_conf_parameter_types cur_data_conf_parameter;
extern cur_data_status_parameter_types cur_data_status;

void Reset_Parameters();
void Reset_Cur_Data_Status(cur_data_status_reset_types set_cur_data_status_reset_type);
int Next_Data_Conf_Parameter(const cur_data_id_types set_next_data_id, const input_dev_id_types set_next_data_input_dev_id, const output_dev_id_types set_next_data_output_dev_id, \
 const unsigned int set_next_data_max_num_chars_to_rcv, const unsigned int set_next_data_input_max_num_try, const char set_next_data_input_can_also_nonnum_key, \
 const unsigned int set_next_data_rcvd_char_disp_format);
int Str_to_Num_Conv(const char *const num_in_str, unsigned long int *num_conv_from_str );
unsigned int Str_Len(const char *const str);
#endif
