/* ********************************************************************
   FILE                   : main.c

   PROGRAM DESCRIPTION    :  all communicaton and transmission between SPI_MASTER and SPI_SLAVE are used by SPI. 

   Send a char from SPI_MASTER to SPI_SLAVE and receive it by SPI in SPI_SLAVE, send a char from SPI_SLAVE to SPI_MASTER and receive it by SPI in SPI_MASTER, and process continues,
   till transmitted and received datas has DATA_TERMINATOR_CHAR. When DATA_TERMINATOR_CHAR is transmitted and received, then don't transmit and receive any more chars respectively,
   for that message transfer.   
      
  First data transmitted from master to slave is Master's about to transmit data's len.
  Data len is transmitted with first char as unit digit and for 3 digits, then PADDED_CHAR, DATA_TERMINATOR_CHAR and NULL_CHAR are inserted at the end of data len digits. 
  Slave also transmits its data len.
  eg for master_tx_valid_data_str[] = "RCVD FROM MASTER" and slave_tx_valid_data_str[] = "FROM SLAVE", then master transmits its data len as "610dx",
  where x = DATA_TERMINATOR_CHAR and d = PADDED_CHAR, which are encoded correct in slave as slave's data len as 16.
  Actual slave to transmit data len = [10(strlen of slave_tx_valid_data_str) + 1(initial slave send garbage value)] < master's data len(16)
  and req_padded_chars = 5  = master's data len - Actual slave to transmit data len, is padded at the end of slave_tx_valid_data_str[]. 
  Slave also transmits its data len as "010x", and received in master as "X010x", where X is a garbage value and where x = DATA_TERMINATOR_CHAR .
  
  Second data is received from master to slave is master's data, will contain padding of PADDED_CHAR's at the location of first DATA_TERMINATOR_CHAR of master_tx_valid_data_str[],
  if actual data transmit by slave (slave_tx_valid_data_str_len + 1[initial slave transmit garbage value]) > master_tx_valid_data_str_len, and at the same time slave also transmits its data to master,
  which will contain padding of PADDED_CHAR's at the location of first DATA_TERMINATOR_CHAR of  slave_tx_valid_data_str[], 
  if actual data transmit by slave (slave_tx_valid_data_str_len + 1[initial slave transmit garbage value]) < master_tx_valid_data_str_len.
  eg for master_tx_valid_data_str[] = "RCVD FROM MASTER" and slave_tx_valid_data_str[] = "FROM SLAVE", then spi_master_tx_data_str[] = "RCVD FROM MASTER"
  and spi_slave_tx_data_str[] = "FROM SLAVE dddddx", where x is a DATA_TERMINATOR_CHAR and d = PADDED_CHAR and discard DATA_TERMINATOR_CHAR and PADDED_CHAR, if any, in rcvd data
  and display rcvd valid data in LCD_SLAVE connected to SPI_SLAVE. eg, if master_tx_valid_data_str[] = "RCVD FROM MASTER", then display rcvd valid data = "RCVD FROM MASTER" in LCD_SLAVE connected to SPI_SLAVE.

   Transmission control(TC) and other communcations related characters.  
   =====================================================================
  '\\'          - in our case as user predefined valid data terminator. 
  '\0'  (NULL)  - NUL char in ascii, defined as a filler character. It can be used as media-fill or time-fill. In our case, data are NULL terminated after DATA_TERMINATOR_CHAR 
                as well as media-fill for unoccupied data and is used as user predefined fill char. 
  '\x80' (PAD) - Padding Character in ascii used in our case as padded char.
                      									 
	 
   AUTHOR                :  K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
   KNOWN BUGS            : 

   NOTE                  :  This is a SPI_SLAVE code and software flow control and error checking are not implemented and  automatic padding of padded chars is used. Its a base code for PIC16F887-repo->10_spi->spi_06->spi6_slave->spi6_slave.X code 									
                                    
   CHANGE LOGS           : 

*****************************************************************************/
// 'C' source line config statements

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.


#include "main.h"
#include "port.h"
#include "lcd.h"
#include "spi.h"
#include "uart.h"
#include "string.h"

#define REQ_COMM_DATA_LEN                (2U)
#define MAX_COMM_NUM_CHARS              (20U)
#define TIME_CNT_WAIT_TO_UNSELECT    (50000UL)

#define PADDED_CHAR                  ('\x80')
#define DATA_TERMINATOR_CHAR           ('\\')

#define SLAVE_LCD_RCVD_DATA_LINE_NUM                  (3U)
#define SLAVE_LCD_ERR_LINE_NUM                        (4U)

typedef enum {FSM_SLAVE_COMM_INITIAL, FSM_SLAVE_COMM_READY, FSM_SLAVE_COMM_DATA_LEN, FSM_SLAVE_COMM_DATA, FSM_SLAVE_WAIT_TO_UNSELECT, FSM_SLAVE_CHECK_COMM_FINISH, FSM_SLAVE_COMM_FINISH, FSM_SLAVE_PROCESS_RCVD_DATA} spi_fsm_states;
static int Str_to_Num_Rcvd_Master_Data_Len_Calc(const char *spi_slave_rcvd_data_str, const unsigned int spi_num_chars_received);
static int Num_To_Str_Slave_Tx_Data_Len_Calc(const unsigned int slave_tx_valid_data_str_len, char *spi_slave_tx_data_str);
void Append_Data_Terminator_Char(char *valid_data_str);

char slave_tx_valid_data_str[MAX_COMM_NUM_CHARS + 1] = "SLA";
char spi_slave_rcvd_data_str[MAX_COMM_NUM_CHARS + 1], spi_transmit_data_str[MAX_COMM_NUM_CHARS + 1], spi_slave_tx_data_str[MAX_COMM_NUM_CHARS + 1];
unsigned int spi_num_chars_received = 0, spi_num_chars_transmitted = 0, slave_tx_valid_data_str_len, req_slave_comm_data_len = 0, slave_rcvd_valid_data_str_len, slave_to_rcv_valid_data_str_len ;

char slave_rcvd_valid_data_str[MAX_COMM_NUM_CHARS + 1];
char  spi_rcv_enable_flag = STATE_NO, spi_tx_enable_flag = STATE_NO, is_slave_tx_data_max_flag, is_rcvd_data_terminator_flag = STATE_NO, is_tx_data_terminator_flag = STATE_NO;
spi_fsm_states slave_spi_fsm_state = FSM_SLAVE_COMM_READY;

void main()
{
    unsigned int i = 0;
	int spi_slave_to_rcv_data_len, req_padded_chars = 0;
	char padded_data_to_master_str[MAX_COMM_NUM_CHARS + 1];
	char first_padded_char_rcvd_flag = STATE_NO;
	char lcd_const_disp_flag[5] = {STATE_NO, STATE_NO, STATE_NO, STATE_NO, STATE_NO};
	
   /* SPI is full duplex, so transmission from master to slave and transmission from slave to master happens at the same time.
     PADDED_CHAR is user predefined padded char transmitted by SPI slave and rcvd in SPI master, as lcd_data_from_master_str_len > slave_tx_valid_data_str_len,
    padding of  PADDING_CHARs are put in at the end of slave_tx_valid_data_str and terminated by DATA_TERMINATOR_CHAR, so that when master transmits 
	and slave has no data to transmit, then slave transmits padded chars to master till master completes transmission.
	.number of PADDED_CHAR =  lcd_data_from_master_str_len - [slave_tx_valid_data_str_len + 1(initial garbage char transmitted by slave to master)]*/
	   
   TRISE = 0x00;
   PORTE = 0x00;
   LCD_PORT_GPIO = 0x00;        
   LCD_PORT = 0x00;   
   ANSEL = 0x00;
   ANSELH = 0x00;  
   LCD_Init();
   UART_Init();
   SPI_Init(SPI_SLAVE_SS_EN, SPI_DATA_SAMPLE_END, SPI_CLOCK_IDLE_LOW, SPI_IDLE_2_ACTIVE);
  
 
    /* At begin, when master transmits a char to slave, at a same time, slave sends a garbage value to master, as SPI is full duplex,
     so transmission from master to slave and transmission from slave to master happens at the same time */
   while(1)	   
   {
	   switch(slave_spi_fsm_state)
	   {
				 case FSM_SLAVE_COMM_INITIAL:
				    spi_rcv_enable_flag = STATE_NO;
				    spi_tx_enable_flag = STATE_NO;
					
				   //SHOULD_REMOVE
				   if(lcd_const_disp_flag[0] == STATE_NO)
				   {
                      UART_Transmit_Str("Slave in FSM_SLAVE_COMM_INITIAL state \r");	
			          lcd_const_disp_flag[0] = STATE_YES;
				   }
				   
				 break;
				 case FSM_SLAVE_COMM_READY:
                      memset(spi_slave_tx_data_str, '\0', MAX_COMM_NUM_CHARS); 
					  
                      //SHOULD_REMOVE
					  UART_Transmit_Str("Slave's Tx Data: ");
				      UART_Transmit_Str(slave_tx_valid_data_str);
					  UART_Transmit_Char('\r');		
					  lcd_const_disp_flag[0] = STATE_NO;
					  
					  /* DATA_TERMINATOR_CHAR is not included in valid data len */  
                      slave_tx_valid_data_str_len = strlen(slave_tx_valid_data_str); 
					  Append_Data_Terminator_Char(slave_tx_valid_data_str);
					
				      if(Num_To_Str_Slave_Tx_Data_Len_Calc(slave_tx_valid_data_str_len, spi_slave_tx_data_str) < 0)
					  {
						  slave_spi_fsm_state = FSM_SLAVE_COMM_INITIAL;
						  break;	
					  }						   
                      memset(spi_slave_rcvd_data_str, '\0', MAX_COMM_NUM_CHARS);	
                      memset(padded_data_to_master_str, '\0', MAX_COMM_NUM_CHARS);
					  memset(slave_rcvd_valid_data_str, '\0', MAX_COMM_NUM_CHARS);
					  first_padded_char_rcvd_flag = STATE_NO;
					  spi_num_chars_transmitted = 0; 
					  spi_num_chars_received = 0; 				     					 
					  slave_spi_fsm_state = FSM_SLAVE_COMM_DATA_LEN;
					  spi_rcv_enable_flag = STATE_YES;
					  spi_tx_enable_flag = STATE_YES;					  
					  is_rcvd_data_terminator_flag = STATE_NO;
					  is_tx_data_terminator_flag = STATE_NO;					 
					  
					  //SHOULD_REMOVE
					  UART_Transmit_Str("Slave in FSM_SLAVE_COMM_DATA_LEN state \r");	
			          UART_Transmit_Str("Tx Slave Len   Rcvd Master Len \r");
					  
				 break;
				 case FSM_SLAVE_COMM_DATA_LEN :
				  //SLAVE has been selected 
				   if(MSSP_SLAVE_SELECT_PIN == 0 && (spi_tx_enable_flag == STATE_YES || spi_rcv_enable_flag == STATE_YES))
				   {   
				       spi_slave_rcvd_data_str[spi_num_chars_received] = SPI_Exchange_Char(spi_slave_tx_data_str[spi_num_chars_transmitted]);
					 
					 //to display transmitted and rcvd comm in data len as char format
					 				   
					   /* to display transmited and rcvd comm in data len in ascii code in hexa format */
					     //SHOULD_REMOVE
					   Goto_XY_LCD_Disp(1,1 + spi_num_chars_transmitted * 3 );
				       Data_Num_Disp_LCD(DISP_FLAG_HEX_DIGIT2, spi_slave_tx_data_str[spi_num_chars_transmitted]);
					   Write_LCD_Data(' ');
				       Goto_XY_LCD_Disp(2,1 + spi_num_chars_received * 3);
				       Data_Num_Disp_LCD(DISP_FLAG_HEX_DIGIT2, spi_slave_rcvd_data_str[spi_num_chars_received]); 
					   Write_LCD_Data(' '); 
					   UART_Transmit_Str("  ");
					   UART_Transmit_Char(spi_slave_tx_data_str[spi_num_chars_transmitted]);
					   UART_Transmit_Str(" : ");
					   UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, spi_slave_tx_data_str[spi_num_chars_transmitted]);
					   UART_Transmit_Str("         ");
					   UART_Transmit_Char(spi_slave_rcvd_data_str[spi_num_chars_received]);
					   UART_Transmit_Str(" : ");
					   UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, spi_slave_rcvd_data_str[spi_num_chars_received]);
					   UART_Transmit_Char('\r');
					   
                       switch(spi_slave_rcvd_data_str[spi_num_chars_received])					   
				       {
					        case DATA_TERMINATOR_CHAR:
							   is_rcvd_data_terminator_flag = STATE_YES; 
							   ++spi_num_chars_received;
							   
	                           //SHOULD_REMOVE
						       UART_Transmit_Str("Rcvd Master's data terminator in data len \r");
						     							   
                            break;
							case PADDED_CHAR:
							   ++spi_num_chars_received;							   
							break;
							default:
						      ++spi_num_chars_received;							  
					   }
					   switch(spi_slave_tx_data_str[spi_num_chars_transmitted])
					   {
						   case DATA_TERMINATOR_CHAR:
						      is_tx_data_terminator_flag = STATE_YES;
							  ++spi_num_chars_transmitted;
							   
	                          //SHOULD_REMOVE
						      UART_Transmit_Str("Tx Slave's data terminator in data len \r");
						    				  
                           break;
                           default:
                              ++spi_num_chars_transmitted;					   
					   }
					   if( is_rcvd_data_terminator_flag == STATE_YES && is_tx_data_terminator_flag == STATE_YES )
					   {
                          strncpy(slave_rcvd_valid_data_str, spi_slave_rcvd_data_str, REQ_COMM_DATA_LEN);
					      slave_rcvd_valid_data_str[REQ_COMM_DATA_LEN] = '\0';
							   
						  //SHOULD_REMOVE						 
						  UART_Transmit_Str("Rcvd valid Slave Data len in str: ");
						  UART_Transmit_Str(slave_rcvd_valid_data_str);
						  UART_Transmit_Char('\r');
								
						  spi_slave_to_rcv_data_len = Str_to_Num_Rcvd_Master_Data_Len_Calc(slave_rcvd_valid_data_str, REQ_COMM_DATA_LEN );
						  if(spi_slave_to_rcv_data_len < 0 )
						  {
							   slave_spi_fsm_state = FSM_SLAVE_COMM_INITIAL;
						       break;	
						  }								 
						  slave_to_rcv_valid_data_str_len = spi_slave_to_rcv_data_len;
								
						  //SHOULD_REMOVE					      
						  UART_Transmit_Str("Rcvd Master Data Len in num: ");
						  UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2,slave_to_rcv_valid_data_str_len);
						  UART_Transmit_Char('\r');
							   
						  memset(spi_slave_tx_data_str, '\0',MAX_COMM_NUM_CHARS);
						  /* (slave_tx_valid_data_str_len + 1) = actual to transmit slave data len including initial garbage value to be transmited from slave. 
                             SPI is full duplex, so transmission from master to slave and transmission from slave to master happens at the same time.
		                  	 PADDED_CHAR is user predefined padded char transmitted by SPI slave and rcvd in SPI master, as spi_slave_to_rcv_data_len > actual to transmit slave data len,
     		                 padding of padded chars are put in at the end of slave_tx_valid_data_str and terminated by '\r', so that when master transmits 
				             and slave has no data to transmit, then slave transmits padded chars to master till master completes transmission.   
				             number of PADDED_CHAR =  spi_slave_to_rcv_data_len -  actual to transmit slave data len */
						 if(slave_to_rcv_valid_data_str_len > (int)(slave_tx_valid_data_str_len))
						 {  
						     req_padded_chars = ((int)slave_to_rcv_valid_data_str_len - (int) (slave_tx_valid_data_str_len));
						     req_slave_comm_data_len = slave_to_rcv_valid_data_str_len;
						     is_slave_tx_data_max_flag = STATE_NO;
   							 for( i = 0; i < req_padded_chars; ++i)
						     {
							      padded_data_to_master_str[i] = PADDED_CHAR;	
					         }
                             padded_data_to_master_str[i] = DATA_TERMINATOR_CHAR;
                             padded_data_to_master_str[i + 1] = '\0';	
						    /* replace DATA_TERMINATOR_CHAR present at the end of slave_tx_valid_data_str with null char */
							 strncpy(spi_slave_tx_data_str, slave_tx_valid_data_str, slave_tx_valid_data_str_len);
							 spi_slave_tx_data_str[slave_tx_valid_data_str_len] = '\0';
                             strcat(spi_slave_tx_data_str, padded_data_to_master_str);								
                         }
                         else
						 {
						   	strcpy(spi_slave_tx_data_str, slave_tx_valid_data_str); 
							req_slave_comm_data_len = (slave_tx_valid_data_str_len) ; 
						    is_slave_tx_data_max_flag = STATE_YES;
						 }
						 
                          //SHOULD_REMOVE 
						 UART_Transmit_Str("To Tx Slave's Data: ");
						 UART_Transmit_Str(spi_slave_tx_data_str);
						 UART_Transmit_Char('\r');
						 UART_Transmit_Str("Tx Slave Data   Rcvd Master Data \r");								
								
						 spi_num_chars_transmitted = 0; 
					     spi_num_chars_received = 0; 
						 memset(spi_slave_rcvd_data_str, '\0', MAX_COMM_NUM_CHARS);	        
	                     memset(slave_rcvd_valid_data_str, '\0', MAX_COMM_NUM_CHARS);							 
						 slave_spi_fsm_state  = FSM_SLAVE_COMM_DATA;
                         is_rcvd_data_terminator_flag = STATE_NO;	
						 is_tx_data_terminator_flag = STATE_NO;
						 
						  //SHOULD_REMOVE
					     UART_Transmit_Str("Slave in FSM_SLAVE_COMM_DATA state");	
			             UART_Transmit_Char('\r');
						 
						 break;
					 }
                  }					   
                  break;
                // #ifdef DATA				   
                   case FSM_SLAVE_COMM_DATA:
				      if(MSSP_SLAVE_SELECT_PIN == 0 && (spi_tx_enable_flag == STATE_YES || spi_rcv_enable_flag == STATE_YES))
				      {
					     spi_slave_rcvd_data_str[spi_num_chars_received] = SPI_Exchange_Char(spi_slave_tx_data_str[spi_num_chars_transmitted]);
				 					 
						  /* to display transmited and rcvd comm in data in ascii code in hexa format */
					      //SHOULD_REMOVE
					      Goto_XY_LCD_Disp(1,1 + spi_num_chars_transmitted * 3 );
				          Data_Num_Disp_LCD(DISP_FLAG_HEX_DIGIT2, spi_slave_tx_data_str[spi_num_chars_transmitted]);
					      Write_LCD_Data(' ');
				          Goto_XY_LCD_Disp(2,1 + spi_num_chars_received * 3);
				          Data_Num_Disp_LCD(DISP_FLAG_HEX_DIGIT2, spi_slave_rcvd_data_str[spi_num_chars_received]); 
					      Write_LCD_Data(' ');
					 	  UART_Transmit_Str("  ");
					      UART_Transmit_Char(spi_slave_tx_data_str[spi_num_chars_transmitted]);
					      UART_Transmit_Str(" : ");
					      UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, spi_slave_tx_data_str[spi_num_chars_transmitted]);
					      UART_Transmit_Str("         ");
					      UART_Transmit_Char(spi_slave_rcvd_data_str[spi_num_chars_received]);
					      UART_Transmit_Str(" : ");
					      UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, spi_slave_rcvd_data_str[spi_num_chars_received]);
					      UART_Transmit_Char('\r');
						
    					 switch( spi_slave_rcvd_data_str[spi_num_chars_received])
		                 {	
                               case DATA_TERMINATOR_CHAR:
							     is_rcvd_data_terminator_flag = STATE_YES;	
						         spi_rcv_enable_flag = STATE_NO;
								 ++spi_num_chars_received;
								 
								 //SHOULD_REMOVE
						         UART_Transmit_Str("Rcvd Master's data terminator in data \r");
						         								 
					           break;
						       case PADDED_CHAR:
	                            if(first_padded_char_rcvd_flag == STATE_NO)
							    {
									slave_rcvd_valid_data_str_len = spi_num_chars_received;
									first_padded_char_rcvd_flag = STATE_YES;
								    if(slave_rcvd_valid_data_str_len != slave_to_rcv_valid_data_str_len)
								    {
									   // error: mismatch of actual valid rcvd data str len and to rcv valid data str len
									   //SHOULD_REMOVE
									   Goto_XY_LCD_Disp(SLAVE_LCD_ERR_LINE_NUM,5);
                                       Data_Str_Disp_LCD("EL ");
                                       UART_Transmit_Str("ERR: rcvd master len mismatch: \r to rcv master's len: ");
                                       UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, slave_to_rcv_valid_data_str_len);
									   UART_Transmit_Str(" , valid rcvd master's len: ");
									   UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, slave_rcvd_valid_data_str_len);
									   UART_Transmit_Char('\r');
									   slave_spi_fsm_state = FSM_SLAVE_COMM_INITIAL;									   
									   break;
								    }
								   
									//SHOULD_REMOVE
									 UART_Transmit_Str("valid rcvd master's data len: ");
                                     UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, slave_to_rcv_valid_data_str_len);
									 UART_Transmit_Char('\r');
                                }								
                                ++spi_num_chars_received;						 
						      break;
                              default:						   
					            ++spi_num_chars_received;				            
				         }	 
					     switch(spi_slave_tx_data_str[spi_num_chars_transmitted])
					     {
                            case DATA_TERMINATOR_CHAR:	                                 					  
					          spi_tx_enable_flag = STATE_NO;
						      is_tx_data_terminator_flag = STATE_YES;
						      ++spi_num_chars_transmitted;
						   
					         //SHOULD_REMOVE
						      UART_Transmit_Str("Tx Slave's data terminator in data \r");						     
							   
					       break;
					       case PADDED_CHAR:
						      ++spi_num_chars_transmitted;
					       break;
                           default:						   
					          ++spi_num_chars_transmitted;						 
				         }	
                         if(slave_spi_fsm_state == FSM_SLAVE_COMM_INITIAL)
                           break;							 
				      }
					  // (MSSP_SLAVE_SELECT_PIN == 1 || (spi_tx_enable_flag == STATE_NO && spi_rcv_enable_flag == STATE_NO)) is true
					  else 
					  {
						  
						 slave_spi_fsm_state =  FSM_SLAVE_WAIT_TO_UNSELECT;
						 
						  //SHOULD_REMOVE
					     UART_Transmit_Str("Slave in FSM_SLAVE_WAIT_TO_UNSELECT state \r");	
			             						 
					  }
			   break;
			   case FSM_SLAVE_WAIT_TO_UNSELECT:
			      if(MSSP_SLAVE_SELECT_PIN == 0)
				  {
					  Delay_Time_By_Count(TIME_CNT_WAIT_TO_UNSELECT);
					  if(MSSP_SLAVE_SELECT_PIN == 0)
					  {
					     Goto_XY_LCD_Disp(SLAVE_LCD_ERR_LINE_NUM,9);
					     Data_Str_Disp_LCD("ES "); 
						 
					     UART_Transmit_Str("ERR: Slave is select \r");				    
						 
						 slave_spi_fsm_state = FSM_SLAVE_COMM_INITIAL; 
					  }
					  else
					  {
						  slave_spi_fsm_state = FSM_SLAVE_CHECK_COMM_FINISH; 
						  
                         //SHOULD_REMOVE
					     UART_Transmit_Str("Slave in FSM_SLAVE_CHECK_COMM_FINISH state \r");		             
						 
					  }
				  } 
			   break;
			   case FSM_SLAVE_CHECK_COMM_FINISH:
                    if(spi_tx_enable_flag == STATE_YES || spi_rcv_enable_flag == STATE_YES)
				    {
					   if(spi_tx_enable_flag == STATE_YES)
                       {
					      Goto_XY_LCD_Disp(SLAVE_LCD_ERR_LINE_NUM,13);
					      Data_Str_Disp_LCD("ET ");
								
					      UART_Transmit_Str("ERR: Slave Tx enable \r");
					      						
						  spi_tx_enable_flag = STATE_NO;
				       }
                       if( spi_rcv_enable_flag == STATE_YES)
                       {
					      Goto_XY_LCD_Disp(SLAVE_LCD_ERR_LINE_NUM,17);
				          Data_Str_Disp_LCD("ER ");
					
					      UART_Transmit_Str("ERR: Slave Rcvd enable \r");
					    						
					      spi_rcv_enable_flag = STATE_NO;
					   }
				 	   slave_spi_fsm_state = FSM_SLAVE_COMM_INITIAL;
				    }
                    else 
					{ 
			        	// terminated comm and no PADDED_CHAR rcvd 
				       if(first_padded_char_rcvd_flag == STATE_NO)
					   {
						   //valid rcvd data len exclude DATA_TERMINATOR_CHAR 
						   slave_rcvd_valid_data_str_len = spi_num_chars_received - 1;
					   }						   
                       slave_spi_fsm_state = FSM_SLAVE_COMM_FINISH;
					   
					   //SHOULD_REMOVE
					   UART_Transmit_Str("Slave in FSM_SLAVE_COMM_FINISH state \r");	
			          					   
				    }			   
			   break;
			   case FSM_SLAVE_COMM_FINISH:
			   
                   //SHOULD_REMOVE
				   UART_Transmit_Str("finish rcvd master data len: ");
				   UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2,slave_rcvd_valid_data_str_len);
				   UART_Transmit_Char('\r');
				  				   
                   lcd_const_disp_flag[SLAVE_LCD_RCVD_DATA_LINE_NUM] = STATE_NO;
                   strncpy(slave_rcvd_valid_data_str, spi_slave_rcvd_data_str, slave_rcvd_valid_data_str_len );	
		           slave_rcvd_valid_data_str[slave_rcvd_valid_data_str_len] = '\0';
								 
				   		  
				    UART_Transmit_Str("Valid rcvd master data: ");
				    UART_Transmit_Str(slave_rcvd_valid_data_str);
				    UART_Transmit_Char('\r');
				   
				   slave_spi_fsm_state = FSM_SLAVE_PROCESS_RCVD_DATA;

                   //SHOULD_REMOVE
				   UART_Transmit_Str("Slave in FSM_SLAVE_PROCESS_RCVD_DATA state \r");	
			       				   
			  break; 
              case FSM_SLAVE_PROCESS_RCVD_DATA:
			     if(lcd_const_disp_flag[SLAVE_LCD_RCVD_DATA_LINE_NUM] == STATE_NO)	
				 {
			        Goto_XY_LCD_Disp(SLAVE_LCD_RCVD_DATA_LINE_NUM,1);
				    Data_Str_Disp_LCD(slave_rcvd_valid_data_str);
				    lcd_const_disp_flag[SLAVE_LCD_RCVD_DATA_LINE_NUM] = STATE_YES;
						   
				    //SHOULD_REMOVE
				    UART_Transmit_Str("Rcvd Master valid Data: ");
				    UART_Transmit_Str(slave_rcvd_valid_data_str);
				    UART_Transmit_Char('\r');
				 } 
              break;			  
			  default:
				 /* error: rcvd data from master, when slave has finished rcvd data or at initial state */
                      ;
			// #endif			    ;
       } 
   }
} 

void Append_Data_Terminator_Char(char *valid_data_str)
{
	unsigned int valid_data_str_len;
	
	valid_data_str_len = strlen(valid_data_str);
	valid_data_str[valid_data_str_len] = DATA_TERMINATOR_CHAR;
	valid_data_str[valid_data_str_len + 1] = '\0';
	
	//SHOULD_REMOVE
	UART_Transmit_Str("Data terminated str: ");
	UART_Transmit_Str(valid_data_str);
	UART_Transmit_Char('\r');
	
} 

static int Num_To_Str_Slave_Tx_Data_Len_Calc(const unsigned int slave_tx_valid_data_str_len, char *spi_slave_tx_data_str)
{
	unsigned int digit_face_value, normal_digit_pos = 0, digit_pos = REQ_COMM_DATA_LEN - 1, cur_lcd_data_to_master_str_len_num = slave_tx_valid_data_str_len, j;
	char normal_slave_data_len_str[REQ_COMM_DATA_LEN];
	unsigned long int digit_place_value = 1;
	
	for(j =0; j < REQ_COMM_DATA_LEN - 1; ++j)
	  digit_place_value *= 10;
	while(normal_digit_pos < REQ_COMM_DATA_LEN)
	{
		digit_face_value = cur_lcd_data_to_master_str_len_num / digit_place_value;
		normal_slave_data_len_str[normal_digit_pos] = '0' + digit_face_value;
		if(normal_slave_data_len_str[normal_digit_pos] < '0' || normal_slave_data_len_str[normal_digit_pos] > '9')
		{
            // error: To Tx non numeric digit of data len
			
			//SHOULD_REMOVE			
			 Goto_XY_LCD_Disp(SLAVE_LCD_ERR_LINE_NUM,1);
             Data_Str_Disp_LCD("EX ");
			 UART_Transmit_Str("ERR: To Tx Slave Data len as Non digit: ");
			 UART_Transmit_Char(normal_slave_data_len_str[normal_digit_pos]);
			 UART_Transmit_Str(" , Pos : ");
			 UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2,normal_digit_pos );
			 UART_Transmit_Char('\r');
			 
			return -1;
		}
		spi_slave_tx_data_str[digit_pos] = normal_slave_data_len_str[normal_digit_pos];
		cur_lcd_data_to_master_str_len_num %= digit_place_value;
		digit_place_value /= 10;
		++normal_digit_pos;
		--digit_pos;
	}
	spi_slave_tx_data_str[REQ_COMM_DATA_LEN] = DATA_TERMINATOR_CHAR;
	spi_slave_tx_data_str[REQ_COMM_DATA_LEN + 1] = '\0';
	
	 //SHOULD_REMOVE
	UART_Transmit_Str("To Tx slave data len n str: ");
	UART_Transmit_Str(spi_slave_tx_data_str);
	UART_Transmit_Char('\r');
	
	return 0;
}	

static int Str_to_Num_Rcvd_Master_Data_Len_Calc(const char *spi_rcvd_data_len_str, const unsigned int spi_num_chars_received)
{
	int digit_face_value, k ;
    int rcvd_master_data_len = 0;	
	unsigned long digit_place_value = 1 ;
    
	for(k =0; k < spi_num_chars_received; ++k)
	{
	   digit_face_value = spi_rcvd_data_len_str[k] - '0'; 
	   if(digit_face_value > 9 || digit_face_value < 0)
       {
		     /* error: rcvd non numeric char in data len */
			 
               //SHOULD_REMOVE			
			   Goto_XY_LCD_Disp(SLAVE_LCD_ERR_LINE_NUM,1);
               Data_Str_Disp_LCD("ED ");
               UART_Transmit_Str("ERR: Rcvd Master Data len as Non digit: ");
			   UART_Transmit_Char(spi_rcvd_data_len_str[k]);
			   UART_Transmit_Str(" , Pos : ");
			   UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, k );
			   UART_Transmit_Char('\r');
			   
			 return -1;
		}
		rcvd_master_data_len += (digit_face_value * digit_place_value);
		digit_place_value *= 10;		
    }
	
	/* //SHOULD_REMOVE
	UART_Transmit_Str("Rcvd master's data len in num: ");
	UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, rcvd_master_data_len);*/
	
	return rcvd_master_data_len;
}

