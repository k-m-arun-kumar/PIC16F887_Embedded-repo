/* ********************************************************************
   FILE                   : main.c

   PROGRAM DESCRIPTION    :  all communicaton and transmission between SPI_MASTER and SPI_SLAVE are used by SPI. 

   Send a char from SPI_MASTER to SPI_SLAVE and receive it by SPI in SPI_SLAVE, send a char from SPI_SLAVE to SPI_MASTER and receive it by SPI in SPI_MASTER, and process continues,
   till transmitted and received datas has DATA_TERMINATOR_CHAR. When DATA_TERMINATOR_CHAR is transmitted and received, then don't transmit and receive any more chars respectively,
   for that message payload transfer.   	 
     
  First data transmitted from master to slave is Master's about to transmit data's len.
  Data len is transmitted with first char as unit digit and for 3 digits, then PADDED_CHAR, DATA_TERMINATOR_CHAR and NULL_CHAR are inserted at the end of data len digits. 
  Slave also transmits its data len.
  eg for master_tx_valid_data_str[] = "RCVD FROM MASTER" and slave_tx_valid_data_str[] = "FROM SLAVE", then master transmits its data len as "610dx",
  where x = DATA_TERMINATOR_CHAR and d = PADDED_CHAR, which are encoded correct in slave as slave's data len as 16.
  Actual slave to transmit data len = [10(strlen of slave_tx_valid_data_str) + 1(initial slave send garbage value)] < master's data len(16)
  and req_padded_chars = 5  = master's data len - Actual slave to transmit data len, is padded at the end of slave_tx_valid_data_str[]. 
  Slave also transmits its data len as "010x", and received in master as "X010x", where X is a garbage value and where x = DATA_TERMINATOR_CHAR .
  
  Second data transmitted from master to slave is master's data, will contain padding of PADDED_CHAR's at the location of first DATA_TERMINATOR_CHAR of master_tx_valid_data_str[],
  if actual data transmit by slave (slave_tx_valid_data_str_len + 1[initial slave transmit garbage value]) > master_tx_valid_data_str_len,
  and at the same time slave also transmits its data to master which will contain padding of PADDED_CHAR's at the location of first DATA_TERMINATOR_CHAR char of slave_tx_valid_data_str[], 
  if actual data transmit by slave (slave_tx_valid_data_str_len + 1[initial slave transmit garbage value]) < master_tx_valid_data_str_len.
  eg for master_tx_valid_data_str[] = "RCVD FROM MASTER" and slave_tx_valid_data_str[] = "FROM SLAVE", then spi_master_tx_data_str[] = "RCVD FROM MASTERx"
  and spi_slave_tx_data_str[] = "FROM SLAVEdddddx", where x = DATA_TERMINATOR_CHAR char and d = PADDED_CHAR and discard DATA_TERMINATOR_CHAR and PADDED_CHAR, if any, in rcvd data
  and display rcvd valid data in LCD_MASTER connected to SPI_MASTER.eg, if slave_tx_valid_data_str[] = "FROM SLAVE", then display rcvd valid data = "FROM SLAVE" in LCD_MASTER connected to SPI_MASTER.
  
  Transmission control(TC) and other communcations related characters 
 =====================================================================
   '\\'          - in our case as user predefined valid data terminator. 
   '\0'  (NULL)  - NUL char in ascii, defined as a filler character. It can be used as media-fill or time-fill. In our case, data are NULL terminated after DATA_TERMINATOR_CHAR 
                as well as media-fill for unoccupied data and is used as user predefined fill char. 
   '\x80' (PAD) - Padding Character in ascii used in our case as padded char. 
                      									 
	 
   AUTHOR                :  K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
   KNOWN BUGS            : 

   NOTE                  :  This is a SPI_MASTER code and software flow control and error checking are not implemented and automatic padding of padded chars is used. Its a base code for PIC16F887-repo->10_spi->spi_06->spi6_master->spi6_master.X 						
                                    
   CHANGE LOGS           : 

*****************************************************************************/   
   
// 'C' source line config statements

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include "main.h"
#include "port.h"
#include "lcd.h"
#include "spi.h"
#include "uart.h"
#include "string.h"

#define REQ_COMM_DATA_LEN             (2U)
#define MAX_COMM_NUM_CHARS           (20U)
#define TIME_CNT_WAIT_TO_UNSELECT (1000UL)
#define PADDED_CHAR               ('\x80')
#define DATA_TERMINATOR_CHAR        ('\\')

#define MASTER_LCD_RCVD_DATA_LINE_NUM                  (3U)
#define MASTER_LCD_ERR_LINE_NUM                        (4U)

typedef enum {FSM_MASTER_COMM_INITIAL, FSM_MASTER_COMM_READY, FSM_MASTER_COMM_DATA_LEN, FSM_MASTER_COMM_DATA, FSM_MASTER_WAIT_TO_UNSELECT, FSM_MASTER_COMM_FINISH, FSM_MASTER_PROCESS_RCVD_DATA} spi_fsm_states;

static int Str_to_Num_Rcvd_Slave_Data_Len_Calc(const char *spi_rcvd_data_len_str, const unsigned int spi_num_chars_received);
static int Num_To_Str_Master_Tx_Data_Len_Calc(const unsigned int master_tx_valid_data_str_len, char *spi_master_tx_data_str);
void Append_Data_Terminator_Char(char *valid_data_str);

char master_tx_valid_data_str[MAX_COMM_NUM_CHARS + 1] = "MAST";
char master_rcvd_valid_data_str[MAX_COMM_NUM_CHARS + 1], spi_master_rcvd_data_str[MAX_COMM_NUM_CHARS + 1], spi_master_tx_data_str[MAX_COMM_NUM_CHARS + 1];
unsigned int spi_num_chars_received = 0, spi_num_chars_transmitted = 0, master_tx_valid_data_str_len, req_master_comm_data_len = 0, master_rcvd_valid_data_str_len, master_to_rcv_valid_data_str_len ;
char spi_rcv_enable_flag = STATE_NO, spi_tx_enable_flag = STATE_NO, is_master_tx_data_max_flag, is_rcvd_data_terminator_flag = STATE_NO, is_tx_data_terminator_flag = STATE_NO;
spi_fsm_states master_fsm_state = FSM_MASTER_COMM_READY;


void main()
{
   char lcd_const_disp_flag[5] = {STATE_NO, STATE_NO, STATE_NO, STATE_NO, STATE_NO};
   char padded_data_to_slave_str[MAX_COMM_NUM_CHARS + 1];
   unsigned int i;
   char first_padded_char_rcvd_flag = STATE_NO;
   int  spi_master_to_rcv_data_len, req_padded_chars = 0 ;
   
   TRISE = 0x00;
   PORTE = 0x00;
   LCD_PORT_GPIO = 0x00;        
   LCD_PORT = 0x00;  
   ANSEL = 0x00;
   ANSELH = 0x00; 
   LCD_Init();
   UART_Init();
   SPI_Init(SPI_MASTER_OSC_DIV4, SPI_DATA_SAMPLE_END, SPI_CLOCK_IDLE_LOW, SPI_IDLE_2_ACTIVE);
  
  
   /* At begin, when master transmits a char to slave, at a same time, slave sends a garbage value to master, as SPI is full duplex,
     so transmission from master to slave and transmission from slave to master happens at the same time for all transaction */
   while(1)
   {
	   switch(master_fsm_state)
	   {
		   case FSM_MASTER_COMM_INITIAL:	

             //SHOULD_REMOVE
			 if(lcd_const_disp_flag[0] == STATE_NO)
			 {
                UART_Transmit_Str("Master in FSM_MASTER_COMM_INITIAL state \r");	
			    lcd_const_disp_flag[0] = STATE_YES;
			 }
			 
			 			  
		   break;
		   case FSM_MASTER_COMM_READY:
		   
               //SHOULD_REMOVE
			   UART_Transmit_Str("Master's Tx Data: ");
			   UART_Transmit_Str(master_tx_valid_data_str);
			   UART_Transmit_Char('\r');
			   lcd_const_disp_flag[0] = STATE_NO;
			   
			   /* DATA_TERMINATOR_CHAR is not included in valid data len */
                master_tx_valid_data_str_len = strlen(master_tx_valid_data_str);
			    Append_Data_Terminator_Char(master_tx_valid_data_str);			   
		        memset(spi_master_tx_data_str, '\0', MAX_COMM_NUM_CHARS);  
		       if(Num_To_Str_Master_Tx_Data_Len_Calc(master_tx_valid_data_str_len, spi_master_tx_data_str) < 0)
			   {
				    master_fsm_state = FSM_MASTER_COMM_INITIAL;
					break;
			   }
			     spi_num_chars_transmitted = 0;
				 spi_num_chars_received = 0; 
				 first_padded_char_rcvd_flag = STATE_NO;				       
                 memset(spi_master_rcvd_data_str, '\0', MAX_COMM_NUM_CHARS);	
                 memset(padded_data_to_slave_str, '\0', MAX_COMM_NUM_CHARS);	
				 memset(master_rcvd_valid_data_str, '\0', MAX_COMM_NUM_CHARS);	
			     
				 master_fsm_state = FSM_MASTER_COMM_DATA_LEN;
				 spi_rcv_enable_flag = STATE_YES;
				 spi_tx_enable_flag = STATE_YES;
                 is_rcvd_data_terminator_flag = STATE_NO;
				 is_tx_data_terminator_flag = STATE_NO;	
                 MSSP_SLAVE_SELECT_PIN = 0;       //Slave is Selected
				 
				 //SHOULD_REMOVE
        		 UART_Transmit_Str("master in FSM_MASTER_COMM_DATA_LEN state \r");	
		       	 UART_Transmit_Str("Tx Master Len   Rcvd Slave Len \r");	
				 
		   break;
		   case FSM_MASTER_COMM_DATA_LEN:
		      if(spi_tx_enable_flag == STATE_YES || spi_rcv_enable_flag == STATE_YES )
	          {
				 spi_master_rcvd_data_str[spi_num_chars_received] = SPI_Exchange_Char(spi_master_tx_data_str[spi_num_chars_transmitted]);
				 				 				 				 
				 // to display transmitted and rcvd comm in data len in ascii code in hexa format 
				  //SHOULD_REMOVE
				  Goto_XY_LCD_Disp(1,1 + spi_num_chars_transmitted * 3 );
				  Data_Num_Disp_LCD(DISP_FLAG_HEX_DIGIT2, spi_master_tx_data_str[spi_num_chars_transmitted]);
				  Write_LCD_Data(' ');
				  Goto_XY_LCD_Disp(2,1 + spi_num_chars_received * 3);
				  Data_Num_Disp_LCD(DISP_FLAG_HEX_DIGIT2, spi_master_rcvd_data_str[spi_num_chars_received]); 
				  Write_LCD_Data(' '); 
				  UART_Transmit_Str("  ");
				  UART_Transmit_Char(spi_master_tx_data_str[spi_num_chars_transmitted]);
				  UART_Transmit_Str(" : ");
				  UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, spi_master_tx_data_str[spi_num_chars_transmitted]);
				  UART_Transmit_Str("         ");
				  UART_Transmit_Char(spi_master_rcvd_data_str[spi_num_chars_received]);
				  UART_Transmit_Str(" : ");
				  UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, spi_master_rcvd_data_str[spi_num_chars_received]);
				  UART_Transmit_Char('\r');
				  
		         switch( spi_master_rcvd_data_str[spi_num_chars_received])
		         {	
                    case DATA_TERMINATOR_CHAR:
                       is_rcvd_data_terminator_flag = STATE_YES; 
					   ++spi_num_chars_received;
					   
					   //SHOULD_REMOVE
					   UART_Transmit_Str("Rcvd Slave's data terminator in data len");
					   UART_Transmit_Char('\r');
					   
                      // spi_master_tx_data_str[spi_num_chars_transmitted] = FILL_CHAR;					 
                    break;
					case PADDED_CHAR:
					  ++spi_num_chars_received;
					break;
                    default:
					   ++spi_num_chars_received;
		         } 
				switch(spi_master_tx_data_str[spi_num_chars_transmitted] ) 
				{
					case DATA_TERMINATOR_CHAR:
					   is_tx_data_terminator_flag = STATE_YES;
					   
	                   //SHOULD_REMOVE
					   UART_Transmit_Str("Tx master's data terminator in data len \r");
					  					   
                    break;
					default:
					  ++spi_num_chars_transmitted; 
					break;
				}	
                if(is_rcvd_data_terminator_flag == STATE_YES && is_tx_data_terminator_flag == STATE_YES)
				{
                       /* ignore initial garbage value received in master from slave */
					  strncpy(master_rcvd_valid_data_str, spi_master_rcvd_data_str + 1,REQ_COMM_DATA_LEN );
					  master_rcvd_valid_data_str[REQ_COMM_DATA_LEN] = '\0';
					  
					  //SHOULD_REMOVE
					  UART_Transmit_Str("Rcvd Slave valid Data len in str: ");
					  UART_Transmit_Str(master_rcvd_valid_data_str);
					  UART_Transmit_Char('\r');
					  
				      spi_master_to_rcv_data_len = Str_to_Num_Rcvd_Slave_Data_Len_Calc(master_rcvd_valid_data_str, REQ_COMM_DATA_LEN);
					  if( spi_master_to_rcv_data_len < 0 )
					  {
						   MSSP_SLAVE_SELECT_PIN = 1;  //Slave is unselected 
						   master_fsm_state = FSM_MASTER_COMM_INITIAL;
						   
						   //SHOULD_REMOVE
						    UART_Transmit_Str("ERR: Slave unselected \r");
					       							
						   break;
					  } 
					  master_to_rcv_valid_data_str_len = spi_master_to_rcv_data_len;
					  
                      //SHOULD_REMOVE 
					  UART_Transmit_Str("Rcvd slave Data Len in num: ");
					  UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2,master_to_rcv_valid_data_str_len);
					  UART_Transmit_Char('\r');
                      
                      memset(spi_master_tx_data_str, '\0',MAX_COMM_NUM_CHARS);
 					  
					  /* ( master_to_rcv_valid_data_str_len + 1) = actual to receive slave data len including initial received from slave garbage value.
                         SPI is full duplex, so transmission from master to slave and transmission from slave to master happens at the same time.
		                PADDED_CHAR is user predefined padded char transmitted by SPI slave and rcvd in SPI master, as actual to receive slave data len > master_tx_valid_data_str_len,
     		             padding of padded chars are put in at the end of master_tx_valid_data_str and terminated by DATA_TERMINATOR_CHAR char ,so that when slave transmits 
				         and master has no data to transmit, then master transmits padded chars to slave till slave completes transmission.   
				         number of PADDED_CHAR = actual to receive slave data len  - 	master_tx_valid_data_str_len  */
					  if( ( master_to_rcv_valid_data_str_len) > (int)master_tx_valid_data_str_len)
			 		  {  
			 	         req_padded_chars = ((int)(master_to_rcv_valid_data_str_len) - (int)master_tx_valid_data_str_len);
						 req_master_comm_data_len = (master_to_rcv_valid_data_str_len);
						 is_master_tx_data_max_flag = STATE_NO;
						 for( i = 0; i < req_padded_chars; ++i)
						 {
							padded_data_to_slave_str[i] = PADDED_CHAR;	
					     }
                         padded_data_to_slave_str[i] = DATA_TERMINATOR_CHAR;
                         padded_data_to_slave_str[i + 1] = '\0';	
						 /* replace DATA_TERMINATOR_CHAR present at the end of master_tx_valid_data_str with null char */
                         strncpy(spi_master_tx_data_str, master_tx_valid_data_str, master_tx_valid_data_str_len);
						 spi_master_tx_data_str[master_tx_valid_data_str_len] = '\0';
                         strcat(spi_master_tx_data_str, padded_data_to_slave_str);								
                      }
					  else
					  {
					 	 strcpy(spi_master_tx_data_str, master_tx_valid_data_str); 
						 req_master_comm_data_len = master_tx_valid_data_str_len; 
						 is_master_tx_data_max_flag = STATE_YES;
					  }
					 
					   //SHOULD_REMOVE 
					  UART_Transmit_Str("To Tx Master's Data:  ");
					  UART_Transmit_Str(spi_master_tx_data_str);
					  UART_Transmit_Char('\r');
					  UART_Transmit_Str("Tx Master Data   Rcvd Slave Data \r");
					  
                      spi_num_chars_transmitted = 0;
					  spi_num_chars_received = 0; 	
                      memset(spi_master_rcvd_data_str, '\0', MAX_COMM_NUM_CHARS);	
                      memset(master_rcvd_valid_data_str, '\0', MAX_COMM_NUM_CHARS);	
                      is_rcvd_data_terminator_flag = STATE_NO;
					  is_tx_data_terminator_flag = STATE_NO;					  
					  master_fsm_state = FSM_MASTER_COMM_DATA;	

                     //SHOULD_REMOVE
        	    	 UART_Transmit_Str("master in FSM_MASTER_COMM_DATA state \r");	
		            					 
                  break;
				}			
		     } 				 
		   break;
		 // #ifdef DATA
		   case FSM_MASTER_COMM_DATA:
		      if(spi_tx_enable_flag == STATE_YES || spi_rcv_enable_flag == STATE_YES )
	          {
			        spi_master_rcvd_data_str[spi_num_chars_received] = SPI_Exchange_Char(spi_master_tx_data_str[spi_num_chars_transmitted]);
				 
				    // to display transmitted and rcvd comm in data in ascii code in hexa format 
				    //SHOULD_REMOVE
				    Goto_XY_LCD_Disp(1,1 + spi_num_chars_transmitted * 3 );
				    Data_Num_Disp_LCD(DISP_FLAG_HEX_DIGIT2, spi_master_tx_data_str[spi_num_chars_transmitted]);
				    Write_LCD_Data(' ');
				    Goto_XY_LCD_Disp(2,1 + spi_num_chars_received * 3);
				    Data_Num_Disp_LCD(DISP_FLAG_HEX_DIGIT2, spi_master_rcvd_data_str[spi_num_chars_received]); 
				    Write_LCD_Data(' ');
                    UART_Transmit_Str("  ");
				    UART_Transmit_Char(spi_master_tx_data_str[spi_num_chars_transmitted]);
				    UART_Transmit_Str(" : ");
				    UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, spi_master_tx_data_str[spi_num_chars_transmitted]);
				    UART_Transmit_Str("         ");
				    UART_Transmit_Char(spi_master_rcvd_data_str[spi_num_chars_received]);
				    UART_Transmit_Str(" : ");
				    UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, spi_master_rcvd_data_str[spi_num_chars_received]);
				    UART_Transmit_Char('\r');					
					
                     switch( spi_master_rcvd_data_str[spi_num_chars_received])
		             {	
                        case DATA_TERMINATOR_CHAR:	
                          /* ignore initial garbage value received in master from slave, if any */						  
						  spi_rcv_enable_flag = STATE_NO;
						  is_rcvd_data_terminator_flag = STATE_YES;	
						  ++spi_num_chars_received;
						  
	                      //SHOULD_REMOVE
					      UART_Transmit_Str("Rcvd Slave's data terminator in data \r");
					     						  
					    break;
						case PADDED_CHAR:
						    if(first_padded_char_rcvd_flag == STATE_NO)
							{
								// valid rcvd data str len , 1: exclude NULL CHAR  
								master_rcvd_valid_data_str_len = spi_num_chars_received - 1;
								first_padded_char_rcvd_flag = STATE_YES;
								if(master_rcvd_valid_data_str_len != master_to_rcv_valid_data_str_len)
								{
									 MSSP_SLAVE_SELECT_PIN = 1;  //Slave is Deselected 
									 master_fsm_state = FSM_MASTER_COMM_INITIAL;
									 
									 //SHOULD_REMOVE
						             UART_Transmit_Str("ERR: Slave unselected");
					                 UART_Transmit_Char('\r');
									 
									// error: mismatch of actual valid rcvd data str len and to rcv valid data str len
									Goto_XY_LCD_Disp(MASTER_LCD_ERR_LINE_NUM,5);
                                    Data_Str_Disp_LCD("EL ");
                                    UART_Transmit_Str("ERR: rcvd slave's len mismatch: \r to rcv slave's len: ");
                                    UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, master_to_rcv_valid_data_str_len);
									UART_Transmit_Str(" , valid rcvd slave's len: ");
									UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, master_rcvd_valid_data_str_len);
									UART_Transmit_Char('\r');
									
									break;
								}
								
								//SHOULD_REMOVE
								UART_Transmit_Str("valid rcvd slave's len: ");
                                UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2,master_rcvd_valid_data_str_len );
								UART_Transmit_Char('\r');
								
								
                            }								
                            ++spi_num_chars_received;						
						break;
                        
                        default:						   
					       ++spi_num_chars_received;
				     } 
					 switch(spi_master_tx_data_str[spi_num_chars_transmitted])
					 {
                         case DATA_TERMINATOR_CHAR:	
                           spi_tx_enable_flag = STATE_NO;
						   is_tx_data_terminator_flag = STATE_YES;	
						   
						   //SHOULD_REMOVE
						  UART_Transmit_Str("Tx master's data terminator in data \r");
						  					  
					     break;
						 case PADDED_CHAR:
						   ++spi_num_chars_transmitted;
						 break;
                         default:						   
					       ++spi_num_chars_transmitted;						 
					 }
				if( master_fsm_state == FSM_MASTER_COMM_INITIAL)
                  break;	 
			  }	 
			  else
			  {
				 //(spi_tx_enable_flag == STATE_NO && spi_rcv_enable_flag == STATE_NO) is true  
				 if(first_padded_char_rcvd_flag == STATE_NO)
				 {
					// terminated comm and no PADDED_CHAR rcvd, rcvd len exclude NULL CHAR and DATA_TERMINATOR_CHAR
					master_rcvd_valid_data_str_len = spi_num_chars_received - 2;
				 }					
				 master_fsm_state = FSM_MASTER_WAIT_TO_UNSELECT; 
				 
                //SHOULD_REMOVE
			    UART_Transmit_Str("Master in FSM_MASTER_WAIT_TO_UNSELECT state \r");	
			 				
			 }				 
			 break;
			 case FSM_MASTER_WAIT_TO_UNSELECT:
                 Delay_Time_By_Count(TIME_CNT_WAIT_TO_UNSELECT);
				 MSSP_SLAVE_SELECT_PIN = 1;  //Slave is unselected
				 master_fsm_state = FSM_MASTER_COMM_FINISH; 

                //SHOULD_REMOVE
                UART_Transmit_Str("Slave unselected \r");
	            UART_Transmit_Str("Master in FSM_MASTER_COMM_FINISH state \r");	
			    				
			 break;
			 case FSM_MASTER_COMM_FINISH:			  			 
				 lcd_const_disp_flag[MASTER_LCD_RCVD_DATA_LINE_NUM] = STATE_NO;	
				 
				 //SHOULD_REMOVE
				 UART_Transmit_Str("finish rcvd slave data len: ");
				 UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, master_rcvd_valid_data_str_len);
				 UART_Transmit_Char('\r');
				 
					
				/* first rcvd char is NULL Char (not a part of data) transmited by slave in DATA LEN stage while rcvd in slave DATA_TERMINATOR_CHAR in DATA LEN stage, 
				  ignore NULL Char in rcvd data str. */	
				 strncpy(master_rcvd_valid_data_str, spi_master_rcvd_data_str + 1, master_rcvd_valid_data_str_len );	
		         master_rcvd_valid_data_str[master_rcvd_valid_data_str_len] = '\0';
						  
				 //SHOULD_REMOVE
				 UART_Transmit_Str("Valid Rcvd Slave's Data: ");
				 UART_Transmit_Str(master_rcvd_valid_data_str);
				 UART_Transmit_Char('\r');
				 
				 master_fsm_state = FSM_MASTER_PROCESS_RCVD_DATA; 
				 
				 //SHOULD_REMOVE
				 UART_Transmit_Str("master in FSM_MASTER_PROCESS_RCVD_DATA state \r");	
			    				 
			 break;
			 case FSM_MASTER_PROCESS_RCVD_DATA:	
                if(lcd_const_disp_flag[MASTER_LCD_RCVD_DATA_LINE_NUM] == STATE_NO)	
				{					 
				    Goto_XY_LCD_Disp(MASTER_LCD_RCVD_DATA_LINE_NUM,1);
				    Data_Str_Disp_LCD(master_rcvd_valid_data_str);
					lcd_const_disp_flag[MASTER_LCD_RCVD_DATA_LINE_NUM] = STATE_YES;
					
					//SHOULD_REMOVE
					UART_Transmit_Str("Rcvd Slave's valid Data: ");
					UART_Transmit_Str(master_rcvd_valid_data_str);
					UART_Transmit_Char('\r');
				}
             break;				 
			 default:
			 /* error: transmit data from slave, when master has finished transmit data */
			 ;
	// #endif
	 
		}
	}
}

void Append_Data_Terminator_Char(char *valid_data_str)
{
	unsigned int valid_data_str_len;
	
	valid_data_str_len = strlen(valid_data_str);
	valid_data_str[valid_data_str_len] = DATA_TERMINATOR_CHAR;
	valid_data_str[valid_data_str_len + 1] = '\0';
	
	//SHOULD_REMOVE
	UART_Transmit_Str("Data terminated str: ");
	UART_Transmit_Str(valid_data_str);
	UART_Transmit_Char('\r');
	
} 

static int Num_To_Str_Master_Tx_Data_Len_Calc(const unsigned int master_tx_valid_data_str_len, char *spi_master_tx_data_str)
{
	unsigned int digit_face_value, normal_digit_pos = 0, digit_pos = REQ_COMM_DATA_LEN - 1, cur_lcd_data_from_master_str_len_num = master_tx_valid_data_str_len, j;
	char normal_master_data_len_str[REQ_COMM_DATA_LEN];
	unsigned long int digit_place_value = 1;
	
	for(j =0; j < REQ_COMM_DATA_LEN - 1; ++j)
	  digit_place_value *= 10;
  
	while(normal_digit_pos < REQ_COMM_DATA_LEN)
	{
		digit_face_value = cur_lcd_data_from_master_str_len_num / digit_place_value;
		normal_master_data_len_str[normal_digit_pos] = '0' + digit_face_value;
		if(normal_master_data_len_str[normal_digit_pos] < '0' || normal_master_data_len_str[normal_digit_pos] > '9')
		{
			// error: To Tx non numeric digit of data len
			
			//SHOULD_REMOVE			
			 Goto_XY_LCD_Disp(MASTER_LCD_ERR_LINE_NUM,1);
             Data_Str_Disp_LCD("EX ");
			 UART_Transmit_Str("ERR: To Tx master Data len as Non digit: ");
			 UART_Transmit_Char(normal_master_data_len_str[normal_digit_pos]);
			 UART_Transmit_Str(" , Pos : ");
			 UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2,normal_digit_pos );
			 UART_Transmit_Char('\r');
			 return -1;
		}
        		
		spi_master_tx_data_str[digit_pos] = normal_master_data_len_str[normal_digit_pos];
		cur_lcd_data_from_master_str_len_num %= digit_place_value;
		digit_place_value /= 10;
		++normal_digit_pos;
		--digit_pos;
	}
	/* append padded char to compensate initial received garbage value from slave  */
	spi_master_tx_data_str[REQ_COMM_DATA_LEN] = PADDED_CHAR;
	spi_master_tx_data_str[REQ_COMM_DATA_LEN + 1] = DATA_TERMINATOR_CHAR;
	spi_master_tx_data_str[REQ_COMM_DATA_LEN + 2] = '\0';

    //SHOULD_REMOVE
    UART_Transmit_Str("To Tx master's data len in str: ");
	UART_Transmit_Str(spi_master_tx_data_str);
	UART_Transmit_Char('\r');
	
    return 0;	
}	
static int Str_to_Num_Rcvd_Slave_Data_Len_Calc(const char *valid_spi_rcvd_data_len_str, const unsigned int valid_spi_num_chars_received)
{
	unsigned k;
	int digit_face_value, rcvd_slave_data_len  = 0;
	unsigned long digit_place_value = 1;
	
	for(k =0; k < valid_spi_num_chars_received; ++k)
	{
	   digit_face_value = valid_spi_rcvd_data_len_str[k] - '0'; 
	   if(digit_face_value > 9 || digit_face_value < 0)
       {
		    /* error: rcvd non numeric char in data len */
			
              //SHOULD_REMOVE			
			   Goto_XY_LCD_Disp(MASTER_LCD_ERR_LINE_NUM,1);
               Data_Str_Disp_LCD("ED ");
               UART_Transmit_Str("ERR: Rcvd slave's Data len as Non digit: ");
			   UART_Transmit_Char(valid_spi_rcvd_data_len_str[k]);
			   UART_Transmit_Str(" , Pos : ");
			   UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, k );
			   UART_Transmit_Char('\r'); 
			
			 return -1;
		}
		rcvd_slave_data_len += (digit_face_value * digit_place_value);
		digit_place_value *= 10;		
    }
	
	/* //SHOULD_REMOVE
	UART_Transmit_Str("Rcvd master's data len in num: ");
	UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, rcvd_slave_data_len); */
	
	return rcvd_slave_data_len;
}
