/**************************************************************************
   FILE          :    msg_fsm.h
 
   PURPOSE       :    message FSM header file
 
   AUTHOR        :    K.M.Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 /* to avoid this header file to be included more than once, conditional directive is used  */
#ifndef _COMM_FSM_H
#define _COMM_FSM_H

#define PADDED_CHAR                 ('\x80')
#define DATA_TERMINATOR_CHAR          ('\\')
#define ACK_CHAR                    ('\x06')
#define SYN_CHAR                    ('\x16')

typedef enum {FSM_TX_INITIAL, FSM_TX_STS, FSM_TX_MW, FSM_TX_MESSAGE, FSM_TX_ACK_AFTER_RCVD_EOT_OR_ETB, FSM_TX_AND_RCVD_ACK_COMM_OVER } spi_tx_fsm_states;
typedef enum {FSM_RCV_INITIAL, FSM_RCV_SYN, FSM_RCV_ENQ, FSM_RCV_MESSAGE, FSM_RCV_SYN_AFTER_TX_EOT_OR_ETB, FSM_WAIT_TO_RCV_ACK_AFTER_TX_EOT_OR_ETB, FSM_WAIT_TO_RCV_ACK_AFTER_RCVD_EOT_OR_ETB, FSM_RCVD_AND_TX_ACK_COMM_OVER} spi_rcv_fsm_states;
/* -------------------- public variable  declaration---------------------------------------- */
extern spi_tx_fsm_states spi_tx_fsm_state;
extern spi_rcv_fsm_states spi_rcv_fsm_state;
 
/* -------------------- public prototype declaration --------------------------------------- */
int Comm_Slave_Fsm_Proc();

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
