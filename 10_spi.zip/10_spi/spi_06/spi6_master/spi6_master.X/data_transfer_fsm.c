/* ********************************************************************
   FILE                   : data_transfer_fsm.c

   PROGRAM DESCRIPTION    : Message Data transfer Fsm Proc 
                      									 
	 
   AUTHOR                :  K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
   KNOWN BUGS            : 

   NOTE                  :  										
                                    
   CHANGE LOGS           : 

*****************************************************************************/
#include "main.h"
#include "port.h"
#include "lcd.h"
#include "uart.h"
#include "spi.h"
#include "msg_type_fsm.h"
#include "comm_fsm.h"
#include "msg_format_fsm.h"
#include "data_transfer_fsm.h"
#include "string.h"

spi_data_transfer_fsm_states master_spi_data_transfer_fsm_state = FSM_MASTER_MSG_DATA_NO_TRANSFER;

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void Msg_Data_Transfer_Fsm()
{
	
	switch(master_spi_msg_fsm_state)
    {
		case FSM_MASTER_MSG_DATA_NO_TRANSFER:
		   break;
		case FSM_MASTER_MSG_DATA_EXCHANGE:   
             if(spi_tx_enable_flag == STATE_YES || spi_rcv_enable_flag == STATE_YES )
	         {
				spi_master_rcvd_data_str[spi_num_chars_received] = SPI_Exchange_Char(spi_master_tx_data_str[spi_num_chars_transmitted]);
				 
				 //to display transmitted and rcvd comm in data len as char format
				 //SHOULD_REMOVE
				 /* Goto_XY_LCD_Disp(1,1 + spi_num_chars_transmitted );
				 Write_LCD_Data(spi_master_tx_data_str[spi_num_chars_transmitted]);
				 Goto_XY_LCD_Disp(2,1 + spi_num_chars_received);
				 Write_LCD_Data(spi_master_rcvd_data_str[spi_num_chars_received]); */
				 
				 // to display transmitted and rcvd comm in data len in ascii code in hexa format 
				  //SHOULD_REMOVE
				  Goto_XY_LCD_Disp(1,1 + spi_num_chars_transmitted * 3 );
				  Data_Num_Disp_LCD(DISP_FLAG_HEX_DIGIT2, spi_master_tx_data_str[spi_num_chars_transmitted]);
				  Write_LCD_Data(' ');
				  Goto_XY_LCD_Disp(2,1 + spi_num_chars_received * 3);
				  Data_Num_Disp_LCD(DISP_FLAG_HEX_DIGIT2, spi_master_rcvd_data_str[spi_num_chars_received]); 
				  Write_LCD_Data(' '); 
				  UART_Transmit_Str("  ");
				  UART_Transmit_Char(spi_master_tx_data_str[spi_num_chars_transmitted]);
				  UART_Transmit_Str(" : ");
				  UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, spi_master_tx_data_str[spi_num_chars_transmitted]);
				  UART_Transmit_Str("         ");
				  UART_Transmit_Char(spi_master_rcvd_data_str[spi_num_chars_received]);
				  UART_Transmit_Str(" : ");
				  UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, spi_master_rcvd_data_str[spi_num_chars_received]);
				  UART_Transmit_Char('\r');
				  
				  switch(spi_master_tx_data_str[spi_num_chars_transmitted] ) 
				  {
				    	 case DATA_TERMINATOR_CHAR:
					        is_tx_end_char_flag = STATE_YES;
					   
	                       //SHOULD_REMOVE
					       UART_Transmit_Str("Tx master's data terminator in data len \r");
					 					   
                         break;
						 case PADDED_CHAR:
						   ++spi_num_chars_transmitted;
						 break;
					     default:
					        ++spi_num_chars_transmitted; 					
				  }
				  switch( spi_master_rcvd_data_str[spi_num_chars_received])
		          {	
                     case DATA_TERMINATOR_CHAR:
                       is_rcvd_end_char_flag = STATE_YES; 
					   ++spi_num_chars_received;
					   
					   //SHOULD_REMOVE
					   UART_Transmit_Str("Rcvd Slave's data terminator in data len \r");
					  					   
                      // spi_master_tx_data_str[spi_num_chars_transmitted] = NULL_CHAR;					 
                    break;
                    case PADDED_CHAR:
					    if(first_padded_char_rcvd_flag == STATE_NO)
					    {
							master_rcvd_valid_data_str_len = spi_num_chars_received;
							first_padded_char_rcvd_flag = STATE_YES;
							if(master_rcvd_valid_data_str_len != master_to_rcv_valid_data_str_len)
							{
						    	// error: mismatch of actual valid rcvd data str len and to rcv valid data str len
								Goto_XY_LCD_Disp(MASTER_LCD_ERR_LINE_NUM,5);
                                Data_Str_Disp_LCD("EL ");
                                UART_Transmit_Str("ERR: rcvd slave's len mismatch: \r to rcv slave's len: ");
                                UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, master_to_rcv_valid_data_str_len);
							    UART_Transmit_Str(" , valid rcvd slave's len: ");
								UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, master_rcvd_valid_data_str_len);
								UART_Transmit_Char('\r');
									
								/* Continue tx data but discard any rcvd data, but continue to rcv control characters */									
								is_rcvd_valid_data_flag = DATA_STATE_INVALID;	
								spi_num_chars_received = 0; 
	                            memset(spi_master_rcvd_data_str, NULL_CHAR, MAX_COMM_NUM_CHARS);
	                            is_rcvd_end_char_flag = STATE_YES;
									
								break;
							}
								
						    //SHOULD_REMOVE
							UART_Transmit_Str("valid rcvd slave's len: ");
                            UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, master_rcvd_valid_data_str_len );
							UART_Transmit_Char('\r');
								
                        }								
                         ++spi_num_chars_received;						
					break;	
                    case DC4_CHAR:
                       /* Continue rcvd data and control characters but discard any transmit data, but continue to transmit control characters  */									
					   is_tx_valid_data_flag = DATA_STATE_INVALID;
					   transmit_count = 0;
	                   spi_num_chars_transmitted = 0;
	                   memset(spi_master_tx_data_str, NULL_CHAR, MAX_COMM_NUM_CHARS);	
	                   is_tx_end_char_flag = STATE_YES;						
					   	
					   //SHOULD_REMOVE
					   UART_Transmit_Str("Rcvd Slave's DC4_CHAR \r");                        
						   
					break;					
					case ACK_CHAR:					    	
					break; 
					case NULL_CHAR:
					break;
                    default:
					   ++spi_num_chars_received;
		          } 
			}
	  }	
      if(is_rcvd_end_char_flag == STATE_YES && is_tx_end_char_flag == STATE_YES)
	  {
		   switch(master_spi_msg_fsm_state)
		  {
	    	  case FSM_MASTER_MSG_NO_DATA:
			     master_spi_msg_fsm_state = FSM_MASTER_MSG_DATA_LEN;
			  break;	 
		      case FSM_MASTER_MSG_DATA_LEN:
			     master_spi_msg_fsm_state = FSM_MASTER_MSG_DATA;
			  break;
			  case  FSM_MASTER_MSG_DATA:
			     master_spi_msg_fsm_state = FSM_MASTER_MSG_NO_DATA;
			  break;
              default:
                //error: invalid msg type						  
                   ;						  
		  }
	 }      	  
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
