/**************************************************************************
   FILE          :    msg_type_fsm.h
 
   PURPOSE       :    Master message type FSM header file
 
   AUTHOR        :    K.M.Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 /* to avoid this header file to be included more than once, conditional directive is used  */
#ifndef _MSG_TYPE_FSM_H
#define _MSG_TYPE_FSM_H

/* --------------------- macro defination ------------------------------------------- */
#define MASTER_LCD_RCVD_DATA_LINE_NUM                  (3U)
#define MASTER_LCD_ERR_LINE_NUM                        (4U)

/* -------------------- data type defination ---------------------------------------- */

typedef enum {FSM_MASTER_MSG_NO_DATA, FSM_MASTER_MSG_DATA_LEN, FSM_MASTER_MSG_DATA} spi_msg_fsm_states;

/* -------------------- public variable  declaration---------------------------------------- */

extern spi_msg_fsm_states master_spi_msg_fsm_state;

/* -------------------- public prototype declaration --------------------------------------- */

void Msg_Type_Fsm();

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/

