/* ********************************************************************
   FILE                   : main.c

   PROGRAM DESCRIPTION    :  all communicaton and transmission between SPI_MASTER and SPI_SLAVE are used by SPI. 

   Send a char from SPI_MASTER to SPI_SLAVE and receive it by SPI in SPI_SLAVE, send a char from SPI_SLAVE to SPI_MASTER and receive it by SPI in SPI_MASTER, and process continues,
   till transmitted and received datas has DATA_TERMINATOR_CHAR. When DATA_TERMINATOR_CHAR is transmitted and received, then don't transmit and receive any more chars respectively,
   for that message payload transfer.
   
   Connection between SPI_MASTER and SPI_SLAVE are established, message transfered and data terminated with logic design from TCP FSM on operation. 
	 
  First connection between master and slave are established, by SPI_MASTER sends SYN char and when SPI_SLAVE is ready for communication, SPI_SLAVE sends STS char and now connection 
  between SPI_MASTER and SPI_SLAVE are established. 
  
   Once connection is established between SPI_MASTER and SPI_SLAVE, then messages are transfered between SPI_MASTER and SPI_SLAVE. 
   
  First data transmitted from master to slave is Master's about to transmit data's len, which is a payload in first transmission message.
  Data len is transmitted with first char as unit digit and for 3 digits, then PADDED_CHAR, DATA_TERMINATOR_CHAR and NULL_CHAR are inserted at the end of data len digits. 
  Slave also transmits its data len.
  eg for master_tx_valid_data_str[] = "RCVD FROM MASTER" and slave_tx_valid_data_str[] = "FROM SLAVE", then master transmits its data len as "610dx",
  where x = DATA_TERMINATOR_CHAR and d = PADDED_CHAR, which are encoded correct in slave as slave's data len as 16.
  Actual slave to transmit data len = [10(strlen of slave_tx_valid_data_str) + 1(initial slave send garbage value)] < master's data len(16)
  and req_padded_chars = 5  = master's data len - Actual slave to transmit data len, is padded at the end of slave_tx_valid_data_str[]. 
  Slave also transmits its data len as "010x", and received in master as "X010x", where X is a garbage value and where x = DATA_TERMINATOR_CHAR .
  
  format for our transmission message for data len in master as  <SOH><STX> <PAYLOAD as data len)> <ETX><ETB>.
    
  Second data transmitted from master to slave is master's data, which is a payload in second transmission message, will contain padding of PADDED_CHAR's at the location of first DATA_TERMINATOR_CHAR of master_tx_valid_data_str[],
  if actual data transmit by slave (slave_tx_valid_data_str_len + 1[initial slave transmit garbage value]) > master_tx_valid_data_str_len,
  and at the same time slave also transmits its data to master which will contain padding of PADDED_CHAR's at the location of first DATA_TERMINATOR_CHAR char of slave_tx_valid_data_str[], 
  if actual data transmit by slave (slave_tx_valid_data_str_len + 1[initial slave transmit garbage value]) < master_tx_valid_data_str_len.
  eg for master_tx_valid_data_str[] = "RCVD FROM MASTER" and slave_tx_valid_data_str[] = "FROM SLAVE", then spi_master_tx_data_str[] = "RCVD FROM MASTERx"
  and spi_slave_tx_data_str[] = "FROM SLAVEdddddx", where x = DATA_TERMINATOR_CHAR char and d = PADDED_CHAR and discard DATA_TERMINATOR_CHAR and PADDED_CHAR, if any, in rcvd data
  and display rcvd valid data in LCD_MASTER connected to SPI_MASTER.eg, if slave_tx_valid_data_str[] = "FROM SLAVE", then display rcvd valid data = "FROM SLAVE" in LCD_MASTER connected to SPI_MASTER.
  
  format for our transmission message for data in master as <SOH><STX> <PAYLOAD as data(master_tx_valid_data_str with may be padded chars) > <ETX><EOT>. 
 
  After communication between master and slave has estabished, and finished process rcvd data, in this code displayed valid rcvd data in LCD, or any error in communciation occured(eg rcvd data len in the first message is incorrect) and want to terminate communciation in

  receive direction, then device transmits DC4 char to initiate terminate communciation in receive direction. When a device has send DC4 char, send DC4 char device no longer want to receive any more messages from slave. 
  After send DC4 char and then rcvd ACK char for DC4 char, then send DC4 char device no longer receive any more messages, but continue to receive valid control characters(commands) and if same device not yet rcvd DC4 char, 
  then continue to transmit messages and control characters(commands). When device has send DC4 char and then rcvd ACK char	for DC4_char and rcvd DC4 char and then send ACK char for send DC4 char, wait for some time , then 
  communication between SPI_MASTER and SPI_SLAVE are terminated. 
  
   (count_retransmit) holds value of  number of times that same message, command or status has been retransmitted. If device does not get rcvd corresponding respond for transmitted message, command or status, in predefined elasped time duration(MAX_TIME_TO_RESPOND)  
   and if (count_retransmit) <= MAX_RETRANSMIT_COUNT, then device retranmsits same message, command or status and increments retransmit count var(count_retransmit) by 1 and restart time(respond_time).
   If device does not rcvd corresponding respond for transmitted message, command or status in predefined elasped time duration(MAX_TIME_TO_RESPOND and if(count_retransmit) > MAX_RETRANSMIT_COUNT, then terminate the communication, 
   in this case, master should deselect that slave in SPI and go to initial comm state(FSM_MASTER_COMM_CLOSED) and in slave, go to initial comm state (FSM_SLAVE_INITIAL).
   eg after master transmits ENQ to slave, if master does not rcvd either with MW or NAK from slave in predefined elasped time duration(MAX_TIME_TO_RESPOND), and if (count_retransmit) <= MAX_RETRANSMIT_COUNT,
   then master retransmits ENQ to that slave and increments retransmit count var(count_retransmit) by 1 and restart time(respond_time).
   
   Any invalid rcvd message, command or status are discarded and take no action. eg master has rcvd XOFF from slave, and master has already stop transmission, then  master, which already stop transmission, should discard rcvd XOFF and take no action on XOFF. 
   if master had rcvd SYN from slave and master should discard SYN and take no action on SYN.
  
  
 Transmission control(TC) and other communications related characters 
 ====================================================================
   '\\'          - in our case as user predefined DATA_TERMINATOR_CHAR. If '\\' is present as part of data, then <ESC><'\\'> in part of data to treat <'\\'> as data rather than user predefined valid data terminator.
   '\0'  (NULL)  - NUL char in ascii, defined as a filler character. It can be used as media-fill or time-fill. In our case, data are NULL terminated after DATA_TERMINATOR_CHAR 
                as well as media-fill for unoccupied data and is used as user predefined fill char for messages's payload.
  '\x01  (SOH) - Start of Heading in ascii or (TC1). Indicates the beginning of a heading in a transmission. The heading can be terminated by STX. 
         heading constitutes a machine-sensible address or routing information.  In our case, no header info is required. 
  '\x02  (STX) - Start of Text in ascii or (TC2).STX has two functions in a transmission: it 1) indicates the beginning of a text and 2) terminate a heading (see SOH). 
                   In our case, in first transmission block, data len is transmitted as text. In next transmission block, data(master_tx_valid_data_str with may be padded chars) is transmitted as text. 
  '\x03' (ETX) - End of Text in ascii or (TC3).Terminates a text in a transmission. text starts with STX and ends with ETX. in our case, ETX is present at the end of data with may be padded chars.
  '\x04' (EOT) - end of transmit in ascii, or (TC4). indicates the conclusion of a transmission. The transmission may have contained one or more texts and associated heading(s). 
                 In our case, after first data len transmission block and then data(master_tx_valid_data_str with may be padded chars) transmission block are transmitted, then EOT is used 
				 and after rcvd EOT and transmitted EOT, then, slave is deselected.
  '\x05' (ENQ) - enquiry in ascii or (TC5). is used by a master station to ask a slave station to send its next message.In our case, when slave has rcvd ENQ from master 
                 and if slave wants to transmits more message, then slave transmits MW.  When ENQ is rcvd in slave and when slave has no transmit data to master, then slave transmits NAK to master.   
  '\x06' (ACK) - acknowlege in ascii, or (TC6). normally used as a flag to indicate no problem detected with current element. 
               In our case, after rcvd ETB or EOT and then valid payload is rcvd, rcvd device transmits ACK. If device has rcvd ACK and transmitted ACK, then transfer of message is complete.
  '\x10' (DLE) - Data Link Escape in ascii, or (TC7).Used to provide supplementary data transmission control functions.  DLE is the "escape" character for transmission control. 
                DLE can potentially be put in the front of a transmission control character (TC1-TC10) to pass it through "as is" instead of controlling the current transmission.
			    transmission format, <SOH><header><STX> <PAYLOAD (DLE)<SOH> > <ETX><ETB>, where (DLE)<SOH> is a part of payload, DLE is used to avoid <SOH> been treated as transmission control
			    and treat <SOH> in payload as normal data in payload. In our case, we dont support DLE to make design simple, so any transmission control character cannot be a part of data.
  '\x11' (XON) – Transmission ON in ascii, is used for software flow control.
  '\x13' (XOFF) – Transmission OFF in ascii, is used for software flow control.
  '\x14' (DC4) - Device Control 4 (Stop) in ascii. Intended to turn off, stop or interrupt an ancillary device, or for any other device control function. 
              In our case, after communication between master and slave has occured, and finished process rcvd data, or any error in communciation occured(eg rcvd data len in the first message is incorrect)
              and want to terminate communciation in receive direction, then device transmits DC4_CHAR to initiate terminate communciation in receive direction. When a device has send DC4_CHAR,

              send DC4_CHAR device no longer want to receive any more messages from slave. After send DC4_CHAR and then rcvd ACK for DC4_CHAR, then send DC4_CHAR device no longer receive any more messages,
              but continue to receive valid control characters(commands) and if same device not yet rcvd DC4_CHAR, then continue to transmit messages and control characters(commands).
  '\x15  (NAK) - negative acknowledge character  in ascii, or (TC8), is a definite flag for, usually, noting that reception was a problem, and, often, that the current element should be sent again.
                 In our case, rcvd any incorrect message format, invalid payload is rcvd or any error in communication occured and want to resent it, then rcvd device transmits NAK.
				 If device that rcvd NAK, in this case, has to resent message to device that transmits NAK.
                 When ENQ is rcvd in slave and when slave has no transmit data to master, then slave transmits NAK to master and master that rcvd NAK, in this case, has to should not transmit ENQ to that slave for a some time duration. 
                 After master transmited SYN, and when NAK is rcvd in master, transmited by slave, to indicate that slave is not ready either to transmit or receive data and then master keeps transmits SYN, until STS is rcvd from slave.			 
  '\x16' (SYN) - Synchronous Idle in ascii.or (TC9) Used as "time-fill" in synchronous transmission. Sent during an idle condition to retain a signal when there are no other characters to send.
               In our case SYN transmitted by master,is used as fill char to transmit after (ETB) has been rcvd or after slave has been selected until STS is rcvd from slave. After rcvd STS in master, master transmits actual data.
		        After master transmited SYN, and when NAK is rcvd in master, transmited by slave, to indicate that slave is not ready either to transmit or receive data and then master keeps transmits SYN, until STS is rcvd from slave.			 
  '\x17' (ETB) - end of transmission block in ascii, or (TC10)is used to indicate end of transmission block, where data was divided into such blocks for transmission purposes.
                 In our case, 2 transmission block is used. First in first transmission block, data len is transmitted as text. 

				 In next transmission block, data(master_tx_valid_data_str with may be padded chars) is transmitted as text.
 '\x1B' (ESC) - Escape in ascii is used in many output devices to start a series of characters called a control sequence or escape sequence. In our case, if any control character is present as part of data,
                 then precede control charcter in data with ESC. eg. <ESC><SYN> in part of data to treat <SYN> as data char rather than control character. 
	             For successive control characters, present as part of data, then precede each successive control characters in data with ESC. 
				 eg. <ESC><PAD><ESC><XON><ESC><XOFF> in part of data to treat <PAD><XON><XOFF> as data chars rather than control characters. In our case, we dont support ESC to make design simple, so any control character cannot be a part of data.		 
  '\x80' (PAD) - Padding Character in ascii used for as in our case as padded char. 
  '\x93  (STS) - Set Transmit State in ascii, 	Notifies that data is ready for transfer from a device, or establishes the transmit state in the receiving device.
                 Doesn't initiate the actual transmission. In our case, after rcvd SYN in slave, slave sends STS to notify master that slave is ready to receive as well as transmit message. 
  '\x95' (MW) - Message Waiting in ascii, is used to Sets a message waiting indicator in the receiving device. 
                In our case, if slave has some valid data to transmit, then after ENQ is received, slave device transmits MW and slave is ready to transmit data and master is ready to receive data. 
		      
	 	 
   where x is used to represent ascii code value in hexa format.    
                      									 
	 
   AUTHOR                :  K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
   KNOWN BUGS            : YET TO FINISH, as unable to use UART, LCD display in pic16f1939, which stopped to proceed forward.	

   NOTE                  :   This is a SPI_MASTER code for pic16f1939 and error checking are not implemented and automatic padding of padded chars is used. 
   It used as a base code from PIC16F887-repo->10_spi->spi_04->spi4_master->spi4_master.X, with yet to add feature of data connection establish, message transfer and data termination with logic design from TCP FSM on operation. 		
                                    
   CHANGE LOGS           : 

*****************************************************************************/
  
// 'C' source line config statements

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include "main.h"
#include "port.h"
#include "lcd.h"
#include "spi.h"
#include "uart.h"
#include "comm_fsm.h"
#include "msg_type_fsm.h"
#include "data_transfer_fsm.h"

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void main()
{
   TRISE = 0x00;
   PORTE = 0x00;
   LCD_PORT_GPIO = 0x00;        
   LCD_PORT = 0x00;  
  // ANSEL = 0x00;
 //  ANSELH = 0x00; 
   LCD_Init();
   UART_Init();
   SPI_Init(SPI_MASTER_OSC_DIV4, SPI_DATA_SAMPLE_END, SPI_CLOCK_IDLE_LOW, SPI_IDLE_2_ACTIVE);  
  
   //SHOULD_REMOVE
   UART_Transmit_Str("HELLO \r");
   Goto_XY_LCD_Disp(1,1);
   Data_Str_Disp_LCD("LCD");
   
   /* At begin, when master transmits a char to slave, at a same time, slave sends a garbage value to master, as SPI is full duplex,
     so transmission from master to slave and transmission from slave to master happens at the same time for all transaction */
   while(1)
   {
	   Comm_Fsm_Proc();
	   Msg_Data_Transfer_Fsm();
	   Msg_Type_Fsm();
   }
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
