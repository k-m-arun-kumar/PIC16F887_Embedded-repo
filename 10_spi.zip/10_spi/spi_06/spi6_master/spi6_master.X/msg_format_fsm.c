/* ********************************************************************
   FILE                   : msg_format_fsm.c

   PROGRAM DESCRIPTION    : Message format FSM Proc in master
                      									 
	 
   AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
   KNOWN BUGS            : 

   NOTE                  :  										
                                    
   CHANGE LOGS           : 

*****************************************************************************/
#include "main.h"
#include "port.h"
#include "lcd.h"
#include "uart.h"
#include "msg_format_fsm.h"
#include "string.h"

spi_tx_msg_fmt_fsm_states spi_tx_msg_fmt_fsm_state = FSM_TX_MSG_FMT_INITIAL;
spi_rcv_msg_fmt_fsm_states spi_rcv_msg_fmt_fsm_state = FSM_RCV_MSG_FMT_INITIAL;
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
int Msg_Format_Fsm_Proc()
{
	return 0;
}

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
