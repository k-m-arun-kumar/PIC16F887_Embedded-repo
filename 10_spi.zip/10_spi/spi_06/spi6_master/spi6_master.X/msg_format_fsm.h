/**************************************************************************
   FILE          :    msg_format_fsm.h
 
   PURPOSE       :    messgae format FSM header file
 
   AUTHOR        :    K.M.Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 /* to avoid this header file to be included more than once, conditional directive is used  */
#ifndef _MSG_FORMAT_FSM_H
#define _MSG_FORMAT_FSM_H

typedef enum {FSM_TX_MSG_FMT_INITIAL, FSM_TX_ENQ, FSM_TX_MSG_FMT_SOH, FSM_TX_MSG_FMT_STX, FSM_TX_MSG_FMT_TEXT, FSM_TX_MSG_FMT_ETX, FSM_TX_MSG_FMT_ETB, FSM_TX_MSG_FMT_EOT } spi_tx_msg_fmt_fsm_states;
typedef enum {FSM_RCV_MSG_FMT_INITIAL, FSM_RCVD_MW, FSM_RCVD_MSG_FMT_SOH, FSM_RCVD_MSG_FMT_STX, FSM_RCV_MSG_FMT_TEXT, FSM_RCVD_MSG_FMT_ETX, FSM_RCVD_MSG_FMT_ETB, FSM_RCVD_MSG_FMT_EOT} spi_rcv_msg_fmt_fsm_states;

/* -------------------- public variable  declaration---------------------------------------- */
extern spi_tx_msg_fmt_fsm_states spi_tx_msg_fmt_fsm_state;
extern spi_rcv_msg_fmt_fsm_states spi_rcv_msg_fmt_fsm_state;
 
/* -------------------- public prototype declaration --------------------------------------- */
int Msg_Format_Fsm_Proc();

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
