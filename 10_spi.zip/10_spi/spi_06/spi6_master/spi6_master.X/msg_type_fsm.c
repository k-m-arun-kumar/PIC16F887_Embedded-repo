/* ********************************************************************
   FILE                   : msg_type_fsm.c

   PROGRAM DESCRIPTION    : Message Type Fsm Proc 
                      									 
	 
   AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
   KNOWN BUGS            : 

   NOTE                  :  										
                                    
   CHANGE LOGS           : 

*****************************************************************************/
#include "main.h"
#include "port.h"
#include "lcd.h"
#include "uart.h"
#include "spi.h"
#include "msg_type_fsm.h"
#include "comm_fsm.h"
#include "msg_format_fsm.h"
#include "data_transfer_fsm.h"
#include "string.h"

spi_msg_fsm_states master_spi_msg_fsm_state = FSM_MASTER_MSG_NO_DATA;
unsigned int master_to_rcv_valid_data_str_len, master_rcvd_valid_data_str_len;;

static int Str_to_Num_Rcvd_Slave_Data_Len_Calc(const char *spi_rcvd_data_len_str, const unsigned int spi_num_chars_received);

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void Msg_Type_Fsm()
{
	int  spi_master_to_rcv_data_len, req_padded_chars = 0 ; 
	unsigned int i, req_master_comm_data_len = 0;
	char is_master_tx_data_max_flag;
	
    switch(master_spi_msg_fsm_state)
    {
        case  FSM_MASTER_MSG_NO_DATA:
		break;
		case FSM_MASTER_MSG_DATA_LEN:
           if(is_rcvd_end_char_flag == STATE_YES && is_tx_end_char_flag == STATE_YES)
		   {
  			    strncpy(master_rcvd_valid_data_str, spi_master_rcvd_data_str,REQ_COMM_DATA_LEN );
				master_rcvd_valid_data_str[REQ_COMM_DATA_LEN] = NULL_CHAR;
					  
				//SHOULD_REMOVE
				UART_Transmit_Str("Rcvd Slave valid Data len in str: ");
				UART_Transmit_Str(master_rcvd_valid_data_str);
				UART_Transmit_Char('\r');
					  
				spi_master_to_rcv_data_len = Str_to_Num_Rcvd_Slave_Data_Len_Calc(master_rcvd_valid_data_str, REQ_COMM_DATA_LEN);
					  
				// MUST_REMOVE used for testing in when error occured connecton should be closed and when triggered connection should estabilish again
				// spi_master_to_rcv_data_len = -1;
					  
				if( spi_master_to_rcv_data_len < 0 )	
				{
				     /* Continue tx data but discard any rcvd data, but continue to rcv control characters */									
				     is_rcvd_valid_data_flag = DATA_STATE_INVALID;	
					 spi_num_chars_received = 0; 
	                 memset(spi_master_rcvd_data_str, NULL_CHAR, MAX_COMM_NUM_CHARS);
	                 is_rcvd_end_char_flag = STATE_YES;			   	
						   
					 break; 
			    }
                master_to_rcv_valid_data_str_len = spi_master_to_rcv_data_len;
					  
                //SHOULD_REMOVE 
			    UART_Transmit_Str("Rcvd slave Data Len in num: ");
			    UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2,master_to_rcv_valid_data_str_len);
			    UART_Transmit_Char('\r');
                      
                Reset_Transfer_Parameters(); 					  
			    /* ( master_to_rcv_valid_data_str_len + 1) = actual to receive slave data len including initial received from slave garbage value.
                   SPI is full duplex, so transmission from master to slave and transmission from slave to master happens at the same time.
		           PADDED_CHAR is user predefined padded char transmitted by SPI slave and rcvd in SPI master, as actual to receive slave data len > master_tx_valid_data_str_len,
     		       padding of padded chars are put in at the end of master_tx_valid_data_str and terminated by DATA_TERMINATOR_CHAR char ,so that when slave transmits 
				   and master has no data to transmit, then master transmits padded chars to slave till slave completes transmission.   
				   number of PADDED_CHAR = actual to receive slave data len  - 	master_tx_valid_data_str_len  */
				    if( ( master_to_rcv_valid_data_str_len) > (int)master_tx_valid_data_str_len)
			 	    {  
			 	         req_padded_chars = ((int)(master_to_rcv_valid_data_str_len) - (int)master_tx_valid_data_str_len);
				         req_master_comm_data_len = (master_to_rcv_valid_data_str_len);
						 is_master_tx_data_max_flag = STATE_NO;
						 for( i = 0; i < req_padded_chars; ++i)
						 {
						   	padded_data_to_slave_str[i] = PADDED_CHAR;	
					     }
                         padded_data_to_slave_str[i] = DATA_TERMINATOR_CHAR;
                         padded_data_to_slave_str[i + 1] = NULL_CHAR;	
						 /* replace DATA_TERMINATOR_CHAR present at the end of master_tx_valid_data_str with null char */
                         strncpy(spi_master_tx_data_str, master_tx_valid_data_str, master_tx_valid_data_str_len);
						 spi_master_tx_data_str[master_tx_valid_data_str_len] = NULL_CHAR;
                         strcat(spi_master_tx_data_str, padded_data_to_slave_str);								
                    }
					else
					{
					 	 strcpy(spi_master_tx_data_str, master_tx_valid_data_str); 
					     req_master_comm_data_len = master_tx_valid_data_str_len; 
					     is_master_tx_data_max_flag = STATE_YES;
				    }
					 
					 //SHOULD_REMOVE 
					 UART_Transmit_Str("To Tx Master's Data:  ");
					 UART_Transmit_Str(spi_master_tx_data_str);
					 UART_Transmit_Char('\r');
					 UART_Transmit_Str("Tx Master Data   Rcvd Slave Data \r");
					  
                     memset(master_rcvd_valid_data_str, NULL_CHAR, MAX_COMM_NUM_CHARS);                     					  
					 //  master_spi_comm_fsm_state = FSM_MASTER_MSG_DATA;	

                    //SHOULD_REMOVE
        	    	 UART_Transmit_Str("master in FSM_MASTER_MSG_DATA state \r");	
		           		 
                     break;
				}			   
		   break;
		 // #ifdef DATA
		   case FSM_MASTER_MSG_DATA:
		      if(  master_spi_comm_fsm_state == FSM_MASTER_COMM_RCVD_TO_CLOSE)
                 break;
				     
              if( is_rcvd_end_char_flag == STATE_YES && is_tx_end_char_flag == STATE_YES )
			  {
				  spi_tx_enable_flag = STATE_NO;
				  spi_rcv_enable_flag = STATE_NO;
                  if(first_padded_char_rcvd_flag == STATE_NO)
			      {
			        	//  transfered data and no PADDED_CHAR rcvd, rcvd len exclude DATA_TERMINATOR_CHAR
				       master_rcvd_valid_data_str_len = spi_num_chars_received - 1;
			      }
                  lcd_const_disp_flag[MASTER_LCD_RCVD_DATA_LINE_NUM] = STATE_NO;	
			
			      //SHOULD_REMOVE
			       UART_Transmit_Str("finish rcvd slave data len: ");
			       UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, master_rcvd_valid_data_str_len);
			       UART_Transmit_Char('\r');
			       
			
			       strncpy(master_rcvd_valid_data_str, spi_master_rcvd_data_str, master_rcvd_valid_data_str_len );	
		           master_rcvd_valid_data_str[master_rcvd_valid_data_str_len] = NULL_CHAR;
					  
			      //SHOULD_REMOVE
			       UART_Transmit_Str("Valid Rcvd Slave's Data: ");
			       UART_Transmit_Str(master_rcvd_valid_data_str);
			       UART_Transmit_Char('\r');				 
			            
      			   Reset_Transfer_Parameters(); 					  
				   master_spi_comm_fsm_state = FSM_MASTER_PROCESS_RCVD_DATA; 
				 
                  //SHOULD_REMOVE
			       UART_Transmit_Str("Master in FSM_MASTER_PROCESS_RCVD_DATA state \r");	
			      
                   break;					 
            }			 
		   break;		
		   default:
             //error: invalid msg type fsm		   
 		     ;
    }		   
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/	
static int Str_to_Num_Rcvd_Slave_Data_Len_Calc(const char *valid_spi_rcvd_data_len_str, const unsigned int valid_spi_num_chars_received)
{
	unsigned k;
	int digit_face_value, rcvd_slave_data_len  = 0;
	unsigned long digit_place_value = 1;
	
	for(k =0; k < valid_spi_num_chars_received; ++k)
	{
	   digit_face_value = valid_spi_rcvd_data_len_str[k] - '0'; 
	   if(digit_face_value > 9 || digit_face_value < 0)
       {
		    /* error: rcvd non numeric char in data len */
			
              //SHOULD_REMOVE			
			   Goto_XY_LCD_Disp(MASTER_LCD_ERR_LINE_NUM,1);
               Data_Str_Disp_LCD("ED ");
               UART_Transmit_Str("ERR: Rcvd slave's Data len as Non digit: ");
			   UART_Transmit_Char(valid_spi_rcvd_data_len_str[k]);
			   UART_Transmit_Str(" , Pos : ");
			   UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, k );
			   UART_Transmit_Char('\r'); 
			
			 return -1;
		}
		rcvd_slave_data_len += (digit_face_value * digit_place_value);
		digit_place_value *= 10;		
    }
	
	/* //SHOULD_REMOVE
	UART_Transmit_Str("Rcvd master's data len in num: ");
	UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, rcvd_slave_data_len); */
	
	return rcvd_slave_data_len;
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
