/* ********************************************************************
   FILE                   : lcd.c

   PROGRAM DESCRIPTION    : LCD library 
                      									 
	 
   AUTHOR                :  K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
   KNOWN BUGS            : 

   NOTE                  :  										
                                    
   CHANGE LOGS           : 

*****************************************************************************/
#include "main.h"
#include "port.h"
#include "lcd.h"
#include "spi.h"
#include "uart.h"
#include "msg_type_fsm.h"
#include "comm_fsm.h"
#include "string.h"

#define MASTER_LCD_RCVD_DATA_LINE_NUM                  (3U)
#define MASTER_LCD_ERR_LINE_NUM                        (4U)

static int Num_To_Str_Master_Tx_Data_Len_Calc(const unsigned int master_tx_valid_data_str_len, char *spi_master_tx_data_str);
static void Append_Data_Terminator_Char(char *valid_data_str);

char lcd_const_disp_flag[5] = {STATE_NO, STATE_NO, STATE_NO, STATE_NO, STATE_NO};
char master_tx_valid_data_str[MAX_COMM_NUM_CHARS + 1] = "MAST";
char master_rcvd_valid_data_str[MAX_COMM_NUM_CHARS + 1], spi_master_rcvd_data_str[MAX_COMM_NUM_CHARS + 1], spi_master_tx_data_str[MAX_COMM_NUM_CHARS + 1];
char padded_data_to_slave_str[MAX_COMM_NUM_CHARS + 1];
unsigned int spi_num_chars_received = 0, spi_num_chars_transmitted = 0, master_tx_valid_data_str_len;
char spi_rcv_enable_flag = STATE_NO, spi_tx_enable_flag = STATE_NO, is_rcvd_end_char_flag = STATE_NO, is_tx_end_char_flag = STATE_NO, first_padded_char_rcvd_flag = STATE_NO;
 unsigned int is_rcvd_valid_data_flag = DATA_STATE_UNKNOWN, is_tx_valid_data_flag = DATA_STATE_UNKNOWN ; 
spi_comm_fsm_states master_spi_comm_fsm_state = FSM_MASTER_COMM_INITIATE_OPEN;
data_validity_states comm_data_validity_state = TX_AND_RVCD_INVALID_DATA; 
unsigned int  transmit_count = 0;
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void Comm_Fsm_Proc()
{    
       char is_rcvd_invalid_char_flag = STATE_YES, is_first_instance_occur_flag = STATE_NO;  
	   
	   switch(master_spi_comm_fsm_state)
	   {
		   case FSM_MASTER_COMM_CLOSED:	
             spi_rcv_enable_flag = STATE_NO;
			 spi_tx_enable_flag = STATE_NO;
			 
             //SHOULD_REMOVE
			 if(is_first_instance_occur_flag == STATE_NO)
			 {
                UART_Transmit_Str("Master in FSM_MASTER_COMM_CLOSED state \r");	
			    is_first_instance_occur_flag = STATE_YES;
			 }
             
			 //SHOULD_CALL
			 /* master_spi_comm_fsm_state = FSM_MASTER_COMM_INITIATE_OPEN; 
			 
             //SHOULD_REMOVE
        	 UART_Transmit_Str("master in FSM_MASTER_COMM_INITIATE_OPEN state");	
		     UART_Transmit_Char('\r');	*/
			 
		   break;
		   case FSM_MASTER_COMM_INITIATE_OPEN:
		       spi_rcv_enable_flag = STATE_YES;
		       spi_tx_enable_flag = STATE_YES;
               master_spi_comm_fsm_state = FSM_MASTER_COMM_INITIATE_OPEN;			 
			   is_rcvd_invalid_char_flag = STATE_YES;
			   is_first_instance_occur_flag = STATE_NO;
			   Reset_Transfer_Parameters();	
		       MSSP_SLAVE_SELECT_PIN = 0;       //Slave is Selected
		       spi_master_tx_data_str[spi_num_chars_transmitted] = SYN_CHAR;
			   SPI_Transmit_Char(spi_master_tx_data_str[spi_num_chars_transmitted]);
			   switch(spi_master_tx_data_str[spi_num_chars_transmitted] ) 
			   {
			        case SYN_CHAR:					 			
						++transmit_count;
						
	                    //SHOULD_REMOVE
			            UART_Transmit_Str("Tx master's SYN_CHAR \r");
			            UART_Transmit_Str("SYN_CHAR transmit count: ");
					    UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, transmit_count);
			            UART_Transmit_Char('\r');
						 	   						       	
                    break;          
                    default:
						
			           //SHOULD_REMOVE
				        UART_Transmit_Str("Tx master's non SYN_CHAR: ");
				        UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, spi_master_tx_data_str[spi_num_chars_transmitted]);
				        UART_Transmit_Char('\r');
						
                     	spi_master_tx_data_str[spi_num_chars_transmitted] = SYN_CHAR ;				 
				}
                spi_master_rcvd_data_str[spi_num_chars_received] =  SPI_Receive_Char();						
				switch( spi_master_rcvd_data_str[spi_num_chars_received])
		        {	
                    case STS_CHAR:
					   is_rcvd_invalid_char_flag = STATE_NO;							
					   master_spi_comm_fsm_state = FSM_MASTER_COMM_ESTABLISHED;
					   
                       //SHOULD_REMOVE 
					   UART_Transmit_Str("Rcvd slave's STS_CHAR \r");
                       UART_Transmit_Str("master in FSM_MASTER_COMM_ESTABLISHED state \r");						 
					         						 
					break; 					
				    default:
					
					   spi_num_chars_received = 0; 
	                   memset(spi_master_rcvd_data_str, NULL_CHAR, MAX_COMM_NUM_CHARS);	
                       master_spi_comm_fsm_state = FSM_MASTER_COMM_SYN_SENT;
					
			           //SHOULD_REMOVE
					   UART_Transmit_Str("ERR: Rcvd slave's non STS_CHAR: ");
					   UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, spi_master_rcvd_data_str[spi_num_chars_received]);
					   UART_Transmit_Char('\r');
					   UART_Transmit_Str("master in FSM_MASTER_COMM_SYN_SENT state\r");		
				}
                
			   
		   break;
           case FSM_MASTER_COMM_SYN_SENT:		      
		      if(spi_tx_enable_flag == STATE_YES || spi_rcv_enable_flag == STATE_YES )
	          {
				  if(transmit_count <  MAX_TRANSMIT_COUNT)
				  {
				     if(is_rcvd_invalid_char_flag == STATE_YES)					 
				     {
					     SPI_Transmit_Char(spi_master_tx_data_str[spi_num_chars_transmitted]);
				         switch(spi_master_tx_data_str[spi_num_chars_transmitted] ) 
				         {
					        case SYN_CHAR:					 			
								++transmit_count;
								
	                           //SHOULD_REMOVE
					           UART_Transmit_Str("Tx master's SYN_CHAR \r");
					           UART_Transmit_Str("SYN_CHAR transmit count: ");
							   UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, transmit_count);
					           UART_Transmit_Char('\r');
						 	   						       	
                            break;          
                            default:
						
					           //SHOULD_REMOVE
					           UART_Transmit_Str("Tx master's non SYN_CHAR: ");
					           UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, spi_master_tx_data_str[spi_num_chars_transmitted]);
					           UART_Transmit_Char('\r');
							   
                     		  spi_master_tx_data_str[spi_num_chars_transmitted] = SYN_CHAR;		 
				         }
				         spi_master_rcvd_data_str[spi_num_chars_received] =  SPI_Receive_Char();
						
				         switch( spi_master_rcvd_data_str[spi_num_chars_received])
		                 {	
                             case STS_CHAR:
					            is_rcvd_invalid_char_flag = STATE_NO;	
								master_spi_comm_fsm_state = FSM_MASTER_COMM_ESTABLISHED;
								
						        //SHOULD_REMOVE 
						        UART_Transmit_Str("Rcvd slave's STS_CHAR \r");
					           	UART_Transmit_Str("master in FSM_MASTER_COMM_ESTABLISHED state \r");		                     
					 					 
					          break; 					
				            /* case NAK_CHAR:
				        	   break; */
					          default:
							    //  ++spi_num_chars_received;
					            is_rcvd_invalid_char_flag = STATE_YES;
								
					            //SHOULD_REMOVE
					            UART_Transmit_Str("ERR: Rcvd slave's non STS_CHAR: ");
					            UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, spi_master_rcvd_data_str[spi_num_chars_received]);
					            UART_Transmit_Char('\r');
				         }
                         if(master_spi_comm_fsm_state == FSM_MASTER_COMM_ESTABLISHED)					
			             {                    
                              break;					 
				         }
                         //Delay_Time_By_Count(TIME_CNT_WAIT_RETRANSMIT);							 
		             } 
				 }
				 else
				 {
	                 MSSP_SLAVE_SELECT_PIN = 1;  //Slave is unselected 
	                 master_spi_comm_fsm_state = FSM_MASTER_COMM_CLOSED;
						 
	                 //SHOULD_REMOVE
	                 UART_Transmit_Str("ERR: Slave is unselected \r");	               
					 UART_Transmit_Str("ERR: Master's max transmit count: ");
					 UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, transmit_count);
					 UART_Transmit_Char('\r');
					
					 break;
				 }
				 			 
			  }
		   break;		   
		   case FSM_MASTER_COMM_ESTABLISHED:
		   
               //SHOULD_REMOVE
			   UART_Transmit_Str("Master's Tx Data: ");
			   UART_Transmit_Str(master_tx_valid_data_str);
			   UART_Transmit_Char('\r');
			   lcd_const_disp_flag[0] = STATE_NO;
			   
			   /* DATA_TERMINATOR_CHAR is not included in valid data len */
                master_tx_valid_data_str_len = strlen(master_tx_valid_data_str);
			    Reset_Transfer_Parameters();	
			    Append_Data_Terminator_Char(master_tx_valid_data_str);			   
		        if(Num_To_Str_Master_Tx_Data_Len_Calc(master_tx_valid_data_str_len, spi_master_tx_data_str) < 0)
			    {
					is_tx_valid_data_flag = STATE_NO;	
				    master_spi_comm_fsm_state = FSM_MASTER_COMM_INITIATE_CLOSE;
					   
					//SHOULD_REMOVE
					UART_Transmit_Str("Master in FSM_MASTER_COMM_INITIATE_CLOSE state \r");	
					
					break;
			    }
			    first_padded_char_rcvd_flag = STATE_NO;				       
                memset(padded_data_to_slave_str, NULL_CHAR, MAX_COMM_NUM_CHARS);	
				memset(master_rcvd_valid_data_str, NULL_CHAR, MAX_COMM_NUM_CHARS);				     
				master_spi_comm_fsm_state = FSM_MASTER_COMM_MSG; 
				master_spi_msg_fsm_state = FSM_MASTER_MSG_DATA_LEN;  
				
				//SHOULD_REMOVE
        		UART_Transmit_Str("master in FSM_MASTER_MSG_DATA_LEN state \r");	
		        UART_Transmit_Str("Tx Master Len   Rcvd Slave Len \r");	
				 
		   break;
		   case FSM_MASTER_COMM_MSG:
		   break; 
           case FSM_MASTER_PROCESS_RCVD_DATA:	
                if(lcd_const_disp_flag[MASTER_LCD_RCVD_DATA_LINE_NUM] == STATE_NO)	
				{					 
				    Goto_XY_LCD_Disp(MASTER_LCD_RCVD_DATA_LINE_NUM,1);
				    Data_Str_Disp_LCD(master_rcvd_valid_data_str);
					lcd_const_disp_flag[MASTER_LCD_RCVD_DATA_LINE_NUM] = STATE_YES;
					
					//SHOULD_REMOVE
					UART_Transmit_Str("Rcvd Slave's valid Data: ");
					UART_Transmit_Str(master_rcvd_valid_data_str);
					UART_Transmit_Char('\r');
					
				}
				is_rcvd_valid_data_flag = DATA_STATE_VALID;
				master_spi_comm_fsm_state = FSM_MASTER_COMM_CLOSE_RCV_CONTINUE_TX; 
				UART_Transmit_Str("Master in FSM_MASTER_COMM_CLOSE_RCV_CONTINUE_TX state \r");	
			  
           break;
		   case FSM_MASTER_COMM_INITIATE_CLOSE:		      				 
		      Reset_Transfer_Parameters();			  
              master_spi_msg_fsm_state = FSM_MASTER_MSG_NO_DATA;			  
		      spi_master_tx_data_str[spi_num_chars_transmitted] = DC4_CHAR;
			  if(spi_tx_enable_flag == STATE_YES || spi_rcv_enable_flag == STATE_YES )
	          {
                   SPI_Transmit_Char(spi_master_tx_data_str[spi_num_chars_transmitted]);
			       switch(spi_master_tx_data_str[spi_num_chars_transmitted] ) 
				   {
					   case DC4_CHAR:
					      ++transmit_count;
								
	                      //SHOULD_REMOVE
					      UART_Transmit_Str("Tx master's DC4_CHAR \r");
					      UART_Transmit_Str("DC4_CHAR transmit count: ");
						  UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, transmit_count);
					      UART_Transmit_Char('\r');
					 					   
                       break;
					   default:
					   
					     //SHOULD_REMOVE
					     UART_Transmit_Str("Tx master's non DC4_CHAR: ");
					     UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, spi_master_tx_data_str[spi_num_chars_transmitted]);
					     UART_Transmit_Char('\r');
						 spi_master_tx_data_str[spi_num_chars_transmitted] =  DC4_CHAR;
					 
				  }	
				  spi_master_rcvd_data_str[spi_num_chars_received] = SPI_Receive_Char();
		          switch( spi_master_rcvd_data_str[spi_num_chars_received])
		          {	
                     case DC4_CHAR:
					 
					   //SHOULD_REMOVE
						UART_Transmit_Str("Rcvd slave's DC4_CHAR \r");	
						
					 break;
					 case ACK_CHAR:
					    Reset_Transfer_Parameters();
					   	master_spi_comm_fsm_state = FSM_MASTER_COMM_DC4_WAIT_2; 
						spi_master_tx_data_str[spi_num_chars_transmitted] = NULL_CHAR;
						
						//SHOULD_REMOVE
						UART_Transmit_Str("Rcvd slave's ACK_CHAR \r");	
				        UART_Transmit_Str("Master in FSM_MASTER_COMM_DC4_WAIT_2 state \r");	
						
					 break; 
                     default:
					   Reset_Transfer_Parameters(); 
					   master_spi_comm_fsm_state = FSM_MASTER_COMM_DC4_WAIT_1; 
					   spi_master_tx_data_str[spi_num_chars_transmitted] =  DC4_CHAR;
						
	                   //SHOULD_REMOVE
					   UART_Transmit_Str("ERR: Rcvd slave's non ACK_CHAR: ");
					   UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, spi_master_rcvd_data_str[spi_num_chars_received]);
					   UART_Transmit_Char('\r');
					   UART_Transmit_Str("master in FSM_MASTER_COMM_DC4_WAIT_1 state\r");					   
		          }                   				  
			  }				  
           break; 
           case FSM_MASTER_COMM_DC4_WAIT_1:
              if(spi_tx_enable_flag == STATE_YES || spi_rcv_enable_flag == STATE_YES )
	          {
				  if(transmit_count < MAX_TRANSMIT_COUNT)
				  {
				     if(is_rcvd_invalid_char_flag == STATE_YES)					 
				     {
					     SPI_Transmit_Char(spi_master_tx_data_str[spi_num_chars_transmitted]);
				         switch(spi_master_tx_data_str[spi_num_chars_transmitted] ) 
				         {
					        case DC4_CHAR:					 			
								++transmit_count;
								
	                           //SHOULD_REMOVE
					           UART_Transmit_Str("Tx master's DC4_CHAR \r");
					           UART_Transmit_Str("DC4_CHAR transmit count: ");
							   UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, transmit_count);
					           UART_Transmit_Char('\r');
						 	   						       	
                            break;          
                            default:
						
					           //SHOULD_REMOVE
					           UART_Transmit_Str("Tx master's non DC4_CHAR: ");
					           UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, spi_master_tx_data_str[spi_num_chars_transmitted]);
					           UART_Transmit_Char('\r');
							   
                     		   spi_master_tx_data_str[spi_num_chars_transmitted] =  DC4_CHAR;		 
				         }
				         spi_master_rcvd_data_str[spi_num_chars_received] =  SPI_Receive_Char();
						
				         switch( spi_master_rcvd_data_str[spi_num_chars_received])
		                 {	
                             case ACK_CHAR:
					            is_rcvd_invalid_char_flag = STATE_NO;
								Reset_Transfer_Parameters();
								master_spi_comm_fsm_state = FSM_MASTER_COMM_DC4_WAIT_2;
                                spi_master_tx_data_str[spi_num_chars_transmitted] = NULL_CHAR;	
								
						        //SHOULD_REMOVE 
						        UART_Transmit_Str("Rcvd slave's ACK_CHAR \r");
								UART_Transmit_Str("Master in FSM_MASTER_COMM_DC4_WAIT_2 state \r");
					           						 
					          break; 
                              case NULL_CHAR:
							    is_rcvd_invalid_char_flag = STATE_YES; 
                              break;							  
				              case DC4_CHAR:
							    is_rcvd_invalid_char_flag = STATE_NO;
								Reset_Transfer_Parameters();
								master_spi_comm_fsm_state = FSM_MASTER_COMM_CLOSING;
                                spi_master_tx_data_str[spi_num_chars_transmitted] = ACK_CHAR;	
								
						        //SHOULD_REMOVE 
						        UART_Transmit_Str("Rcvd slave's DC4_CHAR \r");
								UART_Transmit_Str("Master in FSM_MASTER_COMM_CLOSING state \r");
								
							  break;
					          default:
					            //  ++spi_num_chars_received;
						        is_rcvd_invalid_char_flag = STATE_YES;
								
					            //SHOULD_REMOVE
					            UART_Transmit_Str("ERR: Rcvd slave's non ACK_CHAR and non DC4_CHAR : ");
					            UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, spi_master_rcvd_data_str[spi_num_chars_received]);
					            UART_Transmit_Char('\r');
				         }
                         if(master_spi_comm_fsm_state == FSM_MASTER_COMM_DC4_WAIT_2 || master_spi_comm_fsm_state == FSM_MASTER_COMM_CLOSING)	
                            break;
                         //Delay_Time_By_Count(TIME_CNT_WAIT_RETRANSMIT);						
		             }
				 }
				 else
				 {
	                 MSSP_SLAVE_SELECT_PIN = 1;  //Slave is unselected 
	                 master_spi_comm_fsm_state = FSM_MASTER_COMM_CLOSED;
						 
	                 //SHOULD_REMOVE
	                 UART_Transmit_Str("ERR: Slave is unselected \r");	               
					 UART_Transmit_Str("ERR: Master's max transmit count: ");
					 UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, transmit_count);
					 UART_Transmit_Char('\r');
					
					 break;
				 }
				 			 
			  }		      
           break;   
           case FSM_MASTER_COMM_DC4_WAIT_2:
              if(spi_tx_enable_flag == STATE_YES || spi_rcv_enable_flag == STATE_YES )
	          {
				 
				   if(is_rcvd_invalid_char_flag == STATE_YES)					 
				    {
					     SPI_Transmit_Char(spi_master_tx_data_str[spi_num_chars_transmitted]);
				         switch(spi_master_tx_data_str[spi_num_chars_transmitted] ) 
				         {
					        case NULL_CHAR:					 			
								
	                           //SHOULD_REMOVE
					           UART_Transmit_Str("Tx master's NULL_CHAR as fill char \r");					          
						 	   						       	
                            break;          
                            default:
						
					           //SHOULD_REMOVE
					           UART_Transmit_Str("Tx master's non NULL_CHAR: ");
					           UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, spi_master_tx_data_str[spi_num_chars_transmitted]);
					           UART_Transmit_Char('\r');
							   
                     		   spi_master_tx_data_str[spi_num_chars_transmitted] = NULL_CHAR ;		 
				         }
				         spi_master_rcvd_data_str[spi_num_chars_received] =  SPI_Receive_Char();						
				         switch( spi_master_rcvd_data_str[spi_num_chars_received])
		                 {	
                             case DC4_CHAR:
					            is_rcvd_invalid_char_flag = STATE_NO;
								Reset_Transfer_Parameters();
								master_spi_comm_fsm_state = FSM_MASTER_COMM_SENT_LAST_ACK;
								
						        //SHOULD_REMOVE 
						        UART_Transmit_Str("Rcvd slave's DC4_CHAR \r");
								UART_Transmit_Str("Master in FSM_MASTER_COMM_SENT_LAST_ACK state \r");
					           						 
					          break;
                              							  
				            /* case NAK_CHAR:
				        	   break; */
					          default:
					           // ++spi_num_chars_received;
						        is_rcvd_invalid_char_flag = STATE_YES;
								
					            //SHOULD_REMOVE
					            UART_Transmit_Str("ERR: Rcvd slave's non DC4_CHAR: ");
					            UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, spi_master_rcvd_data_str[spi_num_chars_received]);
					            UART_Transmit_Char('\r');
				         }
                         if(master_spi_comm_fsm_state == FSM_MASTER_COMM_TIME_WAIT)	
                            break;
                         //Delay_Time_By_Count(TIME_CNT_WAIT_RETRANSMIT); 						
		             } 				
				     				 
			  }		      		       
           break;
		   case FSM_MASTER_COMM_CLOSING:
		     if(spi_tx_enable_flag == STATE_YES || spi_rcv_enable_flag == STATE_YES )
	          {
				 if(transmit_count <  MAX_TRANSMIT_COUNT)
				 {
				    if(is_rcvd_invalid_char_flag == STATE_YES)					 
				    {
					     SPI_Transmit_Char(spi_master_tx_data_str[spi_num_chars_transmitted]);
				         switch(spi_master_tx_data_str[spi_num_chars_transmitted] ) 
				         {
					        case ACK_CHAR:					 			
								++transmit_count;
								
	                           //SHOULD_REMOVE
					           UART_Transmit_Str("Tx master's ACK_CHAR \r");					          
						 	   UART_Transmit_Str("ACK_CHAR transmit count: ");
							   UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, transmit_count);
					           UART_Transmit_Char('\r');
							   
                            break;          
                            default:
						
					           //SHOULD_REMOVE
					           UART_Transmit_Str("Tx master's non ACK_CHAR: ");
					           UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, spi_master_tx_data_str[spi_num_chars_transmitted]);
					           UART_Transmit_Char('\r');
							   
                     		   spi_master_tx_data_str[spi_num_chars_transmitted] = ACK_CHAR ;		 
				         }
				         spi_master_rcvd_data_str[spi_num_chars_received] =  SPI_Receive_Char();
						
				         switch( spi_master_rcvd_data_str[spi_num_chars_received])
		                 {	
                             case ACK_CHAR:
					            is_rcvd_end_char_flag = STATE_YES;	
						        is_rcvd_invalid_char_flag = STATE_NO;
								Reset_Transfer_Parameters();
								master_spi_comm_fsm_state = FSM_MASTER_COMM_TIME_WAIT;
								
						        //SHOULD_REMOVE 
						        UART_Transmit_Str("Rcvd slave's ACK_CHAR \r");
								UART_Transmit_Str("Master in FSM_MASTER_COMM_TIME_WAIT state \r");
					           						 
					          break;
					          default:
					            // ++spi_num_chars_received;
						        is_rcvd_invalid_char_flag = STATE_YES;
								
					            //SHOULD_REMOVE
					            UART_Transmit_Str("ERR: Rcvd slave's non ACK_CHAR: ");
					            UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, spi_master_rcvd_data_str[spi_num_chars_received]);
					            UART_Transmit_Char('\r');
								
				         }
                         if(master_spi_comm_fsm_state == FSM_MASTER_COMM_TIME_WAIT)	
                            break;						
                        // Delay_Time_By_Count(TIME_CNT_WAIT_RETRANSMIT); 							
		             } 		 
			     }
                 else
			     {
	                 MSSP_SLAVE_SELECT_PIN = 1;  //Slave is unselected 
	                 master_spi_comm_fsm_state = FSM_MASTER_COMM_CLOSED;
						 
	                 //SHOULD_REMOVE
	                 UART_Transmit_Str("ERR: Slave is unselected \r");	               
					 UART_Transmit_Str("ERR: Master's max transmit count: ");
					 UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, transmit_count);
					 UART_Transmit_Char('\r');
					
					 break;
			     }
			  }			 
		  break;
		  case FSM_MASTER_COMM_SENT_LAST_ACK:
		      spi_master_tx_data_str[spi_num_chars_transmitted] = ACK_CHAR;
			  if(spi_tx_enable_flag == STATE_YES || spi_rcv_enable_flag == STATE_YES )
	          {
                   SPI_Transmit_Char(spi_master_tx_data_str[spi_num_chars_transmitted]);
			       switch(spi_master_tx_data_str[spi_num_chars_transmitted] ) 
				   {
					   case ACK_CHAR:
					      ++transmit_count;
						   master_spi_comm_fsm_state = FSM_MASTER_COMM_TIME_WAIT;
						   
	                      //SHOULD_REMOVE
					      UART_Transmit_Str("Tx master's ACK_CHAR \r");
					      UART_Transmit_Str("ACK_CHAR transmit count: ");
						  UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, transmit_count);
					      UART_Transmit_Char('\r');
					 					   
                       break;
					   default:
					   
					     //SHOULD_REMOVE
					     UART_Transmit_Str("Tx master's non ACK_CHAR: ");
					     UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, spi_master_tx_data_str[spi_num_chars_transmitted]);
					     UART_Transmit_Char('\r');
						 spi_master_tx_data_str[spi_num_chars_transmitted] = ACK_CHAR ;
					 
				  }	
				  spi_master_rcvd_data_str[spi_num_chars_received] = SPI_Receive_Char();
		          switch( spi_master_rcvd_data_str[spi_num_chars_received])
		          {	
                     case DC4_CHAR:	
					 case ACK_CHAR:	
					 case NULL_CHAR:
					 break; 
                     default:
					 
	                   //SHOULD_REMOVE
					   UART_Transmit_Str("ERR: Rcvd slave's any char: ");
					   UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, spi_master_rcvd_data_str[spi_num_chars_received]);
					   UART_Transmit_Char('\r');
		          }                   				  
			  }			
		  break;
          case FSM_MASTER_COMM_TIME_WAIT:
              Delay_Time_By_Count(60000ul);
              master_spi_comm_fsm_state = FSM_MASTER_WAIT_TO_UNSELECT;

			  //SHOULD_REMOVE
              UART_Transmit_Str("Master in FSM_MASTER_WAIT_TO_UNSELECT state \r");	
			  
          break;
 		  case FSM_MASTER_COMM_RCVD_TO_CLOSE:
		      spi_master_tx_data_str[spi_num_chars_transmitted] = ACK_CHAR;
			  if(spi_tx_enable_flag == STATE_YES || spi_rcv_enable_flag == STATE_YES )
	          {
                   SPI_Transmit_Char(spi_master_tx_data_str[spi_num_chars_transmitted]);
			       switch(spi_master_tx_data_str[spi_num_chars_transmitted] ) 
				   {
					   case ACK_CHAR:
					      ++transmit_count;
								
	                      //SHOULD_REMOVE
					      UART_Transmit_Str("Tx master's ACK_CHAR \r");
					      UART_Transmit_Str("ACK_CHAR transmit count: ");
						  UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, transmit_count);
					      UART_Transmit_Char('\r');
					 					   
                       break;
					   default:
					   
					     //SHOULD_REMOVE
					     UART_Transmit_Str("Tx master's non ACK_CHAR: ");
					     UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, spi_master_tx_data_str[spi_num_chars_transmitted]);
					     UART_Transmit_Char('\r');
						 
						 spi_master_tx_data_str[spi_num_chars_transmitted] =  ACK_CHAR;					 
				  }	
				  spi_master_rcvd_data_str[spi_num_chars_received] =  SPI_Receive_Char();
		          switch( spi_master_rcvd_data_str[spi_num_chars_received])
		          {	
				     case NULL_CHAR:
					 case DC4_CHAR:
					 case ACK_CHAR:						
				     default:
					    is_rcvd_invalid_char_flag = STATE_YES;
						Reset_Transfer_Parameters();
					    master_spi_comm_fsm_state = FSM_MASTER_COMM_CLOSE_WAIT; 
						
	                   //SHOULD_REMOVE
					   UART_Transmit_Str("ERR: Rcvd slave's any char: ");
					   UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, spi_master_rcvd_data_str[spi_num_chars_received]);
					   UART_Transmit_Char('\r');
					   UART_Transmit_Str("master in FSM_MASTER_COMM_CLOSE_WAIT state\r");
					   
		          }                   				  
			  }				       
		   break;
		   case FSM_MASTER_COMM_CLOSE_WAIT:
              if(spi_tx_enable_flag == STATE_YES || spi_rcv_enable_flag == STATE_YES )
	          {
				    if(is_rcvd_invalid_char_flag == STATE_YES)					 
				    {
					     SPI_Transmit_Char(spi_master_tx_data_str[spi_num_chars_transmitted]);
				         switch(spi_master_tx_data_str[spi_num_chars_transmitted] ) 
				         {
                            case ACK_CHAR:
							    ++transmit_count;
								
	                           //SHOULD_REMOVE
					            UART_Transmit_Str("Tx master's ACK_CHAR \r");
					            UART_Transmit_Str("ACK_CHAR transmit count: ");
						        UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, transmit_count);
					            UART_Transmit_Char('\r');							   	
							   
                            break;							
                            default:
						
					           //SHOULD_REMOVE
					           UART_Transmit_Str("Tx master's non ACK_CHAR: ");
					           UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, spi_master_tx_data_str[spi_num_chars_transmitted]);
					           UART_Transmit_Char('\r');
							   
                     		   spi_master_tx_data_str[spi_num_chars_transmitted] = ACK_CHAR;		 
				         }
				         spi_master_rcvd_data_str[spi_num_chars_received] =  SPI_Receive_Char();
						
				         switch( spi_master_rcvd_data_str[spi_num_chars_received])
		                 {	
                            case NULL_CHAR:
							case DC4_CHAR:
							case ACK_CHAR:
							   is_rcvd_invalid_char_flag = STATE_YES;
							break;
 							default:							 
					           // ++spi_num_chars_received;
						        is_rcvd_invalid_char_flag = STATE_YES;
								
					            //SHOULD_REMOVE
					            UART_Transmit_Str("ERR: Rcvd slave's non ACK_CHAR: ");
					            UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, spi_master_rcvd_data_str[spi_num_chars_received]);
					            UART_Transmit_Char('\r');
				         }
                        /*  
						   // if app closed 
						 master_spi_comm_fsm_state = FSM_MASTER_COMM_APPL_CLOSED;
						 Reset_Transfer_Parameters();
						 spi_master_tx_data_str[spi_num_chars_transmitted] = DC4_CHAR; 
						 
						 //SHOULD_REMOVE
						 UART_Transmit_Str("master in FSM_MASTER_COMM_APPL_CLOSED state\r"); */
						 
						 if(master_spi_comm_fsm_state == FSM_MASTER_COMM_APPL_CLOSED)	
                             break; 
                         // Delay_Time_By_Count(TIME_CNT_WAIT_RETRANSMIT);	 						 
		             } 				
				   			 
			  }		      		      
		   break;
		   case FSM_MASTER_COMM_APPL_CLOSED:
		      if(spi_tx_enable_flag == STATE_YES || spi_rcv_enable_flag == STATE_YES )				  
	          {
				  
				         SPI_Transmit_Char(spi_master_tx_data_str[spi_num_chars_transmitted]);
				         switch(spi_master_tx_data_str[spi_num_chars_transmitted] ) 
				         {
					        case DC4_CHAR:
							    ++transmit_count;
								
							   //SHOULD_REMOVE
					           UART_Transmit_Str("Tx master's DC4_CHAR \r");
							   UART_Transmit_Str("DC4_CHAR transmit count: ");
						       UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, transmit_count);
					           UART_Transmit_Char('\r');
							   
                            break;							
                            default:
						
					           //SHOULD_REMOVE
					           UART_Transmit_Str("Tx master's non DC4_CHAR: ");
					           UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, spi_master_tx_data_str[spi_num_chars_transmitted]);
					           UART_Transmit_Char('\r');
							   
                     		   spi_master_tx_data_str[spi_num_chars_transmitted] = DC4_CHAR;		 
				         }
				         spi_master_rcvd_data_str[spi_num_chars_received] =  SPI_Receive_Char();						
				         switch( spi_master_rcvd_data_str[spi_num_chars_received])
		                 {	
                            case ACK_CHAR:
							   is_rcvd_invalid_char_flag = STATE_NO;
							   master_spi_comm_fsm_state = FSM_MASTER_COMM_CLOSED;
							   
							   //SHOULD_REMOVE
					            UART_Transmit_Str("Rcvd slave's ACK_CHAR \r"); 
                                UART_Transmit_Str("master in FSM_MASTER_COMM_CLOSED state\r");
								
							break;
 							default:
							 //   ++spi_num_chars_received;
						        is_rcvd_invalid_char_flag = STATE_NO;
								master_spi_comm_fsm_state = FSM_MASTER_COMM_LAST_ACK;
								
					            //SHOULD_REMOVE
					            UART_Transmit_Str("ERR: Rcvd slave's non ACK_CHAR: ");
								UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, spi_master_rcvd_data_str[spi_num_chars_received]);
					            UART_Transmit_Char('\r');	
					            UART_Transmit_Str("master in FSM_MASTER_COMM_LAST_ACK state\r");
				         }
                        
						 if(master_spi_comm_fsm_state == FSM_MASTER_COMM_CLOSED || master_spi_comm_fsm_state == FSM_MASTER_COMM_LAST_ACK )	
                             break; 						 
		             				
				        // Delay_Time_By_Count(TIME_CNT_WAIT_RETRANSMIT);				 
			  }		      		    
		   break;
		   case FSM_MASTER_COMM_LAST_ACK:
		      if(spi_tx_enable_flag == STATE_YES || spi_rcv_enable_flag == STATE_YES )
	          {
				   if(is_rcvd_invalid_char_flag == STATE_YES)					 
				   { 
				       SPI_Transmit_Char(spi_master_tx_data_str[spi_num_chars_transmitted]);
				       switch(spi_master_tx_data_str[spi_num_chars_transmitted] ) 
				       {
					      case DC4_CHAR:
							   ++transmit_count;
							   
							   //SHOULD_REMOVE
					           UART_Transmit_Str("Tx master's DC4_CHAR \r");	
							   UART_Transmit_Str("DC4_CHAR transmit count: ");
						       UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2, transmit_count);
					           UART_Transmit_Char('\r');
							   
                            break;							
                            default:
						
					           //SHOULD_REMOVE
					           UART_Transmit_Str("Tx master's non DC4_CHAR: ");
					           UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, spi_master_tx_data_str[spi_num_chars_transmitted]);
					           UART_Transmit_Char('\r');
							   
                     		   spi_master_tx_data_str[spi_num_chars_transmitted] = DC4_CHAR;		 
				        }
				        spi_master_rcvd_data_str[spi_num_chars_received] =  SPI_Receive_Char();
						
				        switch( spi_master_rcvd_data_str[spi_num_chars_received])
		                {	
                            case ACK_CHAR:
							   is_rcvd_invalid_char_flag = STATE_NO;
							   master_spi_comm_fsm_state = FSM_MASTER_COMM_CLOSED;
							   
							   //SHOULD_REMOVE
					            UART_Transmit_Str("Rcvd slave's ACK_CHAR \r"); 
                                UART_Transmit_Str("master in FSM_MASTER_COMM_CLOSED state\r");
								
							break;
 							default:
							 //   ++spi_num_chars_received;
						        is_rcvd_invalid_char_flag = STATE_YES;							
								
					            //SHOULD_REMOVE
					            UART_Transmit_Str("ERR: Rcvd slave's non ACK_CHAR: ");
                                UART_Transmit_Num(DISP_FLAG_HEX_DIGIT2, spi_master_rcvd_data_str[spi_num_chars_received]);
					            UART_Transmit_Char('\r');	
								
		                } 
                        if( master_spi_comm_fsm_state == FSM_MASTER_COMM_CLOSED)
                            break;							
				       // Delay_Time_By_Count(TIME_CNT_WAIT_RETRANSMIT);	
				   }						
			  }		      	   
		   break;
		   case FSM_MASTER_WAIT_TO_UNSELECT:
                 Delay_Time_By_Count(TIME_CNT_WAIT_TO_UNSELECT);
				 MSSP_SLAVE_SELECT_PIN = 1;  //Slave is unselected
				 master_spi_comm_fsm_state = FSM_MASTER_COMM_FINISH; 

                //SHOULD_REMOVE
                UART_Transmit_Str("Slave unselected \r");
	            UART_Transmit_Str("Master in FSM_MASTER_COMM_FINISH state \r");	
			    UART_Transmit_Char('\r');  
				
		   break;
		   case FSM_MASTER_COMM_FINISH:
				 master_spi_comm_fsm_state = FSM_MASTER_COMM_CLOSED; 
				 
				 //SHOULD_REMOVE
				 UART_Transmit_Str("master in FSM_MASTER_COMM_CLOSED state \r");	
			     				 
		   break;		   			 
		   default:
			 /* error: invalid comm fsm state  */
			 ;
	// #endif
	 
		}
 }
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
 static void Append_Data_Terminator_Char(char *valid_data_str)
{
	unsigned int valid_data_str_len;
	
	valid_data_str_len = strlen(valid_data_str);
	valid_data_str[valid_data_str_len] = DATA_TERMINATOR_CHAR;
	valid_data_str[valid_data_str_len + 1] = NULL_CHAR;
	
	//SHOULD_REMOVE
	UART_Transmit_Str("Data terminated str: ");
	UART_Transmit_Str(valid_data_str);
	UART_Transmit_Char('\r');
	
} 
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
static int Num_To_Str_Master_Tx_Data_Len_Calc(const unsigned int master_tx_valid_data_str_len, char *spi_master_tx_data_str)
{
	unsigned int digit_face_value, normal_digit_pos = 0, digit_pos = REQ_COMM_DATA_LEN - 1, cur_lcd_data_from_master_str_len_num = master_tx_valid_data_str_len, j;
	char normal_master_data_len_str[REQ_COMM_DATA_LEN];
	unsigned long int digit_place_value = 1;
	
	for(j =0; j < REQ_COMM_DATA_LEN - 1; ++j)
	  digit_place_value *= 10;
  
	while(normal_digit_pos < REQ_COMM_DATA_LEN)
	{
		digit_face_value = cur_lcd_data_from_master_str_len_num / digit_place_value;
		normal_master_data_len_str[normal_digit_pos] = '0' + digit_face_value;
		if(normal_master_data_len_str[normal_digit_pos] < '0' || normal_master_data_len_str[normal_digit_pos] > '9')
		{
			// error: To Tx non numeric digit of data len
			
			//SHOULD_REMOVE			
			 Goto_XY_LCD_Disp(MASTER_LCD_ERR_LINE_NUM,1);
             Data_Str_Disp_LCD("EX ");
			 UART_Transmit_Str("ERR: To Tx master Data len as Non digit: ");
			 UART_Transmit_Char(normal_master_data_len_str[normal_digit_pos]);
			 UART_Transmit_Str(" , Pos : ");
			 UART_Transmit_Num(DISP_FLAG_NUM_DIGIT2,normal_digit_pos );
			 UART_Transmit_Char('\r');
			
			return -1;
		}
        		
		spi_master_tx_data_str[digit_pos] = normal_master_data_len_str[normal_digit_pos];
		cur_lcd_data_from_master_str_len_num %= digit_place_value;
		digit_place_value /= 10;
		++normal_digit_pos;
		--digit_pos;
	}
	/* append DATA_TERMINATOR_CHAR   */
	spi_master_tx_data_str[REQ_COMM_DATA_LEN] = DATA_TERMINATOR_CHAR;
	spi_master_tx_data_str[REQ_COMM_DATA_LEN + 1] = NULL_CHAR;
	
    //SHOULD_REMOVE
    UART_Transmit_Str("To Tx master's data len in str: ");
	UART_Transmit_Str(spi_master_tx_data_str);
	UART_Transmit_Char('\r');
	
    return 0;	
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void Reset_Transfer_Parameters()
{
	spi_num_chars_received = 0; 
	memset(spi_master_rcvd_data_str, NULL_CHAR, MAX_COMM_NUM_CHARS);
	is_rcvd_end_char_flag = STATE_NO;
	transmit_count = 0;
	spi_num_chars_transmitted = 0;
	memset(spi_master_tx_data_str, NULL_CHAR, MAX_COMM_NUM_CHARS);	
	is_tx_end_char_flag = STATE_NO;
}
 /*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
