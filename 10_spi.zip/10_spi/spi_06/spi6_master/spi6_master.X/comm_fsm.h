/**************************************************************************
   FILE          :    comm_fsm.h
 
   PURPOSE       :    Master communcation FSM header file
 
   AUTHOR        :    K.M.Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 /* to avoid this header file to be included more than once, conditional directive is used  */
#ifndef _COMM_FSM_H
#define _COMM_FSM_H

/* -------------------- macro  defination ---------------------------------------- */
#define REQ_COMM_DATA_LEN                (2U)
#define MAX_COMM_NUM_CHARS              (20U)
#define TIME_CNT_WAIT_TO_UNSELECT    (1000UL)
#define TIME_CNT_WAIT_RETRANSMIT    (50000ul)
#define MAX_TRANSMIT_COUNT                (10)

#define DATA_TERMINATOR_CHAR          ('\\')                 
#define NULL_CHAR                     ('\0')

#define ACK_CHAR                     ('\x06')
#define DC4_CHAR                     ('\x14')
#define SYN_CHAR                     ('\x16')
#define PADDED_CHAR                  ('\x80')
#define STS_CHAR                     ('\x93') 

/* -------------------- data type defination ---------------------------------------- */

typedef enum {FSM_MASTER_COMM_CLOSED, FSM_MASTER_COMM_INITIATE_OPEN, FSM_MASTER_COMM_SYN_SENT, FSM_MASTER_COMM_ESTABLISHED, FSM_MASTER_COMM_MSG, FSM_MASTER_COMM_CHECK_DATA_TRANSFERED, \
        FSM_MASTER_PROCESS_RCVD_DATA, FSM_MASTER_COMM_INITIATE_CLOSE, FSM_MASTER_COMM_CLOSE_RCV_CONTINUE_TX, FSM_MASTER_COMM_RCVD_TO_CLOSE, FSM_MASTER_COMM_DC4_WAIT_1, FSM_MASTER_COMM_DC4_WAIT_2, FSM_MASTER_COMM_SENT_LAST_ACK,\
		FSM_MASTER_COMM_CLOSING, FSM_MASTER_COMM_CLOSE_WAIT, FSM_MASTER_COMM_APPL_CLOSED, FSM_MASTER_COMM_LAST_ACK, FSM_MASTER_COMM_TIME_WAIT, FSM_MASTER_WAIT_TO_UNSELECT, FSM_MASTER_COMM_FINISH } spi_comm_fsm_states;

typedef enum {TX_AND_RVCD_INVALID_DATA, TX_INVALID_AND_RCVD_VALID_DATA, TX_VALID_AND_RCVD_INVALID_DATA, TX_AND_RCVD_VALID_DATA} data_validity_states;

/* -------------------- public variable  declaration---------------------------------------- */

extern char master_tx_valid_data_str[MAX_COMM_NUM_CHARS + 1], padded_data_to_slave_str[MAX_COMM_NUM_CHARS + 1];
extern char master_rcvd_valid_data_str[MAX_COMM_NUM_CHARS + 1], spi_master_rcvd_data_str[MAX_COMM_NUM_CHARS + 1], spi_master_tx_data_str[MAX_COMM_NUM_CHARS + 1];
extern unsigned int spi_num_chars_received, spi_num_chars_transmitted, master_tx_valid_data_str_len, is_tx_valid_data_flag, is_rcvd_valid_data_flag, transmit_count;
extern char spi_rcv_enable_flag , spi_tx_enable_flag, is_rcvd_end_char_flag, is_tx_end_char_flag, first_padded_char_rcvd_flag; 
extern spi_comm_fsm_states master_spi_comm_fsm_state;
extern char lcd_const_disp_flag[5] ;

/* -------------------- public prototype declaration --------------------------------------- */

void Comm_Fsm_Proc();
void Reset_Transfer_Parameters();

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
