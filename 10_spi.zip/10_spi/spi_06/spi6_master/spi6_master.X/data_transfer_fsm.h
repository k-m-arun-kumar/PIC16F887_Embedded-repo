/**************************************************************************
   FILE          :   data_transfer_fsm .h
 
   PURPOSE       :   Message Data Transfer  FSM header file
 
   AUTHOR        :  K.M.Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 /* to avoid this header file to be included more than once, conditional directive is used  */
#ifndef _DATA_TRANSFER_FSM_H
#define _DATA_TRANSFER_FSM_H

typedef enum {FSM_MASTER_MSG_DATA_NO_TRANSFER, FSM_MASTER_MSG_DATA_EXCHANGE, FSM_MASTER_MSG_DATA_ONLY_RECEIVE, FSM_MASTER_MSG_DATA_ONLY_TRANSMIT } spi_data_transfer_fsm_states;

/* -------------------- public variable  declaration---------------------------------------- */

extern spi_data_transfer_fsm_states master_spi_data_transfer_fsm_state;
extern unsigned int master_to_rcv_valid_data_str_len, master_rcvd_valid_data_str_len;

/* -------------------- public prototype declaration --------------------------------------- */
extern void Msg_Data_Transfer_Fsm();

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
