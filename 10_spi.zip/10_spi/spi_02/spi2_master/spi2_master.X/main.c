/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    :  by using SPI, first SEND a data string 1 terminated by '\r' by SPI_MASTER to SPI_SLAVE and receive it by SPI in SPI_SLAVE and display it in LCD_SLAVE connected to SPI_SLAVE,

AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : This is a SPI_MASTER code and software flow control and error checking are not implemented                                   
                       
CHANGE LOGS           : 

*****************************************************************************/   
// 'C' source line config statements

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include "main.h"
#include "port.h"
#include "lcd.h"
#include "spi.h"
#include "uart.h"
#include "string.h"
void main()
{
   const char lcd_data_from_master_str[] = "RCVD FROM MASTER \r";
   char spi_rcvd_data_str[30];
   unsigned int spi_num_chars_received = 0, spi_num_chars_transmitted = 0, lcd_data_from_master_str_len;
   char lcd_disp_enable_flag = STATE_YES, spi_rcv_enable_flag = STATE_YES, spi_tx_enable_flag = STATE_YES;
   
   TRISE = 0x00;
   PORTE = 0x00;
   LCD_PORT_GPIO = 0x00;        
   LCD_PORT = 0x00;  
   ANSEL = 0x00;
   ANSELH = 0x00; 
   LCD_Init();
   SPI_Init(SPI_MASTER_OSC_DIV64, SPI_DATA_SAMPLE_MIDDLE, SPI_CLOCK_IDLE_LOW, SPI_IDLE_2_ACTIVE);
   Goto_XY_LCD_Disp(1,1);
   
   while(1)
   {
	   if( spi_rcv_enable_flag == STATE_YES || spi_tx_enable_flag == STATE_YES)
           MSSP_SLAVE_SELECT_PIN = 0;       //Slave is Selected
       //__delay_ms(1);
      while(spi_tx_enable_flag == STATE_YES)
	  {
	      SPI_Data_Write_Char(lcd_data_from_master_str[spi_num_chars_transmitted]);
		  if( lcd_data_from_master_str[spi_num_chars_transmitted] != '\r')
          {				
		     ++spi_num_chars_transmitted;
		  }
          else
		  {
		    spi_num_chars_transmitted = 0;
            spi_tx_enable_flag = STATE_NO;
			lcd_data_from_master_str_len = strlen(lcd_data_from_master_str);
            Delay_Time_By_Count((2 * lcd_data_from_master_str_len), MAX_COUNT_DELAY_TIME_LCDPULSE);			
		  }
	  }	
	  // __delay_ms(1); 
	   while(spi_rcv_enable_flag == STATE_YES)
	  {
         spi_rcvd_data_str[spi_num_chars_received] = SPI_Data_Read_Char();
		 if( spi_rcvd_data_str[spi_num_chars_received] != '\r' )
	     {
			++spi_num_chars_received;
	     }
	     else 
	     {
		    spi_rcvd_data_str[spi_num_chars_received] = '\0';
			Data_Str_Disp_LCD(spi_rcvd_data_str); 
            spi_num_chars_received = 0 ; 
            spi_rcv_enable_flag = STATE_NO;			   
	     } 
	  }	 
        
	  // __delay_ms(1);
     if( spi_rcv_enable_flag == STATE_NO && spi_tx_enable_flag == STATE_NO) 	   
        MSSP_SLAVE_SELECT_PIN = 1; //Slave is Deselected      
       
       //__delay_ms(100);
   }
}
