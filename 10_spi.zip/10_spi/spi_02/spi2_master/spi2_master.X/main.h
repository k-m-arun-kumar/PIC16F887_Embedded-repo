/**************************************************************************
   FILE          :    main.h
 
   PURPOSE       :    project header.  
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   PROJECT header- groups the key information about the PIC16F887 device you have used, along with other key
parameters � such as the oscillator frequency and commonly used information such as common data types in the project
	
  CHANGE LOGS     :
	   
 **************************************************************************/
 
 /* to avoid this header file to be included more than once, conditional directive is used  */
#ifndef _MAIN_H
#define _MAIN_H

/* Must include the appropriate microcontroller header file here 
 In most case, microcontroller header is also a device header.
 device header will include the addresses of the special function registers (SFRs) used for port access, plus similar
 details for other on-chip components such as analog-to-digital converters*/
  // Must include the appropriate microcontroller header file here
//#define HI_TECH_COMPILER
#ifdef HI_TECH_COMPILER
  #include <pic.h>
  __CONFIG(0x2CE4);
#else // XC8 compiler
  #include <xc.h>
#endif


#define LED_OFF                                  (0)
#define LED_ON                                   (1)  
#define KEY_PRESSED                              (1) 
#define KEY_NOT_PRESSED                          (0)
#define STATE_YES                               ('y')
#define STATE_NO                                ('n')  
/* set crystal Oscillator(stable operation) frequency (in Hz) here we set 3.6864MHz to get precise baud rate */
#define _XTAL_FREQ                             (3686400UL)
#define OSC_PER_INST                            (4)
// Number of oscillations required to execute per instruction or increment a timer 
// 4 � Original PIC 16f887


typedef unsigned char tByte;
typedef unsigned int tWord;
typedef unsigned long tLong;



#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
