/**************************************************************************
   FILE          :    uart.c
 
   PURPOSE       :   UART Library
 
   AUTHOR        :   K.M.Arun Kumar alias Arunkumar Murugeswaran 
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 #include "uart.h"
 #include "main.h"
 #include "lcd.h"
 
#define ERROR_LINE_NUM     NUM_LINE4

 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/

void Init_UART()
{
	TRISC6 = 0;   /* Tx PIN as output */
	TRISC7 = 1;   /* Rx PIN as input */
	
	SPBRG = 23;  /* (_XTAL_FREQ /(16 * baud_rate) ) - 1,  Osc freq = 3686400 Hz, Baud Rate = 9600  */
	BRG16 = 0 ;  /* 8-bit Baud Rate Generator is used */
	BRGH  = 1;   /* Fast baud rate */
	SYNC  = 0;   /* Asynchrous mode */
    SPEN  = 1;   /* enable serial port pins */
	CREN  = 1;   /* enable continuous receive */
	SREN  = 0;   /* single receive disabled */
	TXIE  = 0;   /* disable transmit interrupt */
	RCIE  = 1;   /* enable receiver interrupt */
	TX9   = 0;   /* 8 bit transmission */
	RX9   = 0;   /* 8 bit reception */
	TXEN  = 0;   /* reset transmitter */
	TXEN  = 1;   /* enable transmitter */
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void Transmit_UART(const char transmit_char)
{
	TXREG = transmit_char;	
	while(TRMT == 0); /* wait as TSR is full */	
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
char Receive_UART()
{
	char receive_char = 0;
	const char framing_error_msg_disp[] = "FERR", overrun_error_msg_disp[] = "OERR";
	
	/* overrun error has occured */
	if(OERR == 1)
	{
		/* internal error : overrun error has occurred */
		Goto_XY_LCD_Disp(ERROR_LINE_NUM, NUM_COL1);
	    Data_Str_Disp_LCD(overrun_error_msg_disp);
		CREN = 0; /* clear (CREN) continuous reception flag to clear OERR flag */
		CREN = 1; /* enable (CREN) continuous reception flag to continue receive datas */
	}
	while(RCIF == 0);	
	
	/* received char has framing error */
 	if(FERR == 1)  
    {  
       receive_char = RCREG;
	   /* internal error: framing error has occurred */
	   Goto_XY_LCD_Disp(ERROR_LINE_NUM, NUM_COL1);
	   Data_Str_Disp_LCD(framing_error_msg_disp);
	   return 0;
 	}
	receive_char = RCREG;
	/* echo received char in virtual terminal */
	Transmit_UART(receive_char);
	return receive_char;
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
