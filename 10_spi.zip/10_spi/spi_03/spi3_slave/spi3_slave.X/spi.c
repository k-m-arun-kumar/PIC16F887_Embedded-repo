/* ********************************************************************
   FILE                   : spi.c

   PROGRAM DESCRIPTION    : SPI library 
                      									 
	 
   AUTHOR                :  K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
   KNOWN BUGS            : 

   NOTE                  :  										
                                    
   CHANGE LOGS           : 

*****************************************************************************/
#include "main.h"
#include "port.h"
#include "spi.h"
#include "lcd.h"

static void SPI_Receive_Wait();
static void SPI_Transmit_Wait();
static void SPI_Transmit_Wait_ByBF();

void SPI_Init(Spi_Type sType, Spi_Data_Sample sDataSample, Spi_Clock_Idle sClockIdle, Spi_Transmit_Edge sTransmitEdge)
{
    TRISC5 = 0;
    if(sType & 0b00000100) //If Slave Mode
    {
        SSPSTAT = sTransmitEdge;
        TRISC3 = 1;  // SPI Clock(SCK) as input 
		TRISA5 = 1;  // SS as input
    }
    else              //If Master Mode
    {
        SSPSTAT = sDataSample | sTransmitEdge;
        TRISC3 = 0;  // SPI Clock(SCK) as output
		TRISA5 = 0;  // SS as output
		MSSP_SLAVE_SELECT_PIN = 1;  // deselect slave    
    }
	TRISC4 = 1;  // SDI as input
    TRISC5 = 0;  //SDO as output 
    SSPCON = sType | sClockIdle;
}

static void SPI_Receive_Wait()
{
	 // Wait for Data Receive complete 
    while ( !SSPSTATbits.BF );
	if(SSPCONbits.SSPOV == 1)
    {
      SSPCONbits.SSPOV = 0;
	  
	  //SHOULD_REMOVE 
	  Goto_XY_LCD_Disp(2,1);
	  Data_Str_Disp_LCD("SSPOV");
	}
}
static void SPI_Transmit_Wait()
{
	 // Wait for Data transmit complete 
    while ( SSPIF == 0 );
	if(SSPCONbits.WCOL == 1)
    {
      SSPCONbits.WCOL = 0;
	  
	  //SHOULD_REMOVE 
	  Goto_XY_LCD_Disp(2,1);
	  Data_Str_Disp_LCD("T WCOL");
	}
	SSPIF = 0;
} 

//Write data to SPI bus
void SPI_Data_Write_Char(const char dat)  
{
	SSPBUF = dat;
	SPI_Transmit_Wait();
}
 void SPI_Data_Write_Str(const char *lcd_data_from_master_str)
{
	// wait till transmission of a char has been complete
	 SSPBUF = *lcd_data_from_master_str;
	 ++lcd_data_from_master_str;
	 SPI_Transmit_Wait();
}
//REad the received data
 char SPI_Data_Read_Char() 
{
	// wait until the all bits receive
    SPI_Receive_Wait(); 
    // read the received data from the buffer	
    return(SSPBUF);            
}

/* unsigned int SPI_Ready_Tx_Data()
{
   while(SSPSTATbits.BF == 1);
   
   if(SSPCONbits.WCOL == 1)
   {
      SSPCONbits.WCOL = 0;
	  return 0;
   }
   return 1;   
}
//Write data to SPI bus
void SPI_Data_Write_Char(const char dat)  
{
     while(SPI_Ready_Tx_Data() == 0);
	  SSPBUF = dat;	     	 
}

//Check whether the data is ready to read using SPI
unsigned int SPI_Data_Ready()   
{
    if(SSPSTATbits.BF)
        return 1;
    else
        return 0;
}

static void SPI_Transmit_Wait_ByBF()
{
	 // Wait for Data transmit complete 
    while ( SSPSTATbits.BF );
	if(SSPCONbits.WCOL == 1)
    {
      SSPCONbits.WCOL = 0;
	  
	  //SHOULD_REMOVE 
	  Goto_XY_LCD_Disp(2,1);
	  Data_Str_Disp_LCD("T WCOL");
	}
} 
/Write data to SPI bus
void SPI_Data_Write_Char(const char dat)  
{
	 SPI_Transmit_Wait_ByBF();
	 SSPBUF = dat;	
}
void SPI_Data_Write_Str(const char *lcd_data_from_master_str)
{
	// wait till transmission of a char has been complete
	 SPI_Transmit_Wait_ByBF();
	 SSPBUF = *lcd_data_from_master_str;
	 ++lcd_data_from_master_str;
}
unsigned int SPI_Data_Ready()
{
   while(SSPIF == 0);
   SSPIF = 0;
    if(SSPCONbits.WCOL == 1)
   {
      SSPCONbits.WCOL = 0;
	  __delay_ms(100);
      return 0;
   } 
   return 1;   
}
//Check whether the data is ready to read using SPI
 unsigned int SPI_Data_Ready()   
{
    if(SSPSTATbits.BF)
        return 1;
    else
        return 0;
} */
