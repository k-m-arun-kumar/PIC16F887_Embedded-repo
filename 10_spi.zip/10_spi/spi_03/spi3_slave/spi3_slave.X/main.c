/* ********************************************************************
   FILE                   : main.c

   PROGRAM DESCRIPTION    : by using SPI, after received a predefined char to initiate transfer data from SPI_SLAVE to SPI_MASTER, which was transmitted by SPI_MASTER to SPI_SLAVE and receive it by SPI in SPI_SLAVE, and after received predefined char, then send a lcd_data_from_master_str string from SPI_SLAVE to SPI_MASTER and 
   display it in LCD_MASTER connected to SPI_MASTER. 
                      									 
	 
   AUTHOR                :  K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
   KNOWN BUGS            :  Not working 

   NOTE                  :  this is a SPI_SLAVE code and software flow control and error checking are not implemented						
                                    
   CHANGE LOGS           : 

*****************************************************************************/
// 'C' source line config statements

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.


#include "main.h"
#include "port.h"
#include "lcd.h"
#include "spi.h"
#include "string.h"
void main()
{
   char spi_rcvd_data_str[30];
   unsigned int spi_num_chars_received = 0, spi_num_chars_transmitted = 0;
   const char lcd_data_to_master_str[] = "RCVD FROM SLAVE \r";
   char lcd_disp_enable_flag = STATE_YES, spi_rcv_enable_flag = STATE_YES, spi_tx_enable_flag = STATE_YES;
   
   TRISE = 0x00;
   PORTE = 0x00;
   LCD_PORT_GPIO = 0x00;        
   LCD_PORT = 0x00;   
   ANSEL = 0x00;
   ANSELH = 0x00;  
   LCD_Init();
   SPI_Init(SPI_SLAVE_SS_EN, SPI_DATA_SAMPLE_MIDDLE, SPI_CLOCK_IDLE_LOW, SPI_IDLE_2_ACTIVE);
   Goto_XY_LCD_Disp(1,1);
   while(1)	   
   {
	   //SLAVE has been selected
	   
	   while( MSSP_SLAVE_SELECT_PIN == 0 && (spi_tx_enable_flag == STATE_YES || spi_rcv_enable_flag == STATE_YES) ) 
	   {
		   if(spi_rcv_enable_flag == STATE_YES)
		   {
               spi_rcvd_data_str[spi_num_chars_received] = SPI_Data_Read_Char();
			   switch(spi_rcvd_data_str[spi_num_chars_received])
		       {
				   /* '#' - predefined char to initiate transfer data from SPI_SLAVE to SPI_MASTER */
				   case '#':
				      spi_tx_enable_flag = STATE_YES;
				      spi_num_chars_received = 0;
				   break;
     			   case '\r':
                     spi_rcvd_data_str[spi_num_chars_received] = '\0';			
                     spi_num_chars_received = 0 ; 
                     spi_rcv_enable_flag = STATE_NO;                    
                   break;
                   default:
                      ++spi_num_chars_received;				   
	           }	           
		   }
           Delay_Time_By_Count(1000ul);	   
           if(spi_tx_enable_flag == STATE_YES)
	       {
	           SPI_Data_Write_Char(lcd_data_to_master_str[spi_num_chars_transmitted]);
		       switch( lcd_data_to_master_str[spi_num_chars_transmitted])
			   {
                   case '\r':
			          spi_num_chars_transmitted = 0;
                      spi_tx_enable_flag = STATE_NO;
                   break;
			       default:
                      ++spi_num_chars_transmitted;	 
			    } 
	        }
             Delay_Time_By_Count(1000ul);			
		    // __delay_ms(100);
        }
    }
}   
