/* ********************************************************************
   FILE                   : main.c

   PROGRAM DESCRIPTION    :  by using SPI, first SEND a predefined char, to initiate transfer data from SPI_SLAVE to SPI_MASTER, which was transmitted by SPI_MASTER to SPI_SLAVE 
   and receive it by SPI in SPI_SLAVE, and after received predefined char, then send a lcd_data_from_master_str string from SPI_SLAVE to SPI_MASTER

   and receive it by SPI in SPI_MASTER and display it in LCD_MASTER connected to SPI_MASTER. 
                      									 
	 
   AUTHOR                :  K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
   KNOWN BUGS            : 

   NOTE                  :  This is a SPI_MASTER code and software flow control and error checking are not implemented and manual padding of dummy char is used 
                                    
   CHANGE LOGS           : 

*****************************************************************************/   
// 'C' source line config statements

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include "main.h"
#include "port.h"
#include "lcd.h"
#include "spi.h"
#include "uart.h"
#include "string.h"
void main()
{
	/* SPI is full duplex, so transmission from master to slave and transmission from slave to master happens at the same time.
	  '/' is user predefined dummy char transmitted by SPI slave and rcvd in SPI master, as '#' < lcd_data_to_master_str_len,
	  so that when slave transmits data char and master has no data to transmit, then master transmits dummy chars to slave till slave completes transmission.  
      padding of dummy chars are put in at the end of '#' and terminated by '\r' and number of '/' = lcd_data_to_master_str_len - 1(1 for '\r') */
   char lcd_data_from_master_str[] = "RCVD FROM MASTER \r", slave_transmit_initiate_str[] = "#////////////////\r";
   char spi_rcvd_data_str[30];
   unsigned int spi_num_chars_received = 0, spi_num_chars_transmitted = 0;
   char lcd_disp_enable_flag = STATE_YES, spi_rcv_enable_flag = STATE_YES, spi_tx_enable_flag = STATE_YES;
   
   TRISE = 0x00;
   PORTE = 0x00;
   LCD_PORT_GPIO = 0x00;        
   LCD_PORT = 0x00;  
   ANSEL = 0x00;
   ANSELH = 0x00; 
   LCD_Init();
   SPI_Init(SPI_MASTER_OSC_DIV4, SPI_DATA_SAMPLE_MIDDLE, SPI_CLOCK_IDLE_LOW, SPI_IDLE_2_ACTIVE);
   Goto_XY_LCD_Disp(1,1);
   /* master asks and initiates slave to transmit data to master and lcd_data_from_master_str = slave_transmit_initiate_str */
   strcpy(lcd_data_from_master_str, slave_transmit_initiate_str);
   while(1)
   {
	  if(spi_rcv_enable_flag == STATE_YES || spi_tx_enable_flag == STATE_YES)
             MSSP_SLAVE_SELECT_PIN = 0;       //Slave is Selected
       //__delay_ms(1);
      if(spi_tx_enable_flag == STATE_YES)
	  {
		  SPI_Data_Write_Char(lcd_data_from_master_str[spi_num_chars_transmitted]); 
	      switch( lcd_data_from_master_str[spi_num_chars_transmitted])
		  {
			  /* '#' - user predefined char to initiate transfer data from SPI_SLAVE to SPI_MASTER */
			  case '#':
			    spi_rcv_enable_flag = STATE_YES; 
				++spi_num_chars_transmitted;
			  break;	 
			  case '\r':
			     spi_num_chars_transmitted = 0;
                 spi_tx_enable_flag = STATE_NO;
              break;
			  default:
			     ++spi_num_chars_transmitted;
		  }				 
	  }	
	   Delay_Time_By_Count(1000ul);
	  // __delay_ms(1); 
	  if(spi_rcv_enable_flag == STATE_YES)
	  {
         spi_rcvd_data_str[spi_num_chars_received] = SPI_Data_Read_Char();
		 switch( spi_rcvd_data_str[spi_num_chars_received])
	     {
			 case '\r':
			   spi_rcvd_data_str[spi_num_chars_received] = '\0';			
               spi_num_chars_received = 0 ; 
               spi_rcv_enable_flag = STATE_NO;			  
			 break;  
             default:	
			    ++spi_num_chars_received;
	     }
	  }	 
       Delay_Time_By_Count(1000ul);  
	  // __delay_ms(1);
       	if(spi_rcv_enable_flag == STATE_NO && spi_tx_enable_flag == STATE_NO) 
		{			
             MSSP_SLAVE_SELECT_PIN = 1; //Slave is Deselected 
             if(lcd_disp_enable_flag == STATE_YES) 
             {	
                // spi_rcvd_data_str[0] = initial garbage value received by master from slave		 
                Data_Str_Disp_LCD(spi_rcvd_data_str + 1); 
				lcd_disp_enable_flag = STATE_NO;
			 }	
        }			 
       
       //__delay_ms(100);
   }
}
