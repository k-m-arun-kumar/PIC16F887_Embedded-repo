/* ********************************************************************
   FILE                   : main.c

   PROGRAM DESCRIPTION    :  by using SPI, first receive a char in SPI_SLAVE and char was transmitted by SPI_MASTER and receive it by SPI in SPI_SLAVE and display it in LCD_SLAVE connected to SPI_SLAVE, then
   send a char from SPI_SLAVE to SPI_MASTER and receive it by SPI in SPI_MASTER and display it in LCD_MASTER connected to SPI_MASTER, and process continues, till
   transmitted and received datas has '\r' char, which is carriage return. When '\r' is transmitted and received, then don't transmit and receive any more chars respectively.
                      									 
	 
   AUTHOR                :  K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
   KNOWN BUGS            : 

   NOTE                  :   
   This is a SPI_SLAVE code and software flow control and error checking are not implemented and and manual padding of dummy chars are put in at the end of lcd_data_to_master_str and modified from PIC16F887-repo->10_spi->spi_01->spi1_slave->spi1_slave.X's main.c with SPI_Exchange_Char() 									
                                    
   CHANGE LOGS           : 

*****************************************************************************/  
// 'C' source line config statements

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.


#include "main.h"
#include "port.h"
#include "lcd.h"
#include "spi.h"
#include "string.h"

void main()
{
   char spi_rcvd_data_str[30], spi_transmit_data_str[30];
   unsigned int spi_num_chars_received = 0, spi_num_chars_transmitted = 0;
   /* SPI is full duplex, so transmission from master to slave and transmission from slave to master happens at the same time.
    '/' is user predefined dummy char transmitted by SPI slave and rcvd in SPI master, as lcd_data_from_master_str_len > lcd_data_to_master_str_len,
    padding of dummy chars are put in at the end of lcd_data_to_master_str and terminated by '\r', so that when master transmits 
	and slave has no data to transmit, then slave transmits dummy chars to master till master completes transmission.
	.number of '/' =  lcd_data_from_master_str_len - [lcd_data_to_master_str_len + 1(initial garbage char transmitted by slave to master)]*/
   const char lcd_data_to_master_str[] = "FROM SLAVE ", dummy_data_to_master_str[] = "////\r";
   char lcd_disp_enable_flag = STATE_YES, spi_rcv_enable_flag = STATE_YES, spi_tx_enable_flag = STATE_YES ;
   char valid_rcvd_char_flag = STATE_NO;
   TRISE = 0x00;
   PORTE = 0x00;
   LCD_PORT_GPIO = 0x00;        
   LCD_PORT = 0x00;   
   ANSEL = 0x00;
   ANSELH = 0x00;  
   LCD_Init();
   SPI_Init(SPI_SLAVE_SS_EN, SPI_DATA_SAMPLE_END, SPI_CLOCK_IDLE_LOW, SPI_IDLE_2_ACTIVE);
   Goto_XY_LCD_Disp(1,1);
   strcpy(spi_transmit_data_str, lcd_data_to_master_str);
   strcat(spi_transmit_data_str, dummy_data_to_master_str); 
    /* At begin, when master transmits a char to slave, at a same time, slave sends a garbage value to master, as SPI is full duplex,
     so transmission from master to slave and transmission from slave to master happens at the same time */
     while(1)	   
   {
	   //SLAVE has been selected
	   while(MSSP_SLAVE_SELECT_PIN == 0 && (spi_tx_enable_flag == STATE_YES || spi_rcv_enable_flag == STATE_YES)) 
	   {
		      if(spi_rcv_enable_flag == STATE_YES || spi_tx_enable_flag == STATE_YES)
		      {
                 spi_rcvd_data_str[spi_num_chars_received] = SPI_Exchange_Char(lcd_data_to_master_str[spi_num_chars_transmitted]);
			     switch( spi_rcvd_data_str[spi_num_chars_received])
				 {
					 case '\r':
					   spi_rcvd_data_str[spi_num_chars_received] = '\0'; 
			           spi_num_chars_received = 0 ; 
                       spi_rcv_enable_flag = STATE_NO;	
					 break;
                     default:					 
	                    ++spi_num_chars_received;
	             }
				 switch( lcd_data_to_master_str[spi_num_chars_transmitted])
				  {		
                     case '\r':	
                        spi_num_chars_transmitted = 0;
                        spi_tx_enable_flag = STATE_NO;
					 break;
                     default:					 
		                ++spi_num_chars_transmitted;
			      }
		      }				  
        }
		if(lcd_disp_enable_flag == STATE_YES)
		{
		    Data_Str_Disp_LCD(spi_rcvd_data_str);
			lcd_disp_enable_flag = STATE_NO;
	    }		
    }
}   
