/* ********************************************************************
   FILE                   : main.c

   PROGRAM DESCRIPTION    :  by using SPI, first send a char from SPI_MASTER to SPI_SLAVE and receive it by SPI in SPI_SLAVE and display it in LCD_SLAVE connected to SPI_SLAVE, then   send a char from SPI_SLAVE to SPI_MASTER and receive it by SPI in SPI_MASTER and display it in LCD_MASTER connected to SPI_MASTER, and process continues, till transmitted and received datas has '\r' char, which is carriage return. When '\r' is transmitted and received, then don't transmit and receive any more chars respectively.
                      									 
	 
   AUTHOR                :  K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
   KNOWN BUGS            : 

   NOTE                  :   This is a SPI_MASTER code and software flow control and error checking are not implemented and modified from PIC16F887-repo->10_spi->spi_01->spi1_master->spi1_master.X's main.c with SPI_Exchange_Char() 									
                                    
   CHANGE LOGS           : 

*****************************************************************************/  
// 'C' source line config statements

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include "main.h"
#include "port.h"
#include "lcd.h"
#include "spi.h"
#include "uart.h"
#include "string.h"

void main()
{
   const char lcd_data_from_master_str[] = "RCVD FROM MASTER \r";
   char desired_spi_rcvd_data_str[30], spi_rcvd_data_str[30];
   unsigned int spi_num_chars_received = 0, spi_num_chars_transmitted = 0, first_dummy_char_pos = 0 ;
   char lcd_disp_enable_flag = STATE_YES, spi_rcv_enable_flag = STATE_YES, spi_tx_enable_flag = STATE_YES;
   
   TRISE = 0x00;
   PORTE = 0x00;
   LCD_PORT_GPIO = 0x00;        
   LCD_PORT = 0x00;  
   ANSEL = 0x00;
   ANSELH = 0x00; 
   LCD_Init();
   SPI_Init(SPI_MASTER_OSC_DIV4, SPI_DATA_SAMPLE_END, SPI_CLOCK_IDLE_LOW, SPI_IDLE_2_ACTIVE);
   Goto_XY_LCD_Disp(1,1);
   /* At begin, when master transmits a char to slave, at a same time, slave sends a garbage value to master, as SPI is full duplex,
     so transmission from master to slave and transmission from slave to master happens at the same time for all transaction */
   while(1)
   {
	   if(spi_rcv_enable_flag == STATE_YES || spi_tx_enable_flag == STATE_YES)
           MSSP_SLAVE_SELECT_PIN = 0;       //Slave is Selected
      if(spi_tx_enable_flag == STATE_YES || spi_rcv_enable_flag == STATE_YES )
	  {
	      spi_rcvd_data_str[spi_num_chars_received] = SPI_Exchange_Char(lcd_data_from_master_str[spi_num_chars_transmitted]);
		  switch( lcd_data_from_master_str[spi_num_chars_transmitted])
		  {	
             case '\r':	
                spi_num_chars_transmitted = 0;
                spi_tx_enable_flag = STATE_NO;
             break;
             default:			 
		        ++spi_num_chars_transmitted;
		  }
		  switch(spi_rcvd_data_str[spi_num_chars_received])
		 {
			 case '\r': 
			   spi_rcvd_data_str[spi_num_chars_received] = '\0'; 
               spi_num_chars_received = 0 ; 
               spi_rcv_enable_flag = STATE_NO;
			 break;
             default:			 
	        	 ++spi_num_chars_received;	
          }        
	  }	
	  if(spi_rcv_enable_flag == STATE_NO && spi_tx_enable_flag == STATE_NO)
	  {		  
         MSSP_SLAVE_SELECT_PIN = 1;  //Slave is Deselected 
		 if(lcd_disp_enable_flag == STATE_YES)
		 {
			 /* SPI is full duplex, so transmission from master to slave and transmission from slave to master happens at the same time.
			 '/' is user predefined dummy char transmitted by SPI slave and rcvd in SPI master, as lcd_data_from_master_str_len > lcd_data_to_master_str_len,
     			padding of dummy chars are put in at the end of lcd_data_to_master_str and terminated by '\r', so that when master transmits 
				and slave has no data to transmit, then slave transmits dummy chars to master till master completes transmission.   
				number of '/' =  lcd_data_from_master_str_len - [lcd_data_to_master_str_len + 1(initial garbage char transmitted by slave to master)]*/
		     while(spi_rcvd_data_str[first_dummy_char_pos] != '/')
		        ++first_dummy_char_pos;	 
		     // first_dummy_char_pos - 2; 1(start garbage value rcvd from slave and 1 for first '\' pos are to be subtracted); 
             strncpy(desired_spi_rcvd_data_str, spi_rcvd_data_str + 1, first_dummy_char_pos - 2 );	
		     desired_spi_rcvd_data_str[first_dummy_char_pos - 1] = '\0';
		     Data_Str_Disp_LCD(desired_spi_rcvd_data_str);
			 lcd_disp_enable_flag = STATE_NO;
		 }	 
	  }	 
   }
}
