/* ********************************************************************
FILE                   : lcd10.c

PROGRAM DESCRIPTION    : In LCD for every press of SW_INC, increment the number and display at location + 4,  if laps in display in line1 wrap to line 2.
   In line 2 if display laps, wrap to line 1. For every press of SW_DEC, decrement the number and display at location - 4.
    For every press of SW_RESET, reset number to 0. number in range 0000 to 9999

AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
 
USED:              
             Desktop OS: Windows 7 Professional (32 bit) (Intel X64)       
     			   IDE: Developed by using Microchip's MPLAB IDE v8.6
                   CADD: Simulated in Proteus 8.0 Professional 
                  
                       
CHANGE LOGS           : 

*****************************************************************************/     

#include <pic.h>
#define SW_INC        RA0
#define SW_DEC      RA1
#define SW_RESET RA2

#define RS_PIN         RD0
#define RW_PIN       RD1
#define EN_PIN         RD2
#define LCD_PORT  PORTC
void delay_time(unsigned int);
void pulse ();
 void lcd_command (unsigned int);
void lcd_data(char);
void data_str(const char * );
void display_num(int num );
void clear_prev_data_display();
unsigned int prev_data_loc = 0x80;
void lcd_init();
void main()
{
          int num = 0; 
         
         TRISA = 0x07;
         TRISD =  0x00; 
          TRISC = 0x00;
        PORTA = 0x00;
         PORTC = 0x00;
         PORTD = 0x00;
        ANSEL = 0x00;
        ANSELH = 0x00;
        lcd_init(); 
        if(SW_INC == 1)
        {
             ++num;  
             display_num(num);       
              
              while(SW_INC == 1);           
       }
        if(SW_DEC == 1)
        {
              if(num <= 0)
                    num  = 10000;
            --num; 
              display_num(num);
             while(SW_DEC == 1);           
       }   
          for(;;)
          {
              if(SW_RESET == 1)
            {
                       num = 0;
                      display_num(num);
                    while(SW_RESET == 1);
            }
           if(SW_INC == 1)
        {
          if(num >= 9999)
                    num  = -1;    
            ++num;  
             display_num(num);       
              
              while(SW_INC == 1);           
       }
        if(SW_DEC == 1)
        {
              if(num <= 0)
                    num  = 10000;
            --num; 
              display_num(num);
             while(SW_DEC == 1);           
       }   
   } 
 }
void lcd_init()
{
    lcd_command(0x30);
    lcd_command(0x30);
    lcd_command(0x30);
    lcd_command(0x38);
    lcd_command(0x01);
    lcd_command(0x0E);
    lcd_command(0x06);                                       
}  
void pulse()
{
        EN_PIN = 1;
        delay_time(1000);
         EN_PIN = 0;
        delay_time(1000);
}
  void lcd_command (unsigned int cmd)
       {
         RW_PIN = 0;
         RS_PIN = 0; 
         LCD_PORT = cmd;
         pulse();
       }
 void lcd_data(char ch)
{
     RW_PIN = 0;
     RS_PIN = 1;
     LCD_PORT =ch;
     pulse();
}
void data_str(const char *char_ptr)
{ 
       while(*char_ptr)
       {
                lcd_data(*(char_ptr++));
       }
}

void delay_time(unsigned int time_delay)
{
         while(time_delay--);
}

void display_num(int num)
{
        unsigned int unit_digit, tens_digit, hundreds_digit, thousands_digit;
        char ch[] = {'0','1', '2', '3', '4', '5', '6', '7', '8', '9'};
         unsigned int loc[] = {0x80, 0x84, 0x88, 0x8C, 0xC0, 0xC4, 0xC8, 0xCC}, num_index, data_loc;
       
       clear_prev_data_display(); 
         num_index =  num  %  8;
        data_loc = loc[ num_index];

       thousands_digit    = num / 1000;
       num %= 1000;
       lcd_command (data_loc); 
       lcd_data(ch[thousands_digit]);    
      
         hundreds_digit = num / 100;
        num %= 100;
        lcd_command (data_loc + 1 ); 
       lcd_data(ch[hundreds_digit]);    
 
         tens_digit = num /10;         
        lcd_command (data_loc + 2); 
       lcd_data(ch[tens_digit]);    

       unit_digit = num %10;
        lcd_command (data_loc + 3); 
       lcd_data(ch[unit_digit]);    
       prev_data_loc =  data_loc; 
}

void clear_prev_data_display()
{
      lcd_command(prev_data_loc);
      data_str("    ");
}
