/* ********************************************************************
FILE                   : lcd13.c

PROGRAM DESCRIPTION    : enter a mobile number in keypad and display corresponding data in LCD.
   when * is pressed and number is 10 digit then calling should display, 
   else invalid number should be displayed 

AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
 
USED:              
             Desktop OS: Windows 7 Professional (32 bit) (Intel X64)       
     			   IDE: Developed by using Microchip's MPLAB IDE v8.6
                   CADD: Simulated in Proteus 8.0 Professional 
                  
                       
CHANGE LOGS           : 

*****************************************************************************/
#include <pic.h>
#include <string.h>
#define MAX_ROW  4
#define MAX_COL   3
#define _XTAL_FREQ 4000000   //  set internal freq to 4MHz
__CONFIG(0X2CE4);            //  config PIC                         

#define  KEYPAD_PHONE_COL1  RA0
#define  KEYPAD_PHONE_COL2  RA1
#define  KEYPAD_PHONE_COL3  RA2
#define  KEYPAD_PHONE_ROWA RA3
#define  KEYPAD_PHONE_ROWB RA4
#define  KEYPAD_PHONE_ROWC RA5
#define  KEYPAD_PHONE_ROWD RA6
#define RS_PIN                                  RD0
#define RW_PIN                                 RD1
#define EN_PIN                                 RD2
#define LCD_PORT                          PORTC
void delay_time(unsigned int);
void pulse ();
 void lcd_command (unsigned int);
void lcd_data(char);
void data_str(const char * );
void lcd_init();

void main()
{
        char keypad_char[]   = {'1','2', '3', '4', '5', '6','7','8','9','*', '0', '#'};
        unsigned int cur_loc = 0x80, num_char = 0;
        const char correct_dial_disp[] = "Calling", incorrect_dial_disp[] = "Invalid Number";   
        char entered_mobile_no[31], disp_flag = 1, no_input_flag = 0;
    
        TRISA = 0x07;
        TRISC = 0x00;
       TRISD  = 0x00;
       PORTA = 0x00;
       PORTC = 0x00;
       PORTD = 0x00;
       ANSEL = 0x00;
       ANSELH = 0x00;
       lcd_init();
       lcd_command(cur_loc);
       for(;;)
      {
               while(num_char < 0x20 && disp_flag == 1)
                { 
                KEYPAD_PHONE_ROWA = 1;
                KEYPAD_PHONE_ROWB  = 0;
                KEYPAD_PHONE_ROWC  = 0;
                KEYPAD_PHONE_ROWD  = 0; 
                    if(KEYPAD_PHONE_COL1 == 1 && no_input_flag == 0 )
                   {
                          lcd_command(cur_loc);
                          lcd_data(keypad_char[0]);
                          entered_mobile_no[num_char] =keypad_char[0];
                          //while(KEYPAD_PHONE_COL1 == 1 && KEYPAD_PHONE_ROWA == 1 && KEYPAD_PHONE_ROWB  == 0 && KEYPAD_PHONE_ROWC == 0 && KEYPAD_PHONE_ROWD  == 0  );
							++num_char;
                  			++cur_loc; 				
							while(KEYPAD_PHONE_COL1 == 1);                    
}
                   if (KEYPAD_PHONE_COL2 == 1 && no_input_flag == 0)
                  {
                           lcd_command(cur_loc); 
                           lcd_data(keypad_char[1]);
                           entered_mobile_no[num_char] =keypad_char[1];
                           //while(KEYPAD_PHONE_COL2 == 1 &&  KEYPAD_PHONE_ROWA == 1 && KEYPAD_PHONE_ROWB  == 0 && KEYPAD_PHONE_ROWC == 0 && KEYPAD_PHONE_ROWD  == 0 );  
                  			++num_char;
                  			++cur_loc; 				
							while(KEYPAD_PHONE_COL2 == 1);
}
                     if (KEYPAD_PHONE_COL3 == 1 && no_input_flag == 0)
                    {
                          lcd_command(cur_loc);
                          lcd_data(keypad_char[2]);
                          entered_mobile_no[num_char] =keypad_char[2];
                           //while(KEYPAD_PHONE_COL3 == 1&& KEYPAD_PHONE_ROWA == 1 && KEYPAD_PHONE_ROWB  == 0 && KEYPAD_PHONE_ROWC == 0 && KEYPAD_PHONE_ROWD  == 0  ); 
							++num_char;
                  			++cur_loc; 				
							while(KEYPAD_PHONE_COL3 == 1);                    
}  
              KEYPAD_PHONE_ROWA = 0;
                KEYPAD_PHONE_ROWB  = 1;
                KEYPAD_PHONE_ROWC  = 0;
                KEYPAD_PHONE_ROWD  = 0; 
                    if(KEYPAD_PHONE_COL1 == 1 && no_input_flag == 0 )
                     {
                            lcd_command(cur_loc);
                           lcd_data(keypad_char[3]);
                          entered_mobile_no[num_char] =keypad_char[3];                              
                          // while(KEYPAD_PHONE_COL1 == 1 && KEYPAD_PHONE_ROWA == 0 && KEYPAD_PHONE_ROWB  == 1 && KEYPAD_PHONE_ROWC == 0 && KEYPAD_PHONE_ROWD  == 0 ); 
							++num_char;
                  			++cur_loc; 				
							while(KEYPAD_PHONE_COL1 == 1);                    
}
                   if (KEYPAD_PHONE_COL2 == 1 && no_input_flag == 0 )
                    {
                        lcd_command(cur_loc);
                       lcd_data(keypad_char[4]);
                       entered_mobile_no[num_char] =keypad_char[4];
                       // while(KEYPAD_PHONE_COL2 ==1 && KEYPAD_PHONE_ROWA == 0 && KEYPAD_PHONE_ROWB  == 1 && KEYPAD_PHONE_ROWC == 0 && KEYPAD_PHONE_ROWD  == 0 );                                                                     
						++num_char;
                  			++cur_loc; 				
							while(KEYPAD_PHONE_COL2 == 1);                    
}
                     if (KEYPAD_PHONE_COL3 == 1&& no_input_flag == 0 )
                     {   
                            lcd_command(cur_loc);
                           lcd_data(keypad_char[5]);
                           entered_mobile_no[num_char] =keypad_char[5];
                          //while(KEYPAD_PHONE_COL3 ==1 && KEYPAD_PHONE_ROWA == 0 && KEYPAD_PHONE_ROWB  == 1 && KEYPAD_PHONE_ROWC == 0 && KEYPAD_PHONE_ROWD  == 0 ); 
							++num_char;
                  			++cur_loc; 				
							while(KEYPAD_PHONE_COL3 == 1);                     
}
                KEYPAD_PHONE_ROWA = 0;
                KEYPAD_PHONE_ROWB  = 0;
                KEYPAD_PHONE_ROWC  = 1;
                KEYPAD_PHONE_ROWD  = 0; 
                    if(KEYPAD_PHONE_COL1 == 1 && no_input_flag == 0)
                   {
                            lcd_command(cur_loc);
                            lcd_data(keypad_char[6]);
                            entered_mobile_no[num_char] =keypad_char[6];
                          ++num_char;
                  			++cur_loc; 				
							while(KEYPAD_PHONE_COL1 == 1);
							// while(KEYPAD_PHONE_COL1 ==1 && KEYPAD_PHONE_ROWA == 0 && KEYPAD_PHONE_ROWB  == 0 && KEYPAD_PHONE_ROWC == 1 && KEYPAD_PHONE_ROWD  == 0 ); 
                   }
                   if (KEYPAD_PHONE_COL2 == 1 && no_input_flag == 0)
                 {
                           lcd_command(cur_loc);
                           lcd_data(keypad_char[7]);
                           entered_mobile_no[num_char] =keypad_char[7];
                           ++num_char;
                  			++cur_loc; 				
							while(KEYPAD_PHONE_COL2 == 1);
							//while(KEYPAD_PHONE_COL2 ==1 && KEYPAD_PHONE_ROWA == 0 && KEYPAD_PHONE_ROWB  == 0 && KEYPAD_PHONE_ROWC == 1 && KEYPAD_PHONE_ROWD  == 0 );
                 }  
                     if (KEYPAD_PHONE_COL3 == 1 && no_input_flag == 0)
                      { 
                            lcd_command(cur_loc);
                           lcd_data(keypad_char[8]);
                           entered_mobile_no[num_char] =keypad_char[8];
                           ++num_char;
                  			++cur_loc; 				
							while(KEYPAD_PHONE_COL3 == 1);
							//while(KEYPAD_PHONE_COL3 ==1 && KEYPAD_PHONE_ROWA == 0 && KEYPAD_PHONE_ROWB  == 0 && KEYPAD_PHONE_ROWC == 1 && KEYPAD_PHONE_ROWD  == 0 );
                      } 
                KEYPAD_PHONE_ROWA = 0;
                KEYPAD_PHONE_ROWB  = 0;
                KEYPAD_PHONE_ROWC  = 0;
                KEYPAD_PHONE_ROWD  = 1; 
                if (KEYPAD_PHONE_COL1 == 1)
                  {
                      lcd_command(cur_loc);
                      lcd_data(keypad_char[9]); 
                      while(KEYPAD_PHONE_COL1 == 1);
                      break;                      
					// while(KEYPAD_PHONE_COL1 ==1 && KEYPAD_PHONE_ROWA == 0 && KEYPAD_PHONE_ROWB  == 0 && KEYPAD_PHONE_ROWC == 0 && KEYPAD_PHONE_ROWD  == 1 ); 
                  }    
                   if (KEYPAD_PHONE_COL2 == 1 && no_input_flag == 0 )
                  {
                       lcd_command(cur_loc);
                       lcd_data(keypad_char[10]); 
                       entered_mobile_no[num_char] =keypad_char[10];
                       ++num_char;
                  	   ++cur_loc; 				
					   while(KEYPAD_PHONE_COL2 == 1);
					//while(KEYPAD_PHONE_COL2 ==1 && KEYPAD_PHONE_ROWA == 0 && KEYPAD_PHONE_ROWB  == 0 && KEYPAD_PHONE_ROWC == 0 && KEYPAD_PHONE_ROWD  == 1 );
                  }                                                          
                  if (KEYPAD_PHONE_COL3 == 1 && no_input_flag == 0)
                  {
                      lcd_command(cur_loc);
                      lcd_data(keypad_char[11]); 
                      entered_mobile_no[num_char] =keypad_char[11];
                      ++num_char;
                  	  ++cur_loc; 				
					  while(KEYPAD_PHONE_COL3 == 1);
					 // while(KEYPAD_PHONE_COL3 ==1 && KEYPAD_PHONE_ROWA == 0 && KEYPAD_PHONE_ROWB  == 0 && KEYPAD_PHONE_ROWC == 0 && KEYPAD_PHONE_ROWD  == 1);
                  } 
                  if(cur_loc == 0x90 )
                     cur_loc = 0xC0;
                  if(cur_loc == 0xCf)
                     no_input_flag  = 1;                                          
            }
            if(disp_flag == 1)
            { 
              
            lcd_command(0x01);   //clear display 
            lcd_command(0x0C); // display on, cursor and blinking off
            /* cur_loc  = 0x80;
            lcd_command(cur_loc); */
            disp_flag  = 0;
            if(num_char == 10)
            {
               data_str(correct_dial_disp);  
            } 
            else
            {
                 data_str(incorrect_dial_disp);  
            }                                               
          }                                                                                 
      }                
     
} 
 void lcd_init()
{
    lcd_command(0x30);
    lcd_command(0x30);
    lcd_command(0x30);
	lcd_command(0x38);
	lcd_command(0x01);
    lcd_command(0x0E);
    lcd_command(0x06);                                       
}     

void pulse()
{
        EN_PIN = 1;
        delay_time(1000);
         EN_PIN = 0;
        delay_time(1000);
}
  void lcd_command (unsigned int cmd)
       {
         RW_PIN = 0;
         RS_PIN = 0; 
         LCD_PORT = cmd;
         pulse();
       }
 void lcd_data(char ch)
{
     RW_PIN = 0;
     RS_PIN = 1;
     LCD_PORT =ch;
     pulse();
}
void data_str(const char *char_ptr)
{ 
       while(*char_ptr)
       {
          lcd_data(*(char_ptr++));
       }
}

void delay_time(unsigned int time_delay)
{
         while(time_delay--);
}
