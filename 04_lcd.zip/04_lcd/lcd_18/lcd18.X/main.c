/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    : display  periodic number from 0 to 9 in LCD at a static location and also with corresponding  number in words and use busy flag in LCD rather than time delay,    wherever applicable, for to do next operation on LCD and use 4 bit interface.
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  : 


USED          :     Desktop OS: Windows 7 Professional (32 bit) (Intel X64)       
     			   IDE: Developed by using Microchip's MPLAB IDE v8.6
                   CADD: Simulated in Proteus 8.0 Professional 
                   HW : Tested OK in PIC development board by www.alselectro.com with LCD as JHD162A
		    Programmer: PICkit 3 
                       										
                                    
CHANGE LOGS           : 

*****************************************************************************/
// PIC16F887 Configuration Bit Settings
// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.
// 'C' source line config statements

// CONFIG1
//#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
#pragma config FOSC = HS        // Oscillator Selection bits (HS oscillator: High-speed crystal/resonator on RA6/OSC2/CLKOUT and RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = ON       // Power-up Timer Enable bit (PWRT enabled)
#pragma config MCLRE = ON       // RE3/MCLR pin function select bit (RE3/MCLR pin function is MCLR)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = ON        // Internal External Switchover bit (Internal/External Switchover mode is enabled)
#pragma config FCMEN = ON       // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is enabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

#include "main.h"
#include "port.h"
#include "lcd.h"
#include "uart.h"

 //__CONFIG(0x2ce2);
value_types to_disp;
/*------------------------------------------------------------*-
FUNCTION NAME  : main

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 
-*------------------------------------------------------------*/

void main()
{
    char unit_ch = '0';
    char num_words[][6] = {"ZERO ", "ONE  ", "TWO  ", "THREE", "FOUR ", "FIVE ", "SIX  ", "SEVEN", "EIGHT", "NINE "};
    unsigned int num = 0;
		
    ANSEL = 0x00;
    ANSELH = 0x00;
	UART_Init();
    LCD_Init();
		   
    for(;;)
    {
       for(unit_ch = '0', num = 0; unit_ch <= '9'; unit_ch++, num++)
       {
		  Goto_XY_LCD_Disp(NUM_LINE1,NUM_COL1);
          Write_LCD_Data(unit_ch); 
		  Goto_XY_LCD_Disp(NUM_LINE2,NUM_COL1);	  
          LCD_Disp_Str(num_words[num]);
          __delay_ms(1000);
		  __delay_ms(1000);
       }     
    }
}
/*------------------------------------------------------------*-
FUNCTION NAME  : Write_Bit

DESCRIPTION     : write bit valve to data's bit, without affecting other bits of data .
                . 0 is the least bit pos and 7 is the most bit pos 

INPUT          : 

OUTPUT         : none

NOTE           : 
-*------------------------------------------------------------*/
void Write_Bit_in_Data(unsigned int *data, const unsigned int bit_pos, const unsigned int set_bit_val )
{
    /* unsigned int bit_pos_data_val = 0x01; // 00000001
	 
      // Left shift appropriate number of places, 	 so for bit_pos = 2, then bit_pos_data_val = 00000100 /
      bit_pos_data_val <<= bit_pos;
     // If we want 1 to be written at this bit_pos of data
     if (set_bit_val == 1)
     {
	    // set 1 to bit_pos and all other bits of data are unchanged 
        *data |= bit_pos_data_val; 
        return;
     }
      // If we want 0 bit value at bit_pos, then only that bit_pos of data is set to 0   and all other bits of data are unchanged. /
     bit_pos_data_val = ~bit_pos_data_val; // Complement
     // if bit_pos = 2, then  bit_pos_data_val= 11111011 /
	 // Bitwise AND 
     *data &= bit_pos_data_val; */
	 
	 if (set_bit_val == 1)
       {
          Set_Bit_in_Data(data, bit_pos);
          return;
       }
       Clear_Bit_in_Data(data, bit_pos ); 
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/	 
