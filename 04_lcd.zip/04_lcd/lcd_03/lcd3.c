/*  */

/* ********************************************************************
FILE                   : lcd3.c

PROGRAM DESCRIPTION    :  display with right shift of a string at 1st line and display with shift left of another string at 2nd line. 

AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : Not proper working

NOTE                  : 
 
USED:              
             Desktop OS: Windows 7 Professional (32 bit) (Intel X64)       
     			   IDE: Developed by using Microchip's MPLAB IDE v8.6
                   CADD: Simulated in Proteus 8.0 Professional 
                   
                                        
CHANGE LOGS           : 

*****************************************************************************/ 
#include <pic.h>
#define RS_PIN  RD0
#define RW_PIN RD1
#define EN_PIN RD2
#define LCD_PORT  PORTC
void delay_time(unsigned int);
void pulse ();
 void lcd_command (unsigned int);
void lcd_data(char);
void data_str(char * );
void lcd_init();
void main()
{
         int i = 0;
          TRISD =  0x00; 
          TRISC = 0x00;
         PORTC = 0x00;
         PORTD = 0x00;
        ANSEL = 0x00;
        ANSELH = 0x00;
        lcd_init(); 
          for(;;)
          {
             for(i = 0; i < 16;  i++)
            {

                lcd_command (0x80 + i);
               data_str(" arun");
                
                lcd_command (0xCA-i);
               data_str("india ");
               delay_time(30000);

//  lcd_command(0x80 + i );
//         lcd_data(' ');
//  lcd_command (0xCF - i);
//              lcd_data(' ');  
            
           }
                     
           }
}
void lcd_init()
{
    lcd_command(0x30);
    lcd_command(0x30);
    lcd_command(0x30);
    lcd_command(0x38);
    lcd_command(0x01);
    lcd_command(0x0E);
    lcd_command(0x06);                                       
}  
void pulse()
{
        EN_PIN = 1;
        delay_time(1000);
         EN_PIN = 0;
        delay_time(1000);
}
  void lcd_command (unsigned int cmd)
       {
         RW_PIN = 0;
         RS_PIN = 0; 
         LCD_PORT = cmd;
         pulse();
       }
 void lcd_data(char ch)
{
     RW_PIN = 0;
     RS_PIN = 1;
     LCD_PORT =ch;
     pulse();
}
void data_str(char *char_ptr)
{ 
       while(*char_ptr)
       {
                lcd_data(*(char_ptr++));
       }
}

void delay_time(unsigned int time_delay)
{
         while(time_delay--);
}
