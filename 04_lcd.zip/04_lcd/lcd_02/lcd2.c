/* ********************************************************************
FILE                   : lcd2.c

PROGRAM DESCRIPTION    :  to display a string in a LCD 

AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
 
USED:              
             Desktop OS: Windows 7 Professional (32 bit) (Intel X64)       
     			   IDE: Developed by using Microchip's MPLAB IDE v8.6
                   CADD: Simulated in Proteus 8.0 Professional 
                    HW : Tested OK in PIC development board by www.alselectro.com with LCD as JHD162A
		    Programmer: PICkit 3 
                                        
CHANGE LOGS           : 

*****************************************************************************/ 
#include <pic.h>
#define RS_PIN                           RE0
#define RW_PIN                           RE1
#define EN_PIN                           RE2

#define LCD_PORT                         PORTD
#define LCD_PORT_GPIO                    TRISD 

#define _XTAL_FREQ       (4000000)
 __CONFIG(0x2ce4); 
 
void delay_time(unsigned int);
void pulse ();
 void lcd_command (unsigned int);
void lcd_data(char);
void data_str(char * );
void lcd_init();
void main()
{
          LCD_PORT_GPIO =  0x00;          
          LCD_PORT = 0x00;
		  TRISE = 0x00;
          PORTE = 0x00;
		 
        ANSEL = 0x00;
        ANSELH = 0x00;
		lcd_init();
		while(1)
		{
           lcd_command (0x80);
           data_str("india");
           __delay_ms(3000);   
		}		
    
}
void lcd_init()
{
    lcd_command(0x30);
    lcd_command(0x30);
    lcd_command(0x30);
    lcd_command(0x38);
    lcd_command(0x01);
    lcd_command(0x0E);
    lcd_command(0x06);                                       
}  
void pulse()
{
        EN_PIN = 1;
        __delay_ms(100);
         EN_PIN = 0;
        __delay_ms(100);
}
  void lcd_command (unsigned int cmd)
       {
         RW_PIN = 0;
         RS_PIN = 0; 
         LCD_PORT = cmd;
         pulse();
       }
 void lcd_data(char ch)
{
     RW_PIN = 0;
     RS_PIN = 1;
     LCD_PORT =ch;
     pulse();
}
void data_str(char *char_ptr)
{ 
       while(*char_ptr)
       {
                lcd_data(*(char_ptr++));
       }
}

void delay_time(unsigned int time_delay)
{
         while(time_delay--);
}

/*command -  0x01: clear display clears data on the display screen */
/* command - 0x02: data address to display is set to 0x80 */
/* */
