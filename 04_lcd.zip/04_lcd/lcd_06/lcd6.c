/* ********************************************************************
FILE                   : lcd6.c

PROGRAM DESCRIPTION    : display  periodic number from 00 to 99 in LCD at a static location

AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
 
USED:              
             Desktop OS: Windows 7 Professional (32 bit) (Intel X64)       
     			   IDE: Developed by using Microchip's MPLAB IDE v8.6
                   CADD: Simulated in Proteus 8.0 Professional 
                   HW : Tested OK in PIC development board by www.alselectro.com with LCD as JHD162A
		    Programmer: PICkit 3 
                       
CHANGE LOGS           : 

*****************************************************************************/ 

#include <pic.h>

#define RS_PIN      RE0
#define RW_PIN      RE1
#define EN_PIN      RE2

#define LCD_PORT              PORTD
#define LCD_PORT_GPIO         TRISD 

 
/* for 16 * 2 LCD disp */                             
#define BEGIN_LOC_LINE1                      (0X80)
#define BEGIN_LOC_LINE2                      (0xC0)
#define BEGIN_LOC_LINE3                      (0x80) 
#define BEGIN_LOC_LINE4                      (0xC0)

#define END_LOC_LINE1                        (0x8F)
#define END_LOC_LINE2                        (0xCF)
#define END_LOC_LINE3                        (0x8F) 
#define END_LOC_LINE4                        (0xCF)

#define LCD_WRITE_ENABLE_PULSE_IN_USEC       (1)
#define LCD_ADDR_SETUP_IN_USEC               (1)
#define LCD_ENABLE_PULSE_BEFORE_WRITE_IN_USEC (1)
#define LCD_DATA_SETUP_IN_USEC               (1)
#define LCD_WRITE_ENABLE_PULSE_DELAY_IN_USEC (1)
#define LCD_CLEAR_EXEC_IN_USEC             (1650)
#define LCD_CURSOR_RETURN_EXEC_IN_USEC     (1650)
#define LCD_OTHER_INST_EXEC_IN_USEC          (40)
 
 
/* num cols = num of chars in a line */     
#define MAX_AVAIL_NUM_COLS                    (16)
#define CONFIGURE_MAX_NUM_LINES               (2)
#define MAX_AVAIL_NUM_LINES                   (2) 
#define MAX_AVAIL_NUM_CHARS_IN_LCD        (MAX_AVAIL_NUM_COLS * MAX_AVAIL_NUM_LINES) 
#define CONFIGURE_MAX_NUM_COLS             (MAX_AVAIL_NUM_COLS)
#define CONFIGURE_MAX_NUM_CHARS_IN_LCD    (CONFIGURE_MAX_NUM_LINES * CONFIGURE_MAX_NUM_COLS ) 
#define MAX_NUM_CHARS_INPUT_DATA          (MAX_AVAIL_NUM_COLS)  

#define INVALID_DATA               (0)
#define ALL_LINES                  (0)
#define NUM_LINE1                  (1)
#define NUM_LINE2                  (2)
#define NUM_LINE3                  (1)
#define NUM_LINE4                  (2)

#define NUM_COL1                   (1)

#define STATE_YES                   ('y')
#define STATE_NO                    ('n')

#define _XTAL_FREQ       (20000000)
 __CONFIG(0x2ce2);

 typedef union 
{
	union
	{
		unsigned long int value_long; 
	    struct 
	    {
		    unsigned int value_byte[2];
	    } val_in_bytes;
	    struct 
	    {
	      	unsigned int value_bit_0: 1;
	    	unsigned int value_bit_1: 1;
		    unsigned int value_bit_2: 1;
		    unsigned int value_bit_3: 1;
		    unsigned int value_bit_4: 1;
		    unsigned int value_bit_5: 1;
		    unsigned int value_bit_6: 1;
		    unsigned int value_bit_7: 1;
		    unsigned int value_bit_8: 1;
		    unsigned int value_bit_9: 1;
		    unsigned int value_bit_10: 1;
		    unsigned int value_bit_11: 1;
		    unsigned int value_bit_12: 1;
		    unsigned int value_bit_13: 1;
		    unsigned int value_bit_14: 1;
		    unsigned int value_bit_15: 1;
	   } val_in_bits;
	} unsigned_val;
  	union 
	{
		long int value_long; 
	    struct 
	    {
		     int value_byte[2];
	    } val_in_bytes;
	    struct 
	    {
	      	 unsigned  int value_bit_0: 1;
	    	 unsigned  int value_bit_1: 1;
		     unsigned  int value_bit_2: 1;
		     unsigned  int value_bit_3: 1;
		     unsigned  int value_bit_4: 1;
		     unsigned  int value_bit_5: 1;
		     unsigned  int value_bit_6: 1;
		     unsigned  int value_bit_7: 1;
		     unsigned  int value_bit_8: 1;
		     unsigned  int value_bit_9: 1;
		     unsigned  int value_bit_10: 1;
		     unsigned  int value_bit_11: 1;
		     unsigned  int value_bit_12: 1;
		     unsigned  int value_bit_13: 1;
		     unsigned  int value_bit_14: 1;
		     unsigned  int value_bit_15: 1;
	   } val_in_bits;
		
	} signed_val;
	
} value_types;

typedef enum 
{  
   DISP_UNSIGN_NUM_DIGIT1 = 0x01, DISP_UNSIGN_NUM_DIGIT2, DISP_UNSIGN_NUM_DIGIT3, DISP_UNSIGN_NUM_DIGIT4, DISP_UNSIGN_NUM_DIGIT5,\
   DISP_SIGN_NUM_DIGIT1 = 0x11, DISP_SIGN_NUM_DIGIT2, DISP_SIGN_NUM_DIGIT3, DISP_SIGN_NUM_DIGIT4, DISP_SIGN_NUM_DIGIT5,\
   DISP_HEX_DIGIT1 = 0x21, DISP_HEX_DIGIT2, DISP_HEX_DIGIT3, DISP_HEX_DIGIT4 
} disp_num_types;

char lcd_avail_loc_within_limit = STATE_YES;
unsigned int cur_disp_lcd_loc = BEGIN_LOC_LINE1, cur_input_lcd_loc = BEGIN_LOC_LINE2;
unsigned int read_command;

/* -------------------- public prototype declaration --------------------------------------- */
void Delay_Time_By_Count(unsigned long int delay_time_in_count);
void LCD_Write_Pulse();
void LCD_Read_Pulse();
void Write_LCD_Command_NO_BF(const unsigned int lcd_cmd);
void Write_LCD_Command(const unsigned int lcd_cmd);
void Write_LCD_Data(const char lcd_disp_ch);
void Data_Str_Disp_LCD(const char *lcd_disp_str);
void Data_Num_Disp_LCD(const disp_num_types lcd_datanum_disp_format, const value_types lcd_disp_data_int);
void Goto_XY_LCD_Disp(const unsigned int start_line_num, const unsigned int start_col_num);
void Goto_XY_LCD_Input(unsigned int start_line_num, unsigned int start_col_num);
void From_Loc_to_XY_LCD(const unsigned int loc_lcd, unsigned int * const loc_lcd_line_num, unsigned int * const loc_lcd_col_num );
void From_XY_To_Loc_LCD(const unsigned int start_line_num, const unsigned int start_col_num, unsigned int * const lcd_loc);
void LCD_Init();
void Check_LCD_Busy();
unsigned int Read_LCD_Command();
void LCD_Clear_Screen();
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void main()
{
          char unit_ch = '0', tens_ch = '0';
          int loc = 0;
		  value_types cur_num;
		  
          TRISD =  0x00; 
          TRISE = 0x00;
       
          ANSEL = 0x00;
          ANSELH = 0x00;
          LCD_Init();

		  Goto_XY_LCD_Disp(NUM_LINE1,NUM_COL1);
		  Data_Str_Disp_LCD("Number");
		
          for(;;)
          {
              for(cur_num.signed_val.value_long = -12; cur_num.signed_val.value_long < 100; ++cur_num.signed_val.value_long )
              {
				   Goto_XY_LCD_Disp(NUM_LINE2, NUM_COL1);
				   Data_Num_Disp_LCD(DISP_SIGN_NUM_DIGIT5, cur_num );
				   __delay_ms(1000);
				   __delay_ms(1000);
			  }   
      
           }
        }
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void LCD_Init()
{
	/* wait for more than 15ms after LCD VSS rises to 4.5V, Busy Flag in LCD (BF) cannot be checked */
	__delay_ms(1500);
    Write_LCD_Command_NO_BF(0x30);
	/* wait for more than 4.1 ms, Busy Flag in LCD (BF) cannot be checked */
	__delay_ms(10);
    Write_LCD_Command_NO_BF(0x30);
	/* wait for more than 100 us, Busy Flag in LCD (BF) cannot be checked */
	__delay_ms(1);
    Write_LCD_Command_NO_BF(0x30);
	__delay_ms(1);
	Write_LCD_Command(0x38);
	LCD_Clear_Screen();
	Write_LCD_Command(0x06);  
	Write_LCD_Command(0x0E);
} 
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void LCD_Clear_Screen()
{
	Write_LCD_Command(0x01);
	__delay_us(LCD_CLEAR_EXEC_IN_USEC);
}
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void LCD_Write_Pulse()
{
    EN_PIN = 1;
    __delay_ms(LCD_WRITE_ENABLE_PULSE_IN_USEC);
    EN_PIN = 0;
    __delay_ms(LCD_WRITE_ENABLE_PULSE_IN_USEC);
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void LCD_Read_Pulse()
{
    EN_PIN = 0;
    __delay_ms(LCD_WRITE_ENABLE_PULSE_IN_USEC);
    EN_PIN = 1;
    __delay_ms(LCD_WRITE_ENABLE_PULSE_IN_USEC);
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void Write_LCD_Command_NO_BF(const unsigned int lcd_cmd)
{
   
   RW_PIN = 0;
   RS_PIN = 0;
   
   __delay_us(LCD_ADDR_SETUP_IN_USEC);   
    EN_PIN = 1;
    __delay_us(LCD_ENABLE_PULSE_BEFORE_WRITE_IN_USEC);
	LCD_PORT = lcd_cmd;
	__delay_us(LCD_DATA_SETUP_IN_USEC);
    EN_PIN = 0;
    //SHOULD_REMOVE
    //Transmit_UART(LCD_PORT);
    __delay_us(LCD_OTHER_INST_EXEC_IN_USEC);    
     
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void Write_LCD_Command(const unsigned int lcd_cmd)
{
     
  // Check_LCD_Busy(); 
   RW_PIN = 0;
   RS_PIN = 0;
   
   __delay_us(LCD_ADDR_SETUP_IN_USEC);   
    EN_PIN = 1;
    __delay_us(LCD_ENABLE_PULSE_BEFORE_WRITE_IN_USEC);
	LCD_PORT = lcd_cmd;
	__delay_us(LCD_DATA_SETUP_IN_USEC);
    EN_PIN = 0;
    //SHOULD_REMOVE
    //Transmit_UART(LCD_PORT);
    __delay_us(LCD_OTHER_INST_EXEC_IN_USEC); 	
	
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
 void Write_LCD_Data(const char lcd_data)
{
	
	// Check_LCD_Busy();
	 RW_PIN = 0;
     RS_PIN = 1;
	
	__delay_us(LCD_ADDR_SETUP_IN_USEC);   
    EN_PIN = 1;
    __delay_us(LCD_ENABLE_PULSE_BEFORE_WRITE_IN_USEC);
	LCD_PORT = lcd_data;
	__delay_us(LCD_DATA_SETUP_IN_USEC);
    EN_PIN = 0;
	
    //SHOULD_REMOVE
    //Transmit_UART(LCD_PORT);
    __delay_us(LCD_OTHER_INST_EXEC_IN_USEC); 	
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void Check_LCD_Busy()
{
	/* LCD_PORT_GPIO = 0xFF;
	LCD_PORT = 0x00; */
	RW_PIN = 1;
    RS_PIN = 0; 
	
    /* busy flag = Bit 7 in LCD PORT, if busy flag == 1, wait till busy flag = 0, then any operation on LCD can be done */
   while((read_command = Read_LCD_Command()) & 0x80)
   {
	   LCD_Read_Pulse();
	   LCD_Read_Pulse();
	   EN_PIN = 0;
	   __delay_ms(LCD_WRITE_ENABLE_PULSE_IN_USEC);
   }	   
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void Delay_Time_By_Count(unsigned long int time_delay)
{
     while(time_delay--);
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
unsigned int Read_LCD_Command()
{
	 LCD_Write_Pulse();
	 read_command  = LCD_PORT;
	 return read_command;
}


/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 25   
-*------------------------------------------------------------*/

void Data_Str_Disp_LCD(const char *char_ptr)
{ 
       char cur_char;
	   
	   Write_LCD_Command(cur_disp_lcd_loc);
       while(*char_ptr)
       {
		    cur_char = *(char_ptr++);
            Write_LCD_Data(cur_char);
		//	Transmit_UART(cur_char);
       }
	  // Transmit_UART('\r');     
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 26  
-*------------------------------------------------------------*/
 void Data_Num_Disp_LCD(const disp_num_types lcd_datanum_disp_format, const value_types lcd_disp_data_int)
{
    unsigned int tens_thousand_digit,thousands_digit, hundreds_digit,tens_digit, unit_digit;
	unsigned long disp_num, num ;
	char num_data[] ={'0','1','2','3','4','5','6','7','8','9'};  
	char hex_data[] ={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'}; 
	unsigned int disp_num_format;
	
	Write_LCD_Command(cur_disp_lcd_loc);
	if(lcd_datanum_disp_format & 0x10 ) //signed lcd_datanum_disp_format
	{
		if(lcd_disp_data_int.signed_val.value_long < 0 )
		{
			Write_LCD_Data('-');
			disp_num = -lcd_disp_data_int.signed_val.value_long;
		}
        else
		{
			Write_LCD_Data('+');
			disp_num = lcd_disp_data_int.signed_val.value_long;
		}
        
	}
	else
	{
    	disp_num = lcd_disp_data_int.unsigned_val.value_long; 
	}
	num =  disp_num ;
	
    switch(lcd_datanum_disp_format)
	{
	  case DISP_UNSIGN_NUM_DIGIT5:
	  case DISP_SIGN_NUM_DIGIT5:  
		  num =  disp_num ;
		  tens_thousand_digit = (unsigned int)(num / (unsigned long)(10000UL));
          Write_LCD_Data(num_data[tens_thousand_digit]);
	  case DISP_UNSIGN_NUM_DIGIT4:
	  case DISP_SIGN_NUM_DIGIT4: 
	      num = disp_num % 10000UL;
	      thousands_digit = (unsigned int)(num / (unsigned long)(1000UL));
	      Write_LCD_Data(num_data[thousands_digit]); 
	  case DISP_UNSIGN_NUM_DIGIT3:
	  case DISP_SIGN_NUM_DIGIT3:
		  num = disp_num % 1000UL;
	      hundreds_digit = (unsigned int) (num / (unsigned long) (100));
	      Write_LCD_Data(num_data[hundreds_digit]);
	  case DISP_UNSIGN_NUM_DIGIT2:
	  case DISP_SIGN_NUM_DIGIT2:
          num = disp_num % 100;
          tens_digit = (unsigned int) (num / 10);
          Write_LCD_Data(num_data[tens_digit]); 		  
	  case DISP_UNSIGN_NUM_DIGIT1:
	  case DISP_SIGN_NUM_DIGIT1:
	     unit_digit = (unsigned int) (disp_num % 10);
         Write_LCD_Data(num_data[unit_digit]); 
	  break;
	  case DISP_HEX_DIGIT4:
	      //  ( 16 * 16 * 16 *16 )  = 0 as divide by zero warning 
	      //num = disp_num % ( 16 * 16 * 16 *16 );
          thousands_digit = (num / (unsigned long) (16 * 16 * 16));
	      Write_LCD_Data(hex_data[thousands_digit]);
	  case DISP_HEX_DIGIT3:
	      num = disp_num %(unsigned long)(16 * 16 * 16);
	      hundreds_digit = (unsigned int) (num / (unsigned long) (16 * 16));
	      Write_LCD_Data(hex_data[hundreds_digit]);
	  case DISP_HEX_DIGIT2:
	      num = disp_num %(unsigned long)(16 * 16);
          tens_digit = (unsigned int) (num / 16);
          Write_LCD_Data(hex_data[tens_digit]);
	  case DISP_HEX_DIGIT1: 
	      unit_digit = (unsigned int) (disp_num % 16);
          Write_LCD_Data(hex_data[unit_digit]);    
	  break;
	  
	}   	
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 28  
-*------------------------------------------------------------*/
/* make sure that loc are within avail lcd loc limit */
void Set_Cur_Loc_LCD(const char set_input_loc_flag,const unsigned int set_input_loc, const char set_disp_loc_flag, const unsigned int set_disp_loc)
{
   if(set_input_loc_flag == STATE_YES)  
     cur_input_lcd_loc = set_input_loc;
   if(set_disp_loc_flag == STATE_YES)
     cur_disp_lcd_loc = set_disp_loc; 
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 29   
-*------------------------------------------------------------*/
void Goto_XY_LCD_Disp(const unsigned int start_line_num, const unsigned int start_col_num)
{
	/* max 4 lines and 20 columns */
	/* for us, lcd line starts from 1, but for uC, line starts from 0 */
	/* for us, lcd col starts from 1, but for uC, col starts from 0 */
    unsigned int start_line_lcd = start_line_num - 1, start_col_lcd = start_col_num - 1, error_disp_start_loc; 
	lcd_avail_loc_within_limit = STATE_YES;
	
   if(start_line_num <= CONFIGURE_MAX_NUM_LINES && start_col_num <= CONFIGURE_MAX_NUM_COLS )
   {
      switch(start_line_num)
	 {
		 case NUM_LINE1:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE1;
		   break;
		 case NUM_LINE2:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE2;
		   break;
		 case NUM_LINE3:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE3;
		   break;
		  case NUM_LINE4:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE4;
		   break;		 
	 }	
      cur_disp_lcd_loc = cur_disp_lcd_loc + start_col_lcd;            
   }
   else
   {
	   /* error due to invalid lcd DISP loc  */
	     lcd_avail_loc_within_limit = STATE_NO;	
   }	   
} 
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 30   
-*------------------------------------------------------------*/ 
void Goto_XY_LCD_Input(unsigned int start_line_num,unsigned int start_col_num)
{
	/* for us, lcd line starts from 1, but for uC, line starts from 0 */
	/* for us, lcd col starts from 1, but for uC, col starts from 0 */
    unsigned int start_line_lcd = start_line_num - 1, start_col_lcd = start_col_num - 1; 
	
	/* max 4 lines and 20 columns */
	lcd_avail_loc_within_limit = STATE_YES;
	if( start_line_num <= CONFIGURE_MAX_NUM_LINES &&  start_col_num <= CONFIGURE_MAX_NUM_COLS )
   {
     switch(start_line_num)
	 {
		 case NUM_LINE1:
		   cur_input_lcd_loc = BEGIN_LOC_LINE1;
		   break;
		 case NUM_LINE2:
		   cur_input_lcd_loc = BEGIN_LOC_LINE2;
		   break;
		 case NUM_LINE3:
		   cur_input_lcd_loc = BEGIN_LOC_LINE3;
		   break;
		  case NUM_LINE4:
		   cur_input_lcd_loc = BEGIN_LOC_LINE4;
		   break; 		  
	 }
	 cur_input_lcd_loc = cur_input_lcd_loc + start_col_lcd;
     Write_LCD_Command(cur_input_lcd_loc); 	 	   
  }
  else
  {
	   /* error due to invalid Lcd loc  */	
	   lcd_avail_loc_within_limit = STATE_NO;
  }	  
} 

 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 31   
-*------------------------------------------------------------*/
void From_XY_To_Loc_LCD(const unsigned int start_line_num, const unsigned int start_col_num, unsigned int * const lcd_loc)
{
	/* max 4 lines and 20 columns */
	   
	lcd_avail_loc_within_limit = STATE_YES;
	
   if(start_line_num <= CONFIGURE_MAX_NUM_LINES && start_col_num <= CONFIGURE_MAX_NUM_COLS )
   {
      switch(start_line_num)
	 {
		 case NUM_LINE1:
		   *lcd_loc = BEGIN_LOC_LINE1;
		   break;
		 case NUM_LINE2:
		   *lcd_loc = BEGIN_LOC_LINE2;
		   break;
		 case NUM_LINE3:
		   *lcd_loc= BEGIN_LOC_LINE3;
		   break;
		  case NUM_LINE4:
		  *lcd_loc = BEGIN_LOC_LINE4;
		   break;		 
	 }	
      *lcd_loc = *lcd_loc + start_col_num - 1;           
   }
   else
   {
	    lcd_avail_loc_within_limit = STATE_NO;
		/* error: due to loc_lcd's line num > max configured line nums */	
		 
	   		
   }	   
} 
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void From_Loc_to_XY_LCD(const unsigned int loc_lcd, unsigned int * const loc_lcd_line_num, unsigned int * const loc_lcd_col_num  )
{
	/* loc_lcd's corresponding line num and col num */
	
	lcd_avail_loc_within_limit = STATE_YES;
	
	if(CONFIGURE_MAX_NUM_LINES <= MAX_AVAIL_NUM_LINES)
	{	
    	if(loc_lcd >= BEGIN_LOC_LINE1 && loc_lcd <= END_LOC_LINE1)
	    {
		     *loc_lcd_line_num = NUM_LINE1;
	         *loc_lcd_col_num = loc_lcd + 1 - BEGIN_LOC_LINE1;		    
	    }
       if(loc_lcd >= BEGIN_LOC_LINE2 && loc_lcd <= END_LOC_LINE2)
	   {
	     	*loc_lcd_line_num = NUM_LINE2;
		    *loc_lcd_col_num = loc_lcd + 1 - BEGIN_LOC_LINE2; 		
	   }     
	   if(loc_lcd >= BEGIN_LOC_LINE3 && loc_lcd <= END_LOC_LINE3)
	   {
		   	*loc_lcd_line_num = NUM_LINE3;
		  	*loc_lcd_col_num = loc_lcd + 1 - BEGIN_LOC_LINE3;			
	   }
       if(loc_lcd >= BEGIN_LOC_LINE4 && loc_lcd <= END_LOC_LINE4)
	   {
		  	*loc_lcd_line_num = NUM_LINE4;
		   	*loc_lcd_col_num = loc_lcd + 1 - BEGIN_LOC_LINE4;				
	   }	  
   } 
   else
   {
	   /* error: configured max lines > 4 */
	   
   }      
}

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
