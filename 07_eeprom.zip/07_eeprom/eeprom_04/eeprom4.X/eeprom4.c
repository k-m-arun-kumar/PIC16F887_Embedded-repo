/* ********************************************************************
FILE                   : eeprom4.c

PROGRAM DESCRIPTION    :  A varible num of digits of a number is  fed by keypad and then ENTER_SW is pressed. Enter_SW terminates input
 and last digit entered is saved in EEPROM. When power reboots occurs after just after ENTER_SW was pressed,
 and when DISP_SW is pressed, last digit fed by keypad is displayed

AUTHOR                : K.M.Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : to check  for power off and then power on simulation in proteus ( press button - stop simulation,
  then press button - advanced simulation by one frame )and then press button - run simulation 
                                  
                       
CHANGE LOGS           : 

*****************************************************************************/  

//#define HI_TECH_COMPILER
#ifdef HI_TECH_COMPILER
  #include <pic.h>
  __CONFIG(0x2CE4);
#else // XC8 compiler
  #include <xc.h>
#endif
#include <string.h>
#define KEY_PRESSED                              (1) 
#define KEY_NOT_PRESSED                          (0)
#define STATE_YES                                 'y'
#define STATE_NO                                  'n'

#define MAX_ROW_KEYPAD                         4
#define MAX_COL_KEYPAD                         3
#define  KEYPAD_PHONE_COL1                    RB0
#define  KEYPAD_PHONE_COL2                    RB1
#define  KEYPAD_PHONE_COL3                    RB2
#define  KEYPAD_PHONE_ROWA                    RB3
#define  KEYPAD_PHONE_ROWB                    RB4
#define  KEYPAD_PHONE_ROWC                    RB5
#define  KEYPAD_PHONE_ROWD                    RB6

#define RS_PIN                                 RD0
#define RW_PIN                                 RD1
#define EN_PIN                                 RD2
#define LCD_PORT                              PORTC

#define ENTER_SW                               RA0
#define BACKSPACE_SW                           RA1 
#define DISP_SW                                RA2
#define RESET_SW                               RA3                                                     


#define DISP_FLAG_NUM_DIGIT1                   (1)
#define DISP_FLAG_NUM_DIGIT2                   (2)
#define DISP_FLAG_NUM_DIGIT3                   (3)
#define DISP_FLAG_NUM_DIGIT4                   (4)
#define DISP_FLAG_NUM_DIGIT5                   (5)
#define DISP_FLAG_HEX_DIGIT1                   (6)
#define DISP_FLAG_HEX_DIGIT2                   (7)
#define DISP_FLAG_HEX_DIGIT3                   (8)
#define DISP_FLAG_HEX_DIGIT4                   (9) 

/* for 20 * 4 LCD disp */                             
#define BEGIN_LOC_LINE1                      (0X80)
#define BEGIN_LOC_LINE2                      (0xC0)
#define BEGIN_LOC_LINE3                      (0x94) 
#define BEGIN_LOC_LINE4                      (0xD4)
#define END_LOC_LINE1                        (0x93)
#define END_LOC_LINE2                        (0xD3)
#define END_LOC_LINE3                        (0xA7) 
#define END_LOC_LINE4                        (0xE7)

/* num cols = num of chars in a line */
#define MAX_COUNT_DELAY_TIME_LCDPULSE     (1000U)
#define MAX_AVAIL_NUM_COLS                    (20)
#define CONFIGURE_MAX_NUM_LINES               (4)
#define MAX_AVAIL_NUM_LINES                   (4) 
#define MAX_AVAIL_NUM_CHARS_IN_LCD        (MAX_AVAIL_NUM_COLS * MAX_AVAIL_NUM_LINES) 
#define CONFIGURE_MAX_NUM_COLS             (MAX_AVAIL_NUM_COLS)
#define CONFIGURE_MAX_NUM_CHARS_IN_LCD    (CONFIGURE_MAX_NUM_LINES * CONFIGURE_MAX_NUM_COLS ) 
#define MAX_NUM_CHARS_INPUT_DATA          (MAX_AVAIL_NUM_COLS)  
#define ASCII_CODE_ZERO_CHAR              (0x30u)

#define INVALID_DATA              (0)
#define ALL_LINES                  (0)
#define NUM_LINE1                  (1)
#define NUM_LINE2                  (2)
#define NUM_LINE3                  (3)
#define NUM_LINE4                  (4)
#define NUM_COL1                   (1)

#define ENTER_NUM_MSG_LINE_NUM     (NUM_LINE1)
#define ENTER_NUM_LINE_NUM         (NUM_LINE2)
#define SAVED_LAST_DIGIT_LINE_NUM  (NUM_LINE3)
#define SAVED_LAST_DIGIT_COL_NUM   (NUM_COL1 + 11)       
#define EEPROM_LAST_DIGIT_ADDR    (0x00)

void Delay_Time_ByCount(unsigned int Delay_Time_Count_count);
void LCD_Init();
void LCD_Pulse ();
void Write_LCD_Command (const unsigned int Write_LCD_Command);
void Write_LCD_Data(const char lcd_disp_ch);
void Data_Str_Disp_LCD(const char *lcd_disp_str);
void Data_Num_Disp_LCD(const unsigned int lcd_datanum_disp_format, const unsigned long lcd_disp_data_int);
void LCD_Const_Disp();
void Datas_LCD_Disp();
void Goto_XY_LCD_Disp(const unsigned int start_line_num, const unsigned int start_col_num);
void Goto_XY_LCD_Input(const unsigned int start_line_num, const unsigned int start_col_num);
void From_Loc_to_XY_LCD(const unsigned int loc_lcd, unsigned int * const loc_lcd_line_num, unsigned int * const loc_lcd_col_num );
void From_XY_To_Loc_LCD(const unsigned int start_line_num, const unsigned int start_col_num, unsigned int * const lcd_loc);

void Get_Entered_Key_No_Long_Press(const char cur_pressed_key);
void Entered_Backspace_Sw_No_Long_Press_Proc();
void Is_Numchars_Within_Limit();
void Retrieve_EEPROM_Datas();

unsigned int cur_disp_lcd_loc = BEGIN_LOC_LINE1, cur_input_lcd_loc = BEGIN_LOC_LINE2, num_chars_entered_cur_data = 0; 
char entered_cur_input_data[MAX_NUM_CHARS_INPUT_DATA + 1], cur_pressed_key = '\0';

char key_or_sw_input_enable_flag = STATE_YES, max_input_num_chars_flag = STATE_NO, need_input_flag = STATE_YES, reset_sw_enable_flag = STATE_YES,\
 enter_sw_enable_flag = STATE_NO, backspace_sw_enable_flag = STATE_NO, disp_sw_enable_flag = STATE_NO, keypad_keys_enable_flag = STATE_YES, \
 lcd_avail_loc_within_limit = STATE_YES, cur_data_can_also_input_nonnum_key = STATE_NO ;
 
unsigned int saved_last_digit, retrieved_last_digit; 
void Reset_Process()
{
	memset(entered_cur_input_data, '\0', sizeof(entered_cur_input_data)/sizeof(char));
    num_chars_entered_cur_data = 0; 
	need_input_flag = STATE_YES; 
	key_or_sw_input_enable_flag =STATE_YES;
	reset_sw_enable_flag = STATE_NO;
    enter_sw_enable_flag = STATE_NO;
    backspace_sw_enable_flag = STATE_NO;
    disp_sw_enable_flag = STATE_NO;
    keypad_keys_enable_flag = STATE_YES;
	lcd_avail_loc_within_limit = STATE_YES;
	if(retrieved_last_digit != 0)
    	eeprom_write(EEPROM_LAST_DIGIT_ADDR, 0);
	retrieved_last_digit = 0;
	cur_input_lcd_loc = BEGIN_LOC_LINE2;
	Write_LCD_Command(0x01); //clear display
    Write_LCD_Command(0x0E); // display on , cursor and blinking OFF
	LCD_Const_Disp();
    Datas_LCD_Disp();
}	
/*------------------------------------------------------------*
FUNCTION NAME  : main

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 1   
-*------------------------------------------------------------*/

void main()
{    
      char keypad_char[]   = {'1','2', '3', '4', '5', '6','7','8','9','*', '0', '#'};	  
      TRISA = 0x0F;
      PORTA = 0x00;
	  TRISB = 0x07;
	  PORTB = 0x00;
      TRISC = 0x00;
      PORTC = 0x00;
      TRISD  = 0x00;
       PORTD = 0x00;
       TRISE = 0x00;
       PORTE = 0x00;
       ANSEL = 0x00;
       ANSELH = 0x00;
       LCD_Init();
	   LCD_Const_Disp();
	   Retrieve_EEPROM_Datas();
	   Datas_LCD_Disp();
       
       for(;;)
       {  
          if(key_or_sw_input_enable_flag == STATE_YES)
          { 
              Is_Numchars_Within_Limit();  
			  
	          KEYPAD_PHONE_ROWA = 1;
              KEYPAD_PHONE_ROWB  = 0;
              KEYPAD_PHONE_ROWC  = 0;
              KEYPAD_PHONE_ROWD  = 0; 
              if(KEYPAD_PHONE_COL1 == KEY_PRESSED)
              {
		         cur_pressed_key = keypad_char[0];//latest pressed key
                 				 
		         if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                 {
				     while(KEYPAD_PHONE_COL1 ==KEY_PRESSED);
					 Get_Entered_Key_No_Long_Press(cur_pressed_key); 		            		  
                 }
			  }	 
              if(KEYPAD_PHONE_COL2 == KEY_PRESSED)
              {
		           cur_pressed_key = keypad_char[1];//latest pressed key
				   if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                   {
		             	 while(KEYPAD_PHONE_COL2 ==KEY_PRESSED);
		                Get_Entered_Key_No_Long_Press(cur_pressed_key); 				
		           } 		  
              } 
              if(KEYPAD_PHONE_COL3 == KEY_PRESSED)
              {
	        	   cur_pressed_key = keypad_char[2];//latest pressed key				
	        	   if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                   {
		               while(KEYPAD_PHONE_COL3 ==KEY_PRESSED);
		               Get_Entered_Key_No_Long_Press(cur_pressed_key); 		
		           } 		  
              } 
              KEYPAD_PHONE_ROWA = 0;
              KEYPAD_PHONE_ROWB  = 1;
              KEYPAD_PHONE_ROWC  = 0;
              KEYPAD_PHONE_ROWD  = 0; 
              if(KEYPAD_PHONE_COL1 == KEY_PRESSED)
              {
		           cur_pressed_key = keypad_char[3];//latest pressed key				  
		           if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                   {		            	 
                      while(KEYPAD_PHONE_COL1 ==KEY_PRESSED);
		              Get_Entered_Key_No_Long_Press(cur_pressed_key); 			               					
		           } 		  
              } 
              if(KEYPAD_PHONE_COL2 == KEY_PRESSED)
              {
	       	       cur_pressed_key = keypad_char[4];//latest pressed key				  
                   if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                   {		              	 
                       while(KEYPAD_PHONE_COL2 ==KEY_PRESSED);
		               Get_Entered_Key_No_Long_Press(cur_pressed_key); 
		           } 		  
              } 
              if(KEYPAD_PHONE_COL3 == KEY_PRESSED)
              {
	           	  cur_pressed_key = keypad_char[5];//latest pressed key				  
	          	  if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                  {		            	  
                      while(KEYPAD_PHONE_COL3 ==KEY_PRESSED);
                      Get_Entered_Key_No_Long_Press(cur_pressed_key); 		            	    						
		           } 		  
              }  
               KEYPAD_PHONE_ROWA = 0;
               KEYPAD_PHONE_ROWB  = 0;
               KEYPAD_PHONE_ROWC  = 1;
               KEYPAD_PHONE_ROWD  = 0; 
               if(KEYPAD_PHONE_COL1 == KEY_PRESSED)
               {
	           	  cur_pressed_key = keypad_char[6];//latest pressed key
				  if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                  {
		           	 while(KEYPAD_PHONE_COL1 ==KEY_PRESSED);
		             Get_Entered_Key_No_Long_Press(cur_pressed_key); 		             	   				
		           } 		  
               } 
               if(KEYPAD_PHONE_COL2 == KEY_PRESSED)
               {
	              cur_pressed_key = keypad_char[7];//latest pressed key/switch					 
	              if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                  {	            		 
                      while(KEYPAD_PHONE_COL2 ==KEY_PRESSED);
	                  Get_Entered_Key_No_Long_Press(cur_pressed_key); 	            		    				
	              } 		  
               } 
               if(KEYPAD_PHONE_COL3 == KEY_PRESSED)
               {
	               cur_pressed_key = keypad_char[8];//latest pressed key
	          	   if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                   {
	        	   	 while(KEYPAD_PHONE_COL3 ==KEY_PRESSED);
	         	     Get_Entered_Key_No_Long_Press(cur_pressed_key);
				   }
               } 
               KEYPAD_PHONE_ROWA = 0;
               KEYPAD_PHONE_ROWB  = 0;
               KEYPAD_PHONE_ROWC  = 0;
               KEYPAD_PHONE_ROWD  = 1; 
               if(KEYPAD_PHONE_COL1 == KEY_PRESSED)
               {
	              cur_pressed_key = keypad_char[9];//latest pressed key					   
	              if(keypad_keys_enable_flag == STATE_YES && cur_data_can_also_input_nonnum_key == STATE_YES&& max_input_num_chars_flag ==STATE_NO )
                  {	            		
                      while(KEYPAD_PHONE_COL1 ==KEY_PRESSED);
		              Get_Entered_Key_No_Long_Press(cur_pressed_key);			
		          } 		  
               } 
               if(KEYPAD_PHONE_COL2 == KEY_PRESSED)
               {
		            cur_pressed_key = keypad_char[10];//latest pressed key						
		            if(keypad_keys_enable_flag == STATE_YES && max_input_num_chars_flag ==STATE_NO)
                    {
		             	  while(KEYPAD_PHONE_COL2 ==KEY_PRESSED);
		                  Get_Entered_Key_No_Long_Press(cur_pressed_key);			
		             } 		  
               }                                               
               if(KEYPAD_PHONE_COL3 == KEY_PRESSED)
               {
	           	   cur_pressed_key = keypad_char[11];//latest pressed key						  
	          	   if(keypad_keys_enable_flag == STATE_YES && cur_data_can_also_input_nonnum_key == STATE_YES && max_input_num_chars_flag ==STATE_NO )
                    {	                  		 
                        while(KEYPAD_PHONE_COL3 ==KEY_PRESSED);
		                 Get_Entered_Key_No_Long_Press(cur_pressed_key);					
		            } 		  
                }    
                if(ENTER_SW == KEY_PRESSED)
                {
	               	 if(enter_sw_enable_flag == STATE_YES)
				     {	                   	    
	                    max_input_num_chars_flag = STATE_NO;								
                         while(ENTER_SW == KEY_PRESSED );
					  /* PROCESS FOR ENTER SW */
                         if(num_chars_entered_cur_data > 0)
				         {
			                 entered_cur_input_data[num_chars_entered_cur_data] = '\0';
				             backspace_sw_enable_flag = STATE_NO;
				             reset_sw_enable_flag = STATE_NO; 
				             enter_sw_enable_flag = STATE_NO;
                             backspace_sw_enable_flag = STATE_NO;
						     keypad_keys_enable_flag = STATE_NO;
							 disp_sw_enable_flag = STATE_YES; 
                             saved_last_digit = cur_pressed_key - ASCII_CODE_ZERO_CHAR;	
							 if(retrieved_last_digit != saved_last_digit)
							 {								 
                                 eeprom_write(EEPROM_LAST_DIGIT_ADDR, saved_last_digit);
                                 retrieved_last_digit = saved_last_digit;								 
							 }
							 Datas_LCD_Disp();						 
							 
							 memset(entered_cur_input_data, '\0', sizeof(entered_cur_input_data)/sizeof(char));
                             num_chars_entered_cur_data = 0; 
				          }                                         		 
                       }
				  }							 
                  if(BACKSPACE_SW ==KEY_PRESSED )		 
                  {                            
					  if(backspace_sw_enable_flag == STATE_YES)
					  {						        
                          while(BACKSPACE_SW == KEY_PRESSED ); 
	                      /* Process for valid Backspace */
			              if(num_chars_entered_cur_data > 0)
			               {
                                Entered_Backspace_Sw_No_Long_Press_Proc();			  
                           } 					  
                        }
				   }		 
                   if(DISP_SW ==KEY_PRESSED )		 
                   {
                       if(disp_sw_enable_flag == STATE_YES)
					   {
                           while(DISP_SW == KEY_PRESSED ); 
                           reset_sw_enable_flag = STATE_YES;                           
                           Datas_LCD_Disp();						   
                       }					  
                    }
					if(RESET_SW ==KEY_PRESSED )
                    {
	                     if(reset_sw_enable_flag == STATE_YES)
					      {	  
	                          while(RESET_SW == KEY_PRESSED ); 
	                          Reset_Process();
					      }							
                    }	
              }                    
                   	
        } 
  }	    

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 10  
-*------------------------------------------------------------*/
void Is_Numchars_Within_Limit()
{
 	/* num char < valid char as when num chars <= max valid, and num char == max valid, then you can entry key and 
	and num char  =  max valid + 1, now you cannot input key */	
	   
	if(num_chars_entered_cur_data < MAX_NUM_CHARS_INPUT_DATA)
        max_input_num_chars_flag = STATE_NO;
     else
	 {
        max_input_num_chars_flag = STATE_YES; 
		/* warning:  num of input data chars has reached max num of chars allocated for cur input data  */
     } 
    	 
}

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 11  
-*------------------------------------------------------------*/
void Get_Entered_Key_No_Long_Press(const char key_data)
{
	/* make sure that entered key is within max available lcd loc and line, currently cur_data_input_max_num_chars_allocated 
	 sures that entered key is within max available lcd loc and within max line */
	 unsigned int cur_input_loc_line_num, cur_input_loc_col_num, next_input_loc_line_num, next_input_loc_col_num;
	
     Write_LCD_Command(cur_input_lcd_loc);
     Write_LCD_Data(key_data);	 
	 Write_LCD_Command(0x0E);// insert cursor on at cur_input_lcd_loc
	     
	 From_Loc_to_XY_LCD(cur_input_lcd_loc, &cur_input_loc_line_num, &cur_input_loc_col_num);
	 if(cur_input_loc_line_num == CONFIGURE_MAX_NUM_LINES && cur_input_loc_col_num == CONFIGURE_MAX_NUM_COLS)
	 {	 
		/* reached  end of max configured line and valid key is pressed, retain same loc position */ 		
	 }
	 else
	 {
		 /* put cur input lcd loc to next location */
		 if(cur_input_loc_col_num == CONFIGURE_MAX_NUM_COLS)
		 {	 
			next_input_loc_line_num = cur_input_loc_line_num + 1;
			next_input_loc_col_num = NUM_COL1;
		 }
         else
         {
			 next_input_loc_line_num = cur_input_loc_line_num;
			 next_input_loc_col_num = cur_input_loc_col_num + 1;
		 }	
		 From_XY_To_Loc_LCD(next_input_loc_line_num, next_input_loc_col_num, &cur_input_lcd_loc);
		 
        entered_cur_input_data[num_chars_entered_cur_data] =key_data;   
        ++num_chars_entered_cur_data; 	 
           		
	 }   		 
	  /* keep track of cur_input_lcd_loc as baskspace we need to -- it and also disp timeouts with.
 	  LCD automatically increments due to loc_command(0x06)in our case as after eg Write_LCD_Command(0x80)
	  ie set DDRAM */      
      enter_sw_enable_flag = STATE_YES;
      backspace_sw_enable_flag = STATE_YES;
} 
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 12   
-*------------------------------------------------------------*/
void Entered_Backspace_Sw_No_Long_Press_Proc()
{
	unsigned int cur_input_loc_line_num, cur_input_loc_col_num, previous_input_loc_line_num, previous_input_loc_col_num;
	
	lcd_avail_loc_within_limit = STATE_YES;	
       	
    if(num_chars_entered_cur_data > 0 && num_chars_entered_cur_data <= MAX_NUM_CHARS_INPUT_DATA )
    {
	    From_Loc_to_XY_LCD(cur_input_lcd_loc, &cur_input_loc_line_num, &cur_input_loc_col_num);
	   if(cur_input_loc_line_num == NUM_LINE1 && cur_input_loc_col_num == NUM_COL1)
	   {	 
		 /* reached begin of line 1 and valid backspace is pressed, retain same loc position */ 
	   }
	   else
	   {
		 /* put cur input lcd loc to one location back from current loc */
		 if(cur_input_loc_col_num == NUM_COL1)
		 {	 
			 previous_input_loc_line_num = cur_input_loc_line_num - 1;
			 previous_input_loc_col_num = CONFIGURE_MAX_NUM_COLS;
		 }
         else
         {
			 previous_input_loc_line_num = cur_input_loc_line_num;
			 previous_input_loc_col_num = cur_input_loc_col_num - 1;
		 }	
		 From_XY_To_Loc_LCD(previous_input_loc_line_num, previous_input_loc_col_num, &cur_input_lcd_loc);
		 
         /* do clear last char operation */
		 entered_cur_input_data[num_chars_entered_cur_data] = '\0'; 
		  /* to get key at previous location */
         Write_LCD_Command(cur_input_lcd_loc);
         --num_chars_entered_cur_data;
         Write_LCD_Data(' '); 
         Write_LCD_Command(0x10); //shift cursor to left  	 
           		
	  }  
	  Write_LCD_Command(cur_input_lcd_loc);
      Write_LCD_Command(0x0E);	
   }
} 
void Retrieve_EEPROM_Datas()
{
	retrieved_last_digit =  eeprom_read(EEPROM_LAST_DIGIT_ADDR);
}
void LCD_Const_Disp()
{
	const char enter_num_msg_disp[] = " Enter Num:", retrieve_last_digit_msg_disp[] = "Last Digit:";
	Goto_XY_LCD_Disp(ENTER_NUM_MSG_LINE_NUM, NUM_COL1);
	Data_Str_Disp_LCD(enter_num_msg_disp);
	Goto_XY_LCD_Disp(SAVED_LAST_DIGIT_LINE_NUM, NUM_COL1);
	Data_Str_Disp_LCD(retrieve_last_digit_msg_disp);	
}
void Datas_LCD_Disp()
{
	Goto_XY_LCD_Disp(SAVED_LAST_DIGIT_LINE_NUM, SAVED_LAST_DIGIT_COL_NUM);	
	Data_Num_Disp_LCD(DISP_FLAG_NUM_DIGIT1, retrieved_last_digit);
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 21   
-*------------------------------------------------------------*/
void LCD_Init()
{
    Write_LCD_Command(0x30);
    Write_LCD_Command(0x30);
    Write_LCD_Command(0x30);
    Write_LCD_Command(0x38);
    Write_LCD_Command(0x01);
    Write_LCD_Command(0x0E); //insert cursor on at cur_input_lcd_loc
	//Write_LCD_Command(0x0C);
    Write_LCD_Command(0x06);                                       
}     

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 23   
-*------------------------------------------------------------*/
  void Write_LCD_Command (unsigned int cmd)
  {
	  unsigned long int  time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	  
       RW_PIN = 0;
       RS_PIN = 0; 
       LCD_PORT = cmd;
      // LCD_Pulse();
	  EN_PIN = 1;
	  while(time_delay--);
    // Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);
      EN_PIN = 0;
	  time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	  while(time_delay--);
   //  Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);
 }
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 24   
-*------------------------------------------------------------*/
 void Write_LCD_Data(const char ch)
{
	unsigned long int  time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	// performance degraded if many data is written to LCD, to check if write loc is within avail disp loc
	// if(lcd_avail_loc_within_limit == STATE_YES) 
	{	
      RW_PIN = 0;
      RS_PIN = 1;
      LCD_PORT =ch;
     // LCD_Pulse();
      EN_PIN = 1;
	  while(time_delay--);
    // Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);
     EN_PIN = 0;
	 time_delay = MAX_COUNT_DELAY_TIME_LCDPULSE;
	  while(time_delay--);
   //  Delay_Time_ByCount(MAX_COUNT_DELAY_TIME_LCDPULSE);	 
	}
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 25   
-*------------------------------------------------------------*/

void Data_Str_Disp_LCD(const char *char_ptr)
{ 
       while(*char_ptr)
       {
            Write_LCD_Data(*(char_ptr++));
       }
     
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 27  
-*------------------------------------------------------------*/
void Delay_Time_ByCount( unsigned int time_delay)
{
       while(time_delay--);
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 26  
-*------------------------------------------------------------*/
void Data_Num_Disp_LCD(const unsigned int lcd_datanum_disp_format, const unsigned long lcd_disp_data_int)
{
    unsigned int tens_thousand_digit,thousands_digit, hundreds_digit,tens_digit, unit_digit;
    unsigned long num = lcd_disp_data_int;
    char num_data[] ={'0','1','2','3','4','5','6','7','8','9'};  
	char hex_data[] ={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'}; 
    switch(lcd_datanum_disp_format)
	{
	  case DISP_FLAG_NUM_DIGIT5: 
		  num =  lcd_disp_data_int % 100000;
		  tens_thousand_digit = (unsigned int)(num / (unsigned long)(10000));
          Write_LCD_Data(num_data[tens_thousand_digit]);
	  case DISP_FLAG_NUM_DIGIT4:
	      num = lcd_disp_data_int % 10000;
	      thousands_digit = (unsigned int)(num / (unsigned long)(1000));
	      Write_LCD_Data(num_data[thousands_digit]); 
	  case DISP_FLAG_NUM_DIGIT3: 
		  num = lcd_disp_data_int % 1000;
	      hundreds_digit = (unsigned int) (num / (unsigned long) (100));
	      Write_LCD_Data(num_data[hundreds_digit]);
	  case DISP_FLAG_NUM_DIGIT2:
          num = lcd_disp_data_int % 100;
          tens_digit = (unsigned int) (num / 10);
          Write_LCD_Data(num_data[tens_digit]); 		  
	  case DISP_FLAG_NUM_DIGIT1:
	     unit_digit = (unsigned int) (lcd_disp_data_int % 10);
         Write_LCD_Data(num_data[unit_digit]); 
	  break;
	  case DISP_FLAG_HEX_DIGIT4:
	      /*  ( 16 * 16 * 16 *16 )  = 0 as divide by zero warning */
	      //num = lcd_disp_data_int % ( 16 * 16 * 16 *16 );
          thousands_digit = (num / (16 * 16 * 16));
	      Write_LCD_Data(hex_data[thousands_digit]);
	  case DISP_FLAG_HEX_DIGIT3:
	      num = lcd_disp_data_int %(unsigned long)(16 * 16 * 16);
	      hundreds_digit = (unsigned int) (num / (unsigned long) (16 * 16));
	      Write_LCD_Data(hex_data[hundreds_digit]);
	  case DISP_FLAG_HEX_DIGIT2:
	      num = lcd_disp_data_int %(unsigned long)(16 * 16);
          tens_digit = (unsigned int) (num / 16);
          Write_LCD_Data(hex_data[tens_digit]);
	  case DISP_FLAG_HEX_DIGIT1: 
	      unit_digit = (unsigned int) (lcd_disp_data_int % 16);
          Write_LCD_Data(hex_data[unit_digit]);    
	  break;
	  default:
	       /* Warning invalid lcd_disp flag */
	    ;
	}   	
}
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 29   
-*------------------------------------------------------------*/
void Goto_XY_LCD_Disp(const unsigned int start_line_num, const unsigned int start_col_num)
{
	/* max 4 lines and 20 columns */
	/* for us, lcd line starts from 1, but for uC, line starts from 0 */
	/* for us, lcd col starts from 1, but for uC, col starts from 0 */
    unsigned int start_line_lcd = start_line_num - 1, start_col_lcd = start_col_num - 1, error_disp_start_loc; 
	lcd_avail_loc_within_limit = STATE_YES;
	
   if(start_line_num <= CONFIGURE_MAX_NUM_LINES && start_col_num <= CONFIGURE_MAX_NUM_COLS )
   {
      switch(start_line_num)
	 {
		 case NUM_LINE1:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE1;
		   break;
		 case NUM_LINE2:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE2;
		   break;
		 case NUM_LINE3:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE3;
		   break;
		  case NUM_LINE4:
		   cur_disp_lcd_loc = BEGIN_LOC_LINE4;
		   break;		 
	 }	
      cur_disp_lcd_loc = cur_disp_lcd_loc + start_col_lcd;
      Write_LCD_Command(cur_disp_lcd_loc);       
   }
   else
   {
	   /* error due to invalid lcd DISP loc  */
	     lcd_avail_loc_within_limit = STATE_NO;		
		       		
   }	   
} 
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 30   
-*------------------------------------------------------------*/ 
void Goto_XY_LCD_Input(unsigned int start_line_num,unsigned int start_col_num)
{
	/* for us, lcd line starts from 1, but for uC, line starts from 0 */
	/* for us, lcd col starts from 1, but for uC, col starts from 0 */
    unsigned int start_line_lcd = start_line_num - 1, start_col_lcd = start_col_num - 1; 
	
	/* max 4 lines and 20 columns */
	lcd_avail_loc_within_limit = STATE_YES;
	if( start_line_num <= CONFIGURE_MAX_NUM_LINES &&  start_col_num <= CONFIGURE_MAX_NUM_COLS )
   {
     switch(start_line_num)
	 {
		 case NUM_LINE1:
		   cur_input_lcd_loc = BEGIN_LOC_LINE1;
		   break;
		 case NUM_LINE2:
		   cur_input_lcd_loc = BEGIN_LOC_LINE2;
		   break;
		 case NUM_LINE3:
		   cur_input_lcd_loc = BEGIN_LOC_LINE3;
		   break;
		  case NUM_LINE4:
		   cur_input_lcd_loc = BEGIN_LOC_LINE4;
		   break; 		  
	 }
	 cur_input_lcd_loc = cur_input_lcd_loc + start_col_lcd;
     Write_LCD_Command(cur_input_lcd_loc); 	 	   
  }
  else
  {
	   /* error due to invalid Lcd loc  */	
	   lcd_avail_loc_within_limit = STATE_NO;
	  	  
  }	  
} 
 /*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 31   
-*------------------------------------------------------------*/
void From_XY_To_Loc_LCD(const unsigned int start_line_num, const unsigned int start_col_num, unsigned int * const lcd_loc)
{
	/* max 4 lines and 20 columns */
	   
	lcd_avail_loc_within_limit = STATE_YES;
	
   if(start_line_num <= CONFIGURE_MAX_NUM_LINES && start_col_num <= CONFIGURE_MAX_NUM_COLS )
   {
      switch(start_line_num)
	 {
		 case NUM_LINE1:
		   *lcd_loc = BEGIN_LOC_LINE1;
		   break;
		 case NUM_LINE2:
		   *lcd_loc = BEGIN_LOC_LINE2;
		   break;
		 case NUM_LINE3:
		   *lcd_loc= BEGIN_LOC_LINE3;
		   break;
		  case NUM_LINE4:
		  *lcd_loc = BEGIN_LOC_LINE4;
		   break;		 
	 }	
      *lcd_loc = *lcd_loc + start_col_num - 1;           
   }
   else
   {
	    lcd_avail_loc_within_limit = STATE_NO;
		/* error: due to loc_lcd's line num > max configured line nums */			 
	   		
   }	   
} 
/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 32   
-*------------------------------------------------------------*/
void From_Loc_to_XY_LCD(const unsigned int loc_lcd, unsigned int * const loc_lcd_line_num, unsigned int * const loc_lcd_col_num  )
{
	/* loc_lcd's corrosponding line num and col num */
	
	lcd_avail_loc_within_limit = STATE_YES;
	
	if(CONFIGURE_MAX_NUM_LINES <= MAX_AVAIL_NUM_LINES)
	{	
    	if(loc_lcd >= BEGIN_LOC_LINE1 && loc_lcd <= END_LOC_LINE1)
	    {
		     *loc_lcd_line_num = NUM_LINE1;
	         *loc_lcd_col_num = loc_lcd + 1 - BEGIN_LOC_LINE1;		    
	    }
       if(loc_lcd >= BEGIN_LOC_LINE2 && loc_lcd <= END_LOC_LINE2)
	   {
	     	*loc_lcd_line_num = NUM_LINE2;
		    *loc_lcd_col_num = loc_lcd + 1 - BEGIN_LOC_LINE2; 		
	   }     
	   if(loc_lcd >= BEGIN_LOC_LINE3 && loc_lcd <= END_LOC_LINE3)
	   {
		   	*loc_lcd_line_num = NUM_LINE3;
		  	*loc_lcd_col_num = loc_lcd + 1 - BEGIN_LOC_LINE3;			
	   }
       if(loc_lcd >= BEGIN_LOC_LINE4 && loc_lcd <= END_LOC_LINE4)
	   {
		  	*loc_lcd_line_num = NUM_LINE4;
		   	*loc_lcd_col_num = loc_lcd + 1 - BEGIN_LOC_LINE4;				
	   }	  
   } 
   else
   {
	   /* error: configured max lines > 4 */
	   
   }      
}
